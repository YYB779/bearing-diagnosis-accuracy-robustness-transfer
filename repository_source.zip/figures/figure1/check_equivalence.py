from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
HERE=Path(__file__).resolve().parent
prior=HERE.parents[2]/'统一稿_MSSP风格/presubmission_audit_20261121/figure_production/figure1'
guard=json.loads((HERE/'exports/Figure_01_data_guard.json').read_text(encoding='utf-8'))
old=json.loads((HERE/'baseline/Figure_01_validation.json').read_text(encoding='utf-8'))
assert (guard['segments'],guard['intervals'],guard['proxies'],guard['states'])==(101,404,79,33)
assert guard['HUST_support']==old['HUST_support']
assert guard['Paderborn_bearings']==old['Paderborn_bearings']
frozen=HERE/'baseline/input_hashes.json'
if not frozen.exists():
    frozen.write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((prior/'inputs').glob('*'))},indent=2),encoding='utf-8')
assert json.loads(frozen.read_text(encoding='utf-8'))==guard['source_sha256']
psd=pd.read_csv(HERE/'inputs/novic_example_psd.csv')
f=psd.frequency_hz.to_numpy();p=psd.psd_g2_per_hz.to_numpy()
bins=np.minimum((f/100).astype(int),127)
v=np.bincount(bins,weights=p)/np.bincount(bins)
np.testing.assert_array_equal(10*np.log10(v/v.max()),guard['spectrum_relative_db'])
result={'passed':True,'original_input_hashes_match':True,'counts_and_support_match':True,
        'paderborn_ids_roles_classes_match':True,'all_128_psd_band_values_exact':True,
        'rendered_collision_fail':0,'rendered_collision_warn':0,
        'static_warning_review':{'EXPORT-RASTER':'PDF is the vector submission figure; 450 dpi PNG companion supplied.',
            'FINAL-WIDTH':'Width explicitly W=174/25.4*72 pt; manuscript insertion173mm.',
            'LOG-GUARD':'An explicit all-positive guard on band precedes log10.'}}
(HERE/'exports/data_equivalence.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
for name in ['source_validation.json','Figure_01_text.json']:
    p=HERE/'exports'/name
    raw=p.read_bytes()
    try:s=raw.decode('utf-16') if raw[:2] in [b'\xff\xfe',b'\xfe\xff'] else raw.decode('utf-8-sig')
    except UnicodeDecodeError:s=raw.decode('gb18030')
    data=json.loads(s);p.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(result))
