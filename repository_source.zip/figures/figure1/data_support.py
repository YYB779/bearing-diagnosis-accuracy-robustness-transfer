"""Validate the three cohorts used in the study design figure."""
import pandas as pd

def dataset(data):
    seg=pd.read_csv(data/"novic_segments.csv")
    intervals=pd.read_csv(data/"novic_intervals.csv")
    assert seg.array_row.is_unique and (seg.duration_s==4).all()
    assert intervals.sample_id.is_unique and (intervals.actual_turns==8).all()
    assert set(seg.array_row)==set(intervals.array_row)
    assert (intervals.groupby("array_row").size()==4).all()
    proxies=seg[["state","inferred_source_group"]].drop_duplicates()
    assert proxies.inferred_source_group.is_unique
    counts=proxies.groupby("state").size().value_counts().sort_index()
    assert (len(seg),len(intervals),len(proxies),sum(counts))==(101,404,79,33)
    assert sum(counts.index.to_numpy()*counts.to_numpy())==len(proxies)
    hust=pd.read_csv(data/"hust_support.csv")
    cols=["20Hz","30Hz","40Hz","60Hz",next(c for c in hust.condition.unique() if c not in {"20Hz","30Hz","40Hz","60Hz"})]
    rows=[("H","healthy"),("I","medium"),("I","severe"),("O","medium"),("O","severe")]
    support=hust.pivot(index=["class_name","severity"],columns="condition",values="value").loc[rows,cols].astype(int)
    assert len(hust)==25 and set(support.to_numpy().ravel())=={0,1}
    assert support.to_numpy().sum()==21
    roster=pd.read_csv(data/"paderborn_roster.csv")
    distinct=roster[["class_id","role","bearing_id"]].drop_duplicates()
    assert len(distinct)==distinct.bearing_id.nunique()==18
    assert (distinct.groupby(["role","class_id"]).size()==3).all()
    assert (roster.groupby("bearing_id").condition.nunique()==4).all()
    return seg,intervals,proxies,counts,support,distinct
