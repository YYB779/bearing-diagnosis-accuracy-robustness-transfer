"""Three evaluation layers, rebuilt from frozen cohort and measured-spectrum data.

Run: python draw_figure1_v3.py
No external photographs, generated measurements or new analyses are used.
"""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch, Polygon, Circle
from matplotlib.lines import Line2D
from matplotlib.text import Text
from data_support import dataset
from bearing_vector import draw_bearing

ROOT=Path(__file__).resolve().parent
W,H=174/25.4*72,555
INK='#173F59'; NAVY='#275F8F'; EDGE='#62737E'
BLUE='#D8EAF3'; ROSE='#F5DDDA'; LAV='#E9E1F0'; SAGE='#E0ECDA'; AMBER='#FAEBD0'

def draw(out,qa_tools):
    out.mkdir(exist_ok=True,parents=True)
    seg,intervals,proxies,counts,support,roster=dataset(ROOT/'inputs')
    psd=pd.read_csv(ROOT/'inputs/novic_example_psd.csv')
    f=psd.frequency_hz.to_numpy(); p=psd.psd_g2_per_hz.to_numpy()
    assert len(f)==51201 and np.allclose(np.diff(f),.25) and (p>=0).all()
    bins=np.minimum((f/100).astype(int),127)
    band=np.bincount(bins,weights=p)/np.bincount(bins)
    assert np.all(band>0)
    rel=10*np.log10(band/band.max())
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],
        'font.size':9,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
        'svg.hashsalt':'evaluation-layers-v3','text.color':INK,'figure.facecolor':'white'})
    fig=plt.figure(figsize=(W/72,H/72))
    ax=fig.add_axes([0,0,1,1],xlim=(0,W),ylim=(H,0)); ax.set_axis_off()
    def text(x,y,s,size=9,weight='normal',color=INK,ha='left'):
        return ax.text(x,y,s,fontsize=size,fontweight=weight,color=color,ha=ha,va='center',linespacing=1.15,zorder=9)
    def line(points,color=EDGE,lw=1.1,**kw):
        ax.plot(*zip(*points),color=color,lw=lw,solid_capstyle='butt',zorder=3,**kw)
    def arrow(x,y,u,v,color=INK):
        ax.annotate('',xy=(u,v),xytext=(x,y),arrowprops=dict(arrowstyle='-|>',lw=1.15,color=color,mutation_scale=9,shrinkA=0,shrinkB=0),zorder=5)
    def box(x,y,w,h,fill,edge=EDGE,depth=0):
        if depth:
            ax.add_patch(Polygon([(x,y),(x+depth,y-depth),(x+w+depth,y-depth),(x+w,y)],facecolor='#F9FBFC',edgecolor=edge,lw=1.1,zorder=2))
            ax.add_patch(Polygon([(x+w,y),(x+w+depth,y-depth),(x+w+depth,y+h-depth),(x+w,y+h)],facecolor=fill,edgecolor=edge,lw=1.1,zorder=2))
        ax.add_patch(Rectangle((x,y),w,h,facecolor=fill,edgecolor=edge,lw=1.1,zorder=2))
    def module(y,h,label,title,right):
        line([(17,y),(8,y),(8,y+h),(W-8,y+h),(W-8,y),(W-17,y)],color=EDGE,lw=1.1,linestyle=(0,(5,3)))
        ax.add_patch(FancyBboxPatch((19,y-10),W-38,22,boxstyle='round,pad=0,rounding_size=3',facecolor=NAVY,edgecolor='white',lw=1.1,zorder=6))
        text(29,y+1,label+'   '+title,11.1,'bold','white')
        text(W-29,y+1,right,8.6,'normal','white','right')
    def note(y,s):
        text(W/2,y,s,8.2,color=EDGE,ha='center')

    # A: physically specified signal intervals nest within recording proxies and states.
    module(20,154,'a','NOVIC+','State holdout')
    text(88,50,'Measured signal',9.5,'bold',ha='center')
    text(229,50,'Four intervals / segment',9.5,'bold',ha='center')
    text(409,50,'Two fault-presence tasks',9.5,'bold',ha='center')
    x0,x1,y0,y1=36,140,74,112
    x=x0+(np.arange(128)+.5)/128*(x1-x0)
    yy=y1-(np.maximum(rel,-50)+50)/50*(y1-y0)
    ax.fill_between(x,yy,y1,color=BLUE,edgecolor='none',linewidth=0,zorder=2)
    ax.plot(x,yy,color=NAVY,lw=1.15,zorder=4)
    line([(x0,y0),(x0,y1),(x1,y1)])
    text(x0-5,y0,'0',8.1,ha='right');text(x0-5,y1,'−50',8.1,ha='right')
    text(x0,y1+9,'0',8.1,ha='center');text(x1,y1+9,'12.8 kHz',8.1,ha='right')
    text(88,65,'Relative PSD (dB)',8.1,ha='center')
    text(88,143,'101 four-second segments',9,'bold',ha='center')
    arrow(149,90,172,90)
    for j,c in enumerate([ROSE,BLUE,SAGE,LAV]):
        xx=181+26*j
        box(xx,79,22,27,c,depth=4)
        text(xx+11,92.5,'8',9.5,'bold',ha='center')
    text(229,116,'404 eight-turn intervals',9,'bold',ha='center')
    arrow(229,125,229,132)
    box(176,135,106,21,BLUE)
    text(229,145.5,'79 recording proxies',8.8,'bold',ha='center')
    line([(286,145.5),(308,145.5),(308,74.5)])
    arrow(308,74.5,334,74.5)
    box(338,63,133,23,LAV)
    text(404.5,74.5,'33 joint states',9.4,'bold',ha='center')
    line([(404.5,89),(404.5,94),(328,94),(328,146)])
    box(338,101,133,22,ROSE)
    text(404.5,112,'Inner-race presence',9,ha='center')
    box(338,135,133,22,BLUE)
    text(404.5,146,'Outer-race presence',9,ha='center')
    arrow(328,112,335,112);arrow(328,146,335,146)
    note(166,'Physical bearing identities are unavailable; recording proxies are the scoring units.')

    # B: an orthographic bearing cue, observed support, and two sequential evaluation stages.
    module(201,149,'b','HUSTbearing','Speed holdout → disturbance tests')
    text(57,232,'Bearing',9.4,'bold',ha='center')
    draw_bearing(ax,57,271,64)
    text(57,311,'Schematic',8.3,ha='center')
    text(214,232,'Motor command (Hz)',9.5,'bold',ha='center')
    cx=[210,233,256,279,302]
    for u,s in zip(cx,['20','30','40','60','VS']):text(u,249,s,8.5,ha='center')
    labels=['Healthy','Inner, mod.','Inner, sev.','Outer, mod.','Outer, sev.']
    for i,(lab,c) in enumerate(zip(labels,[SAGE,ROSE,ROSE,BLUE,BLUE])):
        yy=265+13*i
        ax.add_patch(Rectangle((111,yy-6),204,12,facecolor=c,edgecolor='none',zorder=2))
        text(115,yy,lab,8.4)
        for j,u in enumerate(cx):
            if support.iloc[i,j]:ax.add_patch(Circle((u,yy),2.4,facecolor=NAVY,edgecolor='none',zorder=4))
            else:line([(u-2.4,yy),(u+2.4,yy)],lw=1.1)
    box(341,248,128,30,LAV,depth=4)
    text(405,263,'Hold out one speed',9.2,'bold',ha='center')
    line([(319,278),(330,278),(330,263)]);arrow(330,263,338,263)
    arrow(405,283,405,296)
    box(341,300,128,29,AMBER,depth=4)
    text(405,314.5,'Synthetic disturbances',9.1,'bold',ha='center')
    text(211,337,'21 acquisitions · VS = variable speed',8.4,'bold',ha='center')
    note(361,'Each state reuses its bearing across speeds; disturbances reuse the held-out files.')

    # C: independent target-side roster and two separate training paths to the identical test panel.
    module(389,157,'c','Paderborn','Independent bearing holdout')
    text(92,418,'Development bearings (9)',9.4,'bold',ha='center')
    text(253,418,'Training regime',9.4,'bold',ha='center')
    text(407,418,'Same test bearings (9)',9.4,'bold',ha='center')
    def roster_block(left,role):
        for i,(lab,c) in enumerate(zip(['Healthy','Inner','Outer'],[SAGE,ROSE,BLUE])):
            y=431+18*i
            box(left,y,148,18,c,edge='white')
            text(left+4,y+9,lab,8.3)
            ids=sorted(roster.loc[(roster.class_id==i)&(roster.role==role),'bearing_id'])
            for xx,s in zip([left+68,left+99,left+130],ids):text(xx,y+9,s,8.3,ha='center')
    roster_block(18,'development');roster_block(327,'test')
    box(199,437,105,36,BLUE,depth=4)
    text(251.5,455,'Paderborn-trained\ncontrols',9.4,'bold',ha='center')
    arrow(170,455,195,455);arrow(312,455,321,455)
    line([(327,431),(324,431),(324,485),(327,485)])
    for i,c in enumerate([BLUE,LAV,BLUE]):box(24+i*4,506-i*4,19,14,c)
    text(58,507,'HUST source models',8.7,'bold')
    text(58,521,'Five folds per seed',8.3)
    box(199,497,105,29,LAV,depth=4)
    text(251.5,511.5,'Frozen ensemble',9.3,'bold',ha='center')
    arrow(170,511,195,511)
    line([(312,511),(316,511),(316,478)]);arrow(316,478,321,478)
    text(401,506,'Four operating conditions',8.6,ha='center')
    text(401,520,'per bearing',8.6,ha='center')
    note(538,'Three bearings per class; manufacturer and health status are confounded in the test cohort.')

    # Normalized display-only stroke floor, never numeric data transformations.
    for obj in fig.findobj():
        if isinstance(obj,Line2D) and 0<obj.get_linewidth()<1.1:obj.set_linewidth(1.1)
        elif hasattr(obj,'get_linewidth') and hasattr(obj,'set_linewidth'):
            try:
                width=obj.get_linewidth()
                if np.isscalar(width) and 0<width<1.1:obj.set_linewidth(1.1)
            except (TypeError,ValueError):pass
    from public_optional_alignment import configure_qa, require_matplotlib_panel_alignment
    configure_qa(qa_tools)
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig,axes=[ax],panel_ids=['three-layer schematic'],json_out=out/'Figure_01_alignment.json',strict=True)
    fig.savefig(out/'Figure_01.pdf',dpi=450,metadata={'Title':'Evaluation units across three datasets','CreationDate':None})
    fig.savefig(out/'Figure_01.svg',metadata={'Date':None})
    fig.savefig(out/'Figure_01.png',dpi=450)
    from PIL import Image
    with Image.open(out/'Figure_01.png') as im:
        im.thumbnail((1350,1550))
        im.save(out/'Figure_01_preview.png')
    plt.close(fig)
    guard=dict(segments=len(seg),intervals=len(intervals),proxies=len(proxies),states=int(counts.sum()),
        spectrum_bins=len(p),spectrum_band_count=len(rel),spectrum_relative_db=rel.tolist(),
        HUST_support=support.to_numpy().tolist(),Paderborn_bearings=roster.sort_values(['role','class_id','bearing_id']).to_dict('records'),
        source_sha256={x.name:hashlib.sha256(x.read_bytes()).hexdigest() for x in sorted((ROOT/'inputs').glob('*'))})
    (out/'Figure_01_data_guard.json').write_text(json.dumps(guard,indent=2),encoding='utf-8')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,default=ROOT/'exports')
    p.add_argument('--qa-tools',type=Path,default=ROOT/'qa_tools');a=p.parse_args();draw(a.out,a.qa_tools)
