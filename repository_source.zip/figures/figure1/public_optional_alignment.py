"""Absent external QA is reported as SKIPPED, never passed."""
import importlib.util,json
from pathlib import Path
_checker=None
def configure_qa(directory):
 global _checker
 _checker=None
 f=Path(directory)/'audit_panel_alignment.py'
 if f.is_file():
  spec=importlib.util.spec_from_file_location('external_alignment',f)
  m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  _checker=m.require_matplotlib_panel_alignment
def require_matplotlib_panel_alignment(fig,*,axes,panel_ids,json_out,**kwargs):
 if _checker is not None:return _checker(fig,axes=axes,panel_ids=panel_ids,json_out=json_out,**kwargs)
 report={'status':'SKIPPED','passed':None,'reason':'External layout-audit tools are not redistributed; export is not a new alignment validation.','panel_ids':panel_ids,'axes_count':len(axes)}
 Path(json_out).parent.mkdir(parents=True,exist_ok=True)
 Path(json_out).write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
 return report
