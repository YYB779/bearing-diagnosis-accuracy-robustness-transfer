"""Front-view vector schematic of a rolling-element bearing.

The study-design panel is small in the typeset manuscript, so this cue uses
an engineering front view. Concentric raceways, a regular ball circle, and a
clear bore remain legible after single-column reduction without perspective
skew or raster shading.
"""
import numpy as np
from matplotlib.patches import Circle, Wedge


def draw_bearing(ax, cx, cy, size):
    """Draw a clean, front-facing bearing centred at ``(cx, cy)``."""
    r = float(size) * 0.46
    outline = "#355A6D"
    outer_face = "#D5E4EA"
    race_face = "#8AA8B5"
    inner_face = "#C7D9E0"

    # A quiet lower rim gives the icon a little depth while retaining a true
    # front view. It is deliberately offset by only one pixel.
    ax.add_patch(Circle((cx + 1.0, cy + 1.1), r, facecolor="#B8CBD4",
                        edgecolor="none", linewidth=0, zorder=1))
    ax.add_patch(Circle((cx, cy), r, facecolor=outer_face,
                        edgecolor=outline, linewidth=1.15, zorder=2))
    ax.add_patch(Circle((cx, cy), r * 0.87, facecolor="#EEF4F6",
                        edgecolor="#6D8996", linewidth=0.85, zorder=3))

    # Outer and inner raceways are layered annuli. The balls sit between them.
    ax.add_patch(Circle((cx, cy), r * 0.70, facecolor=race_face,
                        edgecolor=outline, linewidth=0.85, zorder=4))
    ax.add_patch(Circle((cx, cy), r * 0.53, facecolor=inner_face,
                        edgecolor=outline, linewidth=0.8, zorder=5))

    # Eight evenly spaced rolling elements. A very small offset highlight is
    # retained for print legibility and does not change the circular geometry.
    ball_radius = r * 0.105
    ball_circle = r * 0.615
    for angle in np.linspace(0, 2 * np.pi, 8, endpoint=False) + np.pi / 8:
        bx = cx + ball_circle * np.cos(angle)
        by = cy + ball_circle * np.sin(angle)
        ax.add_patch(Circle((bx, by), ball_radius, facecolor="#EAF2F4",
                            edgecolor=outline, linewidth=0.75, zorder=7))
        ax.add_patch(Circle((bx - ball_radius * 0.22,
                             by - ball_radius * 0.22), ball_radius * 0.22,
                            facecolor="white", edgecolor="none", zorder=8))

    # Inner race and open bore. The bore is pure white so it reads as a hole
    # rather than as another shaded component when the figure is reduced.
    ax.add_patch(Circle((cx, cy), r * 0.40, facecolor="#91AFBA",
                        edgecolor=outline, linewidth=0.85, zorder=9))
    ax.add_patch(Circle((cx, cy), r * 0.255, facecolor="white",
                        edgecolor=outline, linewidth=1.0, zorder=10))

    # Two restrained arc accents distinguish the front face without implying
    # an oblique or cylindrical perspective.
    ax.add_patch(Wedge((cx, cy), r * 0.87, 208, 326, width=r * 0.025,
                       facecolor="#FFFFFF", edgecolor="none", zorder=11))
    ax.add_patch(Wedge((cx, cy), r * 0.40, 28, 146, width=r * 0.025,
                       facecolor="#DDEAEF", edgecolor="none", zorder=11))
