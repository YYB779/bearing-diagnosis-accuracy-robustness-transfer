"""Reference-led evidence composites from frozen manuscript source tables.

Run: python render_main_v3.py
All points and intervals are retained. Method ribbons are schematic protocol facts.
"""
from pathlib import Path
import argparse, hashlib, json, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, Rectangle, Polygon, FancyArrowPatch
from matplotlib.colors import LinearSegmentedColormap, ListedColormap
from matplotlib.ticker import MaxNLocator
import numpy as np
import pandas as pd

HERE=Path(__file__).resolve().parent
NAVY='#275F8F'; INK='#173F59'; MUTED='#556570'; GRID='#E1E7EB'
PALES=['#D8EAF3','#F5DDDA','#E9E1F0','#E0ECDA','#FAEBD0']
BLUE='#287DB1'; CORAL='#BD6651'; GREEN='#4A887E'; PURPLE='#8571AD'
SEEDS=[11,22,33]; MARKS=['o','s','^']
TESTS=['clean','AWGN0dB','AWGN-4dB','colored-4dB','impulse-4dB','tone-4dB']
TN=['Clean','White Gaussian, 0 dB','White Gaussian, −4 dB','Colored noise, −4 dB','Sparse impulses, −4 dB','Sinusoid, −4 dB']
ARMS=['clean_ce','awgn_ce','response_ce','response_jsd']
AN=['Clean CE','Gaussian CE','Response CE','Response JSD']
EXCL=['awgn','colored','impulse','tone']; EN=['White Gaussian','Colored noise','Sparse impulses','Sinusoid']
GUARD={}; ALIGN=None

def read(name): return pd.read_csv(HERE/'inputs'/name)
def setup():
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],
       'font.size':8,'axes.labelsize':8,'xtick.labelsize':8,'ytick.labelsize':8,
       'axes.linewidth':1.1,'patch.linewidth':1.1,'xtick.major.width':1.1,'ytick.major.width':1.1,
       'text.color':INK,'axes.labelcolor':INK,'axes.edgecolor':MUTED,
       'xtick.color':INK,'ytick.color':INK,'axes.spines.top':False,'axes.spines.right':False,
       'legend.frameon':False,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
       'figure.facecolor':'white','savefig.facecolor':'white','svg.hashsalt':'bearing-main-v3'})

def text(fig,x,y,s,size=8,ha='left',weight='normal',color=INK,**kwargs):
    return fig.text(x,y,s,fontsize=size,ha=ha,va='center',fontweight=weight,color=color,**kwargs)

def card(fig,x,y,w,h,face='white',dash=True,z=-10):
    p=Rectangle((x,y),w,h,transform=fig.transFigure,facecolor=face,edgecolor=MUTED,
      linewidth=1.1,linestyle=(0,(4,3)) if dash else '-',zorder=z)
    fig.add_artist(p);return p

def banner(fig,x,y,w,label):
    h=5.8/(fig.get_figheight()*25.4)
    p=FancyBboxPatch((x,y-h/2),w,h,boxstyle='round,pad=0.001,rounding_size=0.005',
      transform=fig.transFigure,facecolor=NAVY,edgecolor=NAVY,linewidth=1.1,zorder=20)
    fig.add_artist(p);text(fig,x+.009,y,label,8.7,weight='bold',color='white',zorder=21)

def ribbon(fig,steps):
    # The layered blocks are protocol cartoons, not tensors or empirical measurements.
    n=len(steps); gap=.038; x=.023; w=(.954-gap*(n-1))/n; y=.934; h=.052
    for k,lab in enumerate(steps):
        xx=x+k*(w+gap)
        fig.add_artist(Polygon([(xx,y+h),(xx+.008,y+h+.007),(xx+w+.008,y+h+.007),(xx+w,y+h)],
           transform=fig.transFigure,facecolor='white',edgecolor=MUTED,lw=1.1,zorder=8))
        card(fig,xx,y,w,h,PALES[k%5],False,9)
        text(fig,xx+w/2,y+h/2,lab,8.4,ha='center',weight='bold',linespacing=1.2,zorder=11)
        if k<n-1:fig.add_artist(FancyArrowPatch((xx+w+.006,y+h/2),(xx+w+gap-.009,y+h/2),
            transform=fig.transFigure,arrowstyle='-|>',mutation_scale=10,lw=1.1,color=INK,zorder=10))

def footer(fig,s):
    card(fig,.023,.017,.954,.038,PALES[4],False,5)
    text(fig,.5,.036,s,8,ha='center',zorder=10)

def axnew(fig,rect):
    ax=fig.add_axes(rect);ax.set_facecolor('white');ax.set_axisbelow(True);return ax

def chart(ax,ys,labels=None):
    ax.spines['left'].set_visible(False)
    ax.set_yticks(ys,labels if labels is not None else ['']*len(ys))
    ax.set_ylim(max(ys)+.6,min(ys)-.6);ax.tick_params(axis='y',length=0,pad=5)
    ax.tick_params(axis='x',length=3,pad=4)
    ax.grid(axis='x',color=GRID,lw=1.1)
    for k,y in enumerate(ys):
        if k%2==0:ax.axhspan(y-.47,y+.47,color='#F3F7FA',zorder=0)

def scale01(ax):
    ax.set_xlim(-.035,1.035);ax.set_xticks([0,.25,.5,.75,1],['0','.25','.5','.75','1'])

def seedmarks(ax,q,y,color,col='value',off=0,hollow=False,spread=.105):
    vals=q.set_index('seed').loc[SEEDS,col].to_numpy()
    assert np.isfinite(vals).all()
    ax.plot([vals.min(),vals.max()],[y+off]*2,color=color,lw=1.1,zorder=2)
    for j,(m,v) in enumerate(zip(MARKS,vals)):
        ax.scatter(v,y+off+(j-1)*spread,s=19,marker=m,facecolor='white' if hollow else color,
                   edgecolor=color,lw=1.1,zorder=4)

def key(fig,kind,y=.889):
    if kind=='fault':items=[('Inner-fault presence','o',BLUE,True),('Outer-fault presence','^',CORAL,True)]
    else:
        lead={'metric':[('Macro-F1','o',BLUE,True),('Healthy recall','o',CORAL,False)],
              'timing':[('Nominal timing','o',BLUE,True),('HostService timing','o',CORAL,False)],
              'risk':[('ERM','o',BLUE,True),('Group DRO','o',CORAL,False)]}[kind]
        items=lead+[(f'Seed {s}',m,INK,True) for s,m in zip(SEEDS,MARKS)]
    handles=[Line2D([],[],marker=m,linestyle='',color=c,markerfacecolor=c if f else 'white',
       markeredgewidth=1.1,markersize=4.4,label=lab) for lab,m,c,f in items]
    fig.legend(handles=handles,loc='center',bbox_to_anchor=(.5,y),ncol=len(items),fontsize=8,
       columnspacing=1,handletextpad=.3)

def save(fig,num,axes):
    stem=f'Figure_{num:02d}';out=HERE/'exports';out.mkdir(exist_ok=True)
    fig.canvas.draw()
    ids=list('abcdef'[:len(axes)])
    rows={2:[['a','b'],['c','d']],3:[['a','b'],['c','d'],['e','f']],4:[],5:[ids],6:[['a','b'],['c','d']],7:[ids]}[num]
    cols={2:[['a','c'],['b','d']],3:[['a','c','e'],['b','d','f']],4:[ids],5:[],6:[],7:[]}[num]
    ALIGN(fig,axes=axes,panel_ids=ids,row_groups=rows,column_groups=cols,json_out=out/f'{stem}_alignment.json')
    check_rendered_values(num,axes)
    fig.savefig(out/f'{stem}.pdf',dpi=450,metadata={'Creator':'Matplotlib','CreationDate':None})
    fig.savefig(out/f'{stem}.svg',metadata={'Creator':'Matplotlib'})
    fig.savefig(out/f'{stem}.png',dpi=450)
    # The official PNG is 450 dpi; a separate preview utility makes screen thumbnails.
    plt.close(fig)

def check_rendered_values(num,axes):
    """Independently compare actual Matplotlib artists with frozen table values."""
    from matplotlib.collections import PathCollection, LineCollection
    actual=[float(x) for ax in axes for c in ax.collections if isinstance(c,PathCollection) for x in c.get_offsets()[:,0]]
    if num==2:
        d=read('fig_internal_controls.source_intervals.csv');expected=d.estimate.to_list()
        intervals=sorted((float(s[0,0]),float(s[1,0])) for ax in axes for c in ax.collections if isinstance(c,LineCollection) for s in c.get_segments())
        wanted=sorted(zip(d.low.astype(float),d.high.astype(float)))
        np.testing.assert_allclose(intervals,wanted,atol=0,rtol=0)
    elif num==3:expected=read('fig_same_patch_controls.source.csv').value.to_list()
    elif num==4:
        actual=[float(x) for ax in axes for im in ax.images for x in im.get_array().ravel()]
        expected=read('fig_historical_corruption_source.csv').value.to_list()
    elif num==5:expected=read('fig_excluded_corruptions_source.csv').value.to_list()
    elif num==6:
        d=read('fig_paderborn_specimens_points.csv');expected=d[['macro_f1','nll']].values.ravel().tolist()
        raw=read('fig_paderborn_specimens_bearing_predictions.csv');raw['recipe']=recipe(raw)
        for ax,tm in zip(axes[2:],['nominal','timestamp_sensitive']):
            q=raw[raw.timing==tm].copy();q['call']=q[['p_H','p_I','p_O']].to_numpy().argmax(axis=1)
            ix=pd.MultiIndex.from_product([['Native25 ET','Native25 LR','Shape25 ET','Shape25 LR'],SEEDS],names=['recipe','seed'])
            ids=['K004','K005','K006','KI16','KI18','KI21','KA15','KA16','KA30']
            calls=q.pivot(index=['recipe','seed'],columns='bearing_id',values='call').loc[ix,ids].to_numpy()
            truth=q.drop_duplicates('bearing_id').set_index('bearing_id').loc[ids,'class_id'].to_numpy()
            np.testing.assert_array_equal(ax.images[0].get_array(),calls==truth)
            actual_labels=[t.get_text() for t in ax.texts if t.get_text() in ['H','I','O']]
            assert actual_labels==['HIO'[v] for v in calls.ravel()]
    elif num==7:
        d=read('fig_zero_shot_source.csv').merge(read('healthy_ranking_cells.csv'),on=['cohort','excluded','arm','seed','timing'],validate='one_to_one')
        expected=d[['macro_f1','p_H_auc','nll']].values.ravel().tolist()
    np.testing.assert_allclose(sorted(actual),sorted(expected),rtol=0,atol=0)
    GUARD[f'Figure_{num:02d}'].update({'rendered_artist_values_verified':len(actual),'exact_equality_to_frozen_source':True,'sorted_float64_sha256':hashlib.sha256(np.asarray(sorted(actual),dtype='<f8').tobytes()).hexdigest()})

def fig2():
    d=read('fig_internal_controls.source_intervals.csv');summary=read('fig_internal_controls.source_all_seed_summaries.csv')
    assert len(d)==64 and len(summary)==96 and set(d.seed)=={11} and set(d.n_records)=={79} and set(d.n_states)=={33}
    reps=['metadata_only','native_fullband','time_envelope','time_envelope_meta','order_generic','order_generic_meta','order_geometry','mfos_repository']
    names=['Metadata (8)','Native full band (25)','Time envelope (111)','Time + metadata (119)','Order envelope (99)','Order + metadata (107)','Order + geometry (180)','Repository features (856)']
    models=[('extra_trees','Extra Trees'),('random_forest','Random forest'),('state_calibrated_svm','RBF SVM'),('logistic','Logistic regression')]
    fig=plt.figure(figsize=(174/25.4,182/25.4));ribbon(fig,['79 recording proxies','33 held-out states','Two fault-presence tasks']);key(fig,'fault')
    axes=[];plotted=[]
    for row in range(2):
        base=.494 if row==0 else .115
        card(fig,.023,base-.047,.954,.371)
        for col in range(2):
            j=row*2+col;model,title=models[j];x=.294 if col==0 else .664
            ax=axnew(fig,[x,base+.015,.288,.252]);axes.append(ax);chart(ax,range(8),names if col==0 else None);scale01(ax)
            ax.set_xlim(-.015,1.025);ax.set_ylim(7.5,-.5)
            banner(fig,x-.004,base+.304,.292,chr(97+j)+'  '+title)
            for task,off,c,m in [('inner_presence',-.16,BLUE,'o'),('outer_presence',.16,CORAL,'^')]:
                q=d[(d.model==model)&(d.task==task)].set_index('representation').loc[reps]
                assert (q.low<=q.estimate).all() and (q.estimate<=q.high).all()
                ax.hlines(np.arange(8)+off,q.low,q.high,color=c,lw=1.3)
                ax.scatter(q.estimate,np.arange(8)+off,marker=m,s=22,color=c,edgecolor='white',lw=1.1,zorder=4)
                plotted.extend(q[['estimate','low','high']].values.tolist())
            ax.set_xlabel('Held-state macro-F1')
    footer(fig,'Seed 11 · 2,000 state-cluster bootstrap draws · intervals conditional on fitted models')
    GUARD['Figure_02']={'estimates':len(plotted),'interval_endpoints':128,'all_source_rows_preserved':True,'summary_rows_packaged':96}
    save(fig,2,axes)

def fig3():
    d=read('fig_same_patch_controls.source.csv');assert len(d)==216
    methods=list(d.method.unique());names=['ET · Native25','LR · Native25','ET · Shape25','LR · Shape25','WDCNN · Clean','WDCNN · Gaussian']
    fig=plt.figure(figsize=(174/25.4,207/25.4));ribbon(fig,['32 identical patches / file','6 conventional / neural controls','21 held-out files']);key(fig,'metric',.898)
    axes=[]
    for i,(test,title) in enumerate(zip(TESTS,TN)):
        row,col=divmod(i,2);base=.668-row*.284;x=.222 if col==0 else .699
        card(fig,.023 if col==0 else .512,base-.041,.465,.263)
        ax=axnew(fig,[x,base,.249,.166]);axes.append(ax);chart(ax,range(6),names);scale01(ax)
        banner(fig,.028 if col==0 else .517,base+.199,.455,chr(97+i)+'  '+title)
        ax.axhline(3.5,color=MUTED,lw=1.1,ls=(0,(4,3)))
        for j,m in enumerate(methods):
            for metric,off,c,h in [('macro_f1',-.18,BLUE,False),('recall_H',.18,CORAL,True)]:
                seedmarks(ax,d[(d.panel==test)&(d.method==m)&(d.metric==metric)],j,c,off=off,hollow=h,spread=.105)
    footer(fig,'Each symbol = one algorithm seed; segments span three seeds on the same held-out files')
    GUARD['Figure_03']={'values':216,'conditions':6,'models':6,'seeds':SEEDS,'all_source_rows_preserved':True}
    save(fig,3,axes)

def fig4():
    d=read('fig_historical_corruption_source.csv');assert len(d)==216
    fig=plt.figure(figsize=(174/25.4,207/25.4));ribbon(fig,['4 exposure-training arms','6 test conditions','3 seed values per cell group'])
    score=LinearSegmentedColormap.from_list('score',['#F3F7FA','#AED4E3','#287DB1','#174B71'])
    loss=LinearSegmentedColormap.from_list('loss',['#FBF0E4','#EEC39C','#C3774F','#713A2E'])
    axes=[]
    for k,(metric,title) in enumerate([('macro_f1','Macro-F1'),('recall_H','Healthy recall'),('nll','Negative log likelihood (nats)')]):
        base=.665-k*.284;card(fig,.023,base-.05,.954,.273);banner(fig,.034,base+.202,.927,chr(97+k)+'  '+title)
        ax=axnew(fig,[.251,base,.706,.152]);axes.append(ax)
        q=d[d.metric==metric].set_index(['panel','arm','seed']).value
        vals=np.array([[q.loc[(p,a,s)] for a in ARMS for s in SEEDS] for p in TESTS]);assert vals.size==72
        vmax=1 if metric!='nll' else np.ceil(vals.max()*2)/2;cmap=score if metric!='nll' else loss
        ax.imshow(vals,aspect='auto',interpolation='nearest',vmin=0,vmax=vmax,cmap=cmap)
        for (r,c),val in np.ndenumerate(vals):
            ax.text(c,r,f'{val:.2f}',ha='center',va='center',fontsize=8,color='white' if val/vmax>.55 else INK)
        for x in (2.5,5.5,8.5):ax.axvline(x,color='white',lw=2)
        for y in np.arange(.5,5.5,1):ax.axhline(y,color='white',lw=1.1)
        ax.set_yticks(range(6),TN);ax.set_xticks(range(12),[str(s) for a in ARMS for s in SEEDS]);ax.tick_params(length=0,pad=4)
        for spine in ax.spines.values():spine.set_visible(False)
        for j,a in enumerate(AN):
            ax.text((j*3+1.5)/12,1.13,a,transform=ax.transAxes,ha='center',va='center',fontsize=8,fontweight='bold')
        text(fig,.251,base-.031,'Seed',8)
        text(fig,.958,base-.031,f'Color scale: 0–{vmax:g}; '+('higher is better' if k<2 else 'lower is better'),8,ha='right')
    footer(fig,'Each displayed number is a seed estimate; darker cells encode larger values within each panel')
    GUARD['Figure_04']={'values':216,'metric_matrices':[72,72,72],'all_source_rows_preserved':True}
    save(fig,4,axes)

def fig5():
    d=read('fig_excluded_corruptions_source.csv');assert len(d)==60
    fig=plt.figure(figsize=(174/25.4,132/25.4));ribbon(fig,['Withhold one construction','Matched 480-update fitting','Paired ERM / DRO contrast']);key(fig,'risk',.876)
    axes=[];card(fig,.023,.15,.954,.648)
    for j,title in enumerate(['Clean test','Excluded test','DRO − ERM']):
        x=.226+j*.251;ax=axnew(fig,[x,.248,.210,.430]);axes.append(ax)
        chart(ax,range(4),EN if j==0 else None);banner(fig,x-.006,.753,.222,chr(97+j)+'  '+title)
        if j<2:scale01(ax);ax.set_xlabel('Macro-F1')
        else:
            lim=np.ceil(d[d.display=='Delta F1'].value.abs().max()*10)/10+.008
            ax.set_xlim(-lim,lim);ax.xaxis.set_major_locator(MaxNLocator(4));ax.axvline(0,color=MUTED,lw=1.1,ls='--');ax.set_xlabel('Δ macro-F1')
        for i,e in enumerate(EXCL):
            q=d[d.excluded==e]
            if j==2:seedmarks(ax,q[q.display=='Delta F1'],i,INK)
            else:
                q=q[(q.display=='F1')&((q.panel=='clean') if j==0 else (q.panel!='clean'))]
                for arm,off,c,h in [('mixed_erm',-.16,BLUE,False),('mixed_dro',.16,CORAL,True)]:seedmarks(ax,q[q.arm==arm],i,c,off=off,hollow=h)
    footer(fig,'Three algorithm seeds · same 21 files · source-condition weights · exploratory comparison')
    GUARD['Figure_05']={'values':60,'all_source_rows_preserved':True,'paired_difference_values':12}
    save(fig,5,axes)

def recipe(d):return d.representation.str.replace('native25','Native25').str.replace('shape25','Shape25')+' '+d.model.map({'extra_trees':'ET','logistic':'LR'})

def fig6():
    raw=read('fig_paderborn_specimens_bearing_predictions.csv');pt=read('fig_paderborn_specimens_points.csv');assert len(raw)==216 and len(pt)==24
    for d in [raw,pt]:d['recipe']=recipe(d)
    recipes=['Native25 ET','Native25 LR','Shape25 ET','Shape25 LR'];ids=['K004','K005','K006','KI16','KI18','KI21','KA15','KA16','KA30']
    fig=plt.figure(figsize=(174/25.4,207/25.4));ribbon(fig,['9 development bearings','4 recipes × 3 fitting seeds','9 disjoint test bearings']);key(fig,'timing',.897)
    axes=[];card(fig,.023,.638,.954,.235)
    for j,metric in enumerate(['macro_f1','nll']):
        ax=axnew(fig,[.224+j*.386,.683,.340,.133]);axes.append(ax);chart(ax,range(4),recipes if j==0 else None)
        banner(fig,.224+j*.386,.85,.340,chr(97+j)+'  '+('Macro-F1' if j==0 else 'NLL (nats)'))
        if j==0:scale01(ax)
        else:ax.set_xlim(0,np.ceil(pt.nll.max()*2)/2);ax.xaxis.set_major_locator(MaxNLocator(5))
        for i,r in enumerate(recipes):
            for tm,c,off,h in [('nominal',BLUE,-.16,False),('timestamp_sensitive',CORAL,.16,True)]:
                seedmarks(ax,pt[(pt.recipe==r)&(pt.timing==tm)],i,c,metric,off,h)
    for j,tm in enumerate(['nominal','timestamp_sensitive']):
        card(fig,.023 if j==0 else .512,.116,.465,.496)
        banner(fig,.03 if j==0 else .519,.587,.451,chr(99+j)+'  '+('Nominal bearing calls' if j==0 else 'HostService bearing calls'))
        ax=axnew(fig,[.212+j*.485,.19,.259,.345]);axes.append(ax)
        g=raw[raw.timing==tm].copy();g['call']=g[['p_H','p_I','p_O']].to_numpy().argmax(axis=1)
        ix=pd.MultiIndex.from_product([recipes,SEEDS],names=['recipe','seed'])
        calls=g.pivot(index=['recipe','seed'],columns='bearing_id',values='call').loc[ix,ids].to_numpy()
        truth=g.drop_duplicates('bearing_id').set_index('bearing_id').loc[ids,'class_id'].to_numpy()
        ax.imshow(calls==truth,aspect='auto',interpolation='nearest',cmap=ListedColormap([PALES[1],PALES[0]]),vmin=0,vmax=1)
        for (r,c),v in np.ndenumerate(calls):ax.text(c,r,'HIO'[v],ha='center',va='center',fontsize=8)
        for x in [2.5,5.5]:ax.axvline(x,color='white',lw=2)
        for y in [2.5,5.5,8.5]:ax.axhline(y,color='white',lw=2)
        ax.set_xticks(range(9),ids,rotation=90,ha='right',va='center',rotation_mode='anchor',fontsize=8)
        ax.set_yticks(range(12),[f'{r}  {s}' if s==11 else str(s) for r,s in ix],fontsize=8)
        ax.tick_params(length=0,pad=4)
        for s in ax.spines.values():s.set_visible(False)
        for x,cl in [(1,'Healthy'),(4,'Inner'),(7,'Outer')]:ax.text(x,1.035,cl,transform=ax.get_xaxis_transform(),ha='center',fontsize=8)
    text(fig,.5,.082,'Cell: predicted H / I / O   ·   blue = correct   ·   rose = error   ·   row numbers = fitting seeds',8,ha='center')
    footer(fig,'Nine test bearings; repeated conditions do not increase the independent specimen count')
    GUARD['Figure_06']={'bearing_predictions':216,'summary_rows':24,'plotted_metric_values':48,'all_source_rows_preserved':True}
    save(fig,6,axes)

def fig7():
    d=read('fig_zero_shot_source.csv');rank=read('healthy_ranking_cells.csv')
    d=d.merge(rank,on=['cohort','excluded','arm','seed','timing'],validate='one_to_one');assert len(d)==72 and (d.recall_H==0).all()
    plans=[('none',a) for a in ARMS]+[(e,a) for e in EXCL for a in ['mixed_erm','mixed_dro']]
    labels=AN+[lab+' · '+a for lab in EN for a in ['ERM','DRO']];pos=[0,1,2,3,4.65,5.65,6.95,7.95,9.25,10.25,11.55,12.55]
    fig=plt.figure(figsize=(174/25.4,194/25.4));ribbon(fig,['Frozen HUST ensembles','12 policies × 3 source seeds','Paderborn · 2 timing paths']);key(fig,'timing',.895)
    axes=[];card(fig,.023,.112,.954,.756)
    for j,(metric,title) in enumerate([('macro_f1','Macro-F1'),('p_H_auc','Healthy AUROC'),('nll','NLL (nats)')]):
        x=.257+j*.242;ax=axnew(fig,[x,.169,.206,.620]);axes.append(ax);chart(ax,pos,labels if j==0 else None)
        banner(fig,x-.005,.835,.216,chr(97+j)+'  '+title);ax.axhline(3.85,color=MUTED,lw=1.1,ls=(0,(4,3)))
        if j<2:scale01(ax)
        else:ax.set_xlim(0,np.ceil(d.nll.max()));ax.xaxis.set_major_locator(MaxNLocator(4))
        if j==1:ax.axvline(.5,color=MUTED,lw=1.1,ls=':')
        if j==2:ax.axvline(np.log(3),color=MUTED,lw=1.1,ls=':')
        for (e,a),y in zip(plans,pos):
            for tm,c,off,h in [('nominal',BLUE,-.15,False),('timestamp_sensitive',CORAL,.15,True)]:
                q=d[(d.excluded==e)&(d.arm==a)&(d.timing==tm)];seedmarks(ax,q,y,c,metric,off,h)
    text(fig,.5,.084,'Combined acquisition and specimen differences; each evaluation reuses the same nine test bearings',8,ha='center')
    footer(fig,'Healthy argmax recall = 0 / 3 bearings in all 72 evaluations')
    GUARD['Figure_07']={'evaluation_rows':72,'plotted_metric_values':216,'all_source_rows_preserved':True,'healthy_argmax_recall_all_zero':True}
    save(fig,7,axes)

def main():
    global ALIGN
    ap=argparse.ArgumentParser();ap.add_argument('--qa-tools',type=Path,default=HERE/'qa_tools');ap.add_argument('--figures',default='2,3,4,5,6,7');a=ap.parse_args()
    from public_optional_alignment import configure_qa, require_matplotlib_panel_alignment
    configure_qa(a.qa_tools)
    ALIGN=require_matplotlib_panel_alignment;setup()
    for row in json.loads((HERE/'input_manifest.json').read_text()):assert hashlib.sha256((HERE/'inputs'/row['file']).read_bytes()).hexdigest()==row['sha256']
    for n in map(int,a.figures.split(',')):globals()[f'fig{n}']()
    (HERE/'data_equivalence.json').write_text(json.dumps(GUARD,indent=2))
    print(json.dumps(GUARD,indent=2))
if __name__=='__main__':main()
