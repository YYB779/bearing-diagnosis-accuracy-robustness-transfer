"""Screen previews only. Official Figure_*.png files remain unchanged at 450 dpi."""
from pathlib import Path
from PIL import Image
for p in (Path(__file__).resolve().parent/'exports').glob('Figure_??.png'):
    with Image.open(p) as im:
        im.resize((im.width//3,im.height//3),Image.Resampling.LANCZOS).save(p.with_name(p.stem+'_preview.png'),dpi=(150,150))
