from pathlib import Path
import subprocess,sys,json,concurrent.futures
HERE=Path(__file__).resolve().parent
SKILL=Path(sys.argv[1]) if len(sys.argv)>1 else HERE/'qa_tools';out=HERE/'qa';out.mkdir(exist_ok=True)
def job(args):
    name,cmd=args
    p=subprocess.run([sys.executable,*map(str,cmd)],capture_output=True)
    (out/(name+'.txt')).write_bytes(p.stdout+p.stderr)
    return {'check':name,'exit_code':p.returncode}
jobs=[('source',[SKILL/'validate_figure.py',HERE/'render_main_v3.py','--json'])]
for i in range(2,8):
    p=HERE/'exports'/f'Figure_{i:02d}.pdf'
    jobs.append((f'Figure_{i:02d}_text',[SKILL/'audit_pdf_text.py',p,'--min-pt','8','--json']))
    jobs.append((f'Figure_{i:02d}_collision',[SKILL/'audit_figure_collisions.py',p,'--json-out',out/f'Figure_{i:02d}_collision.json','--overlay-pdf',out/f'Figure_{i:02d}_collision.pdf']))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:results=list(ex.map(job,jobs))
(out/'RESULTS.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
