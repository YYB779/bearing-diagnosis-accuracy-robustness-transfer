"""Record final export dimensions, typography, strokes, hashes and fresh audit results."""
from pathlib import Path
import hashlib,json,subprocess,sys
import fitz
HERE=Path(__file__).resolve().parent
subprocess.run([sys.executable,str(HERE/'make_previews.py')],check=True)
subprocess.run([sys.executable,str(HERE/'run_qa.py')],check=True)
results=json.loads((HERE/'qa'/'RESULTS.json').read_text())
assert all(r['exit_code']==0 for r in results)
report={}
for i in range(2,8):
    f=HERE/'exports'/f'Figure_{i:02d}.pdf'
    with fitz.open(f) as doc:
        page=doc[0]
        sizes=[s['size'] for b in page.get_text('dict')['blocks'] if b['type']==0 for l in b['lines'] for s in l['spans']]
        widths=[d['width'] for d in page.get_drawings() if d['type'] in ['s','fs'] and d['width'] and d['width']>0]
        assert min(sizes)>7.99 and min(widths)>1.099
        collision=json.loads((HERE/'qa'/(f.stem+'_collision.json')).read_text(encoding='utf-8'))
        assert collision['summary']['fail']==collision['summary']['warn']==0
        report[f.stem]={'width_mm':round(page.rect.width*25.4/72,3),'height_mm':round(page.rect.height*25.4/72,3),
          'minimum_font_pt':min(sizes),'minimum_stroke_pt':min(widths),'pdf_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),
          'collision':collision['summary']}
(HERE/'FINAL_QA.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
