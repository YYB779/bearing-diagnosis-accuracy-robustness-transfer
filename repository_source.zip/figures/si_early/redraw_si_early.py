"""Rebuild S1–S8 from frozen CSVs. Run python redraw_si_early.py [--figures 1 ... 8]."""
from pathlib import Path
import argparse, hashlib, json, sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyBboxPatch, FancyArrowPatch, Polygon, Patch
from matplotlib.lines import Line2D
from matplotlib.colors import ListedColormap, LinearSegmentedColormap, BoundaryNorm, Normalize
from matplotlib.text import Text

HERE=Path(__file__).resolve().parent
SKILL=HERE/'qa_tools'
sys.path.insert(0,str(SKILL))
from public_optional_alignment import configure_qa, require_matplotlib_panel_alignment
configure_qa(SKILL)

NAVY='#275F8F'; INK='#173F59'; BLUE='#397FA5'; RED='#B9655F'; GREY='#778A97'
PB='#D8EAF3'; PR='#F5DDDA'; PL='#E9E1F0'; PG='#E0ECDA'; PA='#FAEBD0'
GRID='#DCE4E8'; WHITE='#FFFFFF'
SEEDS=[11,22,33]; MARK=['o','s','^']; COND=['20Hz','30Hz','40Hz','60Hz','VS_0_40_0Hz']; CLAB=['20','30','40','60','VS']
FILES={1:'si_same_model_fold_points.csv',2:'si_hust_support_source.csv',3:'si_native_hust_source.csv',4:'si_consistency_design_source.csv',5:'si_incremental_gains_source.csv',6:'fig_noise_realization_sensitivity.source.csv',7:'fig_bearing_deletion.source.csv',8:'fig_measured_timefrequency_3d.source.csv'}

def theme():
    plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','Helvetica','DejaVu Sans'],
    'font.size':8.4,'axes.labelsize':8.3,'axes.titlesize':9,'xtick.labelsize':8,'ytick.labelsize':8,
    'axes.linewidth':1.1,'patch.linewidth':1.1,'lines.markeredgewidth':1.1,'xtick.major.width':1.1,'ytick.major.width':1.1,'axes.edgecolor':GREY,'text.color':INK,'axes.labelcolor':INK,
    'xtick.color':INK,'ytick.color':INK,'axes.spines.top':False,'axes.spines.right':False,
    'axes.axisbelow':True,'legend.frameon':False,'legend.fontsize':8,
    'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','figure.facecolor':'white',
    'savefig.facecolor':'white','svg.hashsalt':'si-reference-style-v3'})

def canvas(h): return plt.figure(figsize=(185/25.4,h/25.4))
def banner(fig, x, y, w, text, h=.036, size=9):
    fig.patches.append(FancyBboxPatch((x,y),w,h,transform=fig.transFigure,boxstyle='round,pad=0.001,rounding_size=0.006',facecolor=NAVY,edgecolor=NAVY,linewidth=1.1,zorder=10))
    fig.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=size,weight='bold',color='white',zorder=11)
def module(fig,ax,letter,title,pad=.012,heading=True,topgap=.018):
    p=ax.get_position()
    if not hasattr(fig,'_modules'):fig._modules=[]
    fig._modules.append((ax,pad,topgap))
    if heading: banner(fig,p.x0,p.y1+topgap*.42,p.width,letter+'  '+title,h=min(.036,18/(fig.get_figheight()*72)),size=8.5)
def strip(fig, labels, y=.925):
    n=len(labels);gap=.025;x0=.045;total=.91
    w=(total-(n-1)*gap)/n
    for i,lab in enumerate(labels):
        x=x0+i*(w+gap)
        fig.patches.append(FancyBboxPatch((x,y),w,.047,transform=fig.transFigure,boxstyle='round,pad=0.003,rounding_size=0.003',facecolor=[PB,PL,PG,PA][i%4],edgecolor='#89A0AF',linewidth=1.1,zorder=4))
        fig.text(x+w/2,y+.0235,lab,ha='center',va='center',fontsize=8.2,weight='bold',linespacing=1.05,zorder=5)
        if i<n-1: fig.patches.append(FancyArrowPatch((x+w+.005,y+.0235),(x+w+gap-.005,y+.0235),transform=fig.transFigure,arrowstyle='-|>',mutation_scale=7,color=INK,linewidth=1.1,zorder=6))
def quiet(ax,axis='x'):
    ax.grid(axis=axis,color=GRID,lw=1.1);ax.tick_params(width=1.1,length=3,pad=3)
def point(ax,x,y,seed=11,color=BLUE,filled=False,size=24):
    m=MARK[SEEDS.index(seed)] if seed in SEEDS else 'D'
    ax.scatter(x,y,s=size,marker=m,edgecolors=color,facecolors=color if filled else 'white',linewidths=1.1,zorder=5)
def seedlegend(fig,y=.01,svm=False,x=.55):
    hh=[Line2D([],[],color=BLUE,marker=m,mfc='white',ls='',mew=1.1,ms=5) for m in MARK]
    ll=['Seed 11','Seed 22','Seed 33']
    if svm: hh.append(Line2D([],[],color=RED,marker='D',ls='',ms=5));ll.append('SVM')
    fig.legend(hh,ll,loc='lower center',bbox_to_anchor=(x,y),ncol=len(ll),columnspacing=1.3,handletextpad=.4)
def matrix(ax,m,rows,cols,labels,cmap,norm=None):
    ax.imshow(m,cmap=cmap,norm=norm,aspect='auto',interpolation='none',**({} if norm is not None else {'vmin':0,'vmax':1}))
    ax.set(xticks=np.arange(len(cols)),xticklabels=cols,yticks=np.arange(len(rows)),yticklabels=rows)
    ax.spines[:].set_visible(False);ax.tick_params(length=0,pad=4)
    ax.set_xticks(np.arange(len(cols)+1)-.5,minor=True);ax.set_yticks(np.arange(len(rows)+1)-.5,minor=True)
    ax.grid(which='minor',color='white',lw=1.2);ax.tick_params(which='minor',length=0)
    for y in range(len(rows)):
        for x in range(len(cols)):ax.text(x,y,str(labels[y][x]),ha='center',va='center',fontsize=8.2,color=INK)

def s1(t):
    fig=canvas(135);strip(fig,['Same fitted Extra Trees','Known vs held states','Five fixed rotations'])
    axes=fig.subplots(2,3,sharex=True,sharey=True);fig.subplots_adjust(left=.115,right=.975,bottom=.16,top=.80,wspace=.23,hspace=.40)
    reps=[('native_fullband','Native bandwidth'),('time_envelope','Time envelope'),('order_geometry','Order + geometry')]
    for i,task in enumerate(['inner_presence','outer_presence']):
        for j,(rep,title) in enumerate(reps):
            ax=axes[i,j];d=t[(t.task==task)&(t.representation==rep)].sort_values('protocol');assert len(d)==5
            for k,row in enumerate(d.itertuples()):
                ax.axvspan(k-.38,k+.38,facecolor=PB if i==0 else PL,alpha=.35,zorder=0)
                ax.plot([k-.16,k+.16],[row.known_f1,row.unknown_f1],color=GREY,lw=1.3)
                ax.scatter(k-.16,row.known_f1,marker='o',facecolors='white',edgecolors=GREY,s=27,lw=1.1,zorder=4)
                ax.scatter(k+.16,row.unknown_f1,marker='^',color=BLUE,s=27,linewidths=1.1,zorder=5)
            ax.set(xlim=(-.45,4.45),ylim=(.75,1.018),xticks=range(5),yticks=[.8,.9,1]);quiet(ax,'y')
            if i==1:ax.set_xlabel('Rotation')
            if j==0:ax.set_ylabel(('Inner-fault' if i==0 else 'Outer-fault')+' macro-F1')
            module(fig,ax,'abcdef'[i*3+j],title)
    fig.legend([Line2D([],[],color=GREY,marker='o',mfc='white',ls=''),Line2D([],[],color=BLUE,marker='^',ls='')],['Known states','Held-out states'],loc='lower center',bbox_to_anchor=(.56,.015),ncol=2)
    return fig,list(axes.flat),{'paired_fold_rows':len(t),'plotted_points':len(t)*2}

def s2(t):
    fig=canvas(165);strip(fig,['21 acquisition files','Five condition rotations','Fixed-file contrasts'])
    g=fig.add_gridspec(2,2,left=.19,right=.96,bottom=.16,top=.805,wspace=.65,hspace=.65)
    axes=[fig.add_subplot(g[i,j]) for i in range(2) for j in range(2)]
    a,b,c,d=axes
    states=[('H','healthy'),('I','medium'),('I','severe'),('O','medium'),('O','severe')]
    v=t[t.panel=='a'];m=np.array([[float(v[(v.class_name==cl)&(v.severity==sev)&(v.condition==co)].value.iloc[0]) for co in COND] for cl,sev in states])
    matrix(a,m,['Healthy','Inner, moderate','Inner, severe','Outer, moderate','Outer, severe'],CLAB,np.where(m==1,'1','–'),ListedColormap(['#F3F5F6',PB]));a.set_xlabel('Motor command (Hz)')
    v=t[t.panel=='b'];roles=['train','validation','test'];m=np.array([[roles.index(v[(v.test_condition==x)&(v.source_condition==y)].role.iloc[0]) for y in COND] for x in COND])
    matrix(b,m,['Hold '+v for v in CLAB],CLAB,np.array(['Tr','V','Te'])[m],ListedColormap([PG,PA,PB]),BoundaryNorm([-.5,.5,1.5,2.5],3));b.set_xlabel('Motor command (Hz)')
    v=t[t.panel=='c'].set_index('stratum');healthy=int(v.loc['shared_healthy','value']);counts=[int(v.loc[x,'value']) for x in ['severe_faults','medium_faults']]
    for y,n in zip([1,0],counts):
        c.barh(y,healthy,color=PG,height=.44,edgecolor='#819478',lw=1.1);c.barh(y,n,left=healthy,color=PB,height=.44,edgecolor=BLUE,lw=1.1)
        c.text(healthy/2,y,str(healthy),ha='center',va='center');c.text(healthy+n/2,y,str(n),ha='center',va='center')
    c.set(yticks=[1,0],yticklabels=['Severe','Moderate'],xlabel='Acquisition files',xlim=(0,16),xticks=[0,5,10,15],ylim=(-.6,1.6))
    for rid,st in enumerate(['healthy_plus_medium','healthy_plus_severe']):
        for r in t[(t.panel=='d')&(t.stratum==st)].itertuples():
            k=['11','22','33','deterministic'].index(str(r.seed));y=rid+[-.18,-.06,.06,.18][k]
            d.hlines(y,0,r.value,color=PB if k<3 else PR,lw=3,zorder=1)
            point(d,r.value,y,SEEDS[k] if k<3 else 0,BLUE if k<3 else RED,k==3)
    d.axvline(0,lw=1.1,color=GREY);d.set(yticks=[1,0],yticklabels=['Severe','Moderate'],xlabel='Paired Δ macro-F1',ylim=(-.5,1.5),xlim=(-.27,.15));quiet(d)
    for ax,l,title in zip(axes,'abcd',['Acquisition support','Condition roles','Repeated healthy files','Envelope − low-pass']):module(fig,ax,l,title)
    fig.legend([Patch(fc=PG,ec='#819478'),Patch(fc=PB,ec=BLUE)],['Healthy','Damaged'],loc='lower center',bbox_to_anchor=(.28,.015),ncol=2,handlelength=1)
    seedlegend(fig,.015,True,.76)
    return fig,axes,{'source_rows':len(t),'acquisition_files':21,'paired_contrast_points':8}

def s3(t):
    fig=canvas(115);strip(fig,['Eight 1-second windows / file','21 held-out acquisition files','Three ET seeds + SVM'])
    axes=fig.subplots(1,3,sharey=True);fig.subplots_adjust(left=.275,right=.97,top=.79,bottom=.18,wspace=.23)
    reps=['raw_lowpass_33','single_envelope_33','native_fullband_25','native_shape_25','native_envelope_fusion_124']
    names=['Low-pass (33)','Envelope (33)','Native (25)','Shape (25)','Native + envelopes (124)']
    for j,(ax,metric,title) in enumerate(zip(axes,['macro_f1','nll','recall_H'],['Macro-F1','NLL (nats)','Healthy recall'])):
        for y in range(5):ax.axhspan(y-.5,y+.5,color=[PB,'white',PL,'white',PG][y],alpha=.45,zorder=0)
        for r in t[t.metric==metric].itertuples():
            k=3 if r.family=='SVM' else SEEDS.index(int(r.seed));point(ax,r.value,4-reps.index(r.representation)+[-.18,-.06,.06,.18][k],SEEDS[k] if k<3 else 0,RED if k==3 else BLUE,k==3)
        ax.set(yticks=range(5),yticklabels=names[::-1],ylim=(-.5,4.5));quiet(ax)
        if metric!='nll':ax.set(xlim=(-.015,1.03),xticks=[0,.5,1])
        else:ax.set_xlim(left=0)
        module(fig,ax,'abc'[j],title)
    seedlegend(fig,.015,True)
    return fig,list(axes),{'source_rows':len(t),'plotted_points':len(t)}

def s4(t):
    fig=canvas(182);strip(fig,['Same patch / balanced batch','Same 66,083-parameter backend','Only views / objective vary'],y=.94)
    a=fig.add_axes([.045,.51,.91,.36]);a.axis('off');a.set(xlim=(0,1),ylim=(0,1))
    def box(x,y,w,h,label,fc,size=8.2):
        a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.007,rounding_size=.014',fc=fc,ec='#8294A1',lw=1.1,clip_on=False));a.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=size,linespacing=1.1)
    def arr(x,y,xx,yy):a.annotate('',xy=(xx,yy),xytext=(x,y),arrowprops={'arrowstyle':'-|>','lw':1.2,'color':INK,'shrinkA':0,'shrinkB':0})
    def stack(x,y,fc,label):
        for k in [2,1]:
            z=k*.014;prev=(k-1)*.014
            a.add_patch(Polygon([(x+z,y+.17+prev),(x+z,y+.17+z),(x+.09+z,y+.17+z),(x+.09+z,y+z),(x+.09+prev,y+z),(x+.09+prev,y+.17+prev)],closed=True,fc=fc,ec='#688292',lw=1.1))
        a.add_patch(Rectangle((x,y),.09,.17,fc=fc,ec='#688292',lw=1.1))
        a.text(x+.045,y+.085,label,ha='center',va='center',weight='bold',fontsize=8.2)
    for i,(arm,title,view,obj,col) in enumerate([
        ('A','Clean CE','Clean × 3','Mean CE',PG),('B','Gaussian CE','Clean + two\nGaussian views','Mean CE',PB),
        ('C','Response CE','Clean + two\nresponse/noise views','Mean CE',PL),('D','Response JSD','Same inputs as C','Mean CE + 12 JSD',PR)]):
        y=.77-i*.235
        box(.005,y,.18,.18,arm+'   '+title,col)
        arr(.19,y+.09,.22,y+.09);stack(.225,y+.004,col,'3 views')
        box(.367,y,.28,.18,view,col);arr(.34,y+.09,.36,y+.09);arr(.657,y+.09,.70,y+.09)
        box(.71,y,.285,.18,obj,col)
    module(fig,a,'a','Controlled three-view training',pad=.012,topgap=.03)
    fig.text(.5,.474,'18-patch batch  ·  seeds 11 / 22 / 33  ·  five rotations  ·  480 updates',ha='center',fontsize=8.3,weight='bold')
    b=fig.add_axes([.105,.105,.35,.28]);freq=None
    v=t[t.kind=='response_example']
    for curve,d in v.groupby('curve',sort=True):
        b.plot(d.frequency_hz/1000,d.multiplier,color=BLUE if int(curve)%2==0 else '#8B80A4',lw=1.1,alpha=.74)
    for bound in np.exp([-.7,.7]):b.axhline(bound,ls=':',color=GREY,lw=1.1)
    b.axhline(1,lw=1.1,color=GREY);b.set(xlim=(0,12.8),ylim=(0,2.12),xticks=[0,4,8,12.8],xlabel='Frequency (kHz)',ylabel='Amplitude multiplier');quiet(b)
    module(fig,b,'b','Response multipliers',topgap=.025)
    with np.load(HERE/'inputs/S4_training_views.npz',allow_pickle=False) as z:views=z['views'];time=z['time_ms']
    assert views.shape==(3,2048)
    limit=np.ceil(np.abs(views).max());waveaxes=[]
    for i in range(3):
        ax=fig.add_axes([.625,.105+(2-i)*.097,.335,.073])
        ax.plot(time,views[i],lw=1.1,color=[GREY,BLUE,RED][i],rasterized=True)
        ax.set(ylim=(-limit,limit),yticks=[-limit,limit],xlim=(0,80),xticks=[0,40,80]);ax.set_ylabel(['Clean','View 1','View 2'][i]);ax.set_facecolor([PG,PB,PR][i]);waveaxes.append(ax)
        if i<2:ax.tick_params(labelbottom=False)
        else:ax.set_xlabel('Time (ms)')
    # A common module keeps three aligned traces subordinate to the same validation panel.
    banner(fig,.625,.401,.335,'c  Standardized training views',h=.028,size=8.4)
    return fig,[b,*waveaxes],{'response_curves':int(v.curve.nunique()),'response_points':len(v),'training_view_points':int(views.size),'source_patch':str(t.source_patch.dropna().iloc[0]),'schematic_note':'Backend shared by all arms; stacks denote three inputs, not invented layers.'}

def s5(t):
    fig=canvas(185);strip(fig,['Paired changes on fixed files','Three incremental contrasts','Class-specific failures'])
    top=fig.add_gridspec(1,3,left=.16,right=.965,bottom=.635,top=.84,wspace=.27)
    bot=fig.add_gridspec(1,2,left=.16,right=.965,bottom=.13,top=.51,wspace=.5)
    axes=[];ch=['clean','AWGN0dB','AWGN-4dB','colored-4dB','impulse-4dB','tone-4dB'];labels=['Clean','White 0 dB','White −4 dB','Colored','Impulse','Tone']
    for i,(panel,title) in enumerate(zip('abc',['Gaussian: B − A','Response: C − B','Consistency: D − C'])):
        ax=fig.add_subplot(top[i]);axes.append(ax);ax.axvspan(-1,0,color=PR,alpha=.45);ax.axvspan(0,1,color=PG,alpha=.45)
        d=t[(t.figure_panel==panel)&(t.metric=='macro_f1')];assert len(d)==18
        for r in d.itertuples():
            k=SEEDS.index(r.seed);y=5-ch.index(r.challenge)+(k-1)*.14
            ax.hlines(y,0,r.value,color='#9DAFBC',lw=1.1);point(ax,r.value,y,r.seed,BLUE,False,23)
        ax.axvline(0,color=GREY,lw=1.1);ax.set(xlim=(-1,1),xticks=[-1,0,1],ylim=(-.5,5.5),yticks=range(6),yticklabels=labels[::-1] if i==0 else ['']*6,xlabel='Δ macro-F1')
        module(fig,ax,panel,title)
    arms=['clean_ce','awgn_ce','response_ce','response_jsd']
    for i,(panel,title) in enumerate(zip('de',['Clean: inner-race recall','White −4 dB: healthy recall'])):
        ax=fig.add_subplot(bot[i]);axes.append(ax);d=t[(t.kind=='condition_class_recall')&(t.figure_panel==panel)];rows=[];vals=[];bits=[]
        for n,arm in enumerate(arms):
            for seed in SEEDS:
                rr=d[(d.arm==arm)&(d.seed==seed)].set_index('condition').loc[['20 Hz','30 Hz','40 Hz','60 Hz','Variable']]
                rows.append('ABCD'[n]+' · '+str(seed));vals.append(rr.value.to_numpy());bits.append([f'{int(z.numerator_correct)}/{int(z.denominator_records)}' for z in rr.itertuples()])
        matrix(ax,np.array(vals),rows,CLAB,bits,ListedColormap([PR,'#EFF3F5',PB]),BoundaryNorm([-.1,.25,.75,1.1],3))
        for yy in [2.5,5.5,8.5]:ax.axhline(yy,color='white',lw=2.2)
        ax.set_xlabel('Held-out command (Hz)');ax.set_ylabel('Arm · seed');module(fig,ax,panel,title)
    seedlegend(fig,.015)
    return fig,axes,{'paired_delta_points':54,'class_recall_cells':120,'source_rows':len(t)}

def s6(t):
    fig=canvas(165);strip(fig,['21 fixed acquisition files','Three new noise draws','Three algorithm seeds'])
    axes=fig.subplots(2,4,sharex=True,sharey=True);fig.subplots_adjust(left=.19,right=.97,bottom=.15,top=.80,wspace=.19,hspace=.37)
    methods=['Clean CE','AWGN CE','Response CE','Response JSD','MixERM (omitted)','MixDRO (omitted)'];names=['Clean CE','Gaussian CE','Response CE','Response JSD','Mixed ERM','Mixed DRO']
    for i,metric in enumerate(['macro_f1','recall_H']):
        for j,family in enumerate(['awgn','colored','impulse','tone']):
            ax=axes[i,j];d=t[(t.metric==metric)&(t.family==family)]
            ax.axhspan(-.45,1.5,color=PR,alpha=.25);ax.axhspan(1.5,5.45,color=PB,alpha=.25)
            for r in d.itertuples():
                k=SEEDS.index(r.seed);offset=(r.draw-7202)*.14+(k-1)*.038;y=5-methods.index(r.method)+offset
                point(ax,r.value,y,r.seed,RED if r.study=='v7' else BLUE,False,18)
            ax.axhline(1.5,color=GREY,lw=1.1,ls=':');quiet(ax)
            ax.set(yticks=range(6),yticklabels=names[::-1],xticks=[0,.5,1],xlim=(-.035,1.035),ylim=(-.45,5.45),xlabel='Macro-F1' if i==0 else 'Healthy recall');ax.tick_params(labelbottom=True)
            module(fig,ax,'abcdefgh'[i*4+j],['White','Colored','Impulse','Tone'][j],pad=.007)
    seedlegend(fig,.008)
    return fig,list(axes.flat),{'source_rows':len(t),'plotted_points':len(t),'draws':sorted(t.draw.unique().tolist())}

def s7(t):
    fig=canvas(185);strip(fig,['Nine fixed test bearings','Omit one bearing','Recompute macro-F1'])
    axes=fig.subplots(4,2,sharex=True,sharey=True);fig.subplots_adjust(left=.15,right=.96,bottom=.12,top=.85,wspace=.22,hspace=.30)
    configs=[('native25','extra_trees','Native ET'),('shape25','extra_trees','Shape ET'),('native25','logistic','Native logistic'),('shape25','logistic','Shape logistic')];bears=sorted(t.deleted_bearing.unique())
    for i,(rep,model,name) in enumerate(configs):
        for j,timing in enumerate(['nominal','timestamp_sensitive']):
            ax=axes[i,j];d=t[(t.timing==timing)&(t.representation==rep)&(t.model==model)].set_index('deleted_bearing').loc[bears];base=d.primary_f1.unique();assert len(base)==1
            ax.axvline(base[0],color=GREY,ls='--',lw=1.1)
            for y,(bid,r) in enumerate(d.iterrows()):
                z=8-y;color='#78B7A9' if bid.startswith('K00') else '#2E75B6' if bid.startswith('KI') else '#E79B62'
                ax.plot([base[0],r.deletion_f1],[z,z],color=color,lw=1.2);ax.scatter(r.deletion_f1,z,color=color,s=20,linewidths=1.1,zorder=3)
            ax.set(yticks=range(9),yticklabels=bears[::-1],xticks=[0,.3,.6],xlim=(0,.65),ylim=(-.6,8.6));quiet(ax)
            ax.tick_params(axis='y',labelsize=8,pad=2)
            if i==3:ax.set_xlabel('Macro-F1')
            module(fig,ax,'abcdefgh'[i*2+j],name+' | '+('Nominal' if j==0 else 'HostService'),topgap=.018)
    handles=[Line2D([],[],color=c,marker='o',ls='') for c in ['#78B7A9','#2E75B6','#E79B62']]+[Line2D([],[],color=GREY,ls='--')]
    fig.legend(handles,['Healthy','Inner race','Outer race','Full-panel mean'],loc='lower center',bbox_to_anchor=(.55,.008),ncol=4,columnspacing=1.1,handlelength=1.4)
    return fig,list(axes.flat),{'omission_scores':len(t),'bearings':bears,'layout':'Model rows; nominal left, timestamp-sensitive right.'}

def s8(t):
    fig=canvas(185);strip(fig,['Measured H_20Hz acquisition','8 s at 25.6 kHz','STFT power density'])
    original=t.pivot(index='frequency_hz',columns='time_center_s',values='psd_source_x_unit_squared_per_hz');lev=t.pivot(index='frequency_hz',columns='time_center_s',values='relative_psd_db')
    psd=original.to_numpy();db=lev.to_numpy();assert psd.shape==(513,399) and (psd>0).all();err=float(np.max(np.abs(np.maximum(-80,10*np.log10(psd/psd.max()))-db)));assert err<1e-7
    times=original.columns.to_numpy();freq=original.index.to_numpy()/1000;norm=Normalize(-80,0);cmap=LinearSegmentedColormap.from_list('psd_surface',['#F4F7F8',PB,'#5F9FC1',NAVY,'#153F5D'],N=256)
    a=fig.add_axes([.045,.43,.88,.43],projection='3d');a.set_proj_type('ortho');a.set_box_aspect((2.15,1.52,.69),zoom=1.07);a.view_init(elev=38,azim=-65)
    fi=np.unique(np.r_[np.arange(0,len(freq),2),len(freq)-1]);ti=np.unique(np.r_[np.arange(0,len(times),4),len(times)-1]);T,F=np.meshgrid(times[ti],freq[fi]);Z=db[np.ix_(fi,ti)]
    a.plot_surface(T,F,Z,rstride=1,cstride=1,lw=0,edgecolor='none',antialiased=False,rasterized=True,shade=False,cmap=cmap,norm=norm)
    a.set(xlim=(0,8),ylim=(0,12.8),zlim=(-80,0),xticks=[0,2,4,6,8],yticks=[0,6,12],zticks=[-80,-40,0]);a.set_xlabel('Time (s)',labelpad=3);a.set_ylabel('Frequency (kHz)',labelpad=3);a.tick_params(pad=0,labelsize=8)
    for axis in [a.xaxis,a.yaxis,a.zaxis]:axis.pane.fill=False;axis.pane.set_edgecolor(GRID);axis._axinfo['grid'].update({'color':(.82,.86,.87,.7),'linewidth':1.1})
    banner(fig,.06,.865,.88,'a  Measured spectral surface',h=.029)
    fig.text(.09,.83,'Height and colour: relative PSD (dB)',fontsize=8.2,color=GREY)
    b=fig.add_axes([.12,.09,.70,.27]);mesh=b.pcolormesh(times,freq,db,shading='nearest',cmap=cmap,norm=norm,rasterized=True)
    b.set(xlim=(0,8),ylim=(0,12.8),xlabel='Time (s)',ylabel='Frequency (kHz)',xticks=[0,2,4,6,8],yticks=[0,3,6,9,12]);banner(fig,.12,.38,.70,'b  Full-resolution time–frequency map',h=.03)
    cb=fig.colorbar(mesh,cax=fig.add_axes([.855,.09,.022,.27]),ticks=[-80,-60,-40,-20,0]);cb.set_label('Relative PSD (dB)',labelpad=5)
    return fig,[b,cb.ax],{'matrix_shape':list(db.shape),'planar_cells':db.size,'surface_shape':list(Z.shape),'maximum_dB_difference':err,'reference_psd':float(psd.max()),'surface_sampling':'Original every second frequency and fourth time frame with boundary included.'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--figures',nargs='+',type=int,default=list(FILES));p.add_argument('--output',type=Path,default=HERE/'exports');args=p.parse_args();args.output.mkdir(parents=True,exist_ok=True);theme();reports=json.loads((args.output/'data_equivalence.json').read_text()) if (args.output/'data_equivalence.json').exists() else {}
    for n in args.figures:
        data=HERE/'inputs'/FILES[n];t=pd.read_csv(data);fig,axes,report=globals()['s'+str(n)](t)
        for tx in fig.findobj(Text):
            if tx.get_fontsize()<8:tx.set_fontsize(8)
        fig.canvas.draw()
        for ax,pad,gap in ([] if n==7 else getattr(fig,'_modules',[])):
            bb=ax.get_tightbbox(fig.canvas.get_renderer()).transformed(fig.transFigure.inverted());p=ax.get_position()
            x0=bb.x0-.009;x1=bb.x1+.009;y0=bb.y0-.012;yt=p.y1+gap*.42+min(.036,18/(fig.get_figheight()*72))/2
            fig.lines.append(Line2D([p.x0,x0,x0,x1,x1,p.x1],[yt,yt,y0,y0,yt,yt],transform=fig.transFigure,color='#70828E',linestyle=(0,(5,3)),lw=1.1,zorder=-5))
        if n==7:fig.patches.append(Rectangle((.087,.064),.89,.84,transform=fig.transFigure,fc='none',ec='#70828E',linestyle=(0,(5,3)),lw=1.1,zorder=-5))
        # Comparable panels only: schematic/insets and 3D projections have explicit roles.
        compare=axes
        if n==4:compare=axes[1:]
        options={}
        if n==4:options={'column_groups':[['a','b','c']]}
        if n==8:
            compare[1].set_label('scale')
            options={'row_groups':[['a','b']],'exemptions':[{'panels':['a','b'],'checks':['panel-width'],'reason':'A colour scale is intentionally narrower than the data matrix; top/bottom edges must align. Orthographic surface has no comparable planar rectangle.'}]}
        require_matplotlib_panel_alignment(fig,axes=compare,panel_ids=list('abcdefgh'[:len(compare)]),json_out=args.output/f'Figure_S{n}_alignment.json',**options)
        fig.savefig(args.output/f'Figure_S{n}.pdf',dpi=450,metadata={'CreationDate':None,'ModDate':None})
        fig.savefig(args.output/f'Figure_S{n}.svg',dpi=450,metadata={'Date':None})
        fig.savefig(args.output/f'Figure_S{n}.png',dpi=300)
        plt.close(fig);report.update(source_file=FILES[n],source_sha256=hashlib.sha256(data.read_bytes()).hexdigest(),source_rows=len(t),width_mm=185)
        reports['S'+str(n)]=report;print('DONE S'+str(n),flush=True)
    (args.output/'data_equivalence.json').write_text(json.dumps(reports,indent=2)+'\n',encoding='utf8')
if __name__=='__main__':main()
