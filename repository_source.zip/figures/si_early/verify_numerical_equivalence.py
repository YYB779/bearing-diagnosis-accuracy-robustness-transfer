"""Compare actual Matplotlib numerical artist payloads before and after redesign."""
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.collections import PathCollection, QuadMesh
import original_supplements as old
import original_figure01_03 as old8
import redraw_si_early as new
HERE=Path(__file__).resolve().parent

def points(fig,only_y=False):
    a=np.concatenate([np.asarray(c.get_offsets(),float) for ax in fig.axes for c in ax.collections if isinstance(c,PathCollection)])
    if only_y:return np.sort(a[:,1])
    return np.asarray(sorted(map(tuple,a)))

def images(fig):
    return sorted([np.asarray(im.get_array()).tolist() for ax in fig.axes for im in ax.images],key=repr)

def digest(a):return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()

def main():
    report={}
    for n in [1,2,3,5,6,7]:
        t=pd.read_csv(HERE/'inputs'/new.FILES[n]);old.theme();a=getattr(old,'s'+str(n))(t);new.theme();b,_,_=getattr(new,'s'+str(n))(t)
        pa,pb=points(a,n==1),points(b,n==1)
        assert pa.shape==pb.shape and np.array_equal(pa,pb),(n,pa.shape,pb.shape)
        assert images(a)==images(b),n
        report['S'+str(n)]={'same_plotted_values':True,'point_count':len(pa),'point_data_sha256':digest(pa),'same_heatmap_cell_arrays':True,'note':'S1 horizontal offsets changed for clarity; all original metric values are equal.' if n==1 else 'Both numerical coordinates preserved; panel order/colours may differ.'}
        plt.close(a);plt.close(b)
    t=pd.read_csv(HERE/'inputs'/new.FILES[4]);v=t[t.kind=='response_example'];freq=np.fft.rfftfreq(2048,1/25600)/1000
    gains=np.clip(np.random.default_rng(66016).normal(0,.35,(10,5)),-.7,.7)
    actual=[];expected=[]
    for i,d in v.groupby('curve',sort=True):
        assert np.array_equal(d.frequency_hz.to_numpy()/1000,freq)
        actual.append(d.multiplier.to_numpy());expected.append(np.exp(np.interp(freq,[0,2,4,8,12.8],gains[int(i)])))
    err=float(np.max(np.abs(np.asarray(actual)-np.asarray(expected))));assert err<1e-14
    with np.load(HERE/'inputs/S4_training_views.npz',allow_pickle=False) as z:views=z['views']
    report['S4']={'response_points':int(v.shape[0]),'maximum_response_difference':err,'training_view_points':int(views.size),'training_view_sha256':digest(views),'view_replay':'S4_training_view_replay.json'}
    t=pd.read_csv(HERE/'inputs'/new.FILES[8]);a,_,oa=old8.fs8(lambda name:t);b,_,nb=new.s8(t)
    ma=[np.asarray(c.get_array()) for ax in a.axes for c in ax.collections if isinstance(c,QuadMesh)][0]
    mb=[np.asarray(c.get_array()) for ax in b.axes for c in ax.collections if isinstance(c,QuadMesh)][0]
    assert np.array_equal(ma,mb);assert oa['surface_shape']==nb['surface_shape']
    report['S8']={'all_planar_values_equal':True,'planar_cells':int(ma.size),'same_surface_stride_and_shape':True,'surface_shape':nb['surface_shape'],'planar_values_sha256':digest(ma)}
    plt.close(a);plt.close(b)
    (HERE/'qa/NUMERICAL_EQUIVALENCE.json').write_text(json.dumps(report,indent=2)+'\n')
    print('All 8 numerical artist checks passed.')
if __name__=='__main__':main()
