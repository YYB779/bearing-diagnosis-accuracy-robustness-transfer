"""Run bundled source, numerical, alignment and rendered-PDF checks."""
from pathlib import Path
import sys,subprocess,json
import fitz
HERE=Path(__file__).resolve().parent

def run():
    q=HERE/'qa';q.mkdir(exist_ok=True);summary={}
    tasks=[('source',HERE/'qa_tools/validate_figure.py',[str(HERE/'redraw_si_early.py'),'--json']),
           ('numeric',HERE/'verify_numerical_equivalence.py',[]),('views',HERE/'rebuild_training_views.py',[])]
    for name,tool,args in tasks:
        result=subprocess.run([sys.executable,str(tool),*args],capture_output=True)
        (q/f'{name}.txt').write_bytes(result.stdout+result.stderr);summary[name]=result.returncode
    for n in range(1,9):
        pdf=HERE/'exports'/f'Figure_S{n}.pdf';item={}
        for name,tool,args in [('text','audit_pdf_text.py',['--min-pt','8','--json']),('collision','audit_figure_collisions.py',['--json-out',str(q/f'S{n}_collision.json')])]:
            result=subprocess.run([sys.executable,str(HERE/'qa_tools'/tool),str(pdf),*args],capture_output=True)
            (q/f'S{n}_{name}.txt').write_bytes(result.stdout+result.stderr);item[name+'_exit_code']=result.returncode
        with fitz.open(pdf) as doc:
            page=doc[0];spans=[s for b in page.get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans']]
            ds=[d for d in page.get_drawings() if d.get('color') is not None and d.get('width',0)>0]
            item.update(width_mm=page.rect.width*25.4/72,height_mm=page.rect.height*25.4/72,minimum_text_pt=min(s['size'] for s in spans),minimum_vector_stroke_pt=min(d['width'] for d in ds),out_of_page_text=[s['text'] for s in spans if not page.rect.contains(fitz.Rect(s['bbox']))])
        summary['S'+str(n)]=item
    (q/'QA_SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
if __name__=='__main__':run()
