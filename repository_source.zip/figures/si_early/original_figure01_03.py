"""Render Figures 1–3 and S8 from the submitted figure source tables.

python figure01_03.py --source-zip figure_source_data.zip --output exports

The inputs are data tables at their original archive paths. No network or raw
measurements are needed. Optionally pass --qa-tools to run the local panel audit.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
from zipfile import ZipFile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.lines import Line2D
from matplotlib.ticker import NullLocator
import numpy as np
import pandas as pd

BLUE="#176B86"
RED="#B95032"
INK="#1F3038"
MUTED="#51636C"
GRID="#D8E0E3"
PALE="#EFF4F5"
WIDTH=174/25.4
ORDERS=(3.5766233766233766,5.423376623376623)
plt.rcParams.update({"font.family":"sans-serif","font.sans-serif":["Arial","Liberation Sans","DejaVu Sans"],
    "font.size":8,"axes.labelsize":8,"axes.titlesize":9,"xtick.labelsize":7.5,
    "ytick.labelsize":7.5,"legend.fontsize":7.3,"axes.linewidth":.6,"axes.edgecolor":MUTED,
    "axes.labelcolor":INK,"text.color":INK,"xtick.color":MUTED,"ytick.color":MUTED,
    "axes.spines.top":False,"axes.spines.right":False,"axes.axisbelow":True,
    "legend.frameon":False,"pdf.fonttype":42,"svg.fonttype":"none","figure.facecolor":"white",
    "savefig.facecolor":"white","xtick.major.size":2.7,"ytick.major.size":2.7})


def panel(ax,letter,title):
    ax.set_title(letter+"   "+title,loc="left",fontweight="bold",pad=7,color=INK)


def quiet_grid(ax):
    ax.grid(axis="y",color=GRID,lw=.47)
    ax.tick_params(width=.6,pad=3)


def f1(read):
    support=read("si/si_hust_support_source.csv")
    s=support[support.kind.eq("selected_source_support")]
    assert len(s)==25 and s.value.sum()==21
    src=read("fig_internal_controls.source_intervals.csv")
    assert set(src.n_states)=={33} and set(src.n_records)=={79}
    ids=read("source_data/fig_paderborn_specimens_bearing_predictions.csv")
    assert ids.bearing_id.nunique()==9
    fig,axs=plt.subplots(1,3,figsize=(WIDTH,91/25.4))
    fig.subplots_adjust(left=.026,right=.992,bottom=.035,top=.955,wspace=.16)
    heads=[("a","NOVIC+","Held-out states"),("b","HUSTbearing","Held-out speed conditions"),
           ("c","Paderborn","Held-out bearings")]
    for ax,(letter,head,sub) in zip(axs,heads):
        ax.set(xlim=(0,1),ylim=(0,1)); ax.set_axis_off()
        ax.text(.0,.97,letter,weight="bold",fontsize=10,va="top")
        ax.text(.11,.97,head,weight="bold",fontsize=10,va="top")
        ax.text(0,.86,sub,fontsize=8.5,color=BLUE,weight="bold")
        ax.plot([0,.98],[.823,.823],color=GRID,lw=.8)
        ax.plot([0,.98],[.26,.26],color=GRID,lw=.8)
    a,b,c=axs
    for i,(count,unit) in enumerate([("101","four-second segments"),("404","eight-turn intervals"),
                                        ("79","recording proxies"),("33","joint states")]):
        y=.735-i*.125
        a.text(0,y,count,color=BLUE,weight="bold",fontsize=13,va="center")
        a.text(.245,y,unit,va="center",fontsize=8)
    a.text(0,.201,"Two fault-presence tasks",weight="bold",fontsize=8.2)
    a.text(0,.14,"Compare representations on\nthe same held-out proxies.\nBearing IDs are unavailable.",va="top",linespacing=1.36)
    cols=["20Hz","30Hz","40Hz","60Hz","VS"]
    if cols[-1] not in set(s.condition): cols[-1]=next(k for k in s.condition.unique() if k not in cols[:-1])
    xx=np.linspace(.45,.94,5)
    b.text(0,.765,"Setting (Hz)",fontsize=7.7,color=MUTED)
    for x,lab in zip(xx,["20","30","40","60","VS"]): b.text(x,.765,lab,ha="center",fontsize=7.5)
    for i,(cls,severity,lab) in enumerate([("H","healthy","Healthy"),("I","medium","Inner, mod."),("I","severe","Inner, sev."),("O","medium","Outer, mod."),("O","severe","Outer, sev.")]):
        y=.687-i*.077
        b.text(0,y,lab,fontsize=7.6,va="center")
        for x,cond in zip(xx,cols):
            v=s[(s.class_name==cls)&(s.severity==severity)&(s.condition==cond)].value.item()
            if v: b.scatter(x,y,s=23,c=BLUE,linewidth=.5,edgecolors=BLUE)
            else: b.plot([x-.014,x+.014],[y,y],color=MUTED,lw=.7)
    b.text(0,.293,"21 acquisitions across five states",fontsize=7.65,color=MUTED)
    b.text(0,.201,"Synthetic disturbance tests",weight="bold",fontsize=8.2)
    b.text(0,.14,"Noise panels reuse these files.\nEach row reuses its bearing\nacross speeds.",va="top",linespacing=1.36)
    for y,cls in zip([.659,.547,.435],["Healthy","Inner","Outer"]): c.text(.0,y,cls,fontsize=7.6,va="center")
    for x0,name in [(0.37,"Development"),(.75,"Test")]:
        c.text(x0+.068,.765,name,ha="center",fontsize=7.7,color=MUTED)
        for y in [.659,.547,.435]:
            for k in range(3): c.scatter(x0+k*.068,y,s=23,facecolor=BLUE if name=="Test" else "white",edgecolors=BLUE,lw=.9)
    c.text(0,.293,"9 development and 9 test IDs",fontsize=7.65,color=MUTED)
    c.text(0,.201,"Two training regimes",weight="bold",fontsize=8.2)
    c.text(0,.14,"Compare Paderborn-trained\nmodels and frozen HUST models\non the same nine test IDs.",va="top",linespacing=1.36)
    return fig,list(axs),{"state_condition_cells":25,"hust_acquisitions":21,"paderborn_test_ids":9}


def f2(read):
    psd,filters,spectra,rms=[read("fig_bandwidth_controls.source_"+key+".csv")
                            for key in ("psd","filters","spectra","rms")]
    assert [len(d) for d in (psd,filters,spectra,rms)]==[51201,15000,2050,237]
    fig,axs=plt.subplots(2,2,figsize=(WIDTH,140/25.4))
    fig.subplots_adjust(left=.101,right=.985,bottom=.105,top=.944,wspace=.44,hspace=.66)
    a,b,c,d=axs.flat
    for ax,letter,title in zip(axs.flat,"abcd",["Measured vibration spectrum","Zero-phase filter response",
            "Eight-turn envelope spectra","Envelope amplitude by carrier band"]):
        panel(ax,letter,title);quiet_grid(ax)
    for left,right,shade in [(.5,2,"#DCEEF2"),(2,5,"#D7E2ED"),(5,10,"#EFE6DB")]:
        a.axvspan(left,right,facecolor=shade,zorder=0,alpha=.75)
    a.plot(psd.frequency_hz/1000,psd.psd_g2_per_hz,color=BLUE,lw=.27,rasterized=True)
    a.axvline(.180,color=RED,ls="--",lw=1)
    a.set(xlim=(0,12.8),yscale="log",ylim=(2e-13,3e-2),xticks=[0,3,6,9,12],
          xlabel="Frequency (kHz)",ylabel="Power density (g²/Hz)")
    a.set_yticks([1e-12,1e-9,1e-6,1e-3],["1e−12","1e−9","1e−6","1e−3"])
    a.yaxis.set_minor_locator(NullLocator())
    for s,col,style,label in [("Raw LP 180 Hz",MUTED,"--","Raw low-pass, 180 Hz"),("Carrier 2–5 kHz",BLUE,"-","Carrier, 2–5 kHz"),("Envelope LP 1 kHz",RED,"-.","Envelope low-pass, 1 kHz")]:
        f=filters[filters["filter"]==s]
        visible=np.ma.masked_less(f.zero_phase_amplitude_db.to_numpy(),-100)
        b.plot(f.frequency_hz,visible,color=col,ls=style,lw=1.25,label=label)
    b.set(xscale="log",xlim=(1,12000),ylim=(-100,5),xlabel="Frequency (Hz)",ylabel="Amplitude gain (dB)",yticks=[-100,-75,-50,-25,0])
    b.set_xticks([1,10,100,1000,10000],["1","10","100","1k","10k"]);b.xaxis.set_minor_locator(NullLocator())
    b.legend(loc="lower left",borderaxespad=.3,handlelength=1.65,labelspacing=.25,frameon=True,edgecolor="none",framealpha=.96)
    for order in ORDERS:
        for k in range(1,4): c.axvline(order*k,ymax=.78,color="#8E9DA3",ls=":",lw=.72)
    for rep,col,style,lab in [("time_envelope",BLUE,"-","Mean-speed time"),("order_envelope",RED,"--","Integrated order")]:
        t=spectra[(spectra.representation==rep)&(spectra.order<=20)]
        c.plot(t.order,t.normalized_bin_energy,color=col,ls=style,lw=.95,label=lab)
    c.set(xlim=(0,20),ylim=(-.003,.182),xticks=[0,5,10,15,20],yticks=[0,.05,.1,.15],
          xlabel="Order (cycles per revolution)",ylabel="Fraction of spectral energy")
    c.legend(loc="upper right",borderaxespad=.3,handlelength=1.6,labelspacing=.25)
    for ix,band in enumerate(["b500_2000","b2000_5000","b5000_10000"]):
        subset=rms[rms.band.str.contains(band)].sort_values("group")
        assert len(subset)==79 and subset.group.nunique()==79
        vals=subset.mean_envelope_rms_g.to_numpy()
        offsets=[(int(hashlib.sha256(name.encode()).hexdigest()[:8],16)/0xffffffff-.5)*.36 for name in subset.group]
        d.scatter(ix+np.array(offsets),vals,s=7,color=BLUE,alpha=.54,edgecolors="none")
        d.plot([ix-.22,ix+.22],[np.median(vals)]*2,color=INK,lw=1.4,zorder=3)
    d.set(xlim=(-.52,2.52),ylim=(.022,2.1),yscale="log",xlabel="Carrier band (kHz)",ylabel="Mean envelope RMS (g)")
    d.set_xticks([0,1,2],["0.5–2","2–5","5–10"]);d.set_yticks([.03,.1,.3,1],["0.03","0.1","0.3","1"]);d.yaxis.set_minor_locator(NullLocator())
    return fig,list(axs.flat),{"rows":[len(d) for d in (psd,filters,spectra,rms)],"proxy_groups":79,"theoretical_BPFO_BPFI_orders":ORDERS}


def f3(read):
    data=read("fig_internal_controls.source_intervals.csv")
    seeds=read("fig_internal_controls.source_all_seed_summaries.csv")
    assert len(data)==64 and len(seeds)==96 and set(data.seed)=={11} and set(data.n_records)=={79} and set(data.n_states)=={33} and set(data.bootstrap_draws)=={2000}
    models=[("extra_trees","Extra Trees"),("random_forest","Random forest"),
            ("state_calibrated_svm","RBF support vector machine"),("logistic","Logistic regression")]
    reps=["metadata_only","native_fullband","time_envelope","time_envelope_meta","order_generic","order_generic_meta","order_geometry","mfos_repository"]
    names=["Metadata  (8)","Native full band  (25)","Time envelope  (111)","Time + metadata  (119)","Order envelope  (99)","Order + metadata  (107)","Order + geometry  (180)","Repository features  (856)"]
    fig,axs=plt.subplots(2,2,figsize=(WIDTH,149/25.4),sharex=True,sharey=True)
    fig.subplots_adjust(left=.245,right=.984,bottom=.145,top=.944,wspace=.20,hspace=.42)
    for j,(ax,(model,title)) in enumerate(zip(axs.flat,models)):
        panel(ax,"abcd"[j],title)
        for y in range(8):
            if y%2==0: ax.axhspan(y-.5,y+.5,facecolor="#F1F5F6",zorder=0)
        for task,offset,col,marker in [("inner_presence",-.155,BLUE,"o"),("outer_presence",.155,RED,"^")]:
            v=data[(data.model==model)&(data.task==task)].set_index("representation").loc[reps]
            y=np.arange(8)+offset
            assert (v.low<=v.estimate).all() and (v.estimate<=v.high).all()
            ax.hlines(y,v.low,v.high,color=col,lw=1.05)
            ax.scatter(v.estimate,y,c=col,marker=marker,s=14,zorder=2.8,edgecolors="white",lw=.3)
        ax.set(xlim=(-.015,1.025),ylim=(7.5,-.5),yticks=range(8),xticks=[0,.25,.5,.75,1])
        ax.set_yticks(range(8),names)
        ax.grid(axis="x",color=GRID,lw=.5)
        ax.tick_params(axis="y",length=0,pad=4)
        ax.tick_params(axis="x",labelbottom=True)
        ax.spines["left"].set_visible(False)
    fig.text(.61,.073,"Held-state macro-F1",ha="center",fontsize=8.5)
    handles=[Line2D([],[],color=col,lw=1.05,marker=mark,markersize=4,label=lab) for col,mark,lab in [
            (BLUE,"o","Inner-fault presence"),(RED,"^","Outer-fault presence")]]
    fig.legend(handles=handles,loc="lower center",bbox_to_anchor=(.61,.001),ncol=2,columnspacing=1.4)
    return fig,list(axs.flat),{"plotted_intervals":len(data),"seed_summary_rows":len(seeds),"bootstrap_draws":2000}


def fs8(read):
    raw=read("fig_measured_timefrequency_3d.source.csv")
    col="psd_source_x_unit_squared_per_hz"
    original=raw.pivot(index="frequency_hz",columns="time_center_s",values=col)
    levels=raw.pivot(index="frequency_hz",columns="time_center_s",values="relative_psd_db")
    psd=original.to_numpy()
    db=levels.to_numpy()
    assert psd.shape==(513,399) and np.isfinite(psd).all() and (psd>0).all()
    err=float(np.max(np.abs(np.maximum(-80,10*np.log10(psd/psd.max()))-db)))
    assert err<1e-7,err
    t=original.columns.to_numpy(); f=original.index.to_numpy()/1000
    assert np.allclose(np.diff(t),.02) and np.allclose(np.diff(f),.025)
    fig=plt.figure(figsize=(WIDTH,148/25.4))
    norm=Normalize(-80,0);cmap=plt.get_cmap("cividis")
    a=fig.add_axes([.025,.492,.922,.490],projection="3d")
    a.set_proj_type("ortho");a.set_box_aspect((2.15,1.52,.69),zoom=1.26)
    a.view_init(elev=42,azim=-62)
    fi=np.unique(np.r_[np.arange(0,len(f),2),len(f)-1]);ti=np.unique(np.r_[np.arange(0,len(t),4),len(t)-1])
    T,F=np.meshgrid(t[ti],f[fi]);Z=db[np.ix_(fi,ti)]
    a.plot_surface(T,F,Z,rstride=1,cstride=1,linewidth=0,edgecolor="none",antialiased=False,rasterized=True,shade=False,cmap=cmap,norm=norm)
    a.set(xlim=(0,8),ylim=(0,12.8),zlim=(-80,0),xticks=[0,2,4,6,8],yticks=[0,6,12],zticks=[-80,-40,0])
    a.set_xlabel("Time (s)",labelpad=3);a.set_ylabel("Frequency (kHz)",labelpad=2)
    a.tick_params(pad=0,labelsize=7.5)
    for axis in (a.xaxis,a.yaxis,a.zaxis):
        axis.pane.fill=False;axis.pane.set_edgecolor(GRID)
        axis._axinfo["grid"].update({"color":(.82,.86,.87,.7),"linewidth":.45})
    fig.text(.045,.968,"a   Measured spectral surface",fontsize=9,weight="bold",ha="left")
    fig.text(.045,.927,"Height and colour: relative PSD (dB)",fontsize=7.8,color=MUTED)
    b=fig.add_axes([.12,.105,.695,.303])
    mesh=b.pcolormesh(t,f,db,shading="nearest",cmap=cmap,norm=norm,rasterized=True)
    b.set(xlim=(.01,7.99),ylim=(0,12.8),xlabel="Time (s)",ylabel="Frequency (kHz)",xticks=[0,2,4,6,8],yticks=[0,3,6,9,12])
    b.set_xlim(0,8)
    fig.text(.045,.442,"b   Full-resolution time–frequency map",fontsize=9,weight="bold",ha="left")
    cb=fig.colorbar(mesh,cax=fig.add_axes([.843,.105,.019,.303]),ticks=[-80,-60,-40,-20,0])
    cb.set_label("Relative PSD (dB)",labelpad=4)
    return fig,[a,b],{"matrix_shape":list(db.shape),"reference_psd":psd.max(),"maximum_dB_difference":err,
                       "surface_shape":list(Z.shape),"planar_bins":int(db.size),"display_range_dB":[-80,0]}


CAPTIONS={
"1":"Figure 1. Evaluation units for the three datasets. (a) The NOVIC+ analysis uses 101 four-second segments from the provider’s subset E test array. The 404 eight-turn intervals are nested within 79 inferred recording proxies in 33 annotated fault/interference states. (b) Filled circles mark the 21 HUST acquisitions used here. Dashes mark unused state–setting combinations. The columns identify four motor-frequency settings and a variable-speed command (VS). Each row represents a healthy or damage-severity state. The same bearing was measured across speeds within each state, and every test acquisition had another acquisition from that state in fitting. (c) Each circle represents one documented Paderborn bearing. Development and test each contained three healthy, three inner-fault and three outer-fault bearings. Four operating conditions repeat within bearing. The test bearings are common to the within-dataset and frozen-transfer evaluations. Manufacturer and health status are confounded in the test set.",
"2":"Figure 2. Signal information retained by conventional and envelope representations. (a) Measured native vibration power spectral density (PSD) for the full four-second NOVIC+ source containing interval novic_E_008_turn00_08_physical_v3, the first inner-positive interval in filename order. Shading marks the 0.5–2, 2–5 and 5–10 kHz carrier bands. The dashed line marks the 180 Hz raw low-pass cutoff. (b) Forward–backward filter amplitude gains, displayed down to −100 dB. (c) The 2–5 kHz carrier envelope for the same eight-turn interval is expressed in mean-speed-equivalent time or integrated measured order. The view shows 0–20 cycles per revolution. Vertical guides mark the first three theoretical outer- and inner-race harmonics. (d) Each dot is the mean envelope RMS for one of 79 recording proxies in a band. Horizontal lines mark medians. Horizontal offsets separate the dots. The compact raw input has 256 points and the envelopes have 2,048. The complete spectral and filter-response series are in the source data.",
"3":"Figure 3. NOVIC+ held-state classification by representation and classifier. The four panels show all 64 seed-11 estimates from 79 held-out recording proxies in 33 joint states. Circles denote inner-fault presence and triangles outer-fault presence. Feature counts are shown in parentheses. Horizontal segments give conditional 95% percentile intervals from 2,000 state-cluster bootstrap draws stratified by the joint fault label, retaining all recording proxies within a sampled state. The intervals condition on fitted models and split assignments. They do not include variation across independently sampled bearings or refitting. Native features retain all samples within each interval. The 856-feature repository comparator is exploratory. SVM scores use the archived window-sigmoid then recording-average rule. Source data also include the 96 available seed-summary rows.",
"S8":"Figure S8. Measured time–frequency power for a healthy HUST acquisition. (a) Orthographic surface of the short-time Fourier transform power spectral density (PSD) for the X vibration channel of H_20Hz, the first healthy file in filename order. The 20 Hz identifier is a motor command. The first eight seconds contain 204,800 samples at 25.6 kHz. Periodic 1,024-sample Hann windows, a 512-sample hop, constant detrending and 1,024-point one-sided density periodograms give 513 frequencies at 25 Hz spacing and 399 frame centres from 0.02 to 7.98 s. The surface uses every second frequency bin and every fourth time frame, including boundary coordinates. (b) The planar map retains all 204,687 cells. In both panels the scale is 10 log₁₀(PSD / record-maximum PSD), with a display floor at −80 dB. Source data retain the unnormalized density and displayed decibel values. This measured example illustrates signal support and was chosen independently of classifier predictions."
}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-zip",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--qa-tools",type=Path)
    opt=parser.parse_args()
    opt.output.mkdir(parents=True,exist_ok=True)
    qa={}
    with ZipFile(opt.source_zip) as archive:
        def read(name):
            return pd.read_csv(io.BytesIO(archive.read("figures/v7/"+name)))
        for file,func in [("Figure_01",f1),("Figure_02",f2),("Figure_03",f3),("Figure_S8",fs8)]:
            fig,axes,details=func(read)
            if opt.qa_tools and file!="Figure_S8":
                import sys
                sys.path.insert(0,str(opt.qa_tools))
                from audit_panel_alignment import require_matplotlib_panel_alignment
                require_matplotlib_panel_alignment(fig,axes=axes,panel_ids=list("abcd"[:len(axes)]),
                      json_out=opt.output/(file+"_alignment.json"))
            if opt.qa_tools and file=="Figure_S8":
                details["layout_note"]="A 3D orthographic box and a full-width planar array have different geometries. The shared scale and endpoints are checked numerically."
            for ext in ("pdf","png"):fig.savefig(opt.output/(file+"."+ext),dpi=450)
            plt.close(fig);qa[file]=details
    parent=opt.output.parent
    (parent/"captions_01_03.json").write_text(json.dumps(CAPTIONS,indent=2,ensure_ascii=False)+"\n",encoding="utf8")
    (parent/"science_checks_01_03.json").write_text(json.dumps(qa,indent=2)+"\n",encoding="utf8")

if __name__=="__main__": main()
