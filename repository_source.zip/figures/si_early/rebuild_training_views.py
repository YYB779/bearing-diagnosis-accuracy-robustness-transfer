"""Reproduce the exact original training_views for the archived measured patch.

This is a NumPy-only copy of the original response/noise/standardization logic;
the PyTorch loss function is unrelated to generating these illustrative views.
No labels, fitted predictions or model selection are used.
"""
from pathlib import Path
import numpy as np
import json,hashlib
HERE=Path(__file__).resolve().parent

def zscore_patch(x):
    x=np.asarray(x,np.float32)
    centered=x-x.mean(axis=-1,keepdims=True)
    scale=np.sqrt(np.mean(centered**2,axis=-1,keepdims=True))
    return centered/np.maximum(scale,1e-8)

def apply_response(x,log_gains):
    x=np.asarray(x,float);g=np.asarray(log_gains,float)
    anchors=np.array([0,2000,4000,8000,12800])/12800
    freq=np.linspace(0,1,x.shape[-1]//2+1)
    multiplier=np.exp(np.stack([np.interp(freq,anchors,row) for row in g]))
    return np.fft.irfft(np.fft.rfft(x,axis=-1)*multiplier,n=x.shape[-1],axis=-1)

def add_noise(x,z,snr_db):
    x=np.asarray(x,float);z=np.asarray(z,float)
    centered=x-x.mean(-1,keepdims=True);noise=z-z.mean(-1,keepdims=True)
    power=np.mean(noise**2,-1,keepdims=True)
    factor=np.sqrt(np.mean(centered**2,-1,keepdims=True)/np.maximum(power,1e-30))
    snr=np.asarray(snr_db,float)
    if snr.ndim==1:snr=snr[:,None]
    return x+noise*factor*10**(-snr/20)

def training_views(x,rng):
    views=[zscore_patch(x)]
    for _ in range(2):
        gains=np.clip(rng.normal(0,.35,size=(len(x),5)),-.7,.7)
        z=rng.normal(size=x.shape);snr=rng.uniform(-4,12,size=len(x))
        views.append(zscore_patch(add_noise(apply_response(x,gains),z,snr).astype(np.float32)))
    return np.stack(views)

if __name__=='__main__':
    with np.load(HERE/'inputs/S4_training_views.npz',allow_pickle=False) as z:
        x=z['source_patch'];expected=z['views']
    actual=training_views(x[None,:],np.random.default_rng(66017))[:,0]
    assert np.array_equal(actual,expected)
    report={'exact_array_equal':True,'shape':list(actual.shape),'view_sha256':hashlib.sha256(actual.tobytes()).hexdigest(),'maximum_abs_difference':float(np.max(np.abs(actual-expected)))}
    (HERE/'qa/S4_training_view_replay.json').write_text(json.dumps(report,indent=2)+'\n')
    print(report)
