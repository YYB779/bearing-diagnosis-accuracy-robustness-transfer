"""Redraw the numerical supplementary figures from the study tables and reconstructed patches.

python supplements_redraw.py --project EXTRACTED_FIGURE_PACKAGE --figures 1 2 3 5 6 7 --output exports
python supplements_redraw.py --project STUDY_SOFTWARE --figures 4 9 --output exports
S4 and S9 require data/processed/v5/hust_neural_patches.npz, which is
reconstructed from the original HUST files. --figures selects individual figures.
Only raster artwork for the time traces is embedded in the output PDFs.
"""

from pathlib import Path
import argparse
import hashlib
import json
import sys
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
from scipy.signal import welch

BLUE, RED, BLACK, GREY = "#176B86", "#B95032", "#23313B", "#78858D"
LIGHT, GRID = "#DDECEF", "#D9DFE2"
WIDTH = 174 / 25.4
SEEDS = [11, 22, 33]
COND = ["20Hz", "30Hz", "40Hz", "60Hz", "VS_0_40_0Hz"]
CLAB = ["20", "30", "40", "60", "Var."]
SOURCES = {
    1: "figures/v7/si/si_same_model_fold_points.csv",
    2: "figures/v7/si/si_hust_support_source.csv",
    3: "figures/v7/si/si_native_hust_source.csv",
    5: "figures/v7/si/si_incremental_gains_source.csv",
    6: "figures/v7/fig_noise_realization_sensitivity.source.csv",
    7: "figures/v8/fig_bearing_deletion.source.csv",
}
CAPTIONS = {
    1: "Known- and held-state discrimination by the same Extra Trees fit. Panels group inner- and outer-fault presence by feature set. Within each of the five rotations, the open circle and filled triangle show the same seed-11 model on separate recording proxies. Fold indices follow the archived zero-based labels. Known- and held-state tests contain different recording proxies and state compositions, so a paired displacement cannot isolate memorization.",
    2: "HUST acquisition support and condition holdout. (a) A filled cell identifies one acquired file in the indicated state and command. A dash marks each unavailable state–command combination. (b) Tr, V and Te denote training, validation and test. All files at a command share a role in a rotation. All 21 test acquisitions have another training acquisition from the same state-associated bearing. (c) Five healthy acquisitions contribute to both severity strata. The bars count files. (d) Within each stratum, the paired difference in macro-F1 compares a fixed-envelope and a low-pass representation with 33 features. The three tree seeds and the calibrated SVM use the same files. Moderate damage was observed at only three of the five commands.",
    3: "Conventional HUST feature controls on the original eight one-second windows per acquisition. Each panel pools predictions on 21 files from five held-out operating conditions. Three open markers are Extra Trees seeds. The filled diamond is the deterministic, recording-calibrated SVM. Numbers in the feature labels are dimensions. Native uses the 25.6 kHz signal, shape removes within-window mean and scale, and fusion appends 99 envelope descriptors. The five healthy acquisitions originate from one healthy bearing measured under five commands. Seed offsets show individual fits.",
    4: "Controlled three-view training. (a) The four arms use the same 66,083-parameter backend, balanced 18-patch batch, three algorithm seeds, five condition rotations and 480 updates. C and D use identical transformed inputs. (b) Ten response curves use five log-gain anchors (standard deviation 0.35, clipped to ±0.7); dotted lines mark the allowed multipliers. The finite-block, phase-preserving transform is circular. (c) Clean and two response-plus-noise views of the first eligible fold-0 training file and patch, chosen without predictions. Each view is standardized separately and displayed on the same scale. Response curves and illustrative training views use seeds 66016 and 66017, respectively.",
    5: "Incremental changes and class-specific HUST failures. (a–c) Each marker is a paired change in file-level macro-F1 on the same panel and algorithm seed. B adds Gaussian exposure, C adds a spectral-response perturbation, and D adds a consistency penalty on the same views. (d,e) Cell labels give correctly classified files over available class files, separately by training arm, seed and held-out command. The two tables show clean inner-race recall and healthy recall on the −4 dB Gaussian panel, respectively. The five healthy files come from one state-associated bearing. The source table retains the corresponding losses and other class recalls.",
    6: "Sensitivity to three additional synthetic-noise draws. Each column holds one noise construction at −4 dB; rows show three-class macro-F1 and healthy recall. Within a method, draw offsets run from bottom to top in the order 7201, 7202 and 7203. Symbols identify model seeds. Blue marks the four exposure arms. Rust marks mixed ERM and DRO, for which the named construction was omitted from fitting and selection. Each point reuses the same 21 measured files, including the five acquisitions of the healthy bearing. Seed and draw repetitions add no physical specimens.",
    7: "Influence of each Paderborn bearing on within-dataset nominal and timestamp-sensitive macro-F1. Circles give the mean over three fitted seeds after dropping the named bearing from the fixed nine-bearing predictions. Dashed vertical lines mark the corresponding full-panel model means. Line segments extend from each full-panel value to its omission value. Because the remaining eight bearings have class counts 2/3/3 in some order, the changes reflect both specimen influence and class composition. The two timing treatments share the same bearings.",
    9: "Time and frequency effects of the synthetic perturbations on one measured HUST X-channel patch. For each row, the gray trace is the earliest 80 ms of H_20Hz.xls and the colored trace is its transformation. Waveforms use the clean mean and standard deviation. The impulse row uses a wider amplitude range. Power spectral densities use the same clean-variance reference and scale (Welch estimate, seven 512-sample Hann segments, 50% overlap, 50 Hz bins). The five additive disturbances use the original fixed panel arrays. The final row uses the response operator alone, with seed 66016.",
}


def theme():
    plt.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 7.1,
            "axes.labelsize": 7.1,
            "axes.titlesize": 8.1,
            "axes.titleweight": "bold",
            "axes.titlelocation": "left",
            "axes.titlepad": 6,
            "axes.labelcolor": BLACK,
            "text.color": BLACK,
            "axes.edgecolor": "#75818A",
            "axes.linewidth": 0.55,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "xtick.labelsize": 6.7,
            "ytick.labelsize": 6.7,
            "xtick.color": BLACK,
            "ytick.color": BLACK,
            "xtick.major.size": 2.2,
            "ytick.major.size": 2.2,
            "axes.axisbelow": True,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "legend.frameon": False,
            "legend.fontsize": 7,
            "figure.facecolor": "white",
            "savefig.facecolor": "white",
        }
    )


def head(ax, letter, title):
    ax.set_title(f"{letter}   {title}", loc="left", pad=7)


def legend(f, markers, labels, colors, bottom=0.008, filled=None, anchor_x=0.5):
    filled = filled or [True] * len(labels)
    handles = [
        Line2D(
            [],
            [],
            marker=m,
            ls="",
            color=c,
            markerfacecolor=c if yes else "white",
            markeredgewidth=1,
            ms=4.8,
        )
        for m, c, yes in zip(markers, colors, filled)
    ]
    f.legend(
        handles,
        labels,
        loc="lower center",
        bbox_to_anchor=(anchor_x, bottom),
        ncol=len(labels),
        columnspacing=1.5,
        handletextpad=0.35,
    )


def dots(ax, x, y, marker="o", color=BLUE, filled=True, size=18):
    ax.scatter(
        x,
        y,
        s=size,
        marker=marker,
        edgecolors=color,
        facecolors=color if filled else "white",
        linewidth=0.85,
        zorder=4,
    )


def matrix(ax, m, cols, rows, labels, cmap, norm=None):
    ax.imshow(
        m,
        cmap=cmap,
        norm=norm,
        aspect="auto",
        interpolation="none",
        vmin=0 if norm is None else None,
        vmax=1 if norm is None else None,
    )
    ax.set(
        xticks=range(len(cols)),
        xticklabels=cols,
        yticks=range(len(rows)),
        yticklabels=rows,
    )
    ax.tick_params(length=0, pad=3)
    ax.spines[:].set_visible(False)
    ax.set_xticks(np.arange(len(cols) + 1) - 0.5, minor=True)
    ax.set_yticks(np.arange(len(rows) + 1) - 0.5, minor=True)
    ax.grid(which="minor", color="white", linewidth=1)
    ax.tick_params(which="minor", length=0)
    for y in range(len(rows)):
        for x in range(len(cols)):
            ax.text(
                x, y, labels[y][x], ha="center", va="center", fontsize=6.6, color=BLACK
            )


def s1(t):
    fig, axes = plt.subplots(2, 3, figsize=(WIDTH, 3.55), sharex=True, sharey=True)
    fig.subplots_adjust(
        left=0.105, right=0.982, top=0.865, bottom=0.225, hspace=0.33, wspace=0.16
    )
    for i, task in enumerate(["inner_presence", "outer_presence"]):
        for j, (rep, title) in enumerate(
            [
                ("native_fullband", "Native bandwidth"),
                ("time_envelope", "Time envelope"),
                ("order_geometry", "Order + geometry"),
            ]
        ):
            ax = axes[i, j]
            d = t[(t.task == task) & (t.representation == rep)].sort_values("protocol")
            assert len(d) == 5
            for k, row in enumerate(d.itertuples()):
                ax.plot(
                    [k - 0.115, k + 0.115],
                    [row.known_f1, row.unknown_f1],
                    lw=1.1,
                    c="#97A7AD",
                )
                dots(ax, k - 0.115, row.known_f1, color=GREY, filled=False, size=18)
                dots(ax, k + 0.115, row.unknown_f1, marker="^", color=BLUE, size=18)
            if i == 0:
                head(ax, "abc"[j], title)
            if i == 1:
                ax.set_xlabel("Rotation")
            if j == 0:
                ax.set_ylabel(
                    ("Inner-fault" if i == 0 else "Outer-fault") + " macro-F1"
                )
            ax.set(
                xlim=(-0.45, 4.45),
                ylim=(0.75, 1.018),
                xticks=range(5),
                yticks=[0.8, 0.9, 1],
            )
            ax.grid(axis="y", color=GRID, lw=0.55)
    legend(
        fig,
        ["o", "^"],
        ["Known states", "Held-out states"],
        [GREY, BLUE],
        filled=[False, True],
    )
    return fig


def s2(t):
    fig = plt.figure(figsize=(WIDTH, 4.5))
    g = fig.add_gridspec(
        2,
        2,
        left=0.175,
        right=0.97,
        bottom=0.15,
        top=0.91,
        wspace=0.7,
        hspace=0.75,
        height_ratios=[1.1, 1],
    )
    ax = fig.add_subplot(g[0, 0])
    d = t[t.panel == "a"]
    states = [
        ("H", "healthy"),
        ("I", "medium"),
        ("I", "severe"),
        ("O", "medium"),
        ("O", "severe"),
    ]
    m = np.array(
        [
            [
                float(
                    d[
                        (d.class_name == cl) & (d.severity == sev) & (d.condition == c)
                    ].value.iloc[0]
                )
                for c in COND
            ]
            for cl, sev in states
        ]
    )
    matrix(
        ax,
        m,
        CLAB,
        [
            "Healthy",
            "Inner, moderate",
            "Inner, severe",
            "Outer, moderate",
            "Outer, severe",
        ],
        np.where(m == 1, "1", "–"),
        ListedColormap(["#F0F2F3", "#A7CDD5"]),
    )
    head(ax, "a", "Acquisitions in the subset")
    ax.set_xlabel("Motor command (Hz)")
    ax = fig.add_subplot(g[0, 1])
    d = t[t.panel == "b"]
    roles = ["train", "validation", "test"]
    m = np.array(
        [
            [
                roles.index(
                    d[(d.test_condition == a) & (d.source_condition == b)].role.iloc[0]
                )
                for b in COND
            ]
            for a in COND
        ]
    )
    matrix(
        ax,
        m,
        CLAB,
        ["Hold " + c for c in CLAB],
        np.array(["Tr", "V", "Te"])[m],
        ListedColormap(["#E7EEEF", "#D4AE92", "#77A8B6"]),
        BoundaryNorm([-0.5, 0.5, 1.5, 2.5], 3),
    )
    head(ax, "b", "Condition roles")
    ax.set_xlabel("Motor command (Hz)")
    ax = fig.add_subplot(g[1, 0])
    d = t[t.panel == "c"].set_index("stratum")
    healthy = int(d.loc["shared_healthy", "value"])
    counts = [int(d.loc[k, "value"]) for k in ("severe_faults", "medium_faults")]
    ax.barh([1, 0], [healthy] * 2, color="#B2BFC5", height=0.46)
    ax.barh([1, 0], counts, left=healthy, color=BLUE, height=0.46)
    for y, n in zip([1, 0], counts):
        ax.text(healthy / 2, y, str(healthy), ha="center", va="center", fontsize=7)
        ax.text(
            healthy + n / 2,
            y,
            str(n),
            ha="center",
            va="center",
            fontsize=7,
            color="white",
        )
    ax.set(
        yticks=[1, 0],
        yticklabels=["Severe stratum", "Moderate stratum"],
        xlabel="Acquisition files",
        xlim=(0, 16),
        xticks=[0, 5, 10, 15],
        ylim=(-0.6, 1.6),
    )
    head(ax, "c", "Shared healthy acquisitions")
    handles = [Patch(color="#B2BFC5"), Patch(color=BLUE)]
    fig.legend(
        handles,
        ["Healthy", "Damaged"],
        loc="lower center",
        bbox_to_anchor=(0.285, 0.009),
        ncol=2,
        handlelength=1.15,
        columnspacing=1.0,
    )
    ax = fig.add_subplot(g[1, 1])
    d = t[t.panel == "d"]
    head(ax, "d", "Envelope minus low-pass")
    for rid, st in enumerate(["healthy_plus_medium", "healthy_plus_severe"]):
        for _, r in d[d.stratum == st].iterrows():
            k = ["11", "22", "33", "deterministic"].index(str(r.seed))
            dots(
                ax,
                r.value,
                rid + [-0.18, -0.06, 0.06, 0.18][k],
                ["o", "s", "^", "D"][k],
                BLUE if k < 3 else RED,
                filled=k == 3,
                size=18,
            )
    ax.axvline(0, lw=0.7, color=GREY)
    ax.set(
        yticks=[1, 0],
        yticklabels=["Severe", "Moderate"],
        xlabel="Paired Δ macro-F1",
        ylim=(-0.5, 1.5),
        xlim=(-0.27, 0.15),
    )
    ax.grid(axis="x", color=GRID, lw=0.55)
    legend(
        fig,
        ["o", "s", "^", "D"],
        ["ET 11", "ET 22", "ET 33", "SVM"],
        [BLUE] * 3 + [RED],
        bottom=0.009,
        filled=[False, False, False, True],
        anchor_x=0.78,
    )
    return fig


def s3(t):
    fig, axes = plt.subplots(1, 3, figsize=(WIDTH, 2.8), sharey=True)
    fig.subplots_adjust(left=0.24, right=0.98, top=0.82, bottom=0.24, wspace=0.22)
    reps = [
        "raw_lowpass_33",
        "single_envelope_33",
        "native_fullband_25",
        "native_shape_25",
        "native_envelope_fusion_124",
    ]
    names = [
        "Low-pass (33)",
        "Envelope (33)",
        "Native (25)",
        "Shape (25)",
        "Native + envelopes (124)",
    ]
    for j, (ax, metric, title) in enumerate(
        zip(
            axes,
            ["macro_f1", "nll", "recall_H"],
            ["Macro-F1", "NLL (nats)", "Healthy recall"],
        )
    ):
        d = t[t.metric == metric]
        for r in d.itertuples():
            k = 3 if r.family == "SVM" else SEEDS.index(int(r.seed))
            dots(
                ax,
                r.value,
                4 - reps.index(r.representation) + [-0.18, -0.06, 0.06, 0.18][k],
                ["o", "s", "^", "D"][k],
                RED if k == 3 else BLUE,
                k == 3,
                18,
            )
        ax.set(yticks=range(5), yticklabels=names[::-1], ylim=(-0.5, 4.5))
        ax.grid(axis="x", color=GRID, lw=0.55)
        head(ax, "abc"[j], title)
        if metric != "nll":
            ax.set(xlim=(-0.015, 1.03), xticks=[0, 0.5, 1])
        else:
            ax.set_xlim(left=0)
    legend(
        fig,
        ["o", "s", "^", "D"],
        ["ET 11", "ET 22", "ET 33", "SVM"],
        [BLUE] * 3 + [RED],
        filled=[False] * 3 + [True],
    )
    return fig


def get_patches(project, file):
    path = file or project / "data/processed/v5/hust_neural_patches.npz"
    if not path.is_file():
        raise FileNotFoundError(
            "Rebuild HUST patches following the software README, or supply --patch-file."
        )
    with np.load(path, allow_pickle=False) as z:
        x, ids = z["x"], z["patch_id"]
    data = pd.read_csv(project / "data/processed/v5/hust_neural_patch_lineage.csv")
    assert x.shape == (672, 2048) and np.array_equal(ids, data.patch_id.to_numpy(str))
    return x, data


def s4(project, x, d):
    from scripts.v6.consistency import training_views

    eligible = d[~d.condition.isin(["20Hz", "30Hz"])].sort_values(
        ["source_record", "start_sample", "patch_id"]
    )
    r = eligible.iloc[0]
    assert r.patch_id == "hust_native_w008_p0"
    v = training_views(
        x[r.name : r.name + 1], np.random.default_rng(66017), "response"
    )[:, 0]
    fig = plt.figure(figsize=(WIDTH, 4.6))
    g = fig.add_gridspec(
        2,
        2,
        left=0.11,
        right=0.978,
        bottom=0.12,
        top=0.94,
        hspace=0.62,
        wspace=0.48,
        height_ratios=[0.85, 1.05],
    )
    ax = fig.add_subplot(g[0, :])
    ax.axis("off")
    head(ax, "a", "Training arms on the same patch and backend")
    data = [
        ["A", "Clean CE", "Clean × 3", "Mean CE"],
        ["B", "Gaussian CE", "Clean + two Gaussian views", "Mean CE"],
        ["C", "Response CE", "Clean + two response/noise views", "Mean CE"],
        ["D", "Response JSD", "Same inputs as C", "Mean CE + 12 JSD"],
    ]
    tbl = ax.table(
        cellText=data,
        colLabels=["Arm", "Training recipe", "Three inputs per update", "Objective"],
        loc="center",
        bbox=(0, 0, 1, 0.97),
        cellLoc="left",
        colLoc="left",
        colWidths=[0.09, 0.24, 0.42, 0.25],
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(7.3)
    for (row, col), c in tbl.get_celld().items():
        c.set_edgecolor("white")
        c.set_facecolor("#D7E7EB" if row == 0 else ("#EFF4F5" if row % 2 else "white"))
        if row == 0 or col == 0:
            c.set_text_props(weight="bold")
    ax = fig.add_subplot(g[1, 0])
    head(ax, "b", "Response multipliers")
    anchors = [0, 2, 4, 8, 12.8]
    freq = np.fft.rfftfreq(2048, 1 / 25600) / 1000
    gains = np.clip(np.random.default_rng(66016).normal(0, 0.35, (10, 5)), -0.7, 0.7)
    for gain in gains:
        ax.plot(
            freq, np.exp(np.interp(freq, anchors, gain)), lw=0.9, color=BLUE, alpha=0.7
        )
    for bound in np.exp([-0.7, 0.7]):
        ax.axhline(bound, ls=":", lw=0.7, color=GREY)
    ax.axhline(1, lw=0.6, color=GREY)
    ax.set(
        xlim=(0, 12.8),
        ylim=(0, 2.12),
        xticks=[0, 4, 8, 12.8],
        xlabel="Frequency (kHz)",
        ylabel="Amplitude multiplier",
    )
    right = g[1, 1].subgridspec(3, 1, hspace=0.28)
    time = np.arange(2048) * 1000 / 25600
    limit = np.ceil(np.abs(v).max())
    for i in range(3):
        ax = fig.add_subplot(right[i])
        ax.plot(time, v[i], lw=0.52, color=GREY if i == 0 else BLUE, rasterized=True)
        ax.set(
            ylim=(-limit, limit),
            yticks=[-limit, limit],
            xlim=(0, 80),
            xticks=[0, 20, 40, 60, 80],
        )
        ax.set_ylabel(["Clean", "View 1", "View 2"][i], fontsize=6.8)
        if i == 0:
            head(ax, "c", "Standardized training views")
        if i < 2:
            ax.tick_params(labelbottom=False)
        else:
            ax.set_xlabel("Time (ms)")
    return fig


def s5(t):
    fig = plt.figure(figsize=(WIDTH, 6.2))
    g = fig.add_gridspec(
        2,
        1,
        top=0.925,
        bottom=0.09,
        left=0.14,
        right=0.97,
        hspace=0.36,
        height_ratios=[1, 1.85],
    )
    top = g[0].subgridspec(1, 3, wspace=0.27)
    bot = g[1].subgridspec(1, 2, wspace=0.57)
    challenges = [
        "clean",
        "AWGN0dB",
        "AWGN-4dB",
        "colored-4dB",
        "impulse-4dB",
        "tone-4dB",
    ]
    labels = ["Clean", "White 0 dB", "White −4 dB", "Colored", "Impulse", "Tone"]
    for i, (panel, title) in enumerate(
        zip("abc", ["Gaussian B−A", "Response C−B", "Consistency D−C"])
    ):
        ax = fig.add_subplot(top[i])
        head(ax, panel, title)
        points = t[(t.figure_panel == panel) & (t.metric == "macro_f1")]
        assert len(points) == 18
        for v in points.itertuples():
            k = SEEDS.index(v.seed)
            dots(
                ax,
                v.value,
                5 - challenges.index(v.challenge) + (k - 1) * 0.14,
                ["o", "s", "^"][k],
                BLUE,
                False,
                13,
            )
        ax.axvline(0, color=GREY, lw=0.65)
        ax.set(
            xlim=(-1, 1),
            xticks=[-1, -0.5, 0, 0.5, 1],
            ylim=(-0.5, 5.5),
            yticks=range(6),
            yticklabels=labels[::-1] if i == 0 else [""] * 6,
            xlabel="Δ macro-F1",
        )
    arms = ["clean_ce", "awgn_ce", "response_ce", "response_jsd"]
    for i, (panel, title) in enumerate(
        zip("de", ["Clean inner-race recall", "White −4 dB healthy recall"])
    ):
        ax = fig.add_subplot(bot[i])
        d = t[(t.kind == "condition_class_recall") & (t.figure_panel == panel)]
        cols = ["20 Hz", "30 Hz", "40 Hz", "60 Hz", "Variable"]
        rows = []
        values = []
        bits = []
        for n, arm in enumerate(arms):
            for seed in SEEDS:
                rr = (
                    d[(d.arm == arm) & (d.seed == seed)]
                    .set_index("condition")
                    .loc[cols]
                )
                rows.append("ABCD"[n] + "  ·  " + str(seed))
                values.append(rr.value.to_numpy())
                bits.append(
                    [
                        f"{int(z.numerator_correct)}/{int(z.denominator_records)}"
                        for z in rr.itertuples()
                    ]
                )
        matrix(
            ax,
            np.asarray(values),
            CLAB,
            rows,
            bits,
            ListedColormap(["#F5DED3", "#EDF1F1", "#B7D8DF"]),
            BoundaryNorm([-0.1, 0.25, 0.75, 1.1], 3),
        )
        for offset in [2.5, 5.5, 8.5]:
            ax.axhline(offset, c="white", lw=2)
        head(ax, panel, title)
        ax.set_xlabel("Held-out command (Hz)")
        ax.set_ylabel("Arm · seed")
    legend(
        fig,
        ["o", "s", "^"],
        ["Seed 11", "Seed 22", "Seed 33"],
        [BLUE] * 3,
        filled=[False] * 3,
    )
    return fig


def s6(t):
    methods = [
        "Clean CE",
        "AWGN CE",
        "Response CE",
        "Response JSD",
        "MixERM (omitted)",
        "MixDRO (omitted)",
    ]
    names = [
        "Clean CE",
        "Gaussian CE",
        "Response CE",
        "Response JSD",
        "Mixed ERM",
        "Mixed DRO",
    ]
    families = ["awgn", "colored", "impulse", "tone"]
    fig, axes = plt.subplots(2, 4, figsize=(WIDTH, 4), sharex=True, sharey=True)
    fig.subplots_adjust(
        left=0.15, right=0.975, bottom=0.205, top=0.865, hspace=0.38, wspace=0.19
    )
    for i, metric in enumerate(["macro_f1", "recall_H"]):
        for j, family in enumerate(families):
            ax = axes[i, j]
            group = t[(t.metric == metric) & (t.family == family)]
            for r in group.itertuples():
                k = SEEDS.index(r.seed)
                v = (r.draw - 7202) * 0.14 + (k - 1) * 0.038
                dots(
                    ax,
                    r.value,
                    5 - methods.index(r.method) + v,
                    ["o", "s", "^"][k],
                    RED if r.study == "v7" else BLUE,
                    False,
                    10,
                )
            ax.axhline(1.5, c=GREY, lw=0.6, ls=":")
            ax.grid(axis="x", color=GRID, lw=0.5)
            ax.set(
                yticks=range(6),
                yticklabels=names[::-1],
                xticks=[0, 0.5, 1],
                xlim=(-0.035, 1.035),
                ylim=(-0.45, 5.45),
            )
            if i == 0:
                head(ax, "abcd"[j], ["White", "Colored", "Impulse", "Tone"][j])
            ax.set_xlabel("Macro-F1" if i == 0 else "Healthy recall")
            ax.tick_params(labelbottom=True)
    legend(
        fig,
        ["o", "s", "^"],
        ["Seed 11", "Seed 22", "Seed 33"],
        [BLUE] * 3,
        filled=[False] * 3,
    )
    return fig


def s7(t):
    configs = [
        ("native25", "extra_trees", "Native ET"),
        ("shape25", "extra_trees", "Shape ET"),
        ("native25", "logistic", "Native logistic"),
        ("shape25", "logistic", "Shape logistic"),
    ]
    bears = sorted(t.deleted_bearing.unique())
    fig, axes = plt.subplots(2, 4, figsize=(WIDTH, 4.65), sharex=True, sharey=True)
    fig.subplots_adjust(
        left=0.12, right=0.98, top=0.88, bottom=0.16, wspace=0.17, hspace=0.47
    )
    for i, timing in enumerate(["nominal", "timestamp_sensitive"]):
        for j, (rep, model, name) in enumerate(configs):
            ax = axes[i, j]
            d = (
                t[(t.timing == timing) & (t.representation == rep) & (t.model == model)]
                .set_index("deleted_bearing")
                .loc[bears]
            )
            base = d.primary_f1.unique()
            assert len(base) == 1
            ax.axvline(base[0], lw=0.8, color=GREY, ls="--")
            for y, val in enumerate(d.deletion_f1):
                z = 8 - y
                ax.plot([base[0], val], [z, z], c="#A3B7BE", lw=0.8)
                dots(ax, val, z, color=BLUE if i == 0 else RED, size=12)
            ax.set(
                yticks=range(9),
                yticklabels=bears[::-1],
                xticks=[0, 0.3, 0.6],
                xlim=(0.0, 0.65),
                ylim=(-0.6, 8.6),
            )
            head(ax, "abcdefgh"[i * 4 + j], name)
            if j == 0:
                ax.set_ylabel("Nominal" if i == 0 else "Timestamp-based")
            if i == 1:
                ax.set_xlabel("Macro-F1")
    return fig


def s9(x, data):
    from scripts.v6.consistency import test_panels, apply_response
    from scripts.revision.plot_disturbances import ROW_HASHES

    row = (
        data[data.class_name.eq("H")]
        .sort_values(["source_record", "start_sample"])
        .iloc[0]
    )
    assert row.source_record == "H_20Hz.xls" and row.start_sample == 0
    source = {k: np.ascontiguousarray(v[row.name]) for k, v in test_panels(x).items()}
    assert {
        k: hashlib.sha256(v.tobytes()).hexdigest() for k, v in source.items()
    } == ROW_HASHES
    clean = source["clean"].astype(float)
    gains = np.clip(np.random.default_rng(66016).normal(0, 0.35, (1, 5)), -0.7, 0.7)
    source["response"] = apply_response(clean[None, :], gains)[0]
    keys = ["AWGN0dB", "AWGN-4dB", "colored-4dB", "impulse-4dB", "tone-4dB", "response"]
    names = [
        "White, 0 dB",
        "White, −4 dB",
        "Colored, −4 dB",
        "Impulse, −4 dB",
        "Tone, −4 dB",
        "Response only",
    ]

    def spectra(v):
        f, p = welch(
            v.astype(float) / clean.std(),
            fs=25600,
            window="hann",
            nperseg=512,
            noverlap=256,
            nfft=512,
            detrend="constant",
            scaling="density",
        )
        return f / 1000, 10 * np.log10(p)

    spectral = {k: spectra(v) for k, v in source.items()}
    body = {
        k: (v.astype(float) - clean.mean()) / clean.std() for k, v in source.items()
    }
    ordinary = np.ceil(
        max(np.max(np.abs(v)) for k, v in body.items() if k != "impulse-4dB")
    )
    wave_t = np.arange(2048) * 1000 / 25600
    lo = 10 * np.floor(min(v[1].min() for v in spectral.values()) / 10)
    hi = 10 * np.ceil(max(v[1].max() for v in spectral.values()) / 10)
    fig, axes = plt.subplots(6, 2, figsize=(WIDTH, 6.25), sharex="col")
    fig.subplots_adjust(
        left=0.16, right=0.98, top=0.923, bottom=0.13, wspace=0.3, hspace=0.40
    )
    for i, key in enumerate(keys):
        ax, bx = axes[i]
        limit = np.ceil(np.max(np.abs(body[key]))) if key == "impulse-4dB" else ordinary
        for label, c, ls in [
            (key, RED if key == "impulse-4dB" else BLUE, "-"),
            ("clean", GREY, "--"),
        ]:
            ax.plot(
                wave_t,
                body[label],
                c=c,
                ls=ls,
                lw=0.45 if label == "clean" else 0.6,
                rasterized=True,
            )
            xx, yy = spectral[label]
            bx.plot(xx, yy, c=c, lw=0.65 if label == "clean" else 0.95, ls=ls)
        ax.set_ylabel(
            names[i], rotation=0, ha="right", va="center", labelpad=12, fontsize=7
        )
        ax.set(ylim=(-limit, limit), xlim=(0, 80), xticks=[0, 20, 40, 60, 80])
        bx.set(ylim=(lo, hi), xlim=(0, 12.8), xticks=[0, 3.2, 6.4, 9.6, 12.8])
        for panel in (ax, bx):
            panel.grid(axis="y", color=GRID, lw=0.48)
        if i == 0:
            head(ax, "a", "Waveform (clean SD units)")
            head(bx, "b", "PSD (dB re clean variance/Hz)")
        if i == 5:
            ax.set_xlabel("Time (ms)")
            bx.set_xlabel("Frequency (kHz)")
    handles = [
        Line2D([], [], c=GREY, ls="--", lw=1),
        Line2D([], [], c=BLUE, lw=1),
        Line2D([], [], c=RED, lw=1),
    ]
    fig.legend(
        handles,
        ["Measured reference", "Transformed patch", "Impulse perturbation"],
        loc="lower center",
        ncol=3,
        bbox_to_anchor=(0.5, 0.005),
        handlelength=1.6,
        columnspacing=1.2,
    )
    return fig


def table_path(project, number):
    """Find the archived CSV in the code repository or an extracted figure-data package."""
    relative = Path(SOURCES[number])
    candidates = [
        project / relative,
        project / "source_csvs" / relative,
        project / "source_csvs" / relative.name,
        project / relative.name,
    ]
    for path in candidates:
        if path.is_file():
            return path
    raise FileNotFoundError(
        f"Figure S{number} requires {relative}. Supply an extracted figure-data package or the study software."
    )


def main(project, output, which, patch_file, captions):
    sys.path.insert(0, str(project.resolve()))
    theme()
    output.mkdir(parents=True, exist_ok=True)
    if 4 in which or 9 in which:
        x, table = get_patches(project, patch_file)
    for n in which:
        if n == 4:
            fig = s4(project, x, table)
        elif n == 9:
            fig = s9(x, table)
        else:
            t = pd.read_csv(table_path(project, n))
            fig = {1: s1, 2: s2, 3: s3, 5: s5, 6: s6, 7: s7}[n](t)
        fig.savefig(
            output / f"Figure_S{n}.pdf",
            dpi=360,
            metadata={"CreationDate": None, "ModDate": None},
        )
        fig.savefig(output / f"Figure_S{n}.png", dpi=300, facecolor="white")
        plt.close(fig)
    if captions:
        captions.write_text(
            json.dumps(
                {f"S{n}": CAPTIONS[n] for n in which}, indent=2, ensure_ascii=False
            )
            + "\n",
            encoding="utf-8",
        )


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--project", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--patch-file", type=Path)
    p.add_argument(
        "--figures", type=int, nargs="+", choices=list(CAPTIONS), default=list(CAPTIONS)
    )
    p.add_argument("--captions", type=Path)
    args = p.parse_args()
    main(args.project, args.output, args.figures, args.patch_file, args.captions)
