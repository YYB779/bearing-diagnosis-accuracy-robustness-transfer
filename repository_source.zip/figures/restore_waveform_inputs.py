"""Restore omitted illustration arrays from independently reconstructed HUST patches."""
import argparse,hashlib,importlib.util,json
from pathlib import Path
import numpy as np
def digest(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()
def mod(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def main():
 p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--patches',type=Path,required=True);p.add_argument('--figures',type=Path,default=Path(__file__).resolve().parent)
 a=p.parse_args();f=a.figures
 with np.load(a.patches,allow_pickle=False) as n:x=n['x'];ids=n['patch_id'].astype(str)
 assert x.shape==(672,2048) and x.dtype==np.float32
 q=json.loads((f/'si_early/inputs/S4_view_provenance.json').read_text(encoding='utf-8'))
 k=np.flatnonzero(ids==q['patch_id']);assert k.size==1
 source=x[int(k[0])];assert digest(source)==q['source_sha256']
 views=mod(f/'si_early/rebuild_training_views.py','training_views_public').training_views(source[None,:],np.random.default_rng(q['rng_seed']))[:,0]
 assert digest(views)==q['view_sha256']
 np.savez_compressed(f/'si_early/inputs/S4_training_views.npz',source_patch=source,views=views,time_ms=np.arange(2048)*(1000/25600))
 original=mod(a.base/'scripts/revision/plot_disturbances.py','disturbances_public')
 k=np.flatnonzero(ids=='hust_native_w048_p0');assert k.size==1
 rows=original.frozen_row(x[int(k[0])])
 q=json.loads((f/'si_late/data/frozen_s9_provenance.json').read_text(encoding='utf-8'))
 assert {k:digest(v) for k,v in rows.items()}==q['hashes']
 clean=rows['clean'].astype(float);gains=np.asarray(q['response_gains'])
 gain=np.interp(np.linspace(0,1,1025),np.array([0,2000,4000,8000,12800])/12800,gains[0])
 rows['response']=np.fft.irfft(np.fft.rfft(clean[None,:],axis=-1)*np.exp(gain),n=2048,axis=-1)[0]
 np.savez_compressed(f/'si_late/data/frozen_s9_signals.npz',**rows)
 report={'status':'PASS','S4_source':digest(source),'S4_views':digest(views),'S9':{k:digest(v) for k,v in rows.items()}}
 (f/'WAVEFORM_RECONSTRUCTION.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
