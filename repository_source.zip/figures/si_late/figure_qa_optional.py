"""Optional local layout audit; absent tools never imply a passed audit.

This adapter belongs to the figure reproduction package. It contains no external
QA implementation and has no dependency on a private filesystem location.
"""
from pathlib import Path
import importlib.util
import json
import sys

_checker = None

def configure_qa(directory=None):
    global _checker
    _checker = None
    if directory is None:
        directory = Path(__file__).resolve().parent / "qa_tools"
    module_file = Path(directory).resolve() / "audit_panel_alignment.py"
    if not module_file.is_file():
        if directory == Path(__file__).resolve().parent / "qa_tools":
            return
        raise FileNotFoundError(f"Explicit QA tool missing: {module_file}")
    spec = importlib.util.spec_from_file_location("audit_panel_alignment", module_file)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    _checker = module.require_matplotlib_panel_alignment

def require_matplotlib_panel_alignment(fig, *, axes, panel_ids, json_out, **kwargs):
    if _checker is not None:
        kwargs.setdefault("strict", True)
        return _checker(fig, axes=axes, panel_ids=panel_ids, json_out=json_out, **kwargs)
    report = {
        "status": "SKIPPED",
        "passed": None,
        "reason": "No optional external QA tools supplied; image export is not an alignment validation.",
        "panel_ids": panel_ids,
        "axes_count": len(axes),
        "historical_reports": "Archived QA reports concern the original submitted figures, not this rerender."
    }
    target = Path(json_out)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return report
