from pathlib import Path
import subprocess,sys,json,concurrent.futures,os
ROOT=Path(__file__).resolve().parent
QA=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/"qa_tools";OUT=ROOT/"qa";OUT.mkdir(exist_ok=True)
def one(n):
 p=ROOT/"exports"/f"Figure_S{n}.pdf"
 results={}
 for typ,cmd in [("text",["audit_pdf_text.py",str(p),"--min-pt","7","--json"]),("collision",["audit_figure_collisions.py",str(p),"--json-out",str(OUT/f"S{n}_collision.json")])]:
  z=subprocess.run([sys.executable,str(QA/cmd[0]),*cmd[1:]],capture_output=True,env={**os.environ,"PYTHONIOENCODING":"utf-8"})
  (OUT/f"S{n}_{typ}.txt").write_bytes(z.stdout+z.stderr);results[typ]=z.returncode
  if typ=="text":(OUT/f"S{n}_text.json").write_bytes(z.stdout)
 return str(n),results
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:r=dict(pool.map(one,range(9,17)))
for p in [ROOT/"render_s9_s16.py",ROOT/"scripts/supplements_s10_s12.py",ROOT/"scripts/advanced_figures.py",ROOT/"scripts/advanced_s15.py"]:
 if p.name.startswith("run_"):continue
 z=subprocess.run([sys.executable,str(QA/"validate_figure.py"),str(p)],capture_output=True,env={**os.environ,"PYTHONIOENCODING":"utf-8"})
 (OUT/(p.stem+"_source.txt")).write_bytes(z.stdout+z.stderr)
(OUT/"summary.json").write_text(json.dumps(r,indent=2),encoding="utf-8");print(json.dumps(r))
