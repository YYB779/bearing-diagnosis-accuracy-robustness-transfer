"""Final-size typography and stroke styling, guarded against data changes."""
from pathlib import Path
import hashlib
import json
import numpy as np
from matplotlib.text import Text
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from matplotlib.collections import Collection, PathCollection

MIN_STROKE_PT = 1.2
MIN_FONT_PT = 7.2

def array_hash(v):
    a=np.asarray(v)
    return {'shape':list(a.shape),'dtype':str(a.dtype),'sha256':hashlib.sha256(a.tobytes()).hexdigest()}

def content_snapshot(fig):
    records=[]
    for ax in fig.axes:
        item={'xlim':list(ax.get_xlim()),'ylim':list(ax.get_ylim()),'xscale':ax.get_xscale(),'yscale':ax.get_yscale(),
              'lines':[],'collections':[],'images':[],'bar_widths':[]}
        if hasattr(ax,'get_zlim'):item['zlim']=list(ax.get_zlim())
        for line in ax.lines:
            item['lines'].append({'x':array_hash(line.get_xdata()),'y':array_hash(line.get_ydata())})
        for c in ax.collections:
            d={'offsets':array_hash(c.get_offsets()),'array':None if c.get_array() is None else array_hash(c.get_array())}
            # 3-D collections retain their world-coordinate vertices separately.
            if hasattr(c,'_vec'):d['world_vertices']=array_hash(c._vec)
            elif not isinstance(c,PathCollection):d['paths']=[array_hash(p.vertices) for p in c.get_paths()]
            item['collections'].append(d)
        for im in ax.images:item['images'].append({'array':array_hash(im.get_array()),'extent':list(im.get_extent()),'clim':list(im.get_clim())})
        for container in ax.containers:
            if hasattr(container,'datavalues'):item['bar_widths'].append(array_hash(container.datavalues))
        records.append(item)
    return records

def prepare_readability(fig,out,stem):
    for ax in fig.axes:
        if hasattr(ax,'zaxis'):
            for axis in [ax.xaxis,ax.yaxis,ax.zaxis]:
                axis.line.set_linewidth(MIN_STROKE_PT)
                axis.pane.set_linewidth(MIN_STROKE_PT)
                axis._axinfo['grid']['linewidth']=MIN_STROKE_PT
                axis._axinfo['tick']['linewidth']={True:MIN_STROKE_PT,False:MIN_STROKE_PT}
    fig.canvas.draw()
    before=content_snapshot(fig)
    for obj in fig.findobj():
        if isinstance(obj,Text):
            obj.set_fontfamily('Arial')
            obj.set_fontsize(max(MIN_FONT_PT,obj.get_fontsize()))
            box=obj.get_bbox_patch()
            if box is not None:box.set_linewidth(max(box.get_linewidth(),MIN_STROKE_PT))
        if isinstance(obj,Line2D):
            if obj.get_linewidth()>0:obj.set_linewidth(max(obj.get_linewidth(),MIN_STROKE_PT))
            if obj.get_markeredgewidth()>0:obj.set_markeredgewidth(max(obj.get_markeredgewidth(),MIN_STROKE_PT))
        elif isinstance(obj,Patch):
            if obj.get_linewidth()>0:obj.set_linewidth(max(obj.get_linewidth(),MIN_STROKE_PT))
        elif isinstance(obj,Collection):
            widths=np.asarray(obj.get_linewidths())
            if len(widths):obj.set_linewidths(np.where(widths>0,np.maximum(widths,MIN_STROKE_PT),0))
            if isinstance(obj,PathCollection) and len(obj.get_sizes()):
                sizes=np.asarray(obj.get_sizes())
                # Uniform scale within each collection keeps area ordering and
                # inverse-entropy encodings; small anchors retain visible fill.
                scale={'Figure_S10':1.2,'Figure_S11':1.3,'Figure_S13':3.0,'Figure_S14':1.3}.get(stem,1.0)
                obj.set_sizes(sizes*scale)
    fig.canvas.draw()
    after=content_snapshot(fig)
    assert before==after,'Scientific arrays or axis ranges changed during styling.'
    report={'figure':stem,'canvas_mm':[fig.get_figwidth()*25.4,fig.get_figheight()*25.4],
            'font':'Arial','minimum_font_pt':MIN_FONT_PT,'minimum_positive_stroke_pt':MIN_STROKE_PT,
            'arrays_axis_ranges_and_bar_values_unchanged':True,
            'content_sha256':hashlib.sha256(json.dumps(after,sort_keys=True).encode()).hexdigest(),
            'content_snapshot':after}
    Path(out,f'{stem}_data_guard.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
