"""Reference-led layout, semantic module banners, protocol strips and data guards."""
from pathlib import Path
import json, hashlib
import numpy as np
from matplotlib.patches import FancyBboxPatch, Rectangle, Polygon, FancyArrowPatch
from matplotlib.text import Text
from matplotlib.lines import Line2D
from matplotlib.collections import Collection
from baseline_style import content_snapshot, prepare_readability as baseline_prepare

NAVY="#275F8F"; INK="#173F59"; BLUE="#D8EAF3"; ROSE="#F5DDDA"; LAV="#E9E1F0"; SAGE="#E0ECDA"; AMBER="#FAEBD0"
INFO={
 9:("Measured patch and synthetic perturbations",["Measured HUST patch","Frozen transformations","Waveform + spectrum"],"Same 80 ms patch; waveform units use the clean SD"),
10:("Bearing-level influence on the held-out score",["Nine fixed bearings","Delete one bearing","Paired score change"],"72 archived deltas across two timing treatments"),
11:("Noise realization and paired method contrasts",["Seeds 11 / 22 / 33","Draws 7201 / 7202 / 7203","DRO minus ERM"],"Each draw reuses the same 21 acquisitions"),
12:("Healthy ranking and the final class decision",["12 frozen policies","Two ranking scores","Original argmax: 0/3"],"Nominal evaluation; seeds 11, 22 and 33"),
13:("Measured signal support and response design",["Measured H_20Hz","Time-frequency support","Synthetic response family"],"Healthy HUST acquisition; archived curves and relative PSD"),
14:("Timing sensitivity in probability space",["Nine held-out bearings","Two timing treatments","Paired probability vectors"],"Within-Paderborn controls; three fitted seeds per recipe"),
15:("Representation-specific challenge response",["Same signal patches","Six challenge panels","F1 + healthy recall"],"Seeds 11, 22, 33; heatmap cells: mean \u00b1 seed SD"),
16:("Signal retention across representation choices",["Measured vibration","Bandwidth + envelope","Retained signal content"],"79 recording proxies; physically interpretable controls")}

def fbox(fig,xywh,face,edge=NAVY,lw=1.1,z=-5,rounding=.005):
 x,y,w,h=xywh
 patch=FancyBboxPatch((x,y),w,h,boxstyle=f"round,pad=0,rounding_size={rounding}",transform=fig.transFigure,facecolor=face,edgecolor=edge,linewidth=lw,zorder=z)
 fig.patches.append(patch);return patch

def prepare_readability(fig,out,stem):
 if getattr(fig,"_redesigned",False): return
 fig._redesigned=True
 n=int(stem.split("S")[-1]); before=content_snapshot(fig)
 oldh=fig.get_figheight(); newh=(185/25.4 if n in [10,16] else min(185/25.4, oldh+23/25.4))
 # Extra top space houses the experimental logic; all existing plot areas retain physical height.
 ratio=min(oldh/newh, .78/max(ax.get_position().y1 for ax in fig.axes)); fig.set_size_inches(185/25.4,newh)
 for ax in fig.axes:
  p=ax.get_position();ax.set_position([p.x0,p.y0*ratio,p.width,p.height*ratio])
 for t in list(fig.texts):
  x,y=t.get_position()
  if y>.88:t.remove()
  else:t.set_position((x,y*ratio))
 for leg in fig.legends:
  b=leg.get_bbox_to_anchor().transformed(fig.transFigure.inverted())
  leg.set_bbox_to_anchor((b.x0,b.y0*ratio),transform=fig.transFigure)
 if n==10:
  for ax,pos in zip(fig.axes,[[.17,.655,.80,.135],[.17,.420,.80,.135],[.17,.13,.33,.19],[.64,.13,.33,.19]]):ax.set_position(pos)
  fig.axes[1].set_yticks(range(4),["Native ET","Native LR","Shape ET","Shape LR"])
  fig.axes[3].tick_params(axis="y",pad=3)
 if n==11:
  for ax in fig.axes[:2]:
   ax.set_xticks(range(4),["White","Colored","Impulse","Sinusoid"],rotation=40,ha="right")
   for c in ax.collections:
    if hasattr(c,"get_sizes"):c.set_edgecolor(c.get_facecolor())
  for leg in fig.legends:
   if "Algorithm seeds" in leg.get_title().get_text():
    b=leg.get_bbox_to_anchor().transformed(fig.transFigure.inverted());leg.set_bbox_to_anchor((b.x0,b.y0-.022),transform=fig.transFigure)
 if n==15:fig.axes[3].tick_params(axis="y",pad=4)
 if n==16:
  for ax,pos in zip(fig.axes,[[.115,.54,.345,.24],[.61,.54,.345,.24],[.115,.18,.345,.24],[.61,.18,.345,.24]]):ax.set_position(pos)
  for idx,x in [(1,.32),(2,.77)]:
   ax=fig.axes[idx];handles,labels=ax.get_legend_handles_labels();ax.get_legend().remove()
   fig.legend(handles,labels,loc="lower center",bbox_to_anchor=(x,.018),fontsize=8,ncol=1,frameon=False,handlelength=2)
 title,steps,note=INFO[n]
 fbox(fig,(.035,.952,.93,.036),NAVY,edge=NAVY,z=0)
 fig.text(.055,.970,title,fontsize=10,fontweight="bold",color="white",va="center")
 # Three stacked-card protocol stages: depth indicates a processing block, not a quantitative axis.
 for i,(lab,face) in enumerate(zip(steps,[BLUE,LAV,SAGE])):
  x=.045+i*.317
  fbox(fig,(x+.006,.883,.276,.047),"white",edge=INK,lw=1.1,z=0,rounding=.002)
  fbox(fig,(x,.878,.276,.047),face,edge=INK,lw=1.1,z=1,rounding=.002)
  fig.text(x+.138,.9015,lab,ha="center",va="center",fontsize=8.2,color=INK,zorder=3)
  if i==1 and n in [12,13]:fig.text(x+.297,.900,"+",ha="center",va="center",fontsize=11,color=INK)
  elif i<2:fig.patches.append(FancyArrowPatch((x+.283,.900),(x+.309,.900),transform=fig.transFigure,arrowstyle="-|>",mutation_scale=9,linewidth=1.1,color=INK))
 fig.text(.5,.851,note,ha="center",va="center",fontsize=8,color=INK)
 # Full blue banners encode panel identity; direct labels keep the data region unobscured.
 for ax in fig.axes:
  if not hasattr(ax,"_module_heading"):continue
  letter,heading=ax._module_heading;p=ax.get_position()
  heading=heading.replace("Time-robust frequency profile","Frequency profile").replace("Paired degradation profile","Paired degradation").replace("Probability concentration","Predictive entropy").replace("Healthy / strongest-fault\nratio AUROC","Ratio-score AUROC").replace("Measured vibration spectrum","Measured PSD").replace("Envelope amplitude by carrier band","Carrier-band amplitude").replace("Eight-turn envelope spectra","Eight-turn envelope").replace("Zero-phase filter response","Zero-phase filters")
  heading=heading.replace("Timestamp timing","HostService timing").replace("\nchallenge panels","").replace("Macro-F1 across","Macro-F1").replace("Healthy recall across","Healthy recall")
  h=15/(newh*72);y=p.y1+4/(newh*72)
  bx,bw=p.x0,p.width
  if n==14 and letter in "abcd":bx=(.14 if letter in "ac" else .60);bw=.365
  # Intentional wide headings aligned on each panel rather than text-width pills.
  fbox(fig,(bx,y,bw,h),NAVY,edge=NAVY,z=0,rounding=.004)
  fig.text(bx+.008,y+h/2,letter+"  "+heading,fontsize=8.2,fontweight="bold",color="white",va="center",ha="left",zorder=5)
 # A dashed perimeter separates the analytical module from the procedural strip.
 # Keep the border outside labels and legends, without chart-area background tint.
 frame=Rectangle((.012,.008),.976,.818,transform=fig.transFigure,facecolor="none",edgecolor=INK,linewidth=1.1,linestyle=(0,(5,4)),zorder=-10)
 fig.patches.append(frame)
 for ax in fig.axes:
  ax.set_facecolor("white")
  if n==14 and getattr(ax,"_module_heading",("",))[0] in "abcd":
   h3=np.sqrt(3)/2;centre=(.5,h3/3)
   sectors=[([(0,0),(.5,0),centre,(.25,h3/2)],SAGE),([(1,0),(.75,h3/2),centre,(.5,0)],BLUE),([(.5,h3),(.25,h3/2),centre,(.75,h3/2)],AMBER)]
   for vertices,face in sectors:ax.add_patch(Polygon(vertices,facecolor=face,edgecolor="none",alpha=.50,zorder=0))
 for obj in fig.findobj():
  if isinstance(obj,Text): obj.set_fontfamily("Arial");obj.set_fontsize(max(8,obj.get_fontsize()))
 # Retain baseline science/stroke checks; only non-data cards/frames were added.
 baseline_prepare(fig,out,stem)
 after=content_snapshot(fig)
 assert before==after, "Scientific artist arrays or axis limits changed"
 Path(out,f"{stem}_data_equivalence.json").write_text(json.dumps({"figure":stem,"scientific_arrays_and_axis_ranges_unchanged":True,"snapshot_sha256":hashlib.sha256(json.dumps(after,sort_keys=True).encode()).hexdigest(),"width_mm":185,"height_mm":newh*25.4,"new_visual_elements":"processing ribbon, full panel headings, dashed analytical module; original data artists re-rendered"},indent=2),encoding="utf-8")
