"""Render S9 and S16 from the unchanged archived signal arrays and source tables."""
from pathlib import Path
import sys,json,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parent))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd
from scipy.signal import welch
from readability_style import prepare_readability
from figure_qa_optional import configure_qa,require_matplotlib_panel_alignment
ROOT=Path(__file__).resolve().parent
BLUE="#2E75B6";RED="#B95C51";GREY="#7A858E";GRID="#D7DEE2";WIDTH=185/25.4
plt.rcParams.update({"font.family":"sans-serif","font.sans-serif":["Arial"],"font.size":8,"axes.labelsize":8,"xtick.labelsize":8,"ytick.labelsize":8,"legend.fontsize":8,"pdf.fonttype":42,"svg.fonttype":"none","axes.spines.top":False,"axes.spines.right":False})
def head(ax,letter,title):
    ax._module_heading=(letter,title)
def s9():
    with np.load(ROOT / "data/frozen_s9_signals.npz") as data:
        source={k:data[k] for k in data.files}
    clean=source["clean"].astype(float)
    keys = ["AWGN0dB", "AWGN-4dB", "colored-4dB", "impulse-4dB", "tone-4dB", "response"]
    names = [
        "White, 0 dB",
        "White, −4 dB",
        "Colored, −4 dB",
        "Impulse, −4 dB",
        "Tone, −4 dB",
        "Response only",
    ]

    def spectra(v):
        f, p = welch(
            v.astype(float) / clean.std(),
            fs=25600,
            window="hann",
            nperseg=512,
            noverlap=256,
            nfft=512,
            detrend="constant",
            scaling="density",
        )
        return f / 1000, 10 * np.log10(p)

    spectral = {k: spectra(v) for k, v in source.items()}
    body = {
        k: (v.astype(float) - clean.mean()) / clean.std() for k, v in source.items()
    }
    ordinary = np.ceil(
        max(np.max(np.abs(v)) for k, v in body.items() if k != "impulse-4dB")
    )
    wave_t = np.arange(2048) * 1000 / 25600
    lo = 10 * np.floor(min(v[1].min() for v in spectral.values()) / 10)
    hi = 10 * np.ceil(max(v[1].max() for v in spectral.values()) / 10)
    fig, axes = plt.subplots(6, 2, figsize=(WIDTH, 6.25), sharex="col")
    fig.subplots_adjust(
        left=0.20, right=0.96, top=0.923, bottom=0.13, wspace=0.3, hspace=0.40
    )
    for i, key in enumerate(keys):
        ax, bx = axes[i]
        limit = np.ceil(np.max(np.abs(body[key]))) if key == "impulse-4dB" else ordinary
        for label, c, ls in [
            (key, RED if key == "impulse-4dB" else BLUE, "-"),
            ("clean", GREY, "--"),
        ]:
            ax.plot(
                wave_t,
                body[label],
                c=c,
                ls=ls,
                lw=0.45 if label == "clean" else 0.6,
                rasterized=True,
            )
            xx, yy = spectral[label]
            bx.plot(xx, yy, c=c, lw=0.65 if label == "clean" else 0.95, ls=ls)
        ax.set_ylabel(
            names[i], rotation=0, ha="right", va="center", labelpad=12, fontsize=8
        )
        ax.set(ylim=(-limit, limit), xlim=(0, 80), xticks=[0, 20, 40, 60, 80])
        bx.set(ylim=(lo, hi), xlim=(0, 12.8), xticks=[0, 3.2, 6.4, 9.6, 12.8])
        for panel in (ax, bx):
            panel.grid(axis="y", color=GRID, lw=0.48)
        if i == 0:
            head(ax, "a", "Waveform (clean SD)")
            head(bx, "b", "PSD (dB re variance/Hz)")
        if i == 5:
            ax.set_xlabel("Time (ms)")
            bx.set_xlabel("Frequency (kHz)")
    handles = [
        Line2D([], [], c=GREY, ls="--", lw=1),
        Line2D([], [], c=BLUE, lw=1),
        Line2D([], [], c=RED, lw=1),
    ]
    fig.legend(
        handles,
        ["Measured reference", "Transformed patch", "Impulse-transformed"],
        loc="lower center",
        ncol=3,
        bbox_to_anchor=(0.5, 0.005),
        handlelength=1.6,
        columnspacing=1.2,
    )
    return fig


def save(fig,n,axes):
 out=ROOT/"exports";stem=f"Figure_S{n}"
 prepare_readability(fig,out,stem)
 require_matplotlib_panel_alignment(fig,axes=axes,panel_ids=[str(i) for i in range(len(axes))],json_out=out/f"{stem}_alignment.json")
 fig.savefig(out/f"{stem}.pdf",dpi=450,metadata={"Creator":"Matplotlib"})
 fig.savefig(out/f"{stem}.svg",metadata={"Creator":"Matplotlib"})
 fig.savefig(out/f"{stem}.png",dpi=300)
 plt.close(fig)

if __name__=="__main__":
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument("--qa-tools",type=Path);args=ap.parse_args();configure_qa(args.qa_tools)
 fig=s9();save(fig,9,fig.axes)
 sys.path.insert(0,str(ROOT/"scripts"));import figure01_03 as m
 m.panel=head;m.WIDTH=WIDTH
 def read(name):return pd.read_csv(ROOT/"data/figures/v7"/name)
 fig,axes,meta=m.f2(read)
 # Restore coherent scientific categories, while retaining every source point.
 for ax in axes:
  ax.set_facecolor("white")
 # Tinted carrier bands in panel a match the three distributions in panel d.
 save(fig,16,axes)
 (ROOT/"exports/Figure_S16.metadata.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
