"""Render the challenge-by-representation map for Supplementary Fig. S15.

The figure uses only the archived same-patch controls table.  It shows the
seed-averaged response matrix, the healthy-recall counterpart, paired changes
relative to the clean panel, and the macro-F1/healthy-recall envelope.  No
model is refit and no new observations are created.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np
import pandas as pd
from zipfile import ZipFile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from figure_qa_optional import configure_qa, require_matplotlib_panel_alignment
from readability_style import prepare_readability

NAVY = "#275F8F"
BLUE = "#2E75B6"
PALE_BLUE = "#D8EAF3"
TEAL = "#78B7A9"
PALE_GREEN = "#E0ECDA"
ORANGE = "#E79B62"
PALE_ORANGE = "#F6E2C6"
PURPLE = "#8C78B8"
CORAL = "#D9796E"
INK = "#173F59"
MUTED = "#5E6B72"
GRID = "#D7DEE2"
WHITE = "#FFFFFF"


def rcparams() -> None:
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "DejaVu Sans"],
        "font.size": 8.0,
        "axes.titlesize": 8.8,
        "axes.labelsize": 8.0,
        "xtick.labelsize": 8.0,
        "ytick.labelsize": 8.0,
        "axes.linewidth": 0.6,
        "axes.edgecolor": MUTED,
        "axes.labelcolor": INK,
        "text.color": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.axisbelow": True,
        "legend.frameon": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "figure.facecolor": WHITE,
        "savefig.facecolor": WHITE,
    })


def panel_title(ax, letter, title, y=1.07):
    ax._module_heading = (letter, title)

def light_grid(ax, axis: str = "both") -> None:
    ax.set_facecolor("#FBFCFC")
    ax.grid(axis=axis, color=GRID, linewidth=0.48, alpha=0.9)
    ax.tick_params(width=0.5, length=2.2, pad=2.4)


def alignment_gate(fig, out: Path, stem: str, axes: list) -> None:
    prepare_readability(fig, out, stem)
    fig.canvas.draw()
    try:
        require_matplotlib_panel_alignment(
            fig, axes=axes,
            panel_ids=list("abcd"[:len(axes)]),
            json_out=out / f"{stem}_alignment.json",
        )
    except Exception as exc:
        (out / f"{stem}_alignment_error.txt").write_text(str(exc), encoding="utf-8")
        raise


def compact_labels() -> tuple[list[str], list[str]]:
    methods = [
        "ET native25", "LR native25", "ET shape25", "LR shape25",
        "WDCNN clean†", "WDCNN AWGN†",
    ]
    labels = ["Native ET", "Native LR", "Shape ET", "Shape LR",
              "WDCNN clean", "WDCNN AWGN"]
    return methods, labels


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-zip", type=Path, required=True)
    ap.add_argument("--out", type=Path, required=True)
    ap.add_argument("--qa-tools", type=Path, help="Optional external alignment-audit directory; omitted means SKIPPED")
    args = ap.parse_args()
    configure_qa(args.qa_tools)
    rcparams()
    args.out.mkdir(parents=True, exist_ok=True)

    with ZipFile(args.source_zip) as zf:
        df = pd.read_csv(zf.open("figures/v7/fig_same_patch_controls.source.csv"))

    methods, labels = compact_labels()
    panels = ["clean", "AWGN-4dB", "AWGN0dB", "colored-4dB", "impulse-4dB", "tone-4dB"]
    # Single-line, compact labels keep the final-size vector audit from
    # treating intentional multiline tick labels as text collisions.
    panel_labels = ["Clean", "AWGN−4", "AWGN0", "Colored−4", "Impulse−4", "Tone−4"]
    # The two small WDCNN labels carry a dagger in the source table; strip
    # that marker only for matching and restore it in the displayed labels.
    df["method_key"] = df["method"].astype(str).str.replace("†", "", regex=False)
    method_keys = [m.replace("†", "") for m in methods]
    df = df[df["method_key"].isin(method_keys) & df["panel"].isin(panels)].copy()
    df["panel"] = pd.Categorical(df["panel"], categories=panels, ordered=True)
    df["method_key"] = pd.Categorical(df["method_key"], categories=method_keys, ordered=True)
    stats = (df.groupby(["method_key", "panel", "metric"], observed=False)["value"]
             .agg(mean="mean", sd="std", n="count").reset_index())

    def matrix(metric: str) -> tuple[np.ndarray, np.ndarray]:
        q = stats[stats.metric == metric]
        means = q.pivot(index="method_key", columns="panel", values="mean").reindex(index=method_keys, columns=panels)
        sds = q.pivot(index="method_key", columns="panel", values="sd").reindex(index=method_keys, columns=panels)
        return means.to_numpy(float), sds.to_numpy(float)

    f1, f1_sd = matrix("macro_f1")
    rh, rh_sd = matrix("recall_H")
    # Difference from the same method's clean control, preserving the seed
    # summary as paired values rather than treating cells as independent.
    clean = df[df.panel == "clean"].set_index(["method_key", "seed", "metric"])["value"]
    delta_rows = []
    for (method_key, panel, metric, seed), row in df.set_index(["method_key", "panel", "metric", "seed"]).iterrows():
        if panel == "clean":
            continue
        try:
            dlt = float(row.value) - float(clean.loc[(method_key, seed, metric)])
        except KeyError:
            continue
        delta_rows.append((method_key, panel, metric, seed, dlt))
    delta = pd.DataFrame(delta_rows, columns=["method_key", "panel", "metric", "seed", "delta"])

    fig = plt.figure(figsize=(185 / 25.4, 180 / 25.4), constrained_layout=False)
    gs = fig.add_gridspec(2, 2, left=0.17, right=0.89, bottom=0.24, top=0.835,
                          wspace=0.32, hspace=0.50)
    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    ax_c = fig.add_subplot(gs[1, 0])
    ax_d = fig.add_subplot(gs[1, 1])
    panel_axes = [ax_a, ax_b, ax_c, ax_d]

    cmap_perf = LinearSegmentedColormap.from_list("perf", ["#F7F1EB", PALE_ORANGE, PALE_BLUE, NAVY], N=256)
    for ax, vals, sds, letter, title in [
        (ax_a, f1, f1_sd, "a", "Macro-F1 across\nchallenge panels"),
        (ax_b, rh, rh_sd, "b", "Healthy recall across\nchallenge panels"),
    ]:
        im = ax.imshow(vals, vmin=0, vmax=1, cmap=cmap_perf, aspect="auto")
        for i in range(vals.shape[0]):
            for j in range(vals.shape[1]):
                if not np.isfinite(vals[i, j]):
                    continue
                sd_txt = "" if not np.isfinite(sds[i, j]) else f"±{sds[i, j]:.2f}"
                # The mean is the primary encoding; seed SD is a compact
                # secondary cue printed below each cell.
                ax.text(j, i - 0.22, f"{vals[i, j]:.2f}", ha="center", va="center", fontsize=8.0, color=(WHITE if vals[i, j] >= 0.75 else INK),
                        fontweight="bold" if vals[i, j] >= 0.8 else "normal")
                if sd_txt:
                    ax.text(j, i + 0.24, sd_txt, ha="center", va="center", fontsize=8.0, color=(WHITE if vals[i, j] >= 0.75 else MUTED))
        ax.set_xticks(range(len(panels)), panel_labels, rotation=60, ha="right")
        ax.set_yticks(range(len(labels)), labels if letter == "a" else [""] * len(labels))
        ax.tick_params(length=0, pad=2.2)
        for x in np.arange(-0.5, len(panels), 1):
            ax.axvline(x, color=WHITE, lw=0.9)
        for y in np.arange(-0.5, len(labels), 1):
            ax.axhline(y, color=WHITE, lw=0.9)
        panel_title(ax, letter, title)

    # A dedicated colorbar axis keeps both heatmap columns the same width as
    # the lower panels, which is needed for the manuscript alignment audit.
    cax = fig.add_axes([0.915, 0.602, 0.014, 0.232])
    cbar = fig.colorbar(im, cax=cax)
    cbar.set_label("Score", fontsize=8.0, labelpad=3)
    cbar.ax.tick_params(labelsize=8.0, width=0.45, length=2)

    method_colors = [NAVY, BLUE, PURPLE, CORAL, TEAL, ORANGE]
    # Panel c: paired drop relative to clean, with a seed-level uncertainty
    # interval.  The clean baseline is therefore exactly zero for every row.
    x = np.arange(1, len(panels))
    for idx, (method_key, label) in enumerate(zip(method_keys, labels)):
        q = delta[(delta.method_key == method_key) & (delta.metric == "macro_f1")]
        means = q.groupby("panel", observed=False).delta.mean().reindex(panels[1:]).to_numpy(float)
        sds = q.groupby("panel", observed=False).delta.std().reindex(panels[1:]).to_numpy(float)
        ax_c.errorbar(x + (idx - 2.5) * 0.035, means, yerr=sds, color=method_colors[idx], marker="o",
                      markersize=3.0, linewidth=0.9, capsize=1.7, alpha=0.90, label=label)
    ax_c.axhline(0, color=MUTED, linewidth=0.65, linestyle=(0, (2, 2)))
    ax_c.set_xticks(x, panel_labels[1:], rotation=60, ha="right")
    ax_c.set_xlim(0.55, 5.45)
    ax_c.set_ylim(-0.9, 0.2)
    ax_c.set_ylabel("Δ macro-F1 vs clean")
    ax_c.set_xlabel("Test disturbance panel")
    light_grid(ax_c, "y")
    panel_title(ax_c, "c", "Paired degradation profile")
    

    # Panel d: the two axes used by the decision, showing how a high macro-F1
    # can coexist with low healthy recall in a disturbed panel.  Clean cells
    # are outlined in black, while disturbances retain their family colors.
    panel_colors = {"clean": INK, "AWGN-4dB": BLUE, "AWGN0dB": BLUE,
                    "colored-4dB": PURPLE, "impulse-4dB": CORAL, "tone-4dB": ORANGE}
    marker_map = {m: mk for m, mk in zip(method_keys, ["o", "s", "^", "D", "P", "X"])}
    for method_key, marker in marker_map.items():
        q = stats[(stats.method_key == method_key) & (stats.metric.isin(["macro_f1", "recall_H"]))]
        qwide = q.pivot(index="panel", columns="metric", values="mean").reindex(panels)
        for panel in panels:
            xx, yy = qwide.loc[panel, "macro_f1"], qwide.loc[panel, "recall_H"]
            if not np.isfinite(xx) or not np.isfinite(yy):
                continue
            ax_d.scatter(xx, yy, s=27, marker=marker, facecolor=panel_colors[panel],
                         edgecolor=(INK if panel == "clean" else WHITE), linewidth=0.75, alpha=0.9, zorder=4)
    ax_d.axvspan(0.1, 0.5, color=PALE_ORANGE, alpha=0.18, zorder=0)
    ax_d.axhline(0.0, color=GRID, lw=0.55)
    ax_d.set_xlim(0.1, 1.02)
    ax_d.set_ylim(-0.04, 1.04)
    ax_d.set_xlabel("Macro-F1")
    ax_d.set_ylabel("Healthy recall", labelpad=14)
    light_grid(ax_d, "both")
    panel_title(ax_d, "d", "Performance envelope")
    handles = [
        Line2D([], [], marker="o", linestyle="none", color="none", markerfacecolor=INK, markeredgecolor=INK, markersize=4.2, label="Clean"),
        Line2D([], [], marker="o", linestyle="none", color="none", markerfacecolor=BLUE, markeredgecolor=WHITE, markersize=4.2, label="AWGN"),
        Line2D([], [], marker="o", linestyle="none", color="none", markerfacecolor=PURPLE, markeredgecolor=WHITE, markersize=4.2, label="Colored"),
        Line2D([], [], marker="o", linestyle="none", color="none", markerfacecolor=CORAL, markeredgecolor=WHITE, markersize=4.2, label="Impulse"),
        Line2D([], [], marker="o", linestyle="none", color="none", markerfacecolor=ORANGE, markeredgecolor=WHITE, markersize=4.2, label="Tone"),
    ]
    # Keep the family key outside the data region so it does not mask the
    # low-recall cells that motivate this diagnostic.
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.53, 0.095),
               ncol=5, fontsize=8.0, handletextpad=0.4, columnspacing=1.2)
    method_handles = [Line2D([], [], color=color, marker=marker_map[key], markersize=4, linewidth=0.9, label=label)
                      for key, label, color in zip(method_keys, labels, method_colors)]
    fig.legend(handles=method_handles, loc="lower center", bbox_to_anchor=(0.53, 0.045),
               ncol=3, fontsize=8.0, handletextpad=0.4, columnspacing=1.5)

    fig.text(0.055, 0.96, "Challenge response is representation- and metric-dependent", fontsize=10.2,
             fontweight="bold", color=INK, ha="left")
    fig.text(0.055, 0.925, "Same-patch controls; values are means over seeds 11, 22 and 33", fontsize=8.0,
             color=MUTED, ha="left")
    fig.text(0.055, 0.900, "Heatmap cells: mean ± seed SD", fontsize=8.0, color=MUTED, ha="left")
    caption = (
        "Supplementary Fig. S15 | Challenge response by representation and training regime. "
        "(a,b) Seed-averaged macro-F1 and healthy recall for the four conventional controls and two WDCNN controls across the clean, Gaussian, colored-noise, impulse and sinusoid panels; each cell is printed as mean ± seed SD. "
        "(c) Paired change in macro-F1 relative to the same method's clean panel, with error bars showing the across-seed SD. "
        "(d) The same means in macro-F1/healthy-recall coordinates; marker shape identifies the method and color identifies the disturbance family. "
        "These are same-patch control diagnostics based on the archived source table; they add no specimens, refitting or independent validation."
    )
    sources = ["figures/v7/fig_same_patch_controls.source.csv"]
    stem = "Figure_S15"
    alignment_gate(fig, args.out, stem, panel_axes)
    fig.savefig(args.out / f"{stem}.pdf", dpi=450, bbox_inches=None, pad_inches=0,
                metadata={"Creator": "Matplotlib", "CreationDate": None})
    fig.savefig(args.out / f"{stem}.svg", bbox_inches=None, pad_inches=0,
                metadata={"Creator": "Matplotlib"})
    fig.savefig(args.out / f"{stem}.png", dpi=300, bbox_inches=None, pad_inches=0, facecolor=WHITE)
    (args.out / f"{stem}.metadata.json").write_text(json.dumps({
        "figure": stem, "caption": caption, "source_paths": sources,
        "numerical_status": "direct visualization of archived same-patch controls; no model refit",
        "metrics": {"n_rows": int(len(df)), "seeds": [11, 22, 33], "methods": labels, "panels": panel_labels},
    }, indent=2, ensure_ascii=False), encoding="utf-8")
    plt.close(fig)
    print(json.dumps({"figure": stem, "out": str(args.out)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
