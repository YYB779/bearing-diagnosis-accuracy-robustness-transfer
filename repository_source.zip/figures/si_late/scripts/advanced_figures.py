"""Advanced manuscript figures from archived source tables.

This module generates two optional, vector-first supplements without touching the
main manuscript:

* Supplementary Fig. S13: measured HUST time-frequency support plus the response
  multiplier family used by the consistency-design stress test.
* Supplementary Fig. S14: Paderborn control predictions in ternary probability
  geometry, with nominal-to-timestamp-sensitive movement and entropy summary.

All plotted values are read directly from the frozen CSV source tables in the
figure source archive. The script does not re-fit models or create observations.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.lines import Line2D
from matplotlib.patches import Polygon
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from figure_qa_optional import configure_qa, require_matplotlib_panel_alignment
from readability_style import prepare_readability

NAVY = "#275F8F"
BLUE = "#2E75B6"
PALE_BLUE = "#D8EAF3"
TEAL = "#78B7A9"
PALE_GREEN = "#E0ECDA"
ORANGE = "#E79B62"
PALE_ORANGE = "#F6E2C6"
PURPLE = "#8C78B8"
PALE_PURPLE = "#E9E1F0"
CORAL = "#D9796E"
INK = "#173F59"
MUTED = "#5E6B72"
GRID = "#D7DEE2"
WHITE = "#FFFFFF"

CLASS_COLORS = {0: TEAL, 1: BLUE, 2: ORANGE}
CLASS_LABELS = {0: "Healthy", 1: "Inner", 2: "Outer"}


def rcparams() -> None:
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "DejaVu Sans"],
        "font.size": 8.0,
        "axes.titlesize": 8.8,
        "axes.labelsize": 8.0,
        "xtick.labelsize": 8.0,
        "ytick.labelsize": 8.0,
        "axes.linewidth": 0.6,
        "axes.edgecolor": MUTED,
        "axes.labelcolor": INK,
        "text.color": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.axisbelow": True,
        "legend.frameon": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "figure.facecolor": WHITE,
        "savefig.facecolor": WHITE,
    })
    # Explicit assignment keeps source-level publication font validation stable.
    plt.rcParams["font.family"] = ["sans-serif"]
    plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans"]
    plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans"]


def panel_title(ax, letter, title, y=1.07):
    ax._module_heading = (letter, title)

def light_grid(ax, axis="both") -> None:
    ax.set_facecolor("#FBFCFC")
    ax.grid(axis=axis, color=GRID, linewidth=0.48, alpha=0.9)
    ax.tick_params(width=0.5, length=2.2, pad=2.5)


def alignment_gate(fig, out: Path, stem: str) -> None:
    prepare_readability(fig, out, stem)
    fig.canvas.draw()
    axes = list(getattr(fig, "_qa_axes", getattr(fig, "axes", [])))
    err_path = out / f"{stem}_alignment_error.txt"
    if err_path.exists():
        err_path.unlink()
    if len(axes) > 1:
        try:
            require_matplotlib_panel_alignment(
                fig, axes=axes,
                panel_ids=list("abcdefghijklmnopqrstuvwxyz"[:len(axes)]),
                json_out=out / f"{stem}_alignment.json",
            )
        except Exception as exc:
            (out / f"{stem}_alignment_error.txt").write_text(str(exc), encoding="utf-8")
            raise


def save_figure(fig, out: Path, stem: str, caption: str, source_paths: list[str]) -> None:
    out.mkdir(parents=True, exist_ok=True)
    alignment_gate(fig, out, stem)
    fig.savefig(out / f"{stem}.pdf", dpi=450, bbox_inches=None, pad_inches=0)
    fig.savefig(out / f"{stem}.svg", bbox_inches=None, pad_inches=0)
    fig.savefig(out / f"{stem}.png", dpi=300, bbox_inches=None, pad_inches=0)
    meta = {
        "figure": stem,
        "caption": caption,
        "source_paths": source_paths,
        "numerical_status": "direct visualization of archived source tables; no model refit",
    }
    (out / f"{stem}.metadata.json").write_text(json.dumps(meta, indent=2, ensure_ascii=False), encoding="utf-8")
    plt.close(fig)


def load_sources(root: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    tf = pd.read_csv(root / "fig_measured_timefrequency_3d.source.csv")
    # The archive was written with GBK-safe multiplication signs; preserve the
    # descriptive arm labels while all numerical columns remain unchanged.
    consistency = pd.read_csv(root / "si" / "si_consistency_design_source.csv", encoding="gbk")
    paderborn = pd.read_csv(root / "source_data" / "fig_paderborn_specimens_bearing_predictions.csv")
    return tf, consistency, paderborn


def response_cmap() -> LinearSegmentedColormap:
    return LinearSegmentedColormap.from_list(
        "response_family", [PALE_PURPLE, PALE_BLUE, TEAL, NAVY, ORANGE], N=256
    )


def plot_s13(tf: pd.DataFrame, consistency: pd.DataFrame, out: Path) -> None:
    # Regular source grid: 399 time centers x 513 frequency bins.
    times = np.sort(tf["time_center_s"].unique())
    freqs = np.sort(tf["frequency_hz"].unique())
    z = tf.pivot(index="time_center_s", columns="frequency_hz", values="relative_psd_db").loc[times, freqs].to_numpy()
    # Keep the surface light enough for PDF viewers while retaining all ridges.
    td = max(1, len(times) // 100)
    fd = max(1, len(freqs) // 130)
    t_small = times[::td]
    f_small = freqs[::fd]
    z_small = z[::td, ::fd]

    fig = plt.figure(figsize=(185 / 25.4, 180 / 25.4), constrained_layout=False)
    gs = fig.add_gridspec(2, 2, left=0.095, right=0.895, bottom=0.095, top=0.855,
                          wspace=0.43, hspace=0.43)
    ax3 = fig.add_subplot(gs[0, 0], projection="3d")
    ax2 = fig.add_subplot(gs[0, 1])
    axprof = fig.add_subplot(gs[1, 0])
    axresp = fig.add_subplot(gs[1, 1])

    cmap = LinearSegmentedColormap.from_list("psd_surface", ["#F4F7F8", PALE_BLUE, "#5F9FC1", NAVY, "#153F5D"], N=256)
    X, Y = np.meshgrid(t_small, f_small / 1000.0, indexing="xy")
    Z = z_small.T
    surf = ax3.plot_surface(X, Y, Z, cmap=cmap, vmin=-80, vmax=0,
                            linewidth=0, antialiased=True, rcount=min(100, Z.shape[0]),
                            ccount=min(120, Z.shape[1]), shade=True)
    ax3.view_init(elev=25, azim=-58)
    ax3.set_box_aspect((1.45, 1.0, 0.70))
    ax3.set_xlabel("Time (s)", labelpad=2)
    ax3.set_ylabel("f (kHz)", labelpad=1)
    ax3.set_zlabel("Relative PSD (dB)", labelpad=3)
    ax3.set_zlim(-80, 0)
    ax3.set_zticks([-80, -40, 0])
    ax3.set_xticks([0, 4, 8])
    ax3.set_yticks([0, 4, 8, 12])
    ax3.tick_params(axis="both", labelsize=8.0, pad=0)
    ax3.tick_params(axis="z", labelsize=8.0, pad=0)
    ax3.xaxis.pane.set_facecolor((0.98, 0.99, 0.99, 1))
    ax3.yaxis.pane.set_facecolor((0.98, 0.99, 0.99, 1))
    ax3.zaxis.pane.set_facecolor((1, 1, 1, 0))
    ax3.set_title("", pad=0)
    panel_title(ax3, "a", "Measured HUST support")

    # Top-down map emphasizes where the 3-D surface is data-supported.
    im = ax2.imshow(z.T, origin="lower", aspect="auto",
                    extent=[times.min(), times.max(), freqs.min() / 1000, freqs.max() / 1000],
                    vmin=-80, vmax=0, cmap=cmap, interpolation="nearest")
    levels = [-60, -40, -20]
    ax2.contour(times, freqs / 1000, z.T, levels=levels, colors=[WHITE] * len(levels), linewidths=0.45, alpha=0.25)
    light_grid(ax2, "both")
    ax2.set_xlabel("Time (s)")
    ax2.set_ylabel("Frequency (kHz)")
    ax2.set_xticks([0, 2, 4, 6, 8])
    ax2.set_yticks([0, 4, 8, 12])
    panel_title(ax2, "b", "Planar projection")
    cb = fig.colorbar(im, ax=ax2, fraction=0.047, pad=0.026)
    cb.set_label("Relative PSD (dB)", fontsize=8.0)
    cb.ax.tick_params(labelsize=8.0, width=0.45, length=2)

    # Robust frequency profile: time quantiles of the measured relative PSD.
    q10, q50, q90 = np.percentile(z, [10, 50, 90], axis=0)
    f_khz = freqs / 1000.0
    light_grid(axprof, "y")
    axprof.fill_between(f_khz, q10, q90, color=PALE_BLUE, alpha=0.95, linewidth=0, label="10-90% across time")
    axprof.plot(f_khz, q50, color=NAVY, linewidth=1.35, label="Median")
    axprof.plot(f_khz, q10, color=BLUE, linewidth=0.45, alpha=0.8)
    axprof.plot(f_khz, q90, color=BLUE, linewidth=0.45, alpha=0.8)
    axprof.axhline(-40, color=MUTED, linewidth=0.55, linestyle=(0, (2, 2)))
    axprof.text(0.02, -43.0, "−40 dB", transform=axprof.get_yaxis_transform(), ha="left", va="top", fontsize=8.0, color=MUTED)
    axprof.set_xlim(0, 12.8)
    axprof.set_ylim(-82, 3)
    axprof.set_xticks([0, 4, 8, 12.8], ["0", "4", "8", "12.8"])
    axprof.set_yticks([-80, -40, 0])
    axprof.set_xlabel("Frequency (kHz)")
    axprof.set_ylabel("Relative PSD (dB)")
    axprof.legend(loc="lower left", fontsize=8.0, handlelength=1.6, labelspacing=0.2)
    panel_title(axprof, "c", "Time-robust frequency profile")

    # Response multipliers are archived consistency-design curves. Plot in log
    # space because the anchor rows are recorded as log_gain.
    resp = consistency[consistency["kind"] == "response_example"].copy()
    anchors = consistency[consistency["kind"] == "response_anchor"].copy()
    resp["log_multiplier"] = np.log(np.clip(resp["multiplier"].to_numpy(dtype=float), 1e-8, None))
    freq_r = np.sort(resp["frequency_hz"].unique()) / 1000.0
    arr = resp.pivot(index="curve", columns="frequency_hz", values="log_multiplier").loc[:, np.sort(resp["frequency_hz"].unique())].to_numpy()
    med = np.nanmedian(arr, axis=0)
    lo, hi = np.nanpercentile(arr, [10, 90], axis=0)
    light_grid(axresp, "y")
    rcmap = response_cmap()
    for i, row in enumerate(arr):
        col = rcmap(i / max(1, arr.shape[0] - 1))
        axresp.plot(freq_r, row, color=col, linewidth=0.62, alpha=0.72)
    axresp.fill_between(freq_r, lo, hi, color=PALE_ORANGE, alpha=0.75, linewidth=0, zorder=0, label="10-90% across curves")
    axresp.plot(freq_r, med, color=INK, linewidth=1.35, zorder=3, label="Median")
    # Anchor points correspond to the same log-gain scale at five archived bins.
    for curve, g in anchors.groupby("curve", sort=True):
        axresp.scatter(g["frequency_hz"] / 1000.0, g["log_gain"], s=6, color=rcmap(float(curve) / 9), edgecolor=WHITE, linewidth=0.25, zorder=4)
    axresp.axhline(0, color=MUTED, linewidth=0.55, linestyle=(0, (2, 2)))
    axresp.set_xlim(0, 12.8)
    axresp.set_ylim(-0.78, 0.78)
    axresp.set_xticks([0, 4, 8, 12.8], ["0", "4", "8", "12.8"])
    axresp.set_yticks([-0.6, 0, 0.6])
    axresp.set_xlabel("Frequency (kHz)")
    axresp.set_ylabel("ln response multiplier")
    # The median and quantile encoding is explained in the figure subtitle;
    # keeping the lower-left plot area free avoids a line crossing legend text.
    panel_title(axresp, "d", "Response-kernel family")

    # Validate the two aligned lower 2-D panels; 3-D projections and the
    # colorbar are intentionally excluded from the generic rectangle check.
    fig._qa_axes = [axprof, axresp]
    fig.text(0.055, 0.965, "Measured signal support and consistency-design response", fontsize=10.2, fontweight="bold", color=INK, ha="left")
    fig.text(0.055, 0.929, "Healthy HUST acquisition (H_20Hz); relative PSD and archived response multipliers", fontsize=8.0, color=MUTED, ha="left")
    caption = (
        "Supplementary Fig. S13 | Measured signal support and response-kernel family. "
        "(a,b) Relative power spectral density for the archived healthy HUST acquisition over the first 8 s, shown as an orthographic surface and its planar projection (display floor −80 dB). "
        "(c) Median and 10-90% time profile of the same measured PSD. "
        "(d) Ten archived frequency-response multiplier curves used by the consistency-design stress test, plotted as ln(multiplier); white-edged points are the five stored response anchors per curve. "
        "No model was refit and no signal was regenerated for this figure."
    )
    sources = [
        "figures/v7/fig_measured_timefrequency_3d.source.csv",
        "figures/v7/si/si_consistency_design_source.csv",
    ]
    save_figure(fig, out, "Figure_S13", caption, sources)


def ternary_xy(p_h: np.ndarray, p_i: np.ndarray, p_o: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    # Vertices are H=(0,0), I=(1,0), O=(0.5,sqrt(3)/2).
    return p_i + 0.5 * p_o, (np.sqrt(3) / 2.0) * p_o


def draw_ternary_frame(ax) -> None:
    h = np.sqrt(3) / 2.0
    tri = np.array([[0, 0], [1, 0], [0.5, h], [0, 0]])
    ax.plot(tri[:, 0], tri[:, 1], color=MUTED, linewidth=0.7, zorder=1)
    # Barycentric guide lines at 0.2 increments.
    for frac in [0.2, 0.4, 0.6, 0.8]:
        # p_H=frac: from p_I=0 to p_O=1-frac
        x1, y1 = ternary_xy(np.array([frac]), np.array([0.0]), np.array([1 - frac]))
        x2, y2 = ternary_xy(np.array([frac]), np.array([1 - frac]), np.array([0.0]))
        ax.plot([x1[0], x2[0]], [y1[0], y2[0]], color=GRID, linewidth=0.38, zorder=0)
        # p_I=frac
        x1, y1 = ternary_xy(np.array([0.0]), np.array([frac]), np.array([1 - frac]))
        x2, y2 = ternary_xy(np.array([1 - frac]), np.array([frac]), np.array([0.0]))
        ax.plot([x1[0], x2[0]], [y1[0], y2[0]], color=GRID, linewidth=0.38, zorder=0)
        # p_O=frac
        x1, y1 = ternary_xy(np.array([0.0]), np.array([1 - frac]), np.array([frac]))
        x2, y2 = ternary_xy(np.array([1 - frac]), np.array([0.0]), np.array([frac]))
        ax.plot([x1[0], x2[0]], [y1[0], y2[0]], color=GRID, linewidth=0.38, zorder=0)
    ax.set_xlim(-0.07, 1.07)
    ax.set_ylim(-0.08, h + 0.10)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xticks([])
    ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)
    ax.text(-0.035, -0.085, "Healthy", ha="left", va="top", fontsize=8.0, color=CLASS_COLORS[0], fontweight="bold")
    ax.text(1.035, -0.085, "Inner", ha="right", va="top", fontsize=8.0, color=CLASS_COLORS[1], fontweight="bold")
    ax.text(0.59, h - 0.01, "Outer", ha="left", va="center", fontsize=8.0, color=CLASS_COLORS[2], fontweight="bold")


def plot_s14(paderborn: pd.DataFrame, out: Path) -> None:
    df = paderborn.copy()
    p = df[["p_H", "p_I", "p_O"]].to_numpy(dtype=float)
    df["entropy"] = -(p * np.log(np.clip(p, 1e-9, 1.0))).sum(axis=1)
    df["pred"] = p.argmax(axis=1)
    recipes = [
        ("native25", "extra_trees", "Native · Extra Trees"),
        ("native25", "logistic", "Native · Logistic"),
        ("shape25", "extra_trees", "Shape · Extra Trees"),
        ("shape25", "logistic", "Shape · Logistic"),
    ]
    fig = plt.figure(figsize=(185 / 25.4, 180 / 25.4), constrained_layout=False)
    gs = fig.add_gridspec(3, 4, left=0.14, right=0.965, bottom=0.175, top=0.855,
                          wspace=0.70, hspace=0.58, height_ratios=[1, 1, 0.90])
    panel_axes = []
    for idx, (rep, model, title) in enumerate(recipes):
        row, col = divmod(idx, 2)
        ax = fig.add_subplot(gs[row, col * 2: col * 2 + 2])
        panel_axes.append(ax)
        draw_ternary_frame(ax)
        sub = df[(df["representation"] == rep) & (df["model"] == model)]
        # Keep the three archived seeds as separate points; pairing is done
        # by bearing ID and seed so no within-bearing averaging is introduced.
        nom = sub[sub["timing"] == "nominal"].set_index(["bearing_id", "seed"])
        ts = sub[sub["timing"] == "timestamp_sensitive"].set_index(["bearing_id", "seed"])
        for key in sorted(nom.index):
            a = nom.loc[key]
            b = ts.loc[key]
            x0, y0 = ternary_xy(np.array([a.p_H]), np.array([a.p_I]), np.array([a.p_O]))
            x1, y1 = ternary_xy(np.array([b.p_H]), np.array([b.p_I]), np.array([b.p_O]))
            c = CLASS_COLORS[int(a.class_id)]
            ax.plot([x0[0], x1[0]], [y0[0], y1[0]], color=c, linewidth=0.65, alpha=0.48, zorder=2)
            # Marker area encodes inverse entropy (more decisive predictions are larger).
            s0 = 15 + 56 * (1 - a.entropy / np.log(3))
            s1 = 15 + 56 * (1 - b.entropy / np.log(3))
            ax.scatter(x0, y0, s=s0, facecolor=c, edgecolor=WHITE, linewidth=0.35, alpha=0.88, zorder=4)
            ax.scatter(x1, y1, s=s1, facecolor=WHITE, edgecolor=c, linewidth=0.85, alpha=0.98, zorder=5)
        acc_n = float((nom.pred == nom.class_id).mean())
        acc_t = float((ts.pred == ts.class_id).mean())
        ent_n = float(nom.entropy.mean())
        ent_t = float(ts.entropy.mean())
        panel_title(ax, chr(ord("a") + idx), title, y=1.08)
        # Per-recipe accuracy and entropy are reported in the bottom summary
        # bars, leaving the simplex itself visually unobstructed.

    # Summary row: paired nominal/timestamp accuracy and entropy by recipe.
    axacc = fig.add_subplot(gs[2, 0:2])
    axent = fig.add_subplot(gs[2, 2:4])
    labels = [r[2].replace(" · ", "\n") for r in recipes]
    y = np.arange(len(recipes))
    acc_nom, acc_ts, ent_nom, ent_ts = [], [], [], []
    for rep, model, _ in recipes:
        sub = df[(df["representation"] == rep) & (df["model"] == model)]
        for timing, arr in [("nominal", acc_nom), ("timestamp_sensitive", acc_ts)]:
            g = sub[sub["timing"] == timing]
            arr.append(float((g["pred"] == g["class_id"]).mean()))
        ent_nom.append(float(sub[sub["timing"] == "nominal"]["entropy"].mean()))
        ent_ts.append(float(sub[sub["timing"] == "timestamp_sensitive"]["entropy"].mean()))
    for ax, vals0, vals1, xlabel, title, xmax in [
        (axacc, acc_nom, acc_ts, "Argmax accuracy", "Decision accuracy", 0.70),
        (axent, ent_nom, ent_ts, "Predictive entropy (nats)", "Probability concentration", 1.10),
    ]:
        light_grid(ax, "x")
        ax.barh(y + 0.23, vals0, height=0.40, color=PALE_BLUE, edgecolor="none", linewidth=0, label="Nominal")
        ax.barh(y - 0.23, vals1, height=0.40, color=PALE_ORANGE, edgecolor="none", linewidth=0, label="Timestamp-sensitive")
        ax.set_yticks(y, labels)
        ax.invert_yaxis()
        ax.set_ylim(3.48, -0.48000000000000004)
        ax.set_xlim(0, xmax * 1.12)
        ax.set_xlabel(xlabel)
        if ax is axent: ax.set_xticks([0, 0.2, 0.4, 0.6, 0.8, 1.0])
        ax.tick_params(axis="y", length=0, pad=4)
        for yi, v0, v1 in zip(y, vals0, vals1):
            fmt = ".2f"
            ax.text(xmax * 1.015, yi + 0.23, f"{v0:{fmt}}", va="center", ha="left", fontsize=8.0, color=INK, clip_on=False)
            ax.text(xmax * 1.015, yi - 0.23, f"{v1:{fmt}}", va="center", ha="left", fontsize=8.0, color=INK, clip_on=False)
    panel_title(axacc, "e", "Decision accuracy", y=1.10)
    panel_title(axent, "f", "Probability concentration", y=1.10)

    from matplotlib.patches import Patch
    fig._qa_axes = panel_axes
    legend_handles = [
        Patch(facecolor=PALE_BLUE, edgecolor=BLUE, linewidth=0.45, label="Nominal"),
        Patch(facecolor=PALE_ORANGE, edgecolor=ORANGE, linewidth=0.45, label="Timestamp-sensitive"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor=WHITE, markeredgecolor=INK, markersize=5.6, label="Timestamp-sensitive point"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor=INK, markeredgecolor=WHITE, markersize=5.6, label="Nominal point"),
        Line2D([0], [0], color=INK, linewidth=0.75, label="Same bearing"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor=CLASS_COLORS[0], markeredgecolor=WHITE, markersize=4.2, label="True healthy"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor=CLASS_COLORS[1], markeredgecolor=WHITE, markersize=4.2, label="True inner"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor=CLASS_COLORS[2], markeredgecolor=WHITE, markersize=4.2, label="True outer"),
    ]
    fig.legend(handles=legend_handles, loc="lower center", bbox_to_anchor=(0.50, 0.025), ncol=4,
               fontsize=8.0, handletextpad=0.34, columnspacing=0.60, frameon=False)
    fig.text(0.055, 0.968, "Paderborn control predictions in probability geometry", fontsize=10.2, fontweight="bold", color=INK, ha="left")
    fig.text(0.055, 0.928, "Within-Paderborn controls; segments link the same bearing under nominal and\ntimestamp-sensitive evaluation", fontsize=8.0, color=MUTED, ha="left")
    caption = (
        "Supplementary Fig. S14 | Paderborn control predictions in ternary probability geometry. "
        "Each panel shows 27 archived probability vectors per timing for one representation/model recipe (nine held-out bearings × three seeds; 54 markers in total), with filled markers for nominal timing and open markers for timestamp-sensitive timing; line segments connect the same bearing. Marker colours encode the archived true class. "
        "Marker area increases as predictive entropy decreases. Bottom summaries report argmax accuracy and mean predictive entropy for the same archived rows. "
        "This is a within-Paderborn conventional control diagnostic and does not represent the frozen HUST cross-dataset test."
    )
    sources = ["figures/v7/source_data/fig_paderborn_specimens_bearing_predictions.csv"]
    save_figure(fig, out, "Figure_S14", caption, sources)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parents[1] / "figures" / "v7")
    ap.add_argument("--out", type=Path, default=Path(__file__).resolve().parents[1] / "advanced_exports")
    ap.add_argument("--qa-tools", type=Path, help="Optional external alignment-audit directory; omitted means SKIPPED")
    args = ap.parse_args()
    configure_qa(args.qa_tools)
    rcparams()
    tf, consistency, paderborn = load_sources(args.source_root)
    plot_s13(tf, consistency, args.out)
    plot_s14(paderborn, args.out)
    print(json.dumps({"out": str(args.out), "figures": ["Figure_S13", "Figure_S14"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
