"""Re-render the manuscript figures with the visual language of the supplied MSSP paper.

The numerical inputs are the frozen source tables in figure_source_data.zip. This
script changes typography, palette and panel emphasis, then adds three
supplementary diagnostic figures that are direct visualizations of existing
revision analyses. It does not create or alter observations.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from zipfile import ZipFile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from figure_qa_optional import configure_qa, require_matplotlib_panel_alignment
from readability_style import prepare_readability

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))




NAVY = "#275F8F"
BLUE = "#2E75B6"
PALE_BLUE = "#D8EAF3"
TEAL = "#78B7A9"
PALE_GREEN = "#E0ECDA"
ORANGE = "#E79B62"
PALE_ORANGE = "#F6E2C6"
PURPLE = "#8C78B8"
PALE_PURPLE = "#E9E1F0"
CORAL = "#D9796E"
INK = "#173F59"
MUTED = "#5E6B72"
GRID = "#D7DEE2"
WHITE = "#FFFFFF"
WIDTH = 185 / 25.4
SEEDS = (11, 22, 33)
EXCL = ("awgn", "colored", "impulse", "tone")
EX_NAMES = ("White Gaussian", "Colored noise", "Sparse impulses", "Sinusoid")
ARMS = ("clean_ce", "awgn_ce", "response_ce", "response_jsd")
ARM_NAMES = ("Clean CE", "Gaussian CE", "Response CE", "Response JSD")


def reference_rcparams() -> None:
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Arial", "DejaVu Sans"],
        "font.size": 8.1,
        "axes.titlesize": 9.2,
        "axes.labelsize": 8.0,
        "xtick.labelsize": 8.0,
        "ytick.labelsize": 8.0,
        "axes.linewidth": 0.65,
        "axes.edgecolor": MUTED,
        "axes.labelcolor": INK,
        "text.color": INK,
        "xtick.color": INK,
        "ytick.color": INK,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.axisbelow": True,
        "legend.frameon": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "figure.facecolor": WHITE,
        "savefig.facecolor": WHITE,
    })
    # Keep the publication-safe family explicit for static figure validation.
    plt.rcParams["font.family"] = ["sans-serif"]
    plt.rcParams["font.sans-serif"] = ["Arial", "DejaVu Sans"]


def alignment_gate(fig, out: Path, stem: str) -> None:
    """Run an explicitly supplied layout audit, or record SKIPPED before export."""
    prepare_readability(fig, out, stem)
    fig.canvas.draw()
    axes = list(getattr(fig, "axes", []))
    if len(axes) > 1:
        require_matplotlib_panel_alignment(
            fig,
            axes=axes,
            panel_ids=list("abcdefghijklmnopqrstuvwxyz"[:len(axes)]),
            json_out=out / f"{stem}_alignment.json",
            **({"row_groups":[["c","d"]],"column_groups":[["a","b"]]} if stem=="Figure_S10" else {}),
        )


def panel_title(ax, letter, title, y=1.07):
    ax._module_heading = (letter, title)

def panel_grid(ax, axis="x") -> None:
    ax.set_facecolor("#FBFCFC")
    ax.grid(axis=axis, color=GRID, linewidth=0.55)
    ax.tick_params(width=0.55, length=2.6, pad=3)


def read_csv(archive: ZipFile, name: str) -> pd.DataFrame:
    return pd.read_csv(archive.open(name))


def s10(archive: ZipFile, out: Path) -> None:
    d = read_csv(archive, "figures/v8/fig_bearing_deletion.source.csv")
    d["recipe"] = d["representation"].map({"native25": "Native25", "shape25": "Shape25"}) + " " + d["model"].map({"extra_trees": "Extra Trees", "logistic": "Logistic"})
    d["delta"] = d["deletion_f1"] - d["primary_f1"]
    bears = ["K004", "K005", "K006", "KI16", "KI18", "KI21", "KA15", "KA16", "KA30"]
    recipes = ["Native25 Extra Trees", "Native25 Logistic", "Shape25 Extra Trees", "Shape25 Logistic"]
    cmap = LinearSegmentedColormap.from_list("delta", [PALE_ORANGE, WHITE, PALE_BLUE])
    norm = TwoSlopeNorm(vmin=float(d.delta.min()), vcenter=0, vmax=float(d.delta.max()))
    fig, axes = plt.subplots(2, 2, figsize=(WIDTH, 150 / 25.4), gridspec_kw={"height_ratios": [1.15, 0.85]})
    fig.subplots_adjust(left=0.18, right=0.98, top=0.91, bottom=0.19, wspace=0.28, hspace=0.55)
    for ax, timing, letter in zip(axes[0], ["nominal", "timestamp_sensitive"], "ab"):
        q = d[d.timing == timing].pivot(index="recipe", columns="deleted_bearing", values="delta").loc[recipes, bears]
        ax.imshow(q.to_numpy(), cmap=cmap, norm=norm, aspect="auto")
        for i in range(q.shape[0]):
            for j in range(q.shape[1]):
                ax.text(j, i, f"{q.iloc[i, j]:+.2f}", ha="center", va="center", fontsize=7.2, color=INK)
        ax.set_xticks(range(9), bears, rotation=45, ha="right", rotation_mode="anchor")
        ax.set_yticks(range(4), ["Native ET", "Native LR", "Shape ET", "Shape LR"] if letter == "a" else [""] * 4)
        ax.tick_params(length=0, pad=2)
        for y in range(1, 4): ax.axhline(y - 0.5, color=WHITE, lw=1)
        panel_title(ax, letter, "Nominal timing" if timing == "nominal" else "Timestamp timing")
        ax.set_xlabel("Deleted bearing")
    for ax, timing, letter in zip(axes[1], ["nominal", "timestamp_sensitive"], "cd"):
        q = d[d.timing == timing]
        for y, recipe in enumerate(recipes):
            z = q[q.recipe == recipe]
            ax.hlines(y, z.delta.min(), z.delta.max(), color=BLUE if "Native" in recipe else PURPLE, lw=2.0)
            ax.scatter(z.delta, np.full(len(z), y), s=18, color=INK, zorder=3)
            ax.scatter(z.delta.mean(), y, s=38, marker="D", color=ORANGE, edgecolor=WHITE, linewidth=0.5, zorder=4)
        ax.axvline(0, color=MUTED, lw=0.8, ls="--")
        ax.set_yticks(range(4), ["Native ET", "Native LR", "Shape ET", "Shape LR"] if letter == "c" else [""] * 4)
        # Keep method labels clear of horizontal range strokes.
        ax.tick_params(axis="y", pad=30)
        ax.set_xlabel("Change after deleting one bearing")
        # Use all archived deltas when choosing the shared display limits.
        # The former fixed [-0.13, 0.13] range clipped eight of 72 values.
        lower = np.floor(float(d.delta.min()) / 0.05) * 0.05 - 0.01
        upper = np.ceil(float(d.delta.max()) / 0.05) * 0.05 + 0.01
        ax.set_xlim(lower, upper)
        assert (d.delta >= lower).all() and (d.delta <= upper).all()
        ax.set_xticks(np.arange(np.ceil(lower / 0.1), np.floor(upper / 0.1) + 1) * 0.1)
        ax.grid(axis="x", color=GRID, lw=0.55)
        panel_title(ax, letter, "Deletion range and mean")
    fig.text(0.50, 0.04, "Δ macro-F1 = deletion score − full nine-bearing score; diamonds mark the mean", ha="center", fontsize=8.0, color=MUTED)
    alignment_gate(fig, out, "Figure_S10")
    fig.savefig(out / "Figure_S10.pdf", dpi=450, metadata={"Creator": "Matplotlib", "CreationDate": None})
    fig.savefig(out / "Figure_S10.svg", metadata={"Creator": "Matplotlib"})
    fig.savefig(out / "Figure_S10.png", dpi=300, facecolor=WHITE)
    plt.close(fig)


def s11(archive: ZipFile, out: Path) -> None:
    """All 432 source rows are additional draws, with no historical-panel rows."""
    d = read_csv(archive, "figures/v7/fig_noise_realization_sensitivity.source.csv")
    family_names = {"awgn": "White Gaussian", "colored": "Colored noise", "impulse": "Sparse impulses", "tone": "Sinusoid"}
    methods = ["Clean CE", "AWGN CE", "Response CE", "Response JSD", "MixERM (omitted)", "MixDRO (omitted)"]
    display = ["Clean CE", "Gaussian CE", "Response CE", "Response JSD", "Mixed ERM", "Mixed DRO"]
    colours = ["#596778", BLUE, TEAL, PURPLE, ORANGE, "#B45F48"]
    markers = ["o", "s", "^", "D", "P", "X"]
    draws, seeds = [7201, 7202, 7203], [11, 22, 33]
    assert len(d) == 432 and set(d.draw) == set(draws) and set(d.seed) == set(seeds)
    assert not d.duplicated(["method", "family", "seed", "draw", "metric"]).any()
    assert np.isfinite(d.value).all()
    fig, axes = plt.subplots(2, 2, figsize=(WIDTH, 158 / 25.4), sharey="row")
    fig.subplots_adjust(left=0.11, right=0.98, top=0.91, bottom=0.245, wspace=0.28, hspace=0.60)
    # The 9 values for each method/family are all shown: 3 algorithm seeds x 3 draws.
    for ax, metric, letter in zip(axes.flat[:2], ["macro_f1", "recall_H"], "ab"):
        for x, fam in enumerate(family_names):
            for m, method in enumerate(methods):
                q = d[(d.family == fam) & (d.metric == metric) & (d.method == method)]
                assert len(q) == 9
                centre = x + (m - 2.5) * 0.12
                xx = centre + (q.draw.to_numpy() - 7202) * 0.024
                ax.scatter(xx, q.value, s=15, marker=markers[m], color=colours[m],
                           alpha=0.82, linewidths=0.35, edgecolors=WHITE, zorder=3)
        ax.set_xticks(range(4), list(family_names.values()), rotation=45, ha="right")
        ax.set_xlim(-0.48, 3.48)
        ax.set_ylabel("Macro-F1" if metric == "macro_f1" else "Healthy recall")
        ax.set_ylim(-0.03, 1.03)
        ax.set_yticks([0, 0.25, 0.5, 0.75, 1], ["0", ".25", ".5", ".75", "1"])
        ax.grid(axis="y", color=GRID, lw=0.5)
        panel_title(ax, letter, "Additional draws · " + ("Macro-F1" if metric == "macro_f1" else "Healthy recall"))
    paired_rows = []
    seed_markers = ["o", "s", "^"]
    for ax, letter, family in zip(axes.flat[2:], "cd", ["tone", "colored"]):
        q = d[(d.family == family) & (d.metric == "macro_f1") & (d.study == "v7")]
        for j, draw in enumerate(draws):
            for k, seed in enumerate(seeds):
                erm = q[(q.draw == draw) & (q.seed == seed) & (q.method == "MixERM (omitted)")].value
                dro = q[(q.draw == draw) & (q.seed == seed) & (q.method == "MixDRO (omitted)")].value
                assert len(erm) == len(dro) == 1
                delta = float(dro.iloc[0] - erm.iloc[0])
                ax.scatter(j + (k - 1) * 0.10, delta, marker=seed_markers[k],
                           facecolor=INK, edgecolor=WHITE, linewidth=0.45, s=28, zorder=4)
                paired_rows.append({"family": family, "draw": draw, "seed": seed, "DRO_minus_ERM": delta})
        ax.axhline(0, color=MUTED, lw=0.8, ls="--", zorder=2)
        ax.set_xticks(range(3), [str(v) for v in draws])
        ax.set_xlabel("Additional noise-draw identifier")
        ax.set_ylabel("DRO − ERM Δ macro-F1")
        ax.set_xlim(-0.45, 2.45)
        ax.set_ylim(-0.09, 0.12)
        ax.set_yticks([-0.05, 0, 0.05, 0.10])
        ax.grid(axis="y", color=GRID, lw=0.5)
        panel_title(ax, letter, family_names[family] + " · paired contrast")
    method_handles = [Line2D([], [], marker=mk, ls="", color=c, markersize=4.5, label=lab)
                      for mk, c, lab in zip(markers, colours, display)]
    seed_handles = [Line2D([], [], marker=mk, ls="", color=INK, markersize=4.5, label=f"Seed {seed}")
                    for mk, seed in zip(seed_markers, seeds)]
    fig.legend(handles=seed_handles, loc="lower center", bbox_to_anchor=(0.56, 0.142),
               ncol=3, frameon=False, fontsize=8.0, title="Algorithm seeds (c, d)", title_fontsize=8.0)
    fig.legend(handles=method_handles, loc="lower center", bbox_to_anchor=(0.55, 0.027),
               ncol=3, frameon=False, fontsize=8.0, columnspacing=1.7, title="Methods (a, b)", title_fontsize=8.0)
    fig.text(0.11, 0.973, "All points use additional noise draws 7201–7203", fontsize=8.0, color=MUTED)
    alignment_gate(fig, out, "Figure_S11")
    fig.savefig(out / "Figure_S11.pdf", dpi=450, metadata={"Creator": "Matplotlib", "CreationDate": None})
    fig.savefig(out / "Figure_S11.svg", metadata={"Creator": "Matplotlib"})
    fig.savefig(out / "Figure_S11.png", dpi=300, facecolor=WHITE)
    pd.DataFrame(paired_rows).to_csv(out / "Figure_S11_paired_contrasts.csv", index=False)
    plt.close(fig)


def s12(archive: ZipFile, out: Path) -> None:
    d = read_csv(archive, "data/healthy_ranking_cells.csv")
    d = d[d.timing == "nominal"].copy()
    labels = ["Clean CE", "Gaussian CE", "Response CE", "Response JSD", "White ERM", "White DRO", "Colored ERM", "Colored DRO", "Impulse ERM", "Impulse DRO", "Tone ERM", "Tone DRO"]
    d["policy"] = np.select([
        (d.excluded == "none") & (d.arm == a) for a in ARMS
    ] + [
        (d.excluded == e) & (d.arm == a) for e in EXCL for a in ["mixed_erm", "mixed_dro"]
    ], labels, default="unknown")
    order = labels
    mat1 = d.pivot(index="policy", columns="seed", values="p_H_auc").loc[order, [11, 22, 33]]
    mat2 = d.pivot(index="policy", columns="seed", values="H_to_strongest_fault_ratio_auc").loc[order, [11, 22, 33]]
    cmap = LinearSegmentedColormap.from_list("auroc", [PALE_ORANGE, WHITE, PALE_GREEN])
    fig, axes = plt.subplots(1, 2, figsize=(WIDTH, 130 / 25.4), sharey=True)
    fig.subplots_adjust(left=0.24, right=0.96, top=0.87, bottom=0.22, wspace=0.22)
    for ax, mat, letter, title in zip(axes, [mat1, mat2], "ab", ["Healthy score AUROC", "Healthy / strongest-fault\nratio AUROC"]):
        ax.imshow(mat.to_numpy(), cmap=cmap, vmin=0, vmax=1, aspect="auto")
        for i in range(mat.shape[0]):
            for j in range(mat.shape[1]): ax.text(j, i, f"{mat.iloc[i, j]:.2f}", ha="center", va="center", fontsize=8.0)
        ax.set_xticks(range(3), ["Seed 11", "22", "33"])
        ax.set_yticks(range(12), order)
        ax.tick_params(axis="y", labelleft=(letter == "a"))
        ax.tick_params(length=0, pad=3)
        for y in [3.5, 5.5, 7.5, 9.5, 11.5]: ax.axhline(y, color=WHITE, lw=1.5)
        panel_title(ax, letter, title)
    fig.text(0.55, 0.07, "All 36 nominal cells assigned 0/3 healthy bearings by argmax;\nrows retain the 12 frozen policies", ha="center", fontsize=8.0, color=MUTED)
    alignment_gate(fig, out, "Figure_S12")
    fig.savefig(out / "Figure_S12.pdf", dpi=450, metadata={"Creator": "Matplotlib", "CreationDate": None})
    fig.savefig(out / "Figure_S12.svg", metadata={"Creator": "Matplotlib"})
    fig.savefig(out / "Figure_S12.png", dpi=300, facecolor=WHITE)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-zip", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--rank-csv", type=Path)
    parser.add_argument("--qa-tools", type=Path, help="Optional external alignment-audit directory; omitted means SKIPPED")
    args = parser.parse_args()
    configure_qa(args.qa_tools)
    args.output.mkdir(parents=True, exist_ok=True)
    reference_rcparams()
    with ZipFile(args.source_zip) as archive:
        s10(archive, args.output)
        s11(archive, args.output)
        s12(archive, args.output)
    print(json.dumps({"output": str(args.output), "figures": sorted(p.name for p in args.output.glob("Figure_*.pdf"))}, indent=2))


if __name__ == "__main__":
    main()
