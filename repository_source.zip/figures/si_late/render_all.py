"""Re-render all S9-S16 figures using the local frozen input files."""
from pathlib import Path
import argparse,subprocess,sys
ROOT=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument("--qa-tools",type=Path);a=ap.parse_args()
q=[] if a.qa_tools is None else ["--qa-tools",str(a.qa_tools.resolve())]
for cmd in [
 ["scripts/supplements_s10_s12.py","--source-zip",str(ROOT/"data_source.zip"),"--output",str(ROOT/"exports")],
 ["scripts/advanced_figures.py","--source-root",str(ROOT/"data/figures/v7"),"--out",str(ROOT/"exports")],
 ["scripts/advanced_s15.py","--source-zip",str(ROOT/"data_source.zip"),"--out",str(ROOT/"exports")],
 ["render_s9_s16.py"]]:subprocess.run([sys.executable,str(ROOT/cmd[0]),*cmd[1:],*q],cwd=ROOT,check=True)
