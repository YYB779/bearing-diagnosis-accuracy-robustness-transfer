Fixed-prediction HUST weighting sensitivity. Python3.9+ standard library only.
Run: python hust_weight_sensitivity.py --software-zip source_data.zip --output outputs
All source CSV bytes are unchanged from analysis softwarev1.0.2. This is a post-result sensitivity, not independent-bearing inference.
The JSON output records the actual input ZIP hash; this compact ZIP differs from the full software archive but contains the same four source tables.
