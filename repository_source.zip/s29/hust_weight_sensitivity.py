"""Re-score archived HUST predictions under three declared weighting schemes.

Python standard library only. No fitting or changes to archived inputs.
Usage: python hust_weight_sensitivity.py --software-zip PATH --output DIR
"""
import argparse
import csv
import hashlib
import io
import json
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean
from zipfile import ZipFile

MEMBERS = {
    "lineage": "data/processed/v5/hust_neural_patch_lineage.csv",
    "classical": "results/v7/classical/record_predictions.csv",
    "exposure": "results/v6/analysis/record_predictions.csv",
    "mixed": "results/v7/analysis/record_predictions.csv",
}
SCHEMES = ("file", "equal_state", "class_preserving_state")
SEEDS = (11, 22, 33)
COMPARISONS = [
    ("H1_native_minus_shape", "clean_native_et", "clean_shape_et"),
    ("H1_wdcnn_minus_native", "clean_wdcnn", "clean_native_et"),
    ("H1_wdcnn_minus_shape", "clean_wdcnn", "clean_shape_et"),
    ("H2_gaussian_minus_clean", "awgn4_awgn_ce", "awgn4_clean_ce"),
    ("H2_response_minus_gaussian", "awgn4_response_ce", "awgn4_awgn_ce"),
    ("H2_jsd_minus_response", "awgn4_response_jsd", "awgn4_response_ce"),
] + [("H3_" + family + "_dro_minus_erm", family + "_mixed_dro", family + "_mixed_erm")
     for family in ("awgn", "colored", "impulse", "tone")]


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_csv(path, rows):
    assert rows
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def run(software_zip, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    tables, source_hashes = {}, {}
    with ZipFile(software_zip) as archive:
        for key, member in MEMBERS.items():
            payload = archive.read(member)
            source_hashes[member] = hashlib.sha256(payload).hexdigest()
            tables[key] = list(csv.DictReader(io.StringIO(payload.decode("utf-8-sig"))))

    records = {}
    for row in tables["lineage"]:
        label = int(row["class_id"])
        severity = {"healthy": "healthy", "medium": "moderate", "severe": "severe"}[row["severity"]]
        state = "healthy" if label == 0 else ("inner" if label == 1 else "outer") + "_" + severity
        unit = row["source_record"]
        record = {"label": label, "state": state, "condition": row["condition"]}
        assert unit not in records or records[unit] == record
        records[unit] = record
    assert len(tables["lineage"]) == 672
    assert set(Counter(row["source_record"] for row in tables["lineage"]).values()) == {32}
    state_counts = Counter(row["state"] for row in records.values())
    assert state_counts == {"healthy": 5, "inner_moderate": 3, "inner_severe": 5,
                            "outer_moderate": 3, "outer_severe": 5}
    class_counts = Counter(row["label"] for row in records.values())
    assert class_counts == {0: 5, 1: 8, 2: 8}
    class_states = {label: len({row["state"] for row in records.values() if row["label"] == label}) for label in (0, 1, 2)}
    weights = {}
    for scheme in SCHEMES:
        for unit, row in records.items():
            denominator = state_counts[row["state"]]
            value = (1.0 if scheme == "file" else 1.0 / denominator
                     if scheme == "equal_state" else class_counts[row["label"]] / class_states[row["label"]] / denominator)
            weights[scheme, unit] = value
    weight_rows = [{"source_record": unit, **records[unit],
                    **{scheme: weights[scheme, unit] for scheme in SCHEMES}} for unit in sorted(records)]
    write_csv(output / "file_weights.csv", weight_rows)

    cells = defaultdict(dict)
    def add(key, row):
        seed, unit = int(row["seed"]), row["source_record"]
        assert seed in SEEDS and unit in records and unit not in cells[key, seed]
        label = int(row.get("class_id", row.get("label")))
        assert label == records[unit]["label"]
        probability = [float(row["p_" + code]) for code in "HIO"]
        prediction = max(range(3), key=lambda k: probability[k])
        cells[key, seed][unit] = (label, prediction)
    for row in tables["classical"]:
        if row["panel"] == "clean" and row["family"] == "extra_trees":
            add({"native25": "clean_native_et", "shape25": "clean_shape_et"}[row["representation"]], row)
    for row in tables["exposure"]:
        if row["role"] != "test":
            continue
        if row["panel"] == "clean" and row["arm"] == "clean_ce":
            add("clean_wdcnn", row)
        if row["panel"] == "AWGN-4dB":
            add("awgn4_" + row["arm"], row)
    panels = {"awgn": "AWGN-4dB", "colored": "colored-4dB", "impulse": "impulse-4dB", "tone": "tone-4dB"}
    for row in tables["mixed"]:
        if row["panel"] == panels[row["excluded"]]:
            add(row["excluded"] + "_" + row["arm"], row)
    expected_keys = {k for _, a, b in COMPARISONS for k in (a, b)}
    assert len(expected_keys) == 15 and len(cells) == 45
    assert set(cells) == {(k, seed) for k in expected_keys for seed in SEEDS}
    assert all(set(rows) == set(records) for rows in cells.values())

    scores, score_rows = {}, []
    for (key, seed), rows in sorted(cells.items()):
        for scheme in SCHEMES:
            matrix = [[0.0] * 3 for _ in range(3)]
            for unit, (label, prediction) in rows.items():
                matrix[label][prediction] += weights[scheme, unit]
            denominators = [sum(matrix[k]) + sum(matrix[j][k] for j in range(3)) for k in range(3)]
            value = mean(2 * matrix[k][k] / denominators[k] if denominators[k] else 0.0 for k in range(3))
            scores[key, seed, scheme] = value
            score_rows.append({"cell": key, "seed": seed, "weighting": scheme, "macro_f1": value,
                               "confusion_matrix": json.dumps(matrix, separators=(",", ":"))})
    write_csv(output / "weighted_scores.csv", score_rows)
    contrast_rows = []
    for contrast, first, second in COMPARISONS:
        for seed in SEEDS:
            for scheme in SCHEMES:
                contrast_rows.append({"contrast": contrast, "first": first, "second": second, "seed": seed,
                                      "weighting": scheme, "paired_delta": scores[first, seed, scheme] - scores[second, seed, scheme]})
    write_csv(output / "paired_weighted_contrasts.csv", contrast_rows)
    summary = []
    for contrast, first, second in COMPARISONS:
        row = {"contrast": contrast, "first": first, "second": second}
        for scheme in SCHEMES:
            deltas = [scores[first, seed, scheme] - scores[second, seed, scheme] for seed in SEEDS]
            row[scheme] = mean(deltas)
            row[scheme + "_seed_min"] = min(deltas)
            row[scheme + "_seed_max"] = max(deltas)
        row["equal_state_minus_file"] = row["equal_state"] - row["file"]
        row["class_preserving_minus_file"] = row["class_preserving_state"] - row["file"]
        summary.append(row)
    write_csv(output / "weighting_sensitivity_summary.csv", summary)
    metadata = {
        "software_zip_sha256": sha(software_zip), "source_table_sha256": source_hashes,
        "script_sha256": sha(__file__), "plan_sha256": sha(Path(__file__).with_name("EQUAL_STATE_PLAN.md"))
        if Path(__file__).with_name("EQUAL_STATE_PLAN.md").is_file() else None,
        "state_counts": dict(state_counts), "class_counts": dict(class_counts),
        "weighting_class_totals": {scheme: {label: sum(weights[scheme, unit] for unit, row in records.items() if row["label"] == label)
                                           for label in (0, 1, 2)} for scheme in SCHEMES},
        "selected_score_cells": len(cells), "per_seed_score_rows": len(score_rows),
        "contrasts": len(COMPARISONS), "per_seed_contrast_rows": len(contrast_rows),
        "history": "Revision-stage post-result sensitivity. Class-total-preserving exploration was inspected first. The equal-state scheme and complete comparison set were then written down before its calculation. All three schemes and all ten comparisons are retained.",
        "inference": "Design standardization on fixed predictions; no new specimens, independent-bearing inference, fitting, p-values or confidence intervals.",
        "summary": summary,
    }
    (output / "weighting_sensitivity.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    return metadata


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--software-zip", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    result = run(args.software_zip, args.output)
    print(json.dumps({"contrasts": result["contrasts"], "summary": result["summary"]}, indent=2))
