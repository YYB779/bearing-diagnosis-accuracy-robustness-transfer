# HUST equal-state sensitivity: specification before this calculation

Date: 2026-11-21. This is a post-result, fixed-prediction sensitivity analysis requested during revision. It is not prospective preregistration.

## Prior information

The primary acquisition-weighted results and source-state counts are already known. Before this plan was requested, a separate exploratory calculation balanced moderate/severe recordings **within each fault class while preserving original class totals 5/8/8**. That exploration did not reverse the examined H1/H2/H3 directions. It is retained as `HUST_STATE_BALANCE_EXPLORATION.csv`. It is not the weighting scheme specified here and will not be relabelled as this analysis or as prespecified work.

## Target quantity and weights

The new target is macro-F1 after giving each of the five documented source states equal total scoring weight: healthy, inner moderate, inner severe, outer moderate, outer severe. Each acquisition receives weight `1/n_state`, where state counts are respectively 5,3,5,3,5. The weighted confusion matrix therefore has total weight five, with true-class support H:I:O = 1:2:2. This is an explicitly chosen design standardization, not a correction establishing independent-bearing inference and not an estimated plant distribution.

Retain the original acquisition-weighted macro-F1 (`w=1` per acquisition; true-class support 5:8:8) beside it. Predictions, argmax decisions, model choices, class labels, file identities and the three algorithm seeds remain fixed. Use declared classes H/I/O for every macro-average. For each seed, form the weighted 3×3 confusion matrix; compute class F1 as `2*TP/(true-class weight + predicted-class weight)` and take their arithmetic mean. Compute paired method differences within seed, then average three differences. Do not average fold-level F1, average probabilities across seeds, pool seeds as observations, or choose weights based on output direction.

The root revision workflow additionally requested that the earlier class-total-preserving exploration remain visible and be reproducible in the same script. Therefore all final outputs will contain **three** schemes: original file weighting; equal total weight per state; and within-class equal-state weighting preserving class totals 5:8:8. In the third scheme, file weights are 1 for healthy, 4/3 for moderate faults and 4/5 for severe faults. Its earlier inspection is explicitly disclosed above; it is not being retrospectively labelled prespecified.

## Complete comparison set

All the following comparisons will be calculated and retained, without selecting favorable ones:

1. Clean HUST: Native Extra Trees − Shape Extra Trees; clean WDCNN − Native Extra Trees; clean WDCNN − Shape Extra Trees. The WDCNN-minus-Native orientation follows H1's direct neural-versus-conventional question. Another independent reviewer supplied the original file-weighted seed differences before this calculation; the equal-state results have not been calculated at the point of this plan amendment.
2. Original AWGN −4 dB panel: AWGN CE − Clean CE; Response CE − AWGN CE; Response JSD − Response CE.
3. Excluded construction, original −4 dB panels: DRO − ERM separately for white Gaussian, colored Gaussian, impulses and tone.

For every comparison, retain all three seeds and all three weighting schemes. Report each scheme's mean paired difference and the change in that difference after standardization. The complete per-seed scores/confusions and file/state weights will be retained. No significance tests, p-values, confidence intervals, refitting, threshold fitting, or new target observations are introduced.

## Input and integrity rules

Read the version1.0.2 software archive directly: the HUST neural patch-lineage table and the v7 classical, v6 exposure and v7 mixed-training record-prediction tables. Derive state identity from documented class/severity metadata, cross-check file labels, retain the complete 21-acquisition panel per policy/seed, and require exact paired file sets. Record SHA-256 of input archive and each source table. Write a standalone script, CSV tables and JSON metadata into this candidate directory. Canonical manuscript, SI and source predictions remain unchanged; the root authoring workflow decides whether to integrate this sensitivity analysis.
