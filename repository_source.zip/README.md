# Browseable software sources
Companion source snapshot for release v2026.11.21 of:
Separating diagnostic accuracy from robustness and transfer in bearing fault diagnosis
Author: Zongyuan Yang.

Repository: https://github.com/YYB779/bearing-diagnosis-accuracy-robustness-transfer

This small source collection preserves relative program paths within base/, addon/, figures/ and s29/. Frozen input tables, checkpoints, configurations and historical evidence are in the four release assets; extract each relevant complete asset for execution. This source-only snapshot is not a self-contained data or model archive.

- base/: original first-party scripts/tests from bearing_diagnosis_software_v1.0.2.zip.
- addon/: portable revision-strengthening scripts and tests from revision_strengthening_v1.1.1_public.zip.
- figures/: custom drawing programs, optional-QA reporting adapter and waveform reconstruction helper from Figure_sources_v3_public.zip.
- s29/: fixed-prediction weighting sensitivity program and plan from hust_weighting_analysis_source.zip.

Use all four asset READMEs and the public variants' PUBLIC_RELEASE_NOTES.md. The base README preserves an earlier eight-figure numbering; the current manuscript has seven main figures and Figures S1–S16, provided by the current figure source asset. Scientific results and sample limitations are unchanged.

MIT applies to first-party software only. No MIT grant is made for data, derived data or model weights. Provider terms and third-party attributions remain in THIRD_PARTY.md; Paderborn covered material retains CC BY-NC 4.0. Original raw measurements, two illustrative HUST NPZ files and third-party QA utilities are excluded. The public figure package gives a locally verified reconstruction procedure for the two illustrative files. No DOI is asserted until an actual repository deposit.

Historical remarks that software licensing was pending are superseded by the author's MIT selection. No reviewer report, response letter, editorial correspondence or manuscript is included in this source-only archive.
