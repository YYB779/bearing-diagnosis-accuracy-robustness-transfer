"""Fixed new-noise tests without retraining or test-based selection."""
from pathlib import Path
import importlib
import numpy as np
import pytest

def api():
 p=Path(__file__).resolve().parents[2]/'scripts/v7/noise_sensitivity.py'
 assert p.exists(),'Noise sensitivity pipeline is not implemented yet'
 return importlib.import_module('scripts.v7.noise_sensitivity')

def test_noise_draws_are_reproducible_and_independent_of_family_loop_order():
 m=api();x=np.random.default_rng(10).normal(size=(8,2048)).astype(np.float32)
 a=m.make_panel(x,'colored',7201);b=m.make_panel(x,'tone',7201);c=m.make_panel(x,'colored',7201)
 np.testing.assert_array_equal(a,c)
 assert not np.array_equal(a,b)
 assert not np.array_equal(a,m.make_panel(x,'colored',7202))

@pytest.mark.parametrize('family',['awgn','colored','impulse','tone'])
def test_noise_exact_snr_uses_centered_patch_power(family):
 m=api();x=np.random.default_rng(2).normal(size=(8,2048)).astype(np.float32)
 p=m.make_panel(x,family,7201);noise=p.astype(float)-x
 signal=x.astype(float)-x.astype(float).mean(1,keepdims=True)
 noise-=noise.mean(1,keepdims=True)
 snr=10*np.log10(np.mean(signal**2,1)/np.mean(noise**2,1))
 np.testing.assert_allclose(snr,-4.,atol=1e-6)

def test_history_is_not_relabeled_unseen_or_pooled_in_new_replicates():
 m=api()
 assert m.DRAW_SEEDS==[7201,7202,7203]
 assert len(m.FAMILIES)==4
 with pytest.raises(ValueError):m.make_panel(np.zeros((2,2048)),'not-a-family',7201)
 with pytest.raises(ValueError):m.make_panel(np.zeros((2,2048)),'awgn',5102026)
