"""Scientific invariants for whole-bearing Paderborn controls."""
from pathlib import Path
import importlib
import numpy as np
import pandas as pd
import pytest


def common():
    assert Path('scripts/v7/paderborn_specimen.py').exists(), 'Specimen protocol implementation missing'
    return importlib.import_module('scripts.v7.paderborn_specimen')


def test_strict_native_length_and_timestamp_coverage_gate():
    m=common();n=256000;t=np.arange(n)/64000;v=np.sin(2*np.pi*3000*t).astype('float32')
    assert m.screen_record(v,t)['eligible']
    assert not m.screen_record(v[:-1],t[:-1])['eligible']
    shifted=t*.999;assert not m.screen_record(v,shifted)['eligible']
    bad=t.copy();bad[100]=bad[99];assert not m.screen_record(v,bad)['eligible']
    badv=v.copy();badv[1]=np.nan;assert not m.screen_record(badv,t)['eligible']


def test_nominal_and_timestamp_paths_agree_for_exact_uniform_clock():
    m=common();n=256000;t=np.arange(n)/64000;v=np.sin(2*np.pi*3000*t).astype('float32')
    a,b=m.make_patch_views(v,t)
    assert a.shape==b.shape==(16,2048) and a.dtype==b.dtype==np.float32
    assert np.array_equal(a,b)
    with pytest.raises(ValueError):m.make_patch_views(v[:-1],t[:-1])


def test_clock_sensitivity_is_interpolation_not_label_or_amplitude_normalization():
    m=common();n=260000;t=np.arange(n)/65000;v=(2+3*np.sin(2*np.pi*3000*t)).astype('float32')
    a,b=m.make_patch_views(v,t)
    assert not np.array_equal(a,b)
    assert np.mean(a)>1 and np.mean(b)>1


def fixture_frame():
    m=common();rows=[]
    for bearing in m.DEV_IDS:
        for condition in m.CONDITIONS:
            # Deliberately unequal recording support across conditions.
            for run in range(1,2+(condition==m.CONDITIONS[0])):
                for patch in range(16):
                    rows.append(dict(bearing_id=bearing,class_id=m.LABELS[bearing],condition=condition,
                        run=run,file_id=f'{condition}_{bearing}_{run}',patch_index=patch,role='development'))
    return pd.DataFrame(rows)


def test_cv_holds_complete_three_bearing_fold_and_never_test_specimens():
    m=common();f=fixture_frame()
    seen=[]
    for k in range(3):
        tr,va=m.development_partition(f,k)
        a=set(f.iloc[tr].bearing_id);b=set(f.iloc[va].bearing_id)
        assert len(a)==6 and len(b)==3 and not a&b
        assert set(f.iloc[va].class_id)=={0,1,2};seen.extend(b)
    assert sorted(seen)==sorted(m.DEV_IDS)
    fresh=f.iloc[:16].copy();fresh['bearing_id']='K004';fresh['role']='test'
    with pytest.raises(ValueError):m.development_partition(pd.concat([f,fresh]),0)


def test_training_weights_equalize_specimens_and_conditions_with_missing_runs():
    m=common();f=fixture_frame();w=m.training_weights(f)
    z=f.assign(weight=w).groupby(['bearing_id','condition']).weight.sum()
    assert np.allclose(z,z.iloc[0]) and np.isclose(w.mean(),1)
    incomplete=f[~((f.bearing_id=='K001')&(f.condition==m.CONDITIONS[1]))]
    with pytest.raises(ValueError):m.training_weights(incomplete)


def test_hierarchical_aggregation_equalizes_runs_then_conditions_then_bearing():
    m=common();f=fixture_frame();p=np.tile([.2,.3,.5],(len(f),1))
    # First condition has two measurements; each measurement stays equal.
    mask=(f.bearing_id=='K001')&(f.condition==m.CONDITIONS[0])
    p[mask]=[.8,.1,.1]
    measurements,conditions,bearings=m.aggregate_hierarchical(p,f)
    row=bearings[bearings.bearing_id=='K001'].iloc[0]
    assert np.allclose(row[m.PROBS].to_numpy(float),[.35,.25,.4])
    assert len(bearings)==9 and len(conditions)==36
    with pytest.raises(ValueError):m.aggregate_hierarchical(p[:-1],f.iloc[:-1])


def test_selection_uses_pooled_specimen_metrics_and_fixed_index_tie_break():
    m=common();rows=[dict(config_index=2,macro_f1=.8,nll=.2),dict(config_index=1,macro_f1=.8,nll=.2),dict(config_index=0,macro_f1=.7,nll=.1)]
    assert m.select_candidate(rows)['config_index']==1


def test_eligibility_requires_every_condition_but_not_all_four_runs():
    m=common();f=fixture_frame();keep,report=m.eligible_specimens(f)
    assert set(keep)==set(m.DEV_IDS)
    f=f[~((f.bearing_id=='K001')&(f.condition==m.CONDITIONS[0]))]
    keep,report=m.eligible_specimens(f)
    assert 'K001' not in keep
