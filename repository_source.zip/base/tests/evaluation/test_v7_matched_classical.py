"""Controls that protect equal-input conventional comparison from leakage."""
from pathlib import Path
import importlib
import numpy as np
import pandas as pd
import pytest


def api():
    path=Path(__file__).resolve().parents[2]/'scripts/v7/run_matched_classical.py'
    assert path.exists(), 'The matched-input conventional experiment is not implemented yet'
    return importlib.import_module('scripts.v7.run_matched_classical')


def test_known_signal_feature_support_and_amplitude_change():
    m=api();t=np.arange(2048)/25600.;x=np.sin(2*np.pi*2000*t)
    a,names=m.extract_features(np.stack([x,2*x]),'native25')
    assert a.shape==(2,25) and len(set(names))==25
    assert a[0,names.index('spectral_peak')]==2000.
    assert a[1,names.index('rms')]==pytest.approx(2*a[0,names.index('rms')])
    assert a[1,names.index('bin_500_2000_energy')]==pytest.approx(4*a[0,names.index('bin_500_2000_energy')])


def test_shape_representation_discards_positive_gain_and_offset():
    m=api();x=np.random.default_rng(19).normal(size=2048)
    a,names=m.extract_features(np.stack([x,3*x+4]),'shape25')
    np.testing.assert_allclose(a[0],a[1],rtol=1e-5,atol=1e-4)
    assert a[:,names.index('mean')].tolist()==[0.,0.]
    assert a[:,names.index('std')].tolist()==[1.,1.]
    assert a[:,names.index('rms')].tolist()==[1.,1.]


def test_flat_signal_and_invalid_inputs_fail_closed():
    m=api();a,names=m.extract_features(np.zeros((2,2048)),'shape25')
    assert np.isfinite(a).all()
    assert a[:,names.index('rms')].tolist()==[0.,0.]
    with pytest.raises(ValueError):m.extract_features(np.zeros((2,256)),'native25')
    with pytest.raises(ValueError):m.extract_features(np.full((2,2048),np.nan),'shape25')


def test_aggregation_requires_single_label_and_exact_patch_support():
    m=api();f=pd.DataFrame({'source_record':['b','a','a','b'],'class_id':[1,0,0,1]})
    p=np.array([[0.,1.,0.],[1.,0.,0.],[.6,.4,0.],[.2,.8,0.]])
    out=m.aggregate_records(p,f,expected_patches=2)
    assert out.source_record.tolist()==['a','b']
    assert out.p_H.tolist()==pytest.approx([.8,.1])
    assert out.patch_count.tolist()==[2,2]
    f.loc[2,'class_id']=2
    with pytest.raises(ValueError):m.aggregate_records(p,f,expected_patches=2)
    with pytest.raises(ValueError):m.aggregate_records(p,f,expected_patches=32)


def test_split_uses_complete_source_records_and_fixed_condition_rotation():
    m=api();f=pd.DataFrame({'condition':m.CONDITIONS,'source_record':list('abcde')})
    train,val,test=m.partition(f,1)
    assert val.tolist()==[2] and test.tolist()==[1]
    assert train.tolist()==[0,3,4]
    f.loc[2,'source_record']='b'
    with pytest.raises(ValueError):m.partition(f,1)


def test_train_only_scaler_does_not_adapt_at_prediction():
    m=api();model=m.build_model('logistic_regression',{'C':1.},11)
    rng=np.random.default_rng(10);x=rng.normal(size=(30,25));y=np.tile([0,1,2],10)
    model.fit(x,y);scaler=model.named_steps['scale'];before=scaler.mean_.copy()
    model.predict_proba(x[:3]+10000)
    np.testing.assert_array_equal(before,scaler.mean_)
    np.testing.assert_allclose(before,x.mean(0))


def test_candidate_selection_prioritizes_record_f1_then_nll_then_index():
    m=api();rows=[{'config_index':0,'macro_f1':.9,'nll':.3},
        {'config_index':2,'macro_f1':.9,'nll':.2},
        {'config_index':1,'macro_f1':.9,'nll':.2},
        {'config_index':3,'macro_f1':.8,'nll':.01}]
    assert m.select_candidate(rows)['config_index']==1


def test_training_weights_equalize_domain_class_then_complete_record():
    m=api();rows=[]
    for condition in ['20Hz','30Hz','40Hz']:
        for label in range(3):
            for record in range(1+(label==1)):
                for patch in range(32):
                    rows.append({'condition':condition,'class_id':label,
                        'source_record':f'{condition}_{label}_{record}'})
    f=pd.DataFrame(rows);w=m.training_weights(f)
    sums=f.assign(weight=w).groupby(['condition','class_id']).weight.sum()
    np.testing.assert_allclose(sums.to_numpy(),sums.iloc[0])
    assert w.mean()==pytest.approx(1.)


def test_metrics_preserve_zero_recall_and_independent_manual_reconciliation():
    m=api();r=pd.DataFrame({'class_id':[0,1,2],
        'p_H':[.8,.8,.1],'p_I':[.1,.1,.1],'p_O':[.1,.1,.8]})
    out=m.record_metrics(r)
    assert out['recall_I']==0.
    assert out['macro_f1']==pytest.approx((2/3+0+1)/3)
    assert out['nll']==pytest.approx(-np.log([.8,.1,.8]).mean())
    assert m.independent_metrics_check(r,out)['passed'] is True
