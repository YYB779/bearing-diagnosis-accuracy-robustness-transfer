"""Parser for the nested MAT-file layout in the Paderborn Bearing DataCenter."""

from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.io import loadmat


FILE_RE = re.compile(
    r"^(?P<condition>N\d+_M\d+_F\d+)_(?P<bearing>[A-Z]{1,2}\d+)_(?P<run>\d+)\.mat$",
    re.I,
)


def parse_filename(path: Path | str) -> dict:
    path = Path(path)
    match = FILE_RE.match(path.name)
    if not match:
        raise ValueError(f"Unrecognized Paderborn filename: {path.name}")
    condition = match.group("condition").upper()
    bearing = match.group("bearing").upper()
    return {
        "path": str(path),
        "file_id": path.stem,
        "condition": condition,
        "bearing_id": bearing,
        "run": int(match.group("run")),
        "group_id": bearing,
    }


def scan_paderborn(root: Path | str) -> pd.DataFrame:
    root = Path(root)
    files = sorted(root.rglob("*.mat"))
    if not files:
        raise FileNotFoundError(f"No MAT files found under {root}")
    return pd.DataFrame([parse_filename(path) for path in files]).sort_values("file_id").reset_index(drop=True)


def _unwrap_scalar(value):
    while isinstance(value, np.ndarray) and value.shape == ():
        value = value.item()
    return value


def _nested_record(mat: dict) -> np.ndarray:
    keys = [key for key in mat if not key.startswith("__")]
    if len(keys) != 1:
        raise ValueError(f"Expected one root record, found {keys}")
    record = mat[keys[0]]
    if not isinstance(record, np.ndarray) or not record.dtype.names:
        raise ValueError("Paderborn MAT root is not a named record")
    return record


def load_paderborn_mat(path: Path | str) -> dict[str, object]:
    path = Path(path)
    root = _nested_record(loadmat(path, squeeze_me=True))
    x = _unwrap_scalar(root["X"])
    y = _unwrap_scalar(root["Y"])
    if not hasattr(y, "dtype") or not y.dtype.names:
        raise ValueError(f"Paderborn Y record missing in {path}")
    names = [str(name) for name in np.asarray(y["Name"]).flat]
    arrays = {name: np.asarray(data, dtype=np.float64).squeeze() for name, data in zip(names, np.asarray(y["Data"]).flat)}
    raster = [str(value) for value in np.asarray(y["Raster"]).flat]
    raster_by_name = dict(zip(names, raster))
    times = {str(value): np.asarray(data, dtype=np.float64).squeeze() for value, data in zip(np.asarray(x["Raster"]).flat, np.asarray(x["Data"]).flat)}
    return {"signals": arrays, "raster_by_name": raster_by_name, "time_vectors": times}


def signal_sampling_rate_hz(parsed: dict[str, object], name: str) -> float:
    raster = str(parsed["raster_by_name"][name])
    times = parsed["time_vectors"]
    vector = np.asarray(times[raster])
    if vector.size < 2:
        raise ValueError(f"Insufficient time vector for {name}")
    duration = float(vector[-1] - vector[0])
    return float((vector.size - 1) / duration)
