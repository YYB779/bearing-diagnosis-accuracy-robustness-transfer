"""Explicit speed-based order coordinates for future benchmarks.

``resample_to_order`` is retained unchanged for historical reproduction.
New analyses must choose fixed-turn rejection or full-interval pairing
explicitly; neither strict API silently relabels a short interval as one turn.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


def resample_to_order(
    signal: np.ndarray,
    speed_hz: np.ndarray,
    sample_rate_hz: float,
    revolutions: int,
    samples_per_revolution: int,
) -> np.ndarray:
    """Return the legacy clipped-coordinate array for historical reproduction.

    Deprecated for new scientific analyses, but intentionally emits no warning
    and preserves the original numerical behavior. Its right-endpoint rectangle
    phase integral is shifted to zero, and ``min(available, requested)`` silently
    shortens the covered rotation while retaining the requested output length.
    An output of length ``revolutions * samples_per_revolution`` therefore does
    not establish that the output covers that many physical revolutions.

    Use :func:`resample_fixed_revolutions` when enough turns are required, or
    :func:`resample_paired_interval` when both views must cover the full same
    physical interval. Existing processed data are not corrected by this module.
    """
    signal = np.asarray(signal, dtype=float).reshape(-1)
    speed_hz = np.asarray(speed_hz, dtype=float).reshape(-1)
    if signal.size != speed_hz.size:
        raise ValueError("signal and speed_hz must have equal length")
    if sample_rate_hz <= 0 or revolutions <= 0 or samples_per_revolution <= 0:
        raise ValueError("sample rate and output sizes must be positive")
    if not np.isfinite(signal).all() or not np.isfinite(speed_hz).all():
        raise ValueError("signal and speed_hz must be finite")
    if np.any(speed_hz <= 0):
        raise ValueError("speed_hz must be positive")
    phase = np.cumsum(speed_hz) / sample_rate_hz
    phase -= phase[0]
    max_phase = min(float(phase[-1]), float(revolutions))
    target = np.linspace(0.0, max_phase, revolutions * samples_per_revolution, endpoint=False)
    return np.interp(target, phase, signal)


@dataclass(frozen=True)
class OrderResamplingResult:
    """A fixed-turn view and the physical coordinates needed to audit it.

    ``physical_stop_seconds`` is the requested interval boundary. The periodic
    output grid excludes that boundary; it never duplicates a full-turn endpoint.
    Source/target phases are in revolutions, not radians.
    """

    values: np.ndarray
    phase_revolutions: np.ndarray
    time_seconds: np.ndarray
    source_phase_revolutions: np.ndarray
    source_time_seconds: np.ndarray
    physical_start_seconds: float
    physical_stop_seconds: float
    actual_revolutions: float
    available_revolutions: float


@dataclass(frozen=True)
class PairedIntervalResamplingResult:
    """Raw/time-uniform and phase-uniform views with common inclusive endpoints.

    Actual turns depend on the measured speed and sample support. No fixed-turn
    count is assumed. The coordinate arrays, not array length alone, define the
    physical interval and the order-axis spacing.
    """

    raw_values: np.ndarray
    order_values: np.ndarray
    raw_time_seconds: np.ndarray
    order_time_seconds: np.ndarray
    order_phase_revolutions: np.ndarray
    source_phase_revolutions: np.ndarray
    source_time_seconds: np.ndarray
    physical_start_seconds: float
    physical_stop_seconds: float
    actual_revolutions: float


def _count(value: int, name: str, minimum: int = 1) -> int:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)):
        raise ValueError(f"{name} must be an integer >= {minimum}")
    if value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return int(value)


def _source_coordinates(
    signal: np.ndarray,
    speed_hz: np.ndarray,
    sample_rate_hz: float,
    start_time_seconds: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    values = np.asarray(signal, dtype=float)
    speed = np.asarray(speed_hz, dtype=float)
    if values.ndim != 1 or speed.ndim != 1:
        raise ValueError("signal and speed_hz must be one-dimensional")
    if values.size != speed.size or values.size < 2:
        raise ValueError("signal and speed_hz require equal length and at least two samples")
    if not np.isfinite(values).all() or not np.isfinite(speed).all():
        raise ValueError("signal and speed_hz must be finite")
    if np.any(speed <= 0):
        raise ValueError("speed_hz must be positive")
    if not np.isscalar(sample_rate_hz) or not np.isfinite(sample_rate_hz) or sample_rate_hz <= 0:
        raise ValueError("sample_rate_hz must be finite and positive")
    if not np.isscalar(start_time_seconds) or not np.isfinite(start_time_seconds):
        raise ValueError("start_time_seconds must be finite")
    local_time = np.arange(values.size, dtype=float) / float(sample_rate_hz)
    phase = np.concatenate((
        np.zeros(1),
        np.cumsum((speed[:-1] + speed[1:]) / (2.0 * float(sample_rate_hz))),
    ))
    source_time = local_time + float(start_time_seconds)
    if not np.isfinite(phase).all() or np.any(np.diff(phase) <= 0):
        raise ValueError("speed/sample-rate values do not produce a finite increasing phase")
    if not np.isfinite(source_time).all() or np.any(np.diff(source_time) <= 0):
        raise ValueError("start_time_seconds and sample_rate_hz do not resolve distinct timestamps")
    return values, source_time, phase


def resample_fixed_revolutions(
    signal: np.ndarray,
    speed_hz: np.ndarray,
    sample_rate_hz: float,
    revolutions: int,
    samples_per_revolution: int,
    *,
    start_time_seconds: float = 0.0,
) -> OrderResamplingResult:
    """Resample exactly ``revolutions`` turns or reject insufficient support.

    Inputs are simultaneous vibration and strictly positive speed samples on a
    uniform clock. Phase integrates speed by the trapezoidal rule with phase[0]
    exactly zero. Available support ends at the final observed sample, at
    ``start + (N - 1) / fs``; no unobserved last sample period is invented.

    The output contains ``R * samples_per_revolution`` samples on [0, R), so the
    phase-grid spacing is exactly 1/samples_per_revolution. The returned physical
    stop records the interpolated time at phase R, even though that endpoint is
    excluded from this periodic grid. A roundoff-sized tolerance is the only
    allowed discrepancy between requested and available turns.

    This is a new coordinate contract. It has not been applied retroactively to
    the existing curated dataset or any published local result artifact.
    """
    turns = _count(revolutions, "revolutions")
    points_per_turn = _count(samples_per_revolution, "samples_per_revolution")
    values, source_time, phase = _source_coordinates(
        signal, speed_hz, sample_rate_hz, start_time_seconds,
    )
    available = float(phase[-1])
    tolerance = 64 * np.finfo(float).eps * max(1.0, turns, available)
    if turns > available + tolerance:
        raise ValueError(
            f"insufficient revolutions: requested {turns}, available {available:.17g}",
        )
    target_phase = np.arange(turns * points_per_turn, dtype=float) / points_per_turn
    target_time = np.interp(target_phase, phase, source_time)
    output = np.interp(target_phase, phase, values)
    stop_time = float(np.interp(float(turns), phase, source_time))
    return OrderResamplingResult(
        values=output, phase_revolutions=target_phase, time_seconds=target_time,
        source_phase_revolutions=phase, source_time_seconds=source_time,
        physical_start_seconds=float(source_time[0]), physical_stop_seconds=stop_time,
        actual_revolutions=float(turns), available_revolutions=available,
    )


def resample_paired_interval(
    signal: np.ndarray,
    speed_hz: np.ndarray,
    sample_rate_hz: float,
    *,
    time_output_samples: int,
    order_output_samples: int,
    start_time_seconds: float = 0.0,
) -> PairedIntervalResamplingResult:
    """Return paired views over the entire same observed physical interval.

    Both grids include the first and last physical sample timestamps. The raw
    view is uniformly spaced in physical time; the order view is uniformly
    spaced in the integrated phase over the measured actual revolution count.
    Even an interval shorter than one revolution is valid and is labelled with
    its actual count. Its FFT must use phase spacing
    ``actual_revolutions / (order_output_samples - 1)``, never a fictional fixed
    samples-per-revolution constant. The final endpoint can be dropped explicitly
    if a downstream periodic FFT convention requires a half-open interval.

    The start argument names the caller's physical clock; its default is relative
    time zero and must not be mistaken for a recovered source-file start sample.
    Source-file sample IDs and preprocessing versions remain the caller's record.
    """
    raw_count = _count(time_output_samples, "time_output_samples", minimum=2)
    order_count = _count(order_output_samples, "order_output_samples", minimum=2)
    values, source_time, phase = _source_coordinates(
        signal, speed_hz, sample_rate_hz, start_time_seconds,
    )
    raw_time = np.linspace(source_time[0], source_time[-1], raw_count)
    target_phase = np.linspace(0.0, phase[-1], order_count)
    order_time = np.interp(target_phase, phase, source_time)
    return PairedIntervalResamplingResult(
        raw_values=np.interp(raw_time, source_time, values),
        order_values=np.interp(target_phase, phase, values),
        raw_time_seconds=raw_time, order_time_seconds=order_time,
        order_phase_revolutions=target_phase,
        source_phase_revolutions=phase, source_time_seconds=source_time,
        physical_start_seconds=float(source_time[0]),
        physical_stop_seconds=float(source_time[-1]),
        actual_revolutions=float(phase[-1]),
    )
