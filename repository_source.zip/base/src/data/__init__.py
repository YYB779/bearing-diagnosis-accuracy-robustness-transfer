"""Dataset readers, split protocols and signal transforms."""
