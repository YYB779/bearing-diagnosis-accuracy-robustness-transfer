"""Publication-oriented style used by all study figures."""

from __future__ import annotations

import matplotlib.pyplot as plt


CLASS_COLORS = {
    "healthy": "#2C7FB8",
    "outer": "#F28E2B",
    "inner": "#59A14F",
    "ball": "#B07AA1",
    "compound": "#E15759",
}


def apply_publication_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["Times New Roman", "DejaVu Serif"],
            "font.size": 9,
            "axes.labelsize": 9,
            "axes.titlesize": 10,
            "axes.edgecolor": "#333333",
            "axes.linewidth": 0.8,
            "axes.grid": True,
            "grid.color": "#D9D9D9",
            "grid.linewidth": 0.5,
            "grid.alpha": 0.7,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
            "savefig.facecolor": "white",
            "savefig.dpi": 300,
        }
    )
