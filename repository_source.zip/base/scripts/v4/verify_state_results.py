"""Independent read-only verification of frozen v4 benchmark artifacts.

Recomputes metrics without importing the runner's metric/aggregation helpers.
Loads a fixed, score-independent subset of trusted local fitted models. No fit,
selection, feature extraction, or benchmark artifact modification is performed.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import itertools
import json
import subprocess
import sys
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
SPLITS = ("validation", "test_known", "test_unknown")
TOLERANCE = 1e-10


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def from_relative(path):
    return ROOT / str(path).replace("\\", "/")


def record_predictions(frame, value_column="p1"):
    if frame.groupby("inferred_source_group").label.nunique().max() != 1:
        raise AssertionError("one proxy has conflicting labels")
    if frame.groupby("inferred_source_group").state_id.nunique().max() != 1:
        raise AssertionError("one proxy has conflicting states")
    return frame.groupby("inferred_source_group", sort=True).agg(
        label=("label", "first"), state_id=("state_id", "first"),
        p1=(value_column, "mean")).reset_index()


def metric_values(records):
    """Manual binary metrics from record probabilities, including tie-aware AUC."""
    y = records.label.to_numpy(dtype=int)
    p = records.p1.to_numpy(dtype=float)
    assert set(y) == {0, 1}
    assert np.isfinite(p).all() and np.all((p >= 0) & (p <= 1))
    z = p >= 0.5
    frequencies = records.state_id.value_counts().to_dict()
    state_weights = np.array([1.0 / frequencies[key] for key in records.state_id])

    def macro_f1(weights):
        terms = []
        for label in (0, 1):
            tp = weights[(y == label) & (z == label)].sum()
            fp = weights[(y != label) & (z == label)].sum()
            fn = weights[(y == label) & (z != label)].sum()
            denominator = 2 * tp + fp + fn
            terms.append(2 * tp / denominator if denominator else 0.0)
        return float(np.mean(terms))

    eps = np.finfo(np.float64).eps
    correct_class_probability = np.where(y == 1, p, 1 - p)
    correct_class_probability = np.clip(correct_class_probability, eps, 1 - eps)
    positive, negative = p[y == 1], p[y == 0]
    differences = positive[:, None] - negative[None, :]
    return dict(n_records=len(y), n_states=int(records.state_id.nunique()),
                macro_f1=macro_f1(np.ones(len(y))),
                state_weighted_macro_f1=macro_f1(state_weights),
                balanced_accuracy=float(np.mean([np.mean(z[y == label] == label) for label in (0, 1)])),
                auroc=float(np.mean((differences > 0) + 0.5 * (differences == 0))),
                nll=float(-np.log(correct_class_probability).mean()),
                brier=float(np.square(p - y).mean()))


def expected_blocks(repository):
    blocks = json.loads((ROOT / "data/processed/v3/novic_physical_feature_blocks.json").read_text(encoding="utf-8"))["blocks"]
    native = pd.read_csv(ROOT / "data/processed/v4/native_fullband_features.csv", nrows=0)
    generic = [name for name in blocks["order_envelope"] if not any(token in name.lower() for token in ("bpfi", "bpfo", "bsf", "ftf", "harmonic"))]
    result = dict(metadata_only=blocks["metadata_only"], native_fullband=[c for c in native if c != "sample_id"],
                  time_envelope=blocks["time_envelope"], time_envelope_meta=blocks["time_envelope"] + blocks["metadata_only"],
                  order_generic=generic, order_generic_meta=generic + blocks["metadata_only"], order_geometry=blocks["order_envelope"])
    if repository:
        result["mfos_repository"] = [c for c in pd.read_csv(ROOT / "data/processed/v4/mfos_repository_features.csv", nrows=0) if c != "sample_id"]
    return result


def input_feature_table(repository):
    table = pd.read_csv(ROOT / "data/processed/v3/novic_physical_features.csv")
    native = pd.read_csv(ROOT / "data/processed/v4/native_fullband_features.csv")
    assert np.array_equal(table.sample_id, native.sample_id)
    table = table.merge(native, on="sample_id", validate="one_to_one", sort=False)
    if repository:
        repo = pd.read_csv(ROOT / "data/processed/v4/mfos_repository_features.csv")
        assert np.array_equal(table.sample_id, repo.sample_id)
        table = table.merge(repo, on="sample_id", validate="one_to_one", sort=False)
    return table.set_index("sample_id", verify_integrity=True)


def direct_state_weights(training):
    records_per_state = training[["state_id", "inferred_source_group"]].drop_duplicates().groupby("state_id").size().to_dict()
    windows_per_record = training.inferred_source_group.value_counts().to_dict()
    weights = np.array([1.0 / (records_per_state[s] * windows_per_record[r]) for s, r in zip(training.state_id, training.inferred_source_group)])
    return weights / weights.mean()


def calibration_check(result, assignment):
    training = assignment[assignment.assigned_split.eq("train")]
    audits = result["calibration_audit"]
    assert len(audits) == 3
    expected_folds = set(training.state_fold)
    assert len(expected_folds) == 3
    assert {entry["held_state_fold"] for entry in audits} == expected_folds
    all_training_states = set(training.state_id)
    validation_and_unknown = set(assignment.loc[assignment.assigned_split.isin(["validation", "test_unknown"]), "state_id"])
    held_records = []
    for entry in audits:
        holdout = training[training.state_fold.eq(entry["held_state_fold"])]
        fitting = training[~training.state_fold.eq(entry["held_state_fold"])]
        fit_states, held_states = set(entry["fit_state_ids"]), set(entry["held_state_ids"])
        assert fit_states == set(fitting.state_id)
        assert held_states == set(holdout.state_id)
        assert not fit_states & held_states
        assert fit_states | held_states == all_training_states
        assert not (fit_states | held_states) & validation_and_unknown
        assert entry["fit_records"] == fitting.inferred_source_group.nunique()
        assert entry["held_records"] == holdout.inferred_source_group.nunique()
        fit_record_ids, held_record_ids = set(fitting.inferred_source_group), set(holdout.inferred_source_group)
        assert not fit_record_ids & held_record_ids
        for part in (fitting, holdout):
            assert set(part[result["task"]]) == {0, 1}
        held_records.extend(sorted(held_record_ids))
    assert len(held_records) == len(set(held_records)) == training.inferred_source_group.nunique()
    assert set(held_records) == set(training.inferred_source_group)
    assert result["calibration_records"] == training.inferred_source_group.nunique()
    return dict(result=result["_stem"], folds=3, oof_records=len(held_records), train_states=len(all_training_states),
                explicit_record_ids_in_saved_audit=False,
                evidence="Saved state IDs and record counts match assignment-derived train-only membership; inner fitted estimators and OOF scores were not persisted.")


def predetermined_reload_keys(repository):
    if repository:
        rep = "mfos_repository"
        return [(f"state_dual_{fold}", "inner_presence" if fold % 2 == 0 else "outer_presence", rep, "state_calibrated_svm", 11) for fold in range(5)] + [
            ("state_dual_0", "inner_presence", rep, "extra_trees", 11),
            ("state_dual_4", "outer_presence", rep, "extra_trees", 33),
            ("state_dual_2", "outer_presence", rep, "random_forest", 11),
            ("state_dual_1", "outer_presence", rep, "logistic", 11),
            ("state_dual_3", "inner_presence", rep, "logistic", 11)]
    return [(f"state_dual_{fold}", "inner_presence" if fold % 2 == 0 else "outer_presence", "native_fullband", "state_calibrated_svm", 11) for fold in range(5)] + [
        ("state_dual_0", "inner_presence", "time_envelope", "extra_trees", 11),
        ("state_dual_4", "outer_presence", "order_geometry", "extra_trees", 33),
        ("state_dual_2", "outer_presence", "native_fullband", "random_forest", 11),
        ("state_dual_1", "outer_presence", "metadata_only", "logistic", 11),
        ("state_dual_3", "inner_presence", "order_generic", "logistic", 11)]


def model_reload_checks(folder, results, predictions, assignments, repository):
    table = input_feature_table(repository)
    by_key = {(r["protocol"], r["task"], r["representation"], r["model"], r["seed"]): r for r in results}
    checks, sigmoid_units = [], []
    for key in predetermined_reload_keys(repository):
        result = by_key[key]
        model_path = folder / (result["_stem"] + ".joblib")
        assert digest(model_path) == result["model_sha256"]
        model = joblib.load(model_path)
        saved = predictions[result["_stem"]]
        x = table.loc[saved.sample_id, result["feature_columns"]].to_numpy(dtype=float)
        before_mean = getattr(getattr(model, "scaler", None), "mean_", np.array([])).copy()
        reloaded = model.predict_proba(x)[:, 1]
        difference = float(np.max(np.abs(reloaded - saved.p1.to_numpy())))
        assert difference < TOLERANCE, (key, difference)
        assert np.array_equal(before_mean, getattr(getattr(model, "scaler", None), "mean_", np.array([])))
        check = dict(result=result["_stem"], rows=len(saved), max_abs_prediction_difference=difference,
                     trusted_local_model_loaded=True, prediction_did_not_mutate_scaler=True)
        if result["model"] in ("logistic", "state_calibrated_svm"):
            training = assignments[result["protocol"]].query("assigned_split == 'train'")
            training_x = table.loc[training.sample_id, result["feature_columns"]].to_numpy(dtype=float)
            weights = direct_state_weights(training)
            expected_mean = np.average(training_x, axis=0, weights=weights)
            expected_variance = np.average((training_x - expected_mean) ** 2, axis=0, weights=weights)
            np.testing.assert_allclose(model.scaler.mean_, expected_mean, rtol=1e-11, atol=1e-10)
            np.testing.assert_allclose(model.scaler.var_, expected_variance, rtol=1e-10, atol=1e-9)
            assert np.isclose(model.scaler.n_samples_seen_, len(training), rtol=1e-12, atol=1e-9)
            check["scaler_weighted_train_mean_variance_verified"] = True
            if result["model"] == "state_calibrated_svm":
                expected_support_vectors = model.scaler.transform(training_x)[model.svm.support_]
                np.testing.assert_allclose(model.svm.support_vectors_, expected_support_vectors, rtol=1e-12, atol=1e-12)
                check["final_support_vectors_match_train_only_rows"] = True
                assert model.calibration_records == len(training.inferred_source_group.unique())
                assert model.calibration_audit == result["calibration_audit"]
                decisions = model.svm.decision_function(model.scaler.transform(x))
                diagnosis = saved.copy()
                diagnosis["decision"] = decisions
                for split, frame in diagnosis.groupby("split", sort=False):
                    current = record_predictions(frame)
                    decision_records = record_predictions(frame, value_column="decision")
                    alternate_p = model.sigmoid.predict_proba(decision_records[["p1"]].to_numpy())[:, 1]
                    alternate = decision_records.copy()
                    alternate["p1"] = alternate_p
                    abs_diff = np.abs(current.p1.to_numpy() - alternate_p)
                    sigmoid_units.append(dict(result=result["_stem"], split=split, records=len(current),
                        mean_abs_probability_difference=float(abs_diff.mean()), max_abs_probability_difference=float(abs_diff.max()),
                        records_crossing_p05=int(np.sum((current.p1.to_numpy() >= 0.5) != (alternate_p >= 0.5))),
                        saved_mean_window_probability_nll=metric_values(current)["nll"],
                        diagnostic_sigmoid_mean_decision_nll=metric_values(alternate)["nll"],
                        role="Operation-order diagnostic only; alternative predictions are not substituted, selected, or saved into benchmark results."))
        assert digest(model_path) == result["model_sha256"]
        checks.append(check)
    return checks, sigmoid_units


def verify(folder, repository=False):
    design_path = folder / "design.json"
    design = json.loads(design_path.read_text(encoding="utf-8"))
    design_hash = digest(design_path)
    frozen_inputs = []
    for relative, expected in design["sha256"].items():
        actual = digest(from_relative(relative))
        assert actual == expected, relative
        frozen_inputs.append(dict(path=relative, sha256=actual, matches=True))
    assignment = pd.read_csv(from_relative(design["split_source"]))
    assignments = {key: group.reset_index(drop=True) for key, group in assignment.groupby("protocol", sort=True)}
    assert len(assignments) == 5
    for protocol, frame in assignments.items():
        assert len(frame) == 404 and frame.sample_id.nunique() == 404
        assert frame.inferred_source_group.nunique() == 79
        assert frame.groupby("inferred_source_group").assigned_split.nunique().max() == 1
        state_sets = {split: set(part.state_id) for split, part in frame.groupby("assigned_split")}
        assert state_sets["test_known"] <= state_sets["train"]
        assert not state_sets["test_unknown"] & set.union(state_sets["train"], state_sets["validation"], state_sets["test_known"])
        assert not state_sets["validation"] & set.union(state_sets["train"], state_sets["test_known"])
    unknown = assignment[assignment.assigned_split.eq("test_unknown")]
    assert len(unknown) == 404 and unknown.sample_id.nunique() == 404
    assert unknown.inferred_source_group.nunique() == 79 and unknown.state_id.nunique() == 33
    assert unknown.groupby("inferred_source_group").protocol.nunique().max() == 1
    blocks = expected_blocks(repository)
    expected = {}
    for protocol, task, rep, model in itertools.product(assignments, design["tasks"], design["representations"], design["models"]):
        name, seeds, grid = model
        for seed in seeds:
            stem = f"{protocol}_{task}_{rep}_{name}_s{seed}"
            expected[stem] = (protocol, task, rep, name, seed, grid)
    files = sorted(path for path in folder.glob("*.json") if path.name != "design.json")
    assert {p.stem for p in files} == set(expected), (len(files), len(expected))
    assert len(files) == design["expected_selected_models"]
    assert len(list(folder.glob("*.joblib"))) == len(files)
    assert len(list(folder.glob("*_predictions.csv"))) == len(files)
    metric_checks, result_summaries, results, calibration_checks, predictions = [], [], [], [], {}
    candidate_count, hashes_checked = 0, 0
    failures = []
    for path in files:
        result = json.loads(path.read_text(encoding="utf-8"))
        result["_stem"] = path.stem
        results.append(result)
        protocol, task, rep, name, seed, grid = expected[path.stem]
        assert (result["protocol"], result["task"], result["representation"], result["model"], result["seed"]) == (protocol, task, rep, name, seed)
        assert result["design_sha256"] == design_hash
        assert result["n_features"] == len(result["feature_columns"]) == design["feature_counts"][rep]
        assert result["feature_columns"] == blocks[rep] and len(set(result["feature_columns"])) == result["n_features"]
        assert not any(c in {"sample_id", "state_id", "inner_presence", "outer_presence", "inferred_source_group", "subset", "split"} for c in result["feature_columns"])
        assert [item["config"] for item in result["candidates"]] == grid
        candidate_count += len(result["candidates"])
        candidate_scores = [(item["validation_record"]["macro_f1"], -item["validation_record"]["nll"]) for item in result["candidates"]]
        selected_index = max(range(len(candidate_scores)), key=lambda index: candidate_scores[index])
        assert result["chosen"] == grid[selected_index]
        assert result["validation"] == result["candidates"][selected_index]["validation_record"]
        assert result["test_predict_calls"] == 1
        pp = folder / result["predictions"]
        assert pp.name == path.stem + "_predictions.csv"
        assert digest(pp) == result["predictions_sha256"]
        assert digest(folder / (path.stem + ".joblib")) == result["model_sha256"]
        hashes_checked += 2
        # Preserve the writer's binary64 probabilities: default fast parsing can
        # split/rejoin exact score ties and thereby change AUROC after grouping.
        pred = pd.read_csv(pp, float_precision="round_trip")
        predictions[path.stem] = pred
        frame = assignments[protocol]
        expected_pred = frame[~frame.assigned_split.eq("train")].set_index("sample_id")
        assert len(pred) == len(expected_pred) and pred.sample_id.nunique() == len(pred)
        assert set(pred.sample_id) == set(expected_pred.index)
        reference = expected_pred.loc[pred.sample_id]
        for column in ("inferred_source_group", "state_id", "state_fold", "subset"):
            assert np.array_equal(pred[column], reference[column]), (path.name, column)
        assert np.array_equal(pred["split"], reference["assigned_split"])
        assert np.array_equal(pred["label"], reference[task])
        assert set(pred["split"]) == set(SPLITS)
        training = frame[frame.assigned_split.eq("train")]
        assert result["train_records"] == training.inferred_source_group.nunique()
        assert result["train_states"] == training.state_id.nunique()
        if name == "state_calibrated_svm":
            calibration_checks.append(calibration_check(result, frame))
        else:
            assert not result["calibration_audit"] and result["calibration_records"] is None
        per_result_errors = []
        for split in SPLITS:
            records = record_predictions(pred[pred.split.eq(split)])
            actual = metric_values(records)
            saved = result[split]
            errors = {metric: abs(float(actual[metric]) - float(saved[metric])) for metric in actual}
            if max(errors.values()) >= TOLERANCE:
                failures.append(dict(result=path.stem, split=split, errors=errors))
            metric_checks.append(dict(result=path.stem, split=split, recomputed=actual, absolute_errors=errors))
            per_result_errors.extend(errors.values())
        result_summaries.append(dict(result=path.stem, candidates=len(grid), selected_index=selected_index,
                                     max_abs_metric_error=max(per_result_errors), hashes_match=True))
    assert candidate_count == design["candidate_pipeline_fits"]
    assert not failures, failures[:3]
    oof = []
    for task, rep, model in itertools.product(design["tasks"], design["representations"], design["models"]):
        name, seeds, _ = model
        for seed in seeds:
            selected = [r for r in results if (r["task"], r["representation"], r["model"], r["seed"]) == (task, rep, name, seed)]
            assert len(selected) == 5
            full = pd.concat([predictions[r["_stem"]].query("split == 'test_unknown'") for r in selected], ignore_index=True)
            assert len(full) == 404 and full.sample_id.nunique() == 404
            records = record_predictions(full)
            assert len(records) == 79 and records.state_id.nunique() == 33
            oof.append(dict(task=task, representation=rep, model=name, seed=seed, **metric_values(records)))
    reload_checks, sigmoid_units = model_reload_checks(folder, results, predictions, assignments, repository)
    for relative, expected_digest in design["sha256"].items():
        assert digest(from_relative(relative)) == expected_digest
    assert digest(design_path) == design_hash
    max_errors = {metric: max(check["absolute_errors"][metric] for check in metric_checks) for metric in metric_checks[0]["absolute_errors"]}
    known_assignment = assignment[assignment.assigned_split.eq("test_known")][["protocol", "inferred_source_group"]].drop_duplicates()
    return dict(status="pass with disclosed calibration-unit limitation", benchmark=str(folder.relative_to(ROOT)),
        design_sha256=design_hash, frozen_input_hash_checks=frozen_inputs,
        selected_models=len(results), recorded_candidate_pipeline_fits=candidate_count,
        candidate_count_interpretation="Recorded top-level candidate pipelines; SVM candidates internally fit 3 OOF SVMs, 1 final SVM and 1 sigmoid. Losing candidate models and predictions are not persisted, so their metrics cannot be independently recomputed.",
        prediction_hashes_verified=len(results), model_hashes_verified=len(results),
        result_design_hashes_verified=len(results), hash_checks=hashes_checked,
        metric_split_rows=len(metric_checks), manual_metric_fields=list(max_errors),
        metric_tolerance=TOLERANCE, maximum_absolute_metric_errors=max_errors,
        prediction_csv_float_parser="round_trip; original frozen input feature tables retain the runner's default parser",
        candidate_selection_rule_checks=len(results), feature_schema_checks=len(results),
        calibration_selected_models=len(calibration_checks), calibration_folds_verified=3 * len(calibration_checks),
        calibration_checks=calibration_checks, reloaded_models=reload_checks,
        reload_sampling="Fixed before scoring: native/repository SVMs across all 5 rotations, plus 2 Extra Trees, 1 Random Forest and 2 logistic models; 10 total.",
        svm_sigmoid_aggregation_diagnostics=sigmoid_units,
        unknown_oof_groups=len(oof), unknown_oof_records_per_group=79, unknown_oof_states_per_group=33,
        known_proxy_rotation_occurrences=len(known_assignment), known_unique_proxies=known_assignment.inferred_source_group.nunique(),
        known_rotations_per_proxy=sorted(known_assignment.groupby("inferred_source_group").size().unique().tolist()),
        unknown_oof_metrics=oof, selected_results=result_summaries, metric_recomputations=metric_checks,
        benchmark_artifacts_modified=False, new_model_fits=0,
        limits=["All metrics are computationally verified conditional on frozen saved predictions, not independent physical validation.",
                "Saved inner calibration audit lists state IDs and record counts, not record IDs or inner estimators/OOF scores; assignment membership and source were audited, not historical runtime access exhaustively reconstructed.",
                "SVM sigmoid fits mean decision per OOF training proxy but inference averages sigmoid-transformed windows; these nonlinear operations differ.",
                "State-weighted fitting/calibration targets an engineered combination distribution; equal-record evaluation uses a different weighting and is not a calibration guarantee.",
                "Hash consistency proves artifact consistency with this frozen design, not independent preregistration or untouched test knowledge before design."])


def verify_analysis(main, repository):
    """Rebuild all 64 intervals/56 paired contrasts from the declared draws."""
    from sklearn.metrics import f1_score
    folder = ROOT / "results/v4/analysis"
    filenames = ("unknown_oof_summary.csv", "unknown_cluster_intervals.csv", "paired_cluster_contrasts.csv", "record_predictions.csv", "fold_metrics.csv", "seed_sensitivity.csv", "analysis_provenance.json")
    snapshots = {name: digest(folder / name) for name in filenames}
    pooled = pd.read_csv(folder / "unknown_oof_summary.csv", float_precision="round_trip")
    intervals = pd.read_csv(folder / "unknown_cluster_intervals.csv", float_precision="round_trip")
    paired = pd.read_csv(folder / "paired_cluster_contrasts.csv", float_precision="round_trip")
    records = pd.read_csv(folder / "record_predictions.csv", float_precision="round_trip")
    folds = pd.read_csv(folder / "fold_metrics.csv", float_precision="round_trip")
    seeds = pd.read_csv(folder / "seed_sensitivity.csv", float_precision="round_trip")
    provenance = json.loads((folder / "analysis_provenance.json").read_text(encoding="utf-8"))
    assert provenance["script_sha256"] == digest(ROOT / "scripts/v4/analyze_state_results.py")
    keys = ["task", "representation", "model", "seed"]
    expected_oof = {tuple(row[key] for key in keys): row for benchmark in (main, repository) for row in benchmark["unknown_oof_metrics"]}
    assert len(pooled) == len(expected_oof) == 96
    pooled_errors = []
    for row in pooled.to_dict("records"):
        expected = expected_oof[tuple(row[key] for key in keys)]
        for metric in main["manual_metric_fields"]:
            pooled_errors.append(abs(row[metric] - expected[metric]))
    assert max(pooled_errors) < TOLERANCE
    expected_folds = {(row["result"], row["split"]): row["recomputed"] for benchmark in (main, repository) for row in benchmark["metric_recomputations"]}
    assert len(folds) == len(expected_folds) == 1440
    fold_errors = []
    for row in folds.to_dict("records"):
        stem = f"{row['protocol']}_{row['task']}_{row['representation']}_{row['model']}_s{row['seed']}"
        expected = expected_folds[(stem, row["split"])]
        for metric in main["manual_metric_fields"]:
            fold_errors.append(abs(row[metric] - expected[metric]))
    assert max(fold_errors) < TOLERANCE
    unknown = records[records.split.eq("test_unknown")]
    assert len(unknown) == 96 * 79
    states = pd.read_csv(ROOT / "results/v4/state_fold_assignments.csv", dtype={"joint_label": str}).sort_values("state_id").reset_index(drop=True)
    rng = np.random.default_rng(20261020)
    multiplicity = np.zeros((2000, 33), dtype=int)
    for _, stratum in states.groupby("joint_label", sort=True):
        positions = stratum.index.to_numpy()
        draws = rng.choice(positions, size=(2000, len(positions)), replace=True)
        multiplicity[:, positions] = (draws[:, :, None] == positions[None, None, :]).sum(axis=1)
    state_lookup = {key: i for i, key in enumerate(states.state_id)}
    distributions, interval_errors, sklearn_errors = {}, [], []
    for key, frame in unknown[unknown.seed.eq(11)].groupby(keys, sort=True):
        frame = frame.sort_values("inferred_source_group")
        assert len(frame) == frame.inferred_source_group.nunique() == 79
        y, z = frame.label.to_numpy(dtype=int), frame.p1.to_numpy(dtype=float) >= 0.5
        w = multiplicity[:, [state_lookup[state] for state in frame.state_id]]
        terms = []
        for label in (0, 1):
            tp = w[:, (y == label) & (z == label)].sum(axis=1)
            fp = w[:, (y != label) & (z == label)].sum(axis=1)
            fn = w[:, (y == label) & (z != label)].sum(axis=1)
            terms.append(2 * tp / (2 * tp + fp + fn))
        distribution = (terms[0] + terms[1]) / 2
        distributions[key] = distribution
        # Independent library comparison on fixed draws checks our vectorized
        # confusion arithmetic, including unequal 20-proxy normal-state weight.
        for draw in (0, 1, 1999):
            reference = f1_score(y, z, labels=[0, 1], average="macro", zero_division=0, sample_weight=w[draw])
            sklearn_errors.append(abs(float(reference) - distribution[draw]))
        stored = intervals
        for field, value in zip(keys, key):
            stored = stored[stored[field].eq(value)]
        assert len(stored) == 1
        stored = stored.iloc[0]
        for field, actual in (("estimate", metric_values(frame)["macro_f1"]), ("low", float(np.quantile(distribution, .025))), ("high", float(np.quantile(distribution, .975)))):
            interval_errors.append(abs(float(stored[field]) - actual))
    assert len(distributions) == len(intervals) == 64
    contrast_errors = []
    for row in paired.to_dict("records"):
        left = (row["task"], row["a"], row["model"], 11)
        right = (row["task"], row["b"], row["model"], 11)
        difference = distributions[left] - distributions[right]
        estimate = expected_oof[left]["macro_f1"] - expected_oof[right]["macro_f1"]
        for actual, stored in ((estimate, row["macro_f1_difference"]), (float(np.quantile(difference, .025)), row["low"]), (float(np.quantile(difference, .975)), row["high"])):
            contrast_errors.append(abs(actual - stored))
    assert len(paired) == 56
    seed_errors = []
    for row in seeds.to_dict("records"):
        group = pooled[pooled.task.eq(row["task"]) & pooled.representation.eq(row["representation"]) & pooled.model.eq(row["model"])]
        assert row["seeds"] == len(group)
        expected = {"macro_f1_mean": group.macro_f1.mean(), "macro_f1_min": group.macro_f1.min(), "macro_f1_max": group.macro_f1.max(), "nll_mean": group.nll.mean(), "brier_mean": group.brier.mean()}
        seed_errors.extend(abs(row[field] - value) for field, value in expected.items())
    for errors in (interval_errors, contrast_errors, sklearn_errors, seed_errors):
        assert max(errors) < TOLERANCE
    assert snapshots == {name: digest(folder / name) for name in filenames}
    return dict(status="pass", source_sha256=snapshots, oof_summary_rows=96, fold_metric_rows=1440,
                bootstrap_intervals=64, paired_contrasts=56, draws_per_interval=2000,
                sklearn_spot_checks=len(sklearn_errors), seed_summaries=len(seeds),
                max_oof_metric_error=max(pooled_errors), max_fold_metric_error=max(fold_errors),
                max_interval_error=max(interval_errors), max_paired_contrast_error=max(contrast_errors),
                max_sklearn_draw_f1_error=max(sklearn_errors), max_seed_summary_error=max(seed_errors),
                interpretation="Paired joint-label-stratified state-cluster percentile draws, conditional on fixed fitted models; not physical population replication or a bootstrap of training/selection.")


def render_report(document):
    main = document["state_benchmark"]
    errors = main["maximum_absolute_metric_errors"]
    reload_max = max(row["max_abs_prediction_difference"] for row in main["reloaded_models"])
    sigmoid = main["svm_sigmoid_aggregation_diagnostics"]
    sigmoid_max = max(row["max_abs_probability_difference"] for row in sigmoid)
    flips = sum(row["records_crossing_p05"] for row in sigmoid)
    tests = document["native_tests"]
    lines = ["# Independent verification of frozen v4 model results", "",
        f"Verified at {document['verified_utc']}. The audit fits no model and does not alter the runner, design, inputs, fitted models or saved benchmark predictions.", "",
        "## Artifact and metric verification", "",
        f"The main benchmark contains **{main['selected_models']} selected models** and **{main['recorded_candidate_pipeline_fits']} recorded candidate pipelines**, exactly matching all planned protocol × task × representation × family × seed combinations. All 420 model hashes, 420 prediction hashes, 420 result-to-design hashes and six frozen input hashes agree. The design SHA256 is `{main['design_sha256']}`.", "",
        f"All **{main['metric_split_rows']} model/split metric rows** were independently recalculated after averaging saved interval probabilities within each filename-derived recording proxy. Manual formulas were used for binary Macro-F1, state-weighted Macro-F1, balanced accuracy, pairwise tie-aware AUROC, float64-epsilon-clipped NLL and binary Brier loss. Largest absolute differences: Macro-F1 {errors['macro_f1']:.3g}; NLL {errors['nll']:.3g}; Brier {errors['brier']:.3g}. The tolerance was {TOLERANCE:g}. No arithmetic or sample/label alignment failure was found.", "",
        "Saved prediction CSVs are read with `float_precision='round_trip'`. The default parser changed exact probability ties in one validation Random Forest case, shifting AUROC from the saved 0.614 to 0.612 while F1/NLL/Brier remained consistent. Round-trip parsing restores 0.614; no fitted result or probability file was changed. Original feature-table parsing intentionally remains identical to the frozen runner.", "",
        "Every chosen configuration agrees with maximum validation equal-proxy Macro-F1, then minimum validation NLL, then first grid item. All 980 candidate configurations and their recorded order match the design. Losing candidates' fitted models and raw validation probabilities were not saved; their validation metrics cannot be independently reconstructed. Thus 980 is the number of recorded candidate pipelines, not 980 independently verified or independent scientific experiments. SVM candidates also contain internal OOF and sigmoid fits.", "",
        f"Unknown-state test predictions provide exactly 404 intervals from 79 proxies and 33 states once in each of {main['unknown_oof_groups']} task/representation/family/seed OOF groups. The known-state diagnostic has {main['known_proxy_rotation_occurrences']} proxy/rotation occurrences from {main['known_unique_proxies']} unique proxies, each appearing in {main['known_rotations_per_proxy']} rotations; these must not be pooled as independent tests.", "",
        "## Training and calibration isolation", "",
        f"The split maps preserve complete source proxies, isolate unknown-test and validation states from actual training states across A/B/C, and deliberately retain training states in the known-state diagnostic. All {main['calibration_selected_models']} selected SVM audits and their {main['calibration_folds_verified']} inner folds match the actual three candidate training-state folds. Expected fitting and held states, training-only record counts, both-class support and exactly-once held training records were checked. Neither validation nor unknown-test states enter these audits. Known-test proxies are excluded even though their states occur in training.", "",
        f"Ten trusted local model files were reloaded using fixed model IDs chosen independently of scores. Their predicted probabilities from the original frozen feature tables match saved probabilities within {reload_max:.3g}. For all seven sampled scaled estimators, independently calculated weighted training means and variances match the persisted scaler; sampled final SVM support vectors exactly match indexed transformed training rows. Prediction does not mutate the scaler. These checks support actual train-only final fitting. The inner fitted SVMs and OOF scores were not persisted, so their saved state/count audit plus source-code inspection cannot establish a complete historical trace of every access.", "",
        "## SVM calibration-unit limitation", "",
        "Let d_i be a window decision, and g(d) the fitted ridge sigmoid. Training first averages OOF decisions in a proxy and fits g(mean_i d_i). Inference instead predicts g(d_i) for each window and the scoring routine takes mean_i g(d_i). In general, g(mean_i d_i) differs from mean_i g(d_i). Therefore the final mean-window probability is not calibrated by the same record-level mapping used to train the sigmoid. No held test is used to fit either mapping; this is an aggregation-order and inference-unit mismatch, not test leakage.", "",
        f"The audit diagnoses both operations on five preselected native-fullband SVMs (one per rotation, alternating target). Across their 15 split checks, maximum absolute proxy-probability difference is {sigmoid_max:.6g}, with {flips} proxy/split threshold-crossing occurrences at p≥0.5. The alternate operation is an audit diagnostic only: no alternative prediction replaces a saved result, no hyperparameter is reselected, and no performance remedy is claimed. The per-model differences and both diagnostic NLL values are retained in `verification.json`.", "",
        "Even with matching aggregation, OOF decisions come from smaller two-fold training pools while final decisions come from the complete three-fold actual training pool. Their score distributions can differ. In addition, calibration uses equal-state weights whereas primary metrics give each proxy equal weight. Neither the label 'calibrated SVM' nor train-only sigmoid fitting demonstrates reliable probabilities on unseen combinations. The manuscript should call this a training-state OOF sigmoid SVM and state that record probabilities average sigmoid-transformed window scores; NLL/Brier are measured outcomes, not calibration guarantees. A prospective revised mapping would need a separately frozen design and should not silently overwrite these results.", "",
        "## Native full-band feature verification", "",
        f"Command: `{tests['command']}`. Exit code {tests['returncode']}. `{tests['summary']}` The 10 tests cover 3000/12000-Hz carrier-energy retention versus a 180-Hz low-pass, finite zero-input features, inward native cropping, outside-interval impulse exclusion, variable point budgets, invalid boundaries, all 404 IDs and 25 finite feature columns. No test correction was required.", "",
        "The native feature extractor keeps raw 25.6-kHz channel 0 on each common physical interval, using ceil(start×fs) through floor(stop×fs) inclusively, before any statistic or within-interval periodogram. No low-pass, resampling or full-segment filter context is added. Native support varies from 3712 to 9168 points. Summed endpoint discrepancy stays below 2/fs; this baseline is not matched to the 2048-point inputs. Exact Nyquist energy contributes to the total spectrum and statistics but is excluded from the final upper-exclusive physical band.", "",
        "## Reproduction and interpretation", "",
        "Run `python scripts/v4/verify_state_results.py`. The verifier uses independent aggregation/metric formulas, all stored feature and assignment hashes, and fixed model reload IDs. Results are `results/v4/verification.json` and this report. Add `--repository` only after all 60 repository models are complete to audit its frozen design through the same checks.", "",
        "This verifies artifact arithmetic, declared isolation and selected inference behavior. It does not establish bearing independence, new-rig validation, lack of all possible shortcuts, or preregistration. State sharing in v3 answers a known-combination/new-proxy task; v4 changes the test population and training composition. Score differences between these designs cannot all be attributed to leakage."]
    if document.get("repository_benchmark"):
        repo = document["repository_benchmark"]
        lines.extend(["", "## Repository-extension verification", "",
            f"The separate repository benchmark passed the same checks: {repo['selected_models']} selected models, {repo['recorded_candidate_pipeline_fits']} recorded candidates, {repo['metric_split_rows']} recomputed model/split metric rows and {len(repo['reloaded_models'])} fixed model reloads. Its hashes and design are verified separately. SVM aggregation-unit limitations also apply to this extension."])
    if document.get("analysis_verification"):
        analysis = document["analysis_verification"]
        lines.extend(["", "## Analysis and conditional-interval verification", "",
            f"The 96 pooled OOF rows and 1,440 fold rows agree with the independent raw-result recomputation. All 64 conditional intervals and 56 paired contrasts were independently rebuilt from the fixed 2,000 joint-label-stratified state-cluster draws, preserving every proxy in its state. The maximum interval discrepancy is {analysis['max_interval_error']:.3g}, and the maximum paired-contrast discrepancy is {analysis['max_paired_contrast_error']:.3g}. Manual weighted confusion arithmetic also agrees with sklearn Macro-F1 on 192 fixed group/draw checks. All 64 seed summaries agree. These checks verify the declared conditional bootstrap, not unconditional inference over machines, bearings, model selection or retraining."])
    return "\n".join(lines) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repository", action="store_true", help="also require and verify all 60 repository-extension models")
    args = parser.parse_args()
    command = [sys.executable, "-m", "pytest", "tests/data/test_v4_native_features.py", "-q", "-p", "no:cacheprovider"]
    test = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=120)
    assert test.returncode == 0, test.stdout + test.stderr
    summary = next((line for line in reversed(test.stdout.splitlines()) if "passed" in line), "test command exited zero")
    output = dict(verified_utc=datetime.now(timezone.utc).isoformat(), verifier_sha256=digest(Path(__file__)),
                  native_tests=dict(command="python -m pytest tests/data/test_v4_native_features.py -q -p no:cacheprovider",
                                    returncode=test.returncode, summary=summary, stdout=test.stdout, stderr=test.stderr),
                  state_benchmark=verify(ROOT / "results/v4/state_benchmark"), repository_benchmark=None,
                  benchmark_inputs_or_artifacts_modified=False)
    if args.repository:
        output["repository_benchmark"] = verify(ROOT / "results/v4/repository_benchmark", repository=True)
        if (ROOT / "results/v4/analysis/analysis_provenance.json").exists():
            output["analysis_verification"] = verify_analysis(output["state_benchmark"], output["repository_benchmark"])
    target = ROOT / "results/v4/verification.json"
    target.write_text(json.dumps(output, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    report = ROOT / "docs/v4/model_verification.md"
    report.write_text(render_report(output), encoding="utf-8")
    result = output["state_benchmark"]
    print(json.dumps(dict(status=result["status"], selected=result["selected_models"], candidates=result["recorded_candidate_pipeline_fits"],
                         metric_rows=result["metric_split_rows"], max_errors=result["maximum_absolute_metric_errors"],
                         reloads=len(result["reloaded_models"]), native_tests=summary,
                         report=str(report), verification=str(target)), indent=2), flush=True)


if __name__ == "__main__":
    main()
