"""Retrospective state-disjoint diagnosis with a same-model known-state test.

Fit/selection/calibration use training/validation only. All test predictions are
stored, including failures. Physical-bearing identity is not established.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, f1_score, log_loss, roc_auc_score
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

ROOT = Path(__file__).resolve().parents[2]
TASKS = ('inner_presence', 'outer_presence')
REPS = ('metadata_only', 'native_fullband', 'time_envelope', 'time_envelope_meta',
        'order_generic', 'order_generic_meta', 'order_geometry')
MODEL_GRID = (
    ('extra_trees', (11, 22, 33), ({'leaf': 1}, {'leaf': 3})),
    ('random_forest', (11,), ({'leaf': 1}, {'leaf': 3})),
    ('state_calibrated_svm', (11,), ({'C': .1}, {'C': 1.}, {'C': 10.})),
    ('logistic', (11,), ({'C': .1}, {'C': 1.}, {'C': 10.})),
)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def balanced_state_weights(frame):
    """Equal total weight per state; equal records within state, then windows."""
    if frame.groupby('inferred_source_group').state_id.nunique().max() != 1:
        raise ValueError('record maps to multiple states')
    records = frame.drop_duplicates('inferred_source_group')
    nrecords = records.groupby('state_id').size()
    nwindows = frame.groupby('inferred_source_group').size()
    w = 1. / (frame.state_id.map(nrecords).to_numpy(float)
               * frame.inferred_source_group.map(nwindows).to_numpy(float))
    return w / w.mean()


def record_table(frame, y, p):
    out = frame[['inferred_source_group', 'state_id', 'state_fold', 'subset']].copy()
    out['label'] = np.asarray(y, int)
    out['p1'] = np.asarray(p, float)
    if out.groupby('inferred_source_group').label.nunique().max() != 1:
        raise ValueError('conflicting labels within record')
    return out.groupby('inferred_source_group', sort=True).agg(
        state_id=('state_id', 'first'), state_fold=('state_fold', 'first'),
        subset=('subset', 'first'), label=('label', 'first'), p1=('p1', 'mean')).reset_index()


def score_records(table):
    y, p = table.label.to_numpy(int), table.p1.to_numpy(float)
    if not np.isfinite(p).all() or np.any((p < 0) | (p > 1)):
        raise ValueError('invalid probabilities')
    pred = (p >= .5).astype(int)
    sw = 1. / table.state_id.map(table.groupby('state_id').size()).to_numpy(float)
    return {'n_records': len(y), 'n_states': int(table.state_id.nunique()),
            'macro_f1': float(f1_score(y, pred, labels=[0, 1], average='macro', zero_division=0)),
            'state_weighted_macro_f1': float(f1_score(y, pred, labels=[0, 1], average='macro',
                                                    sample_weight=sw, zero_division=0)),
            'balanced_accuracy': float(balanced_accuracy_score(y, pred)),
            'auroc': float(roc_auc_score(y, p)) if len(np.unique(y)) == 2 else None,
            'nll': float(log_loss(y, np.c_[1-p, p], labels=[0, 1])),
            'brier': float(np.mean((p-y)**2))}


class ScaledLinear:
    def __init__(self, c, seed):
        self.scaler = StandardScaler()
        self.estimator = LogisticRegression(C=c, max_iter=3000, random_state=seed)

    def fit(self, x, y, weights):
        self.estimator.fit(self.scaler.fit_transform(x, sample_weight=weights), y, sample_weight=weights)
        return self

    def predict_proba(self, x):
        return self.estimator.predict_proba(self.scaler.transform(x))


class StateCalibratedSVM:
    """Three state-blocked OOF decision scores -> record-level ridge sigmoid.

    Sigmoid C=1 is fixed, not tuned. OOF records have equal total weight per
    state. Final SVM/scaler refit on training only; no validation/test fitting.
    """
    def __init__(self, c):
        self.c = c
        self.calibration_audit = []

    def _base(self):
        return StandardScaler(), SVC(C=self.c, kernel='rbf', gamma='scale', probability=False)

    def fit(self, x, y, frame):
        folds = sorted(frame.state_fold.unique())
        if len(folds) != 3:
            raise ValueError('calibration requires the three candidate training-state folds')
        decisions = np.full(len(y), np.nan)
        for fold in folds:
            ca = frame.state_fold.eq(fold).to_numpy()
            tr = ~ca
            if set(y[tr]) != {0, 1} or set(y[ca]) != {0, 1}:
                raise ValueError('single-class calibration fit or holdout')
            assert not set(frame.loc[tr, 'state_id']) & set(frame.loc[ca, 'state_id'])
            scaler, svm = self._base()
            weights = balanced_state_weights(frame.loc[tr])
            svm.fit(scaler.fit_transform(x[tr], sample_weight=weights), y[tr], sample_weight=weights)
            decisions[ca] = svm.decision_function(scaler.transform(x[ca]))
            self.calibration_audit.append({'held_state_fold': int(fold),
                'fit_state_ids': sorted(frame.loc[tr, 'state_id'].unique().tolist()),
                'held_state_ids': sorted(frame.loc[ca, 'state_id'].unique().tolist()),
                'fit_records': int(frame.loc[tr, 'inferred_source_group'].nunique()),
                'held_records': int(frame.loc[ca, 'inferred_source_group'].nunique())})
        assert np.isfinite(decisions).all()
        rt = record_table(frame, y, decisions)
        weights = 1. / rt.state_id.map(rt.groupby('state_id').size()).to_numpy(float)
        weights /= weights.mean()
        self.sigmoid = LogisticRegression(C=1., max_iter=2000)
        self.sigmoid.fit(rt[['p1']].to_numpy(), rt.label.to_numpy(), sample_weight=weights)
        self.scaler, self.svm = self._base()
        weights = balanced_state_weights(frame)
        self.svm.fit(self.scaler.fit_transform(x, sample_weight=weights), y, sample_weight=weights)
        self.calibration_records = len(rt)
        return self

    def predict_proba(self, x):
        decision = self.svm.decision_function(self.scaler.transform(x))
        return self.sigmoid.predict_proba(decision[:, None])


def fit_candidate(name, config, x, y, frame, seed):
    weights = balanced_state_weights(frame)
    if name == 'state_calibrated_svm':
        return StateCalibratedSVM(config['C']).fit(x, y, frame)
    if name == 'logistic':
        return ScaledLinear(config['C'], seed).fit(x, y, weights)
    cls = ExtraTreesClassifier if name == 'extra_trees' else RandomForestClassifier
    model = cls(n_estimators=200 if name == 'extra_trees' else 300,
                min_samples_leaf=config['leaf'], max_features=1. if name == 'extra_trees' else 'sqrt',
                class_weight=None, n_jobs=2, random_state=seed)
    model.fit(x, y, sample_weight=weights)
    return model


def load_inputs(include_repository=False):
    fp = ROOT / 'data/processed/v3/novic_physical_features.csv'
    lp = ROOT / 'data/processed/v3/novic_physical_lineage.csv'
    bp = ROOT / 'data/processed/v3/novic_physical_feature_blocks.json'
    npth = ROOT / 'data/processed/v4/native_fullband_features.csv'
    ap = ROOT / 'results/v4/state_dual_test_assignments.csv'
    table, frame, native = pd.read_csv(fp), pd.read_csv(lp), pd.read_csv(npth)
    assert table.sample_id.equals(frame.sample_id) and native.sample_id.equals(frame.sample_id)
    blocks = json.loads(bp.read_text(encoding='utf-8'))['blocks']
    generic = [c for c in blocks['order_envelope'] if not any(
        term in c.lower() for term in ('bpfi', 'bpfo', 'bsf', 'ftf', 'harmonic'))]
    cols = {'metadata_only': blocks['metadata_only'],
            'native_fullband': [c for c in native if c != 'sample_id'],
            'time_envelope': blocks['time_envelope'],
            'time_envelope_meta': blocks['time_envelope'] + blocks['metadata_only'],
            'order_generic': generic, 'order_generic_meta': generic + blocks['metadata_only'],
            'order_geometry': blocks['order_envelope']}
    table = table.merge(native, on='sample_id', validate='one_to_one', sort=False)
    paths = [fp, lp, bp, npth, ap, Path(__file__)]
    if include_repository:
        rp = ROOT / 'data/processed/v4/mfos_repository_features.csv'
        repo = pd.read_csv(rp)
        assert repo.sample_id.equals(frame.sample_id)
        repo_columns = [c for c in repo if c != 'sample_id']
        if any(any(t in c.lower() for t in ('label', 'class', 'file_id', 'sample_id')) for c in repo_columns):
            raise ValueError('identifier or label-like repository feature column')
        cols['mfos_repository'] = repo_columns
        table = table.merge(repo, on='sample_id', validate='one_to_one', sort=False)
        paths.append(rp)
    for k, cc in cols.items():
        if not np.isfinite(table[cc].to_numpy(float)).all():
            raise ValueError('nonfinite ' + k)
    return table, pd.read_csv(ap), cols, paths


def run(args):
    table, assignments, blocks, paths = load_inputs(args.repository)
    out = ROOT / ('results/v4/repository_benchmark' if args.repository else 'results/v4/state_benchmark')
    out.mkdir(parents=True, exist_ok=True)
    representations = ['mfos_repository'] if args.repository else list(REPS)
    registration = {'frozen_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'retrospective extension; all v3 outcomes and external v4 outcomes already known; no v4 internal models fit before this design',
        'purpose': 'same trained model, known-state new-record versus completely held-out state combinations; adequate native-bandwidth raw baseline and metadata/geometry ablations',
        'split_source': 'results/v4/state_dual_test_assignments.csv',
        'tasks': TASKS, 'representations': representations,
        'feature_counts': {k: len(blocks[k]) for k in representations},
        'models': MODEL_GRID,
        'expected_selected_models': 5*2*len(representations)*6,
        'candidate_pipeline_fits': 5*2*len(representations)*14,
        'selection': 'maximum validation equal-record macro-F1, lower record NLL, first grid item; no refit after validation; fixed p>=0.5',
        'training_weights': 'equal state total; equal record within state; equal window within record; mean weight one; class_weight=None',
        'svm_calibration': 'three whole state-fold training OOF; training-only weighted scalers; average decision per record; state-weighted ridge sigmoid C=1; final base fits training only',
        'primary': 'pooled unknown-state OOF equal-record macro-F1, each of 79 recording proxies once; equal-state weighted macro-F1 secondary',
        'known_test': 'same model as unknown test; held records of training states; repeated across rotations, hence not independent pooled observations',
        'uncertainty': '2000 joint-label-stratified state-cluster percentile bootstrap draws, conditional on fixed trained models; selected by seed11 beforehand for primary comparisons, other ET seeds sensitivity; no bearing-level independence claim',
        'limitations': ['33 fixed states, normal is one state in fold1; normal absent from training in rotations0 and1',
            'record IDs are filename-derived proxies; state definition reflects exact discrete engineering combinations, not unseen fault types',
            'native baseline variable native points vs 2048 envelope points; no matched-point claim',
            'known and unknown tests have different state composition; same model removes training-set confound but not all population differences'],
        'sha256': {str(p.relative_to(ROOT)): digest(p) for p in paths},
        'software': {'numpy': np.__version__, 'pandas': pd.__version__, 'sklearn': sklearn.__version__}}
    dp = out / 'design.json'
    if dp.exists():
        old = json.loads(dp.read_text(encoding='utf-8'))
        registration['frozen_utc'] = old['frozen_utc']
        # JSON changes tuples to lists: compare canonical encodings.
        if json.dumps(registration, sort_keys=True) != json.dumps(old, sort_keys=True):
            raise ValueError('frozen design mismatch; do not overwrite')
    else:
        dump(dp, registration)
    print('DESIGN FROZEN ' + str(dp), flush=True)
    if args.freeze_only:
        return
    for protocol in sorted(assignments.protocol.unique()):
        frame = assignments[assignments.protocol.eq(protocol)].reset_index(drop=True)
        assert frame.sample_id.equals(table.sample_id)
        masks = {s: frame.assigned_split.eq(s).to_numpy() for s in ('train', 'validation', 'test_known', 'test_unknown')}
        for s, mask in masks.items():
            for task in TASKS:
                assert set(frame.loc[mask, task]) == {0, 1}, (protocol, s, task)
        for task in TASKS:
            y = frame[task].to_numpy(int)
            trframe = frame.loc[masks['train']].reset_index(drop=True)
            for rep in representations:
                cc = blocks[rep]
                x = table[cc].to_numpy(float)
                for name, seeds, grid in MODEL_GRID:
                    for seed in seeds:
                        stem = f'{protocol}_{task}_{rep}_{name}_s{seed}'
                        result_path = out / (stem + '.json')
                        if result_path.exists():
                            continue
                        start = time.perf_counter()
                        best, selected, candidates = (-1., -np.inf), None, []
                        for config in grid:
                            model = fit_candidate(name, config, x[masks['train']], y[masks['train']], trframe, seed)
                            vp = model.predict_proba(x[masks['validation']])[:, 1]
                            vm = score_records(record_table(frame.loc[masks['validation']], y[masks['validation']], vp))
                            key = (vm['macro_f1'], -vm['nll'])
                            candidates.append({'config': config, 'validation_record': vm})
                            if key > best:
                                best, selected, chosen, selected_vp = key, model, config, vp
                        # Exactly one inference on combined test rows after selection.
                        tm = masks['test_known'] | masks['test_unknown']
                        tp = selected.predict_proba(x[tm])[:, 1]
                        pfull = np.full(len(frame), np.nan)
                        pfull[tm], pfull[masks['validation']] = tp, selected_vp
                        rows, metrics = [], {}
                        for split in ('validation', 'test_known', 'test_unknown'):
                            mask = masks[split]
                            rt = record_table(frame.loc[mask], y[mask], pfull[mask])
                            metrics[split] = score_records(rt)
                            sf = frame.loc[mask, ['sample_id', 'inferred_source_group', 'state_id', 'state_fold', 'subset']].copy()
                            sf['split'], sf['label'], sf['p1'] = split, y[mask], pfull[mask]
                            rows.append(sf)
                        pp, mp = out / (stem + '_predictions.csv'), out / (stem + '.joblib')
                        pd.concat(rows, ignore_index=True).to_csv(pp, index=False)
                        joblib.dump(selected, mp, compress=3)
                        result = {'protocol': protocol, 'task': task, 'representation': rep, 'model': name,
                            'seed': seed, 'feature_columns': cc, 'n_features': len(cc), 'chosen': chosen,
                            'candidates': candidates, **metrics, 'seconds': time.perf_counter()-start,
                            'calibration_audit': getattr(selected, 'calibration_audit', []),
                            'calibration_records': getattr(selected, 'calibration_records', None),
                            'train_states': int(trframe.state_id.nunique()),
                            'train_records': int(trframe.inferred_source_group.nunique()),
                            'test_predict_calls': 1, 'design_sha256': digest(dp),
                            'predictions': pp.name, 'predictions_sha256': digest(pp), 'model_sha256': digest(mp)}
                        dump(result_path, result)
                        print(f"DONE {stem}: known={metrics['test_known']['macro_f1']:.3f}; unknown={metrics['test_unknown']['macro_f1']:.3f}", flush=True)
    print('COMPLETE state benchmark', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repository', action='store_true', help='separate planned public repository implementation extension')
    parser.add_argument('--freeze-only', action='store_true')
    # Persist custom estimators under an importable module, not __main__.
    from scripts.v4.run_state_benchmark import run as stable_run
    stable_run(parser.parse_args())
