"""Post hoc inference-unit sensitivity using all 80 frozen selected SVMs.

No fitting, hyperparameter selection or frozen-artifact replacement occurs.
Original inference: mean_r sigmoid(d_window).
Matched inference unit: sigmoid(mean_r d_window), matching calibration inputs.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib
import json
from pathlib import Path
import sys
import time

import joblib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits


ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
DEFAULT_OUTPUT = ROOT / "results/v4/svm_aggregation_sensitivity"


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def aggregate_decisions(frame, decisions, sigmoid):
    """Apply the existing sigmoid after complete-record decision averaging."""
    f = frame[["inferred_source_group", "state_id", "state_fold", "subset", "label"]].copy()
    d = np.asarray(decisions, dtype=float)
    if len(f) != len(d) or d.ndim != 1 or not np.isfinite(d).all():
        raise ValueError("Decision scores must be finite and align with window rows")
    if not np.array_equal(np.asarray(sigmoid.classes_), [0, 1]):
        raise ValueError("Expected binary sigmoid classes [0, 1]")
    grouped = f.groupby("inferred_source_group", sort=True)
    for column in ["label", "state_id", "state_fold", "subset"]:
        if grouped[column].nunique(dropna=False).max() != 1:
            raise ValueError(f"conflicting record {column}")
    f["decision"] = d
    f["p1_window"] = sigmoid.predict_proba(d[:, None])[:, 1]
    out = f.groupby("inferred_source_group", sort=True).agg(
        state_id=("state_id", "first"), state_fold=("state_fold", "first"),
        subset=("subset", "first"), label=("label", "first"),
        n_windows=("decision", "size"), mean_decision=("decision", "mean"),
        decision_std=("decision", lambda x: float(np.std(x.to_numpy(), ddof=0))),
        p1_original=("p1_window", "mean")).reset_index()
    out["p1_corrected"] = sigmoid.predict_proba(out[["mean_decision"]].to_numpy())[:, 1]
    out["probability_difference"] = out.p1_corrected-out.p1_original
    out["absolute_probability_difference"] = np.abs(out.probability_difference)
    out["prediction_original"] = (out.p1_original >= 0.5).astype(int)
    out["prediction_corrected"] = (out.p1_corrected >= 0.5).astype(int)
    out["class_changed"] = out.prediction_original.ne(out.prediction_corrected)
    return out


def comparison_metrics(records, score_records):
    metrics = {}
    for name, column in [("original", "p1_original"), ("corrected", "p1_corrected")]:
        one = records.copy()
        one["p1"] = one[column]
        metrics.update({name+"_"+k: v for k, v in score_records(one).items()})
    for key in ["macro_f1", "state_weighted_macro_f1", "nll", "brier", "balanced_accuracy", "auroc"]:
        a, b = metrics["original_"+key], metrics["corrected_"+key]
        metrics["delta_"+key] = None if a is None or b is None else b-a
    metrics.update({"max_absolute_probability_difference": float(records.absolute_probability_difference.max()),
                    "mean_absolute_probability_difference": float(records.absolute_probability_difference.mean()),
                    "class_changes": int(records.class_changed.sum())})
    return metrics


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    begin = time.perf_counter()
    # Import the exact module named in the joblib pickle before deserializing.
    helper = importlib.import_module("scripts.v4.run_state_benchmark")
    table, assignments, blocks, input_paths = helper.load_inputs(include_repository=True)
    benchmark_dirs = [ROOT/"results/v4/state_benchmark", ROOT/"results/v4/repository_benchmark"]
    model_paths = sorted(p for folder in benchmark_dirs
                         for p in folder.glob("*state_calibrated_svm_s11.joblib"))
    if len(model_paths) != 80:
        raise ValueError(f"Expected 80 frozen selected SVMs, found {len(model_paths)}")
    metadata = {p: json.loads(p.with_suffix(".json").read_text(encoding="utf-8")) for p in model_paths}
    model_keys = {(m["protocol"], m["task"], m["representation"]) for m in metadata.values()}
    expected = {(f"state_dual_{f}", t, r) for f in range(5) for t in helper.TASKS for r in blocks}
    if model_keys != expected:
        raise ValueError("Frozen model tuple set does not match 5 folds x 2 tasks x 8 representations")
    frozen_paths = set(Path(p).resolve() for p in input_paths)
    for p, m in metadata.items():
        frozen_paths.update([p.resolve(), p.with_suffix(".json").resolve(),
                             (p.parent/m["predictions"]).resolve(), (p.parent/"design.json").resolve()])
    before = {str(p): {"sha256": digest(p), "mtime_ns": p.stat().st_mtime_ns} for p in sorted(frozen_paths)}
    for p, m in metadata.items():
        if digest(p) != m["model_sha256"]:
            raise ValueError("Frozen model checksum mismatch: "+str(p))
        if digest(p.parent/m["predictions"]) != m["predictions_sha256"]:
            raise ValueError("Frozen prediction checksum mismatch: "+str(p))
        if digest(p.parent/"design.json") != m["design_sha256"]:
            raise ValueError("Frozen design checksum mismatch: "+str(p))

    all_records, fold_metrics, model_checks = [], [], []
    with threadpool_limits(limits=1):
        for i, p in enumerate(model_paths):
            m = metadata[p]
            protocol, task, rep = m["protocol"], m["task"], m["representation"]
            frame = assignments[assignments.protocol.eq(protocol)].reset_index(drop=True)
            if not frame.sample_id.equals(table.sample_id):
                raise ValueError("Assignment and feature sample ordering differs")
            cc = m["feature_columns"]
            if cc != blocks[rep]:
                raise ValueError("Frozen feature order does not match loaded representation")
            if frame.groupby("inferred_source_group").assigned_split.nunique().max() != 1:
                raise ValueError("A source recording crosses a split")
            test_mask = frame.assigned_split.isin(["test_known", "test_unknown"]).to_numpy()
            selected = frame.loc[test_mask].copy()
            selected["label"] = selected[task].to_numpy(int)
            x = table.loc[test_mask, cc].to_numpy(float)
            model = joblib.load(p)
            if not isinstance(model, helper.StateCalibratedSVM) or model.c != m["chosen"]["C"]:
                raise ValueError("Wrong frozen model class or selected C")
            fingerprints = {name: joblib.hash(getattr(model, name)) for name in ["scaler", "svm", "sigmoid"]}
            model_fingerprint = joblib.hash(model)
            decision = model.svm.decision_function(model.scaler.transform(x))
            original_window = model.sigmoid.predict_proba(decision[:, None])[:, 1]
            frozen = pd.read_csv(p.parent/m["predictions"])
            frozen = frozen[frozen.split.isin(["test_known", "test_unknown"])].set_index("sample_id")
            if set(frozen.index) != set(selected.sample_id):
                raise ValueError("Frozen test sample set differs")
            frozen_aligned = frozen.loc[selected.sample_id]
            if not np.array_equal(frozen_aligned.label.to_numpy(int), selected.label.to_numpy(int)):
                raise ValueError("Frozen test labels differ")
            discrepancy = float(np.max(np.abs(frozen_aligned.p1.to_numpy()-original_window)))
            if discrepancy > 1e-12:
                raise ValueError(f"Original probability reproduction mismatch {discrepancy}")
            full_counts = frame.groupby("inferred_source_group").size()
            for split in ["test_known", "test_unknown"]:
                sm = selected.assigned_split.eq(split).to_numpy()
                sf = selected.loc[sm]
                observed_counts = sf.groupby("inferred_source_group").size()
                if not observed_counts.equals(full_counts.loc[observed_counts.index]):
                    raise ValueError("Incomplete source group in test aggregation")
                records = aggregate_decisions(sf, decision[sm], model.sigmoid)
                records.insert(0, "split", split)
                records.insert(0, "representation", rep)
                records.insert(0, "task", task)
                records.insert(0, "protocol", protocol)
                summary = comparison_metrics(records, helper.score_records)
                for key in ["macro_f1", "nll", "brier"]:
                    if abs(summary["original_"+key]-m[split][key]) > 1e-10:
                        raise ValueError("Original aggregate metric does not match frozen result")
                fold_metrics.append({"protocol": protocol, "task": task, "representation": rep,
                                     "split": split, **summary})
                all_records.append(records)
            unchanged = all(joblib.hash(getattr(model, name)) == fp for name, fp in fingerprints.items())
            if not unchanged or joblib.hash(model) != model_fingerprint:
                raise ValueError("Frozen estimator state changed during inference")
            model_checks.append({"protocol": protocol, "task": task, "representation": rep,
                                 "model_path": str(p.relative_to(ROOT)), "selected_C": model.c,
                                 "original_probability_max_reproduction_error": discrepancy,
                                 "scaler_svm_sigmoid_unchanged": unchanged,
                                 "model_hash_before": model_fingerprint,
                                 "model_hash_after": joblib.hash(model),
                                 "model_file_sha256": digest(p)})
            if (i+1) % 20 == 0:
                print(f"Audited frozen SVMs {i+1}/80", flush=True)

    records = pd.concat(all_records, ignore_index=True)
    unknown = records[records.split.eq("test_unknown")].copy()
    pooled_rows = []
    for (task, rep), one in unknown.groupby(["task", "representation"], sort=True):
        if len(one) != 79 or one.inferred_source_group.nunique() != 79 or one.protocol.nunique() != 5:
            raise ValueError("Unknown OOF must contain each of the 79 records exactly once")
        pooled_rows.append({"task": task, "representation": rep, "split": "test_unknown_oof",
                            **comparison_metrics(one, helper.score_records)})
    if len(pooled_rows) != 16:
        raise ValueError("Expected 16 pooled task x representation results")
    after = {str(p): {"sha256": digest(p), "mtime_ns": p.stat().st_mtime_ns} for p in sorted(frozen_paths)}
    if before != after:
        raise ValueError("An original input/model/prediction/design artifact changed")
    # p1 names the matched record-inference probability for convenient SI use.
    records["p1"] = records.p1_corrected
    files = {"corrected_record_predictions.csv": records,
             "corrected_unknown_oof_record_predictions.csv": records[records.split.eq("test_unknown")],
             "pooled_unknown_metrics.csv": pd.DataFrame(pooled_rows),
             "fold_metrics.csv": pd.DataFrame(fold_metrics),
             "frozen_model_checks.csv": pd.DataFrame(model_checks)}
    for name, content in files.items():
        content.to_csv(out/name, index=False)
    audit = {"created_utc": datetime.now(timezone.utc).isoformat(),
             "status": "complete: post hoc inference-only sensitivity after identifying an implementation-unit mismatch",
             "reason": "sigmoid fitted to record-mean training OOF decisions, whereas frozen inference averages window sigmoid probabilities",
             "original_aggregation": "mean_window sigmoid(decision_window)",
             "matched_inference_aggregation": "sigmoid(mean_window decision_window)",
             "no_retraining": True, "no_hyperparameter_reselection": True,
             "no_test_based_aggregation_selection": True,
             "frozen_models": len(model_paths), "tasks": list(helper.TASKS),
             "representations": list(blocks), "unknown_oof_records_per_task_representation": 79,
             "known_test_interpretation": "five per-fold descriptive points; repeated recordings must not be treated as independent pooled known-test observations",
             "unknown_rows": len(unknown), "all_record_rows": len(records),
             "max_probability_difference_unknown": float(unknown.absolute_probability_difference.max()),
             "max_probability_difference_all_tests": float(records.absolute_probability_difference.max()),
             "class_changes_unknown": int(unknown.class_changed.sum()),
             "max_original_probability_reproduction_error": float(pd.DataFrame(model_checks).original_probability_max_reproduction_error.max()),
             "all_scalers_svms_sigmoids_unchanged": True,
             "all_frozen_file_hashes_and_mtimes_unchanged": True,
             "frozen_artifact_snapshot": before,
             "script_sha256": digest(Path(__file__)),
             "output_sha256": {name: digest(out/name) for name in files},
             "elapsed_seconds": time.perf_counter()-begin,
             "limitations": ["Posterior correction was motivated by implementation review after tests were seen; it is not pre-specified",
                             "C and all fitted parameters remain those selected under the original window-probability aggregation",
                             "Matched inference unit does not guarantee calibrated probabilities under shift",
                             "No new training or validation aggregation search is performed",
                             "This sensitivity does not fix any OOF-versus-final-base score-distribution differences",
                             "Original manuscript tables remain frozen; present original and corrected inference explicitly"]}
    (out/"audit.json").write_text(json.dumps(audit, indent=2, allow_nan=False), encoding="utf-8")
    print(json.dumps({k: audit[k] for k in ["frozen_models", "unknown_rows", "all_record_rows",
                     "max_probability_difference_unknown", "class_changes_unknown", "elapsed_seconds"]}), flush=True)


if __name__ == "__main__":
    main()
