"""Native full-band conventional features on the existing v3 physical intervals.

The 25.6-kHz channel-0 interval is cropped before any statistics or periodogram.
There is no low-pass, resampling, demodulation, or cross-interval filter context.
The input sample count varies with the measured duration of each eight-turn span.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
FS = 25600.0
BINS = ((0.0, 500.0), (500.0, 2000.0), (2000.0, 5000.0), (5000.0, 12800.0))
PREFIX = "native_fullband__"
BASE_PATH = ROOT / "scripts/v3/prepare_novic_physical_features.py"
spec = importlib.util.spec_from_file_location("native_v4_v3_feature_definitions", BASE_PATH)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def crop_native_interval(x: np.ndarray, start_s: float, stop_s: float) -> tuple[np.ndarray, dict]:
    """Inward crop: ceil(start*fs) through floor(stop*fs), both included."""
    x = np.asarray(x)
    if x.ndim != 1 or len(x) < 3:
        raise ValueError("Native source must be a one-dimensional sampled signal")
    if not np.isfinite([start_s, stop_s]).all() or start_s < 0 or stop_s <= start_s:
        raise ValueError("Native interval boundaries must be finite, ordered and nonnegative")
    if stop_s > (len(x) - 1) / FS:
        raise ValueError("Native interval exceeds the final measured source-sample time")
    first, last = int(np.ceil(start_s * FS)), int(np.floor(stop_s * FS))
    if first < 0 or last >= len(x) or last - first + 1 < 3:
        raise ValueError("Native interval must contain at least three measured source samples")
    retained_start, retained_stop = first / FS, last / FS
    start_error, stop_error = retained_start - start_s, stop_s - retained_stop
    if start_error < -1e-12 or stop_error < -1e-12:
        raise ValueError("Native crop unexpectedly extends outside the physical interval")
    details = dict(first_native_sample=first, last_native_sample_inclusive=last,
                   native_points=last - first + 1,
                   physical_start_s=float(start_s), physical_stop_s=float(stop_s),
                   retained_start_s=float(retained_start), retained_stop_s=float(retained_stop),
                   retained_point_span_s=float((last - first) / FS),
                   start_endpoint_error_s=float(start_error), stop_endpoint_error_s=float(stop_error),
                   summed_endpoint_error_s=float(start_error + stop_error), native_sample_rate_hz=FS)
    return x[first:last + 1], details


def native_features(x: np.ndarray) -> tuple[dict, dict]:
    """Twelve amplitude, five spectral, and eight fixed physical-band features."""
    values, definitions = base.feature_block(np.asarray(x, dtype=float), FS, "Hz", "g", list(BINS))
    values = {PREFIX + key: value for key, value in values.items()}
    definitions = {PREFIX + key: {**value, "block": "native_fullband"} for key, value in definitions.items()}
    if len(values) != 25 or not np.isfinite(list(values.values())).all():
        raise ValueError("Native full-band feature vector must contain 25 finite values")
    return values, definitions


def build_feature_table(raw: np.ndarray, lineage: pd.DataFrame) -> tuple[pd.DataFrame, dict, pd.DataFrame]:
    """Preserve every lineage row and ID while reading only source channel zero."""
    if raw.ndim != 3 or raw.shape[2] < 1:
        raise ValueError("Native source must have segment, time, channel dimensions")
    required = {"sample_id", "array_row", "physical_start_s", "physical_stop_s"}
    if not required <= set(lineage.columns) or lineage.sample_id.duplicated().any():
        raise ValueError("Lineage must contain physical endpoints and unique sample IDs")
    rows, crop_rows, definitions = [], [], {}
    for row in lineage.itertuples(index=False):
        source_row = int(row.array_row)
        if source_row != row.array_row or source_row < 0 or source_row >= raw.shape[0]:
            raise ValueError("Lineage source-row index is invalid")
        cropped, details = crop_native_interval(raw[source_row, :, 0], float(row.physical_start_s), float(row.physical_stop_s))
        values, current_definitions = native_features(cropped)
        if definitions and definitions != current_definitions:
            raise ValueError("Native feature schema changed between intervals")
        definitions = current_definitions
        rows.append({"sample_id": row.sample_id, **values})
        crop_rows.append({"sample_id": row.sample_id, "array_row": source_row, **details})
    features = pd.DataFrame(rows)
    crops = pd.DataFrame(crop_rows)
    if len(features) != len(lineage) or not np.array_equal(features.sample_id, lineage.sample_id):
        raise ValueError("Native output failed to preserve lineage order")
    return features, definitions, crops


def main() -> None:
    output = ROOT / "data/processed/v4"
    output.mkdir(parents=True, exist_ok=True)
    lineage_path = ROOT / "data/processed/v3/novic_physical_lineage.csv"
    schema_path = ROOT / "data/raw/novic_variable_speed/official_schema_and_pairing.json"
    inputs = [lineage_path, schema_path, BASE_PATH]
    before = {str(path.relative_to(ROOT)): digest(path) for path in inputs}
    lineage = pd.read_csv(lineage_path)
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    raw_path = ROOT / schema["data_path"]
    raw_sha = digest(raw_path)
    if set(lineage.source_sha256) != {raw_sha}:
        raise ValueError("Raw array SHA256 does not match frozen v3 lineage")
    raw = np.load(raw_path, mmap_mode="r", allow_pickle=False)
    if tuple(raw.shape) != tuple(schema["dimensions"]):
        raise ValueError("Raw array dimensions disagree with the official schema")
    if len(lineage) != 404 or lineage.array_row.nunique() != 101:
        raise ValueError("Native baseline expects the complete frozen 404-interval lineage")
    features, definitions, crops = build_feature_table(raw, lineage)
    columns = features.columns.drop("sample_id").tolist()
    max_endpoint_error = float(crops.summed_endpoint_error_s.max())
    if max_endpoint_error >= 2 / FS:
        raise ValueError("Native crop lost two or more sample periods at its endpoints")
    features_path = output / "native_fullband_features.csv"
    definitions_path = output / "native_fullband_definitions.json"
    audit_path = output / "native_fullband_audit.json"
    features.to_csv(features_path, index=False)
    definition_document = dict(
        schema_version="native-fullband-v4.1", sample_id_column="sample_id",
        blocks={"native_fullband": columns}, feature_definitions=definitions,
        definitions_count=len(definitions), sample_rate_hz=FS,
        physical_bins_hz=[list(bounds) for bounds in BINS],
        source="v3 feature_block: 12 amplitude statistics + 5 Hann periodogram statistics + energy and fraction in four physical Hz bands",
        spectrum="one-sided Hann periodogram, detrend=constant, scaling=density, native fs=25600; integrate density times native bin width",
        nyquist_policy="Total spectral energy and all five spectrum statistics retain the full native spectrum through Nyquist. Fixed bands are upper-exclusive, so the exact 12800-Hz Nyquist bin is outside the last band when N is even.",
        normalization="No learned normalization at extraction; any scaler must be fitted on training data only.",
        metadata_features_included=False,
        limitation="Variable native point count, not matched to the 2048-point representations; full-band native statistical/spectral conventional baseline, not a coordinate-only control.")
    write_json(definitions_path, definition_document)
    unchanged = before == {str(path.relative_to(ROOT)): digest(path) for path in inputs}
    if not unchanged:
        raise ValueError("An inspected v3/schema input changed during native extraction")
    overlap = 0
    for _, q in crops.groupby("array_row"):
        ordered = q.sort_values("physical_start_s")
        if len(ordered) > 1:
            overlap = max(overlap, int(np.maximum(0, ordered.last_native_sample_inclusive.to_numpy()[:-1] - ordered.first_native_sample.to_numpy()[1:] + 1).max()))
    audit = dict(
        status="complete; no model fitting or prediction", schema_version="native-fullband-v4.1",
        sample_count=len(features), source_segment_count=int(lineage.array_row.nunique()),
        feature_count=len(columns), metadata_features_included=False,
        raw_path=str(raw_path), raw_sha256=raw_sha, raw_shape=list(raw.shape),
        vibration_channel=0, native_sample_rate_hz=FS, native_nyquist_hz=FS / 2,
        crop_rule="ceil(physical_start_s*25600) through floor(physical_stop_s*25600), both endpoints included; crop before feature extraction",
        filtering="none", resampling="none", demodulation="none",
        spectral_window="Hann within each cropped interval only; no outside-interval filtering or Hilbert context",
        native_point_count_min=int(crops.native_points.min()), native_point_count_max=int(crops.native_points.max()),
        native_point_count_unique=int(crops.native_points.nunique()), variable_point_budget=True,
        matched_to_2048_point_budget=False,
        maximum_start_endpoint_error_s=float(crops.start_endpoint_error_s.max()),
        maximum_stop_endpoint_error_s=float(crops.stop_endpoint_error_s.max()),
        maximum_summed_endpoint_error_s=max_endpoint_error, endpoint_error_limit_s=2 / FS,
        maximum_adjacent_native_sample_overlap=overlap,
        source_context="The full raw segment is addressable for cropping but no value outside each closed interval enters its feature calculation.",
        feature_formula_source=str(BASE_PATH.relative_to(ROOT)),
        all_features_finite=bool(np.isfinite(features[columns].to_numpy()).all()),
        sample_ids_match_v3_lineage=bool(np.array_equal(features.sample_id, lineage.sample_id)),
        input_sha256=before, v3_inputs_unchanged=unchanged,
        models_fitted=0, test_predictions_computed=0,
        outputs={str(p.relative_to(ROOT)): {"sha256": digest(p), "bytes": p.stat().st_size} for p in [features_path, definitions_path]},
        limitations=["Native full-band input contains variable samples per matched physical interval and is not a 2048-point input-budget control.",
                     "Statistical/spectral features are conventional diagnostics, not a claim of optimal native-band classification.",
                     "No new recording, bearing identity or physical independence is created by interval-local processing.",
                     "Fixed physical bins are upper-exclusive; the exact Nyquist bin contributes to total spectral energy/statistics but not the final band if native point count is even."],
        intervals=crops.to_dict("records"))
    write_json(audit_path, audit)
    print(json.dumps({key: value for key, value in audit.items() if key != "intervals"}, indent=2), flush=True)


if __name__ == "__main__":
    main()
