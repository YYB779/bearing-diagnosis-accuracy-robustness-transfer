"""Recompute record endpoints and state-cluster uncertainty from frozen predictions."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score, log_loss, balanced_accuracy_score, roc_auc_score

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/v4/analysis'
KEYS = ['task', 'representation', 'model', 'seed']


def binary_f1(y, p, w):
    """Vectorized over bootstrap rows; sklearn-compatible binary macro-F1."""
    pred = p >= .5
    tp = w @ ((y == 1) & pred).astype(float)
    tn = w @ ((y == 0) & ~pred).astype(float)
    fp = w @ ((y == 0) & pred).astype(float)
    fn = w @ ((y == 1) & ~pred).astype(float)
    return .5 * (np.divide(2*tp, 2*tp+fp+fn, out=np.zeros_like(tp), where=2*tp+fp+fn > 0)
                 + np.divide(2*tn, 2*tn+fp+fn, out=np.zeros_like(tn), where=2*tn+fp+fn > 0))


def record_scores(g):
    y, p = g.label.to_numpy(int), g.p1.to_numpy(float)
    w = 1./g.state_id.map(g.groupby('state_id').size()).to_numpy(float)
    return {'n_records': len(g), 'n_states': g.state_id.nunique(),
        'macro_f1': f1_score(y, p >= .5, labels=[0, 1], average='macro', zero_division=0),
        'state_weighted_macro_f1': f1_score(y, p >= .5, labels=[0, 1], average='macro', sample_weight=w, zero_division=0),
        'balanced_accuracy': balanced_accuracy_score(y, p >= .5),
        'auroc': roc_auc_score(y, p), 'nll': log_loss(y, np.c_[1-p, p], labels=[0, 1]),
        'brier': np.mean((p-y)**2)}


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows, predictions = [], []
    for dirname, expected in [('state_benchmark', 420), ('repository_benchmark', 60)]:
        folder = ROOT / 'results/v4' / dirname
        files = [p for p in folder.glob('*.json') if p.name != 'design.json']
        assert len(files) == expected, (dirname, len(files), expected)
        for path in sorted(files):
            result = json.loads(path.read_text(encoding='utf-8'))
            pp = folder / result['predictions']
            assert hashlib.sha256(pp.read_bytes()).hexdigest() == result['predictions_sha256']
            f = pd.read_csv(pp, float_precision='round_trip')
            for split, sub in f.groupby('split', sort=True):
                rec = sub.groupby('inferred_source_group', sort=True).agg(
                    state_id=('state_id', 'first'), state_fold=('state_fold', 'first'),
                    subset=('subset', 'first'), label=('label', 'first'), p1=('p1', 'mean')).reset_index()
                identifiers = {k: result[k] for k in KEYS}
                identifiers.update(protocol=result['protocol'], split=split)
                metric = record_scores(rec)
                for k in ('macro_f1', 'nll', 'brier'):
                    assert abs(metric[k]-result[split][k]) < 1e-12, (path, split, k)
                rows.append({**identifiers, 'n_features': result['n_features'], **metric})
                for k, v in identifiers.items():
                    rec[k] = v
                predictions.append(rec)
    runs, pred = pd.DataFrame(rows), pd.concat(predictions, ignore_index=True)
    runs.to_csv(OUT / 'fold_metrics.csv', index=False)
    pred.to_csv(OUT / 'record_predictions.csv', index=False)
    pooled = []
    for key, f in pred[pred.split.eq('test_unknown')].groupby(KEYS, sort=True):
        assert len(f) == 79 and f.inferred_source_group.nunique() == 79 and f.state_id.nunique() == 33
        pooled.append(dict(zip(KEYS, key), **record_scores(f)))
    pooled = pd.DataFrame(pooled)
    pooled.to_csv(OUT / 'unknown_oof_summary.csv', index=False)
    # Every resample preserves joint-label state support, and the same draws
    # compare every representation/model. 79 records are dependent within33states.
    states = pd.read_csv(ROOT / 'results/v4/state_fold_assignments.csv').sort_values('state_id').reset_index(drop=True)
    assert len(states) == 33
    if 'joint_label' not in states:
        states['joint_label'] = states.inner_presence + 2*states.outer_presence
    rng = np.random.default_rng(20261020)
    counts = np.zeros((2000, len(states)), int)
    for _, s in states.groupby('joint_label'):
        indices = s.index.to_numpy()
        draw = rng.choice(indices, size=(2000, len(indices)), replace=True)
        for k in indices:
            counts[:, k] = (draw == k).sum(axis=1)
    state_index = dict(zip(states.state_id, states.index))
    intervals, draws, paired = [], {}, []
    for key, f in pred[pred.split.eq('test_unknown') & pred.seed.eq(11)].groupby(KEYS, sort=True):
        f = f.sort_values('inferred_source_group')
        y, p = f.label.to_numpy(int), f.p1.to_numpy(float)
        w = counts[:, [state_index[s] for s in f.state_id]]
        d = binary_f1(y, p, w)
        draws[key] = d
        score = record_scores(f)
        intervals.append(dict(zip(KEYS, key), estimate=score['macro_f1'],
            low=float(np.quantile(d, .025)), high=float(np.quantile(d, .975)),
            n_records=79, n_states=33, bootstrap_draws=2000))
    pd.DataFrame(intervals).to_csv(OUT / 'unknown_cluster_intervals.csv', index=False)
    pairs = [('time_envelope', 'native_fullband'), ('order_generic', 'time_envelope'),
             ('time_envelope_meta', 'time_envelope'), ('order_generic_meta', 'order_generic'),
             ('order_geometry', 'order_generic'), ('mfos_repository', 'native_fullband'),
             ('mfos_repository', 'order_geometry')]
    for task in ('inner_presence', 'outer_presence'):
        for model in pooled.model.unique():
            for a, b in pairs:
                k1, k2 = (task, a, model, 11), (task, b, model, 11)
                delta = draws[k1] - draws[k2]
                v1 = pooled[(pooled.task.eq(task)) & pooled.representation.eq(a) & pooled.model.eq(model) & pooled.seed.eq(11)].iloc[0]
                v2 = pooled[(pooled.task.eq(task)) & pooled.representation.eq(b) & pooled.model.eq(model) & pooled.seed.eq(11)].iloc[0]
                paired.append({'task': task, 'model': model, 'a': a, 'b': b,
                    'macro_f1_difference': v1.macro_f1-v2.macro_f1,
                    'low': float(np.quantile(delta, .025)), 'high': float(np.quantile(delta, .975)),
                    'interpretation': 'paired conditional state-cluster percentile interval; multiple exploratory contrasts, not adjusted significance tests'})
    pd.DataFrame(paired).to_csv(OUT / 'paired_cluster_contrasts.csv', index=False)
    seedsummary = pooled.groupby(['task', 'representation', 'model']).agg(
        seeds=('seed', 'size'), macro_f1_mean=('macro_f1', 'mean'),
        macro_f1_min=('macro_f1', 'min'), macro_f1_max=('macro_f1', 'max'),
        nll_mean=('nll', 'mean'), brier_mean=('brier', 'mean')).reset_index()
    seedsummary.to_csv(OUT / 'seed_sensitivity.csv', index=False)
    (OUT / 'analysis_provenance.json').write_text(json.dumps({
        'selected_models': 480, 'candidate_pipelines': 1120,
        'fold_metric_rows': len(runs), 'record_prediction_rows': len(pred),
        'primary_seed': 11, 'cluster_unit': 'exact state combination', 'states': 33,
        'unknown_oof_records': 79, 'bootstrap_draws': 2000,
        'known_test_pooling': 'not pooled; same records repeat across rotations',
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2), encoding='utf-8')
    print(seedsummary.to_string(index=False), flush=True)


if __name__ == '__main__':
    main()
