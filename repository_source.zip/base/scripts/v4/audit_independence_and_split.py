"""Read-only NOVIC source audit plus new v4 metadata outputs; no model fitting.

The raw array is memory mapped. No raw recording is copied. Run from any cwd.
"""
from __future__ import annotations

import hashlib
import json
from itertools import combinations, product
from pathlib import Path
import re

import numpy as np
import pandas as pd
from scipy.fft import irfft, next_fast_len, rfft
from scipy.signal import resample_poly
from scipy.stats import spearmanr

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "results/v4"
DOC = ROOT / "docs/v4/independence_and_split_audit.md"
SALT = "novic_state_blocked_v4_20261020"
KNOWN_SALT = "novic_seen_state_diagnostic_v4_20261020"
RECORD_SALT = "novic_record_blocked_v4_20261020"
TASKS = ("inner_presence", "outer_presence")
SPLITS = ("train", "validation", "test")


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def dump_json(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def markdown(df):
    # Keep reproduction independent of optional tabulate.
    df = df.fillna("").astype(str)
    return "\n".join(["| " + " | ".join(df.columns) + " |",
                      "| " + " | ".join(["---"] * len(df.columns)) + " |"] +
                     ["| " + " | ".join(row) + " |" for row in df.to_numpy()])


def support(frame, protocol):
    rows = []
    for split, q in frame.groupby("assigned_split", sort=False):
        states = q.drop_duplicates("state_id")
        groups = q.drop_duplicates("inferred_source_group")
        row = dict(protocol=protocol, split=split, windows=len(q),
                   segments=q.array_row.nunique(), source_groups=len(groups), states=len(states),
                   subsets=";".join(sorted(q.subset.unique())))
        for task in TASKS:
            for unit, table in (("states", states), ("source_groups", groups), ("windows", q)):
                for label in (0, 1):
                    row[f"{task}_{unit}_{label}"] = int(table[task].eq(label).sum())
        for label in ("00", "01", "10", "11"):
            row[f"joint_{label}_states"] = int(states.joint_label.eq(label).sum())
        rows.append(row)
    return rows


def duplication_screen(manifest, features):
    schema_path = ROOT / "data/raw/novic_variable_speed/official_schema_and_pairing.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    raw = np.load(ROOT / schema["data_path"], mmap_mode="r", allow_pickle=False)
    names = np.load(ROOT / schema["names_path"], allow_pickle=False).astype(str)
    assert np.array_equal(names, manifest.upstream_name.to_numpy())
    assert raw.shape == (101, 102400, 9)
    n = len(manifest)
    full = np.empty((n, raw.shape[1]), dtype=np.float32)
    coarse = []
    hashes = []
    for i in range(n):
        vibration = np.asarray(raw[i, :, 0], dtype=np.float64)
        rpm = np.asarray(raw[i, :, 8], dtype=np.float64)
        hashes.append(dict(array_row=i,
                           vibration_sha256=hashlib.sha256(vibration.tobytes()).hexdigest(),
                           rpm_sha256=hashlib.sha256(rpm.tobytes()).hexdigest()))
        centered = vibration - vibration.mean()
        full[i] = centered / np.linalg.norm(centered)
        coarse.append(resample_poly(centered, 1, 8))
    hashes = pd.DataFrame(hashes).merge(manifest[["array_row", "state_id", "subset", "inferred_source_group", "split"]], on="array_row")
    hashes.to_csv(OUT / "source_channel_fingerprints.csv", index=False)
    exact = hashes[hashes.duplicated("vibration_sha256", keep=False)]
    rpm_duplicates = hashes[hashes.duplicated("rpm_sha256", keep=False)]
    gram = full @ full.T
    gram[np.diag_indices_from(gram)] = 0
    zi, zj = np.unravel_index(np.abs(gram).argmax(), gram.shape)

    # Exhaust all 5,050 source pairs, all coarse lags retaining >=2 s overlap.
    # Anti-aliased 3.2-kHz projection is a screening representation only.
    coarse = np.asarray(coarse)
    coarse -= coarse.mean(axis=1, keepdims=True)
    length = coarse.shape[1]
    nfft = next_fast_len(2 * length - 1)
    fft = rfft(coarse, n=nfft, axis=1)
    energies = np.pad(np.cumsum(coarse ** 2, axis=1), ((0, 0), (1, 0)))
    lags = np.arange(-(length // 2), length // 2 + 1)
    circular_indices = np.where(lags >= 0, lags, nfft + lags)
    x_start, x_stop = np.maximum(lags, 0), np.minimum(length, length + lags)
    y_start, y_stop = np.maximum(-lags, 0), np.minimum(length, length - lags)
    pairs = []
    for i in range(n - 1):
        for start in range(i + 1, n, 16):
            js = np.arange(start, min(start + 16, n))
            corr = irfft(fft[i][None, :] * fft[js].conj(), n=nfft, axis=1)[:, circular_indices]
            ex = (energies[i, x_stop] - energies[i, x_start])[None, :]
            ey = energies[js[:, None], y_stop] - energies[js[:, None], y_start]
            score = np.abs(corr) / np.sqrt(ex * ey)
            for j, values in zip(js, score):
                k = int(values.argmax())
                pairs.append(dict(array_row_i=i, array_row_j=int(j),
                                  coarse_max_abs_normalized_xcorr=float(values[k]),
                                  coarse_lag_samples=int(lags[k]),
                                  overlap_s=float((length - abs(lags[k])) / 3200),
                                  raw_zero_lag_abs_pearson=float(abs(gram[i, j]))))
    pairs = pd.DataFrame(pairs).sort_values("coarse_max_abs_normalized_xcorr", ascending=False)
    candidates = pairs[pairs.coarse_max_abs_normalized_xcorr.ge(0.995)].copy()
    confirmed = []
    for row in candidates.itertuples():
        x = np.asarray(raw[row.array_row_i, :, 0], dtype=np.float64)
        y = np.asarray(raw[row.array_row_j, :, 0], dtype=np.float64)
        best = 0.0
        for lag in range(8 * row.coarse_lag_samples - 7, 8 * row.coarse_lag_samples + 8):
            xx, yy = (x[lag:], y[:len(y)-lag]) if lag >= 0 else (x[:len(x)+lag], y[-lag:])
            if len(xx) < 51200:
                continue
            xx, yy = xx - xx.mean(), yy - yy.mean()
            value = abs(float(np.dot(xx, yy) / (np.linalg.norm(xx) * np.linalg.norm(yy))))
            best = max(best, value)
        confirmed.append(best)
    candidates["confirmed_raw_abs_pearson"] = confirmed
    candidates.to_csv(OUT / "near_duplicate_candidates.csv", index=False)
    top = pairs.head(20).copy()
    lookup = manifest.set_index("array_row")
    for side in ("i", "j"):
        for col in ("state_id", "subset", "inferred_source_group", "split"):
            top[f"{col}_{side}"] = top[f"array_row_{side}"].map(lookup[col])
    top.to_csv(OUT / "near_duplicate_top_pairs.csv", index=False)
    feature_values = features.drop(columns="sample_id")
    exact_feature_rows = int(feature_values.duplicated(keep=False).sum())
    result = dict(source_segments=n, source_pairs_screened=len(pairs),
                  official_name_array_alignment_verified=True,
                  raw_shape=list(raw.shape),
                  exact_duplicate_vibration_segments=len(exact),
                  exact_duplicate_rpm_segments=len(rpm_duplicates),
                  exact_duplicate_feature_rows=exact_feature_rows,
                  raw_zero_lag_max_abs_pearson=float(abs(gram[zi, zj])),
                  raw_zero_lag_max_pair=[int(zi), int(zj)],
                  coarse_max_abs_normalized_xcorr=float(pairs.iloc[0].coarse_max_abs_normalized_xcorr),
                  coarse_max_pair=[int(pairs.iloc[0].array_row_i), int(pairs.iloc[0].array_row_j)],
                  near_duplicate_candidate_threshold=0.995,
                  coarse_near_duplicate_candidates=len(candidates),
                  native_confirmed_near_duplicates=int(sum(v >= 0.995 for v in confirmed)),
                  projection_sample_rate_hz=3200, minimum_overlap_s=2.0,
                  limitation="Bounded channel-0 screen; downsampling suppresses high-band differences and similarities; does not identify repeated bearings, common mounts, nonlinear transforms or overlap shorter than 2 seconds.")
    dump_json(OUT / "source_duplication_audit.json", result)
    return result


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    DOC.parent.mkdir(parents=True, exist_ok=True)
    manifest_path = ROOT / "data/raw/novic_variable_speed/subsetE_segment_manifest.csv"
    lineage_path = ROOT / "data/processed/v3/novic_physical_lineage.csv"
    groups_path = ROOT / "data/processed/v3/novic_source_group_manifest.csv"
    split_path = ROOT / "results/v3/controlled_benchmark/split_assignments.csv"
    features_path = ROOT / "data/processed/v3/novic_physical_features.csv"
    paths = [manifest_path, lineage_path, groups_path, split_path, features_path,
             ROOT / "data/processed/v3/novic_physical_feature_blocks.json"]
    before = {str(p.relative_to(ROOT)): sha(p) for p in paths}
    m = pd.read_csv(manifest_path, dtype={"record_prefix": str, "misalignment_code": str, "unbalance_code": str})
    g = pd.read_csv(groups_path)
    l = pd.read_csv(lineage_path)
    f = pd.read_csv(features_path)
    m = m.merge(g[["inferred_source_group", "split"]], on="inferred_source_group", validate="many_to_one")
    m["state_id"] = m.state.replace({"normal": "inner0_outer0_misalign0_unbalance0"})
    m["joint_label"] = m.inner_presence.astype(str) + m.outer_presence.astype(str)
    for row in m.itertuples():
        match = re.fullmatch(r"inner(0|02)_outer(0|02)_misalign(0|015|03)_unbalance(0|10034|18070)", row.state_id)
        assert match is not None
        inner, outer, misalignment, unbalance = match.groups()
        assert (int(inner != "0"), int(outer != "0")) == (row.inner_presence, row.outer_presence)
        assert (misalignment, unbalance) == (row.misalignment_code, row.unbalance_code)
    assert not m.array_row.duplicated().any()
    assert set(l.array_row) == set(m.array_row)
    assert (l.groupby("array_row").size() == 4).all()
    assert (m.groupby("state_id")[list(TASKS)].nunique().max() == 1).all()
    assert not (m.state_id.eq("inner0_outer0_misalign0_unbalance0") & m.state.ne("normal")).any()
    # Verify that the complete subset/state/prefix group key is exactly the key in v3.
    expected = m.upstream_name.str.replace("./processed_data_4s/", "", regex=False).str.replace(r"_[0-9]+\.npy$", "", regex=True)
    assert expected.equals(m.inferred_source_group)
    ll = l.merge(m[["array_row", "state_id", "joint_label"]], on="array_row", validate="many_to_one")
    for col in ["inferred_source_group", "subset", *TASKS]:
        assert np.array_equal(l[col].to_numpy(), m.set_index("array_row").loc[l.array_row, col].to_numpy())
    state = m.groupby("state_id", sort=True).agg(
        upstream_state=("state", "first"), inner_presence=("inner_presence", "first"),
        outer_presence=("outer_presence", "first"), misalignment_code=("misalignment_code", "first"),
        unbalance_code=("unbalance_code", "first"), joint_label=("joint_label", "first"),
        segments=("array_row", "size"), source_groups=("inferred_source_group", "nunique"),
        subset_count=("subset", "nunique"), v3_split_count=("split", "nunique"))
    state["windows"] = 4 * state.segments
    designed_states = {f"inner{inner}_outer{outer}_misalign{mis}_unbalance{unb}"
                       for inner, outer, mis, unb in product(("0", "02"), ("0", "02"), ("0", "015", "03"), ("0", "10034", "18070"))}
    missing_states = sorted(designed_states - set(state.index))
    for subset in ("subsetA", "subsetB", "subsetC"):
        z = m[m.subset.eq(subset)].groupby("state_id")
        state[subset + "_segments"] = z.size().reindex(state.index, fill_value=0)
        state[subset + "_source_groups"] = z.inferred_source_group.nunique().reindex(state.index, fill_value=0)
    for split in SPLITS:
        z = m[m.split.eq(split)].groupby("state_id")
        state["v3_" + split + "_segments"] = z.size().reindex(state.index, fill_value=0)
        state["v3_" + split + "_source_groups"] = z.inferred_source_group.nunique().reindex(state.index, fill_value=0)
    state["v3_state_crosses_split"] = state.v3_split_count.gt(1)
    state["ordering_sha256"] = [hashlib.sha256((SALT + "|" + key).encode("utf-8")).hexdigest() for key in state.index]
    state["state_fold"] = -1
    for _, q in state.groupby("joint_label", sort=True):
        ordered = q.sort_values(["ordering_sha256"])
        for position, key in enumerate(ordered.index):
            state.loc[key, "state_fold"] = position % 5
    state.reset_index().to_csv(OUT / "state_support.csv", index=False)
    state[["joint_label", "state_fold", "ordering_sha256"]].reset_index().to_csv(OUT / "state_fold_assignments.csv", index=False)
    ll["state_fold"] = ll.state_id.map(state.state_fold)
    assignments, all_support = [], []
    for fold in range(5):
        q = ll.copy()
        q["protocol"] = f"state_blocked_{fold}"
        q["assigned_split"] = np.select([q.state_fold.eq(fold), q.state_fold.eq((fold + 1) % 5)], ["test", "validation"], default="train")
        assert q.groupby("state_id").assigned_split.nunique().eq(1).all()
        assert q.groupby("inferred_source_group").assigned_split.nunique().eq(1).all()
        for split in SPLITS:
            for task in TASKS:
                assert set(q.loc[q.assigned_split.eq(split), task]) == {0, 1}
        assignments.append(q[["sample_id", "array_row", "inferred_source_group", "subset", "state_id", "state_fold", *TASKS, "protocol", "assigned_split"]])
        all_support.extend(support(q, f"state_blocked_{fold}"))
    pd.concat(assignments, ignore_index=True).to_csv(OUT / "state_split_assignments.csv", index=False)
    new_support = pd.DataFrame(all_support)
    new_support.to_csv(OUT / "state_split_support.csv", index=False)
    # Same fitted model, two test populations. Hold out one entire proxy from
    # every eligible training-candidate state, leaving its other proxy/proxies.
    group_folds = ll.drop_duplicates("inferred_source_group")[["inferred_source_group", "state_id", "joint_label", "state_fold"]].copy()
    group_folds["known_record_ordering_sha256"] = [hashlib.sha256((KNOWN_SALT + "|" + key).encode("utf-8")).hexdigest() for key in group_folds.inferred_source_group]
    dual_assignments, dual_support = [], []
    for fold in range(5):
        q = ll.copy()
        q["protocol"] = f"state_dual_{fold}"
        q["assigned_split"] = np.select([q.state_fold.eq(fold), q.state_fold.eq((fold + 1) % 5)], ["test_unknown", "validation"], default="train")
        candidates = group_folds[~group_folds.state_fold.isin([fold, (fold + 1) % 5])]
        held_known = []
        for _, records in candidates.groupby("state_id", sort=True):
            if len(records) >= 2:
                held_known.append(records.sort_values("known_record_ordering_sha256").iloc[0].inferred_source_group)
        q.loc[q.inferred_source_group.isin(held_known), "assigned_split"] = "test_known"
        assert q.groupby("inferred_source_group").assigned_split.nunique().eq(1).all()
        sets = {split: set(z.state_id) for split, z in q.groupby("assigned_split")}
        assert sets["test_known"] <= sets["train"]
        assert not sets["test_unknown"] & set.union(sets["train"], sets["validation"], sets["test_known"])
        assert not sets["validation"] & set.union(sets["train"], sets["test_known"])
        for split in ("train", "validation", "test_unknown", "test_known"):
            for task in TASKS:
                assert set(q.loc[q.assigned_split.eq(split), task]) == {0, 1}, (fold, split, task)
        dual_assignments.append(q[["sample_id", "array_row", "inferred_source_group", "subset", "state_id", "state_fold", *TASKS, "protocol", "assigned_split"]])
        dual_support.extend(support(q, f"state_dual_{fold}"))
    dual = pd.concat(dual_assignments, ignore_index=True)
    dual.to_csv(OUT / "state_dual_test_assignments.csv", index=False)
    dual_unknown = dual[dual.assigned_split.eq("test_unknown")]
    assert dual_unknown.groupby("sample_id").size().eq(1).all()
    assert len(dual_unknown) == len(l)
    dual_support = pd.DataFrame(dual_support)
    dual_support.to_csv(OUT / "state_dual_test_support.csv", index=False)
    group_folds["record_ordering_sha256"] = [hashlib.sha256((RECORD_SALT + "|" + key).encode("utf-8")).hexdigest() for key in group_folds.inferred_source_group]
    group_folds["record_fold"] = -1
    for _, records in group_folds.groupby("joint_label", sort=True):
        for position, idx in enumerate(records.sort_values("record_ordering_sha256").index):
            group_folds.loc[idx, "record_fold"] = position % 5
    group_folds.to_csv(OUT / "record_fold_assignments.csv", index=False)
    record_assignments, record_support = [], []
    for fold in range(5):
        q = ll.copy()
        q["record_fold"] = q.inferred_source_group.map(group_folds.set_index("inferred_source_group").record_fold)
        q["protocol"] = f"record_matched_{fold}"
        q["assigned_split"] = np.select([q.record_fold.eq(fold), q.record_fold.eq((fold + 1) % 5)], ["test", "validation"], default="train")
        assert q.groupby("inferred_source_group").assigned_split.nunique().eq(1).all()
        for split in SPLITS:
            for task in TASKS:
                assert set(q.loc[q.assigned_split.eq(split), task]) == {0, 1}
        record_assignments.append(q[["sample_id", "array_row", "inferred_source_group", "subset", "state_id", "record_fold", *TASKS, "protocol", "assigned_split"]])
        record_support.extend(support(q, f"record_matched_{fold}"))
    record = pd.concat(record_assignments, ignore_index=True)
    assert record[record.assigned_split.eq("test")].groupby("sample_id").size().eq(1).all()
    record.to_csv(OUT / "record_matched_split_assignments.csv", index=False)
    record_support = pd.DataFrame(record_support)
    record_support.to_csv(OUT / "record_matched_split_support.csv", index=False)
    print("SPLIT_MAPS_READY: results/v4/state_fold_assignments.csv; state_dual_test_assignments.csv; state_dual_test_support.csv; record_matched_split_assignments.csv", flush=True)
    old = pd.read_csv(split_path)
    old = old.merge(ll[["sample_id", "array_row", "state_id", "joint_label"]], on="sample_id", validate="many_to_one")
    overlaps, old_support = [], []
    for protocol, q in old.groupby("protocol", sort=False):
        old_support.extend(support(q, protocol))
        for left, right in combinations(SPLITS, 2):
            overlap = sorted(set(q.loc[q.assigned_split.eq(left), "state_id"]) & set(q.loc[q.assigned_split.eq(right), "state_id"]))
            for key in overlap:
                overlaps.append(dict(protocol=protocol, split_left=left, split_right=right, state_id=key))
    overlap_df = pd.DataFrame(overlaps)
    overlap_df.to_csv(OUT / "v3_state_overlap.csv", index=False)
    old_support = pd.DataFrame(old_support)
    old_support.to_csv(OUT / "v3_split_state_support.csv", index=False)
    prefix = m.groupby(["subset", "record_prefix", "state_id"]).agg(segments=("array_row", "size"), segment_indices=("segment_index", lambda x: ";".join(map(str, sorted(x))))).reset_index()
    prefix.to_csv(OUT / "record_prefix_mapping.csv", index=False)
    duplicates = duplication_screen(m, f)
    blocks = json.loads(paths[-1].read_text(encoding="utf-8"))["blocks"]
    columns = set(c for values in blocks.values() for c in values)
    assert columns == set(f.columns) - {"sample_id"}
    forbidden = {"inner_presence", "outer_presence", "misalignment_code", "unbalance_code", "inferred_source_group", "state", "state_id", "subset", "record_prefix", "array_row", "split"}
    assert not columns.intersection(forbidden)
    fg = ll[["sample_id", "inferred_source_group", "state_id", "subset", *TASKS]].merge(f[["sample_id", *blocks["metadata_only"]]], on="sample_id", validate="one_to_one")
    fg = fg.groupby("inferred_source_group", sort=True).agg({**{c: "first" for c in ["state_id", "subset", *TASKS]}, **{c: "mean" for c in blocks["metadata_only"]}}).reset_index()
    correlations = []
    for col in blocks["metadata_only"]:
        for task in TASKS:
            rho = float(spearmanr(fg[col], fg[task]).statistic) if fg[col].nunique() > 1 else None
            correlations.append(dict(feature=col, task=task, group_mean_spearman=rho, independent_bearing_units_known=False))
    pd.DataFrame(correlations).to_csv(OUT / "metadata_label_descriptive_correlations.csv", index=False)
    group_meta = m.drop_duplicates("inferred_source_group")
    composition = []
    for field in ["subset", "misalignment_code", "unbalance_code"]:
        for code, q in group_meta.groupby(field):
            composition.append(dict(field=field, code=str(code), source_groups=len(q), inner_positive=int(q.inner_presence.sum()), outer_positive=int(q.outer_presence.sum()), states=q.state_id.nunique()))
    pd.DataFrame(composition).to_csv(OUT / "metadata_label_composition.csv", index=False)
    assert before == {str(p.relative_to(ROOT)): sha(p) for p in paths}
    summary = dict(source_segments=len(m), source_groups=len(g), upstream_states=len(state),
                   physical_bearing_count=None, state_joint_label_support=state.joint_label.value_counts().sort_index().to_dict(),
                   states_across_subsets=int(state.subset_count.gt(1).sum()),
                   states_across_v3_record_splits=int(state.v3_split_count.gt(1).sum()),
                   missing_of_36_designed_states=missing_states,
                   labels_and_nuisance_codes_verified_from_upstream_path=True,
                   record_prefix_count=int(m.record_prefix.nunique()),
                   global_prefixes_mapped_to_multiple_states=int(m.groupby("record_prefix").state_id.nunique().gt(1).sum()),
                   subset_prefix_pairs_mapped_to_multiple_states=int(m.groupby(["subset", "record_prefix"]).state_id.nunique().gt(1).sum()),
                   input_sha256=before, input_files_unchanged=True, models_fitted=0, test_predictions_computed=0,
                   state_fold_salt=SALT, state_fold_algorithm="Within each joint inner/outer label, SHA256(salt+'|'+canonical_state_id), ascending digest, position modulo 5.")
    summary["known_diagnostic_record_salt"] = KNOWN_SALT
    summary["record_matched_fold_salt"] = RECORD_SALT
    dump_json(OUT / "independence_audit_summary.json", summary)
    short = new_support[["protocol", "split", "states", "source_groups", "segments", "windows", "joint_00_states", "joint_01_states", "joint_10_states", "joint_11_states"]]
    dual_short = dual_support[["protocol", "split", "states", "source_groups", "segments", "windows", "inner_presence_source_groups_0", "inner_presence_source_groups_1", "outer_presence_source_groups_0", "outer_presence_source_groups_1"]]
    record_short = record_support[["protocol", "split", "states", "source_groups", "segments", "windows"]]
    old_short = old_support[["protocol", "split", "states", "source_groups", "segments", "windows"]]
    overlap_counts = overlap_df.groupby(["protocol", "split_left", "split_right"]).size().rename("shared_states").reset_index()
    report = f'''# NOVIC v4 independence and split audit

Audit scope: metadata, source identity, channel-0 duplication, feature schema and split support. No model was fitted, selected or evaluated. The six inspected metadata/feature input files were checksum-verified unchanged. This audit applies the scientific-critical-thinking skill by separating observed dependence from unverified physical identity and by bounding the claims of each protocol.

## Finding and supported unit

The 101 source segments and 404 derived intervals map to 79 filename-derived recording proxies but only **33 upstream fault/interference states**. Of these states, **18 occur in multiple acquisition subsets**, and **13 cross the frozen record-holdout train/validation/test partition**. The original record grouping isolates its declared proxies; it does not isolate repeated combinations or establish separate bearing specimens. State sharing is an estimand limitation and a shortcut risk, not proof of copied signals or direct label leakage.

The release identifies subset, fault-severity folder and file index. It does not define the first filename integer as an independently acquired recording or supply a specimen/mounting identifier. The primary paper describes TDMS-to-NumPy conversion and four-second segmentation, a rig with two bearing housings, artificial inner/outer cracks, and three operating regimes. It specifies 36 designed combinations, whereas the acquired container supports 33. It does not establish specimen independence for these 79 proxies. A is sinusoidal speed with varying brake load, B triangular speed without applied brake load, and C five constant speed levels. These regime differences include torque and speed. Sources: [official Zenodo release](https://zenodo.org/records/15743425), [author manuscript, section 5.1 and Table 2](https://arxiv.org/pdf/2505.24001). The current Zenodo fetch returned HTTP 429; its locally saved official API JSON was used to cross-check field semantics. The author PDF was accessed successfully on 2026-10-20.

Identifiable units are (1) a released four-second array row, (2) a conservative subset/state/filename-prefix proxy inferred locally, and (3) the documented severity combination. None is a verified physical bearing. Unknown bearing reuse, mounting, session and rig dependence remain even with state blocking. The 33 states must never be described as 33 independent bearings.

## State definition and prefix evidence

`state_id` is the complete upstream `inner*/outer*/misalign*/unbalance*` folder, without subset, source filename or segment suffix. The `normal` folder is explicitly normalized to `inner0_outer0_misalign0_unbalance0`. There is no anomaly folder with that same all-zero combination in this acquired subset. Raw folder text remains in `upstream_state`. State codes retain severity strings (`015`, `03`, `10034`, `18070`) exactly; these are categories, not bearing IDs.

Joint inner/outer state support is 00: 9, 01: 8, 10: 9, and 11: 7. Six states occur in all A/B/C, 12 in two subsets, and 15 in one. `record_prefix` has 49 distinct values: 16 values map to more than one state globally, and 9 subset/prefix pairs map to more than one state. Consequently prefix alone, or subset/prefix alone, cannot safely identify an acquisition. For example subset A prefix 0 appears in `normal` and `inner02_outer0_misalign03_unbalance0`; prefix 1 similarly appears in normal and an inner-fault combination. The current full 79-key rule exactly reproduces `subset/state/prefix` by deleting only the final `_segment.npy` suffix. That is a documented conservative proxy, not confirmation of its recording semantics. Full mapping: `results/v4/record_prefix_mapping.csv`.

The author-released aligned filename array was independently loaded and exactly matched all 101 manifest paths. Both binary targets and both nuisance codes were independently re-parsed from those paths and matched the manifest. The three designed but absent states are: {', '.join('`' + key + '`' for key in missing_states)}. Absence is specific to the acquired 101-row container, not a claim that the complete three-part release lacks these states.

## Current v3 splits

{markdown(old_short)}

Each source proxy is isolated, but the following numbers of exact severity combinations are shared:

{markdown(overlap_counts)}

`unseen_A/B/C` therefore assess a new acquisition regime with overlapping states, not unseen combinations or independent bearings. Their train and validation folds also share some combinations. The frozen record test contains 13 states, seven also seen in training. `results/v4/v3_state_overlap.csv` lists every shared state; `v3_split_state_support.csv` gives class-specific support. These are concerns for claims of broad generalization, not grounds to declare the existing within-source comparisons numerically invalid.

## Exact and near-duplicate screen

Channel-0 source SHA256 was independently recomputed for all 101 segments. There are **{duplicates['exact_duplicate_vibration_segments']} exact duplicate vibration segments**, **{duplicates['exact_duplicate_feature_rows']} exact duplicate feature rows**, and **{duplicates['exact_duplicate_rpm_segments']} source rows belonging to repeated RPM hashes**. The largest absolute full-resolution zero-lag waveform Pearson correlation is {duplicates['raw_zero_lag_max_abs_pearson']:.6f}, between rows {duplicates['raw_zero_lag_max_pair']}.

For a bounded near-duplicate screen, native channel 0 is anti-aliased and downsampled by eight to 3.2 kHz; all 5,050 source pairs are searched over all lags preserving at least two seconds of overlap. Overlap-normalized cross-correlation permits gain and sign changes. The largest absolute screen correlation is {duplicates['coarse_max_abs_normalized_xcorr']:.6f} for rows {duplicates['coarse_max_pair']}. The fixed candidate threshold is 0.995, yielding {duplicates['coarse_near_duplicate_candidates']} candidates; {duplicates['native_confirmed_near_duplicates']} reach 0.995 on the native waveform after a +/-7 native-sample lag check. Top 20 pairs and hashes are saved, including their source states and splits.

Absence of a flagged pair only excludes the tested forms of replication. Downsampling can obscure high-band replication and the screen misses nonlinear transformations or overlap under two seconds. Strong shared spectra or repeated bearings do not require similar waveforms. Finite four-second segments, shared rig history and full-segment zero-phase filtering create dependence that hashes cannot diagnose. Adjacent eight-turn intervals share a boundary and a full-segment filter/Hilbert context; they are dependent observations and must stay together.

## Label and metadata shortcuts

All 373 declared feature columns were checked against the actual feature CSV. The eight metadata inputs are RPM mean, SD, minimum, maximum, range, duration, actual turns and RPM linear slope. No label, nuisance code, state, subset, source ID, filename, array index or split column enters the declared classifier blocks. Merely storing labels in the NPZ does not show they entered the fitted input; the v3 runner explicitly selects feature-block columns. Its SVM scaler is fitted inside each training/calibration estimator. This audit found no explicit forbidden-field input path.

Condition shortcuts remain plausible: RPM statistics encode regime/speed; duration is mechanically linked to eight turns and mean speed; actual turns is constant; regime A also changes torque; sparse nuisance combinations and unequal source/segment counts make label composition vary. A metadata-only control describes this issue but appending metadata to every representation does not remove interactions with vibration. `metadata_label_composition.csv` reports source-group label counts for each regime and nuisance code. `metadata_label_descriptive_correlations.csv` gives descriptive Spearman associations after averaging each metadata input per proxy. These are exploratory composition checks, with no p-values or claim of independent samples.

Further work should repeat paired representations with all metadata removed, keep the existing metadata-only control, report both state and source support, and preserve absent nuisance/class cells as unsupported. Splits must be fixed before inspecting model scores. Model selection, calibration and any learned scaling must use only training or explicit validation states; an inner calibration fold must also group by `state_id` across A/B/C. Reusing v3's source-proxy calibration grouping would reintroduce combination sharing within training.

## Executable stricter protocol

`results/v4/state_support.csv` is the authoritative 33-row support/fold table; `state_fold_assignments.csv` is its compact assignment. The deterministic salt is `{SALT}`. Separately within each joint inner/outer label, sort the canonical state IDs by the hex SHA256 digest of `salt + '|' + state_id`, then assign fold = zero-based position modulo five. This uses labels for declared stratification and never uses signal values, predictions or performance. Every instance of a state across all subsets and proxies inherits the same fold.

For protocol `state_blocked_k`, test fold k, validate on fold (k+1) modulo five, and train on the other three folds. The precomputed `state_split_assignments.csv` gives every sample ID and assigned split for all five rotations. The script asserts no state or source-proxy intersection across any split and both binary classes in every split. All four joint labels occur in every split, as shown below. Unequal state/window counts remain because rounding and the 24 normal segments are not discarded.

{markdown(short)}

This is feasible for **unseen combinations on the same measured rig**. It deliberately allows A/B/C in training and test while forbidding a state shared across them. It does not isolate a new regime simultaneously. To add a joint regime-and-state challenge, test only the held regime's chosen state fold, train and validate on the remaining regimes using disjoint state folds, and quarantine every other appearance of test states. Such a protocol must report lost data and exact class support rather than assume it is feasible. Existing `unseen_A/B/C` should remain a separate regime test.

### Main same-model dual-test design

The main v4 design further retains a known-state/new-proxy diagnostic from the three candidate training state folds. Within each candidate state having at least two distinct proxies, sort proxy IDs by SHA256 of `{KNOWN_SALT}|` plus the full proxy key and hold out exactly the first proxy, including every one of its segments and intervals, as `test_known`. All remaining proxies are actual `train`; single-proxy candidate states stay entirely in training. The unknown test fold is `test_unknown`, and the next whole state fold is `validation`. The same selected/fitted model predicts both tests. Test-known states must occur in training; validation and test-unknown states occur nowhere else in that rotation.

{markdown(dual_short)}

The script verifies both classes for both tasks in all four partitions of every rotation. `state_dual_test_assignments.csv` is the authoritative per-sample main-design map; `state_dual_test_support.csv` includes full class/state support. All 79 proxies occur in the strict unknown-state test exactly once across the five rotations. Primary endpoint: equal-proxy out-of-fold Macro-F1 after averaging all interval probabilities within each proxy. Each unknown proxy contributes once. The known diagnostic deliberately repeats a proxy in several rotations; it must not be pooled as independent replicate tests. Report known diagnostic results by rotation or average repeated predictions within proxy with a disclosed dependence interpretation.

The all-zero normal state is in fold 1, carrying 20 proxies and 24 four-second segments. It is entirely validation in rotation 0 and unknown-state test in rotation 1. Those two training sets therefore contain no pure-normal state, although they retain neither-bearing-fault examples with rotor interference and both classes of both targets. The true training proxy counts are 22, 22, 43, 46 and 44. These uneven supports arise from blocking the actual states and the fixed diagnostic holdout; no support-driven salt search or model-driven reassignment was performed. They require per-rotation reporting alongside pooled unknown-state OOF results.

Sharing state across subsets in v3 was appropriate for a known-state/new-record question and is not itself an error or proof of leakage. A v3-to-v4 score decrease cannot be attributed entirely to leakage: the estimand, exact training states, number of training proxies, class mix and nuisance support all change. The same-model dual test controls the fitted training set when comparing known and unknown states, but the test populations still differ in combination support, and this comparison is not a causal estimate of leakage.

### Record-only fivefold proportion control

A counterfactual audit scheme holds out proxies while permitting known states: within each joint inner/outer label, sort all 79 proxy IDs by SHA256 of `{RECORD_SALT}|` plus full proxy key and assign position modulo five. Rotation k tests fold k, validates on (k+1) modulo five and trains on the other three. This matches the nominal 3/1/1 fold ratio, not necessarily the exact proxy count in uneven state folds or the reduced dual-test training set. Its purpose is to expose that training fraction alone cannot justify interpreting any v3/v4 difference as a leakage effect. It is an assignment/support audit, with no fitted counterfactual model.

{markdown(record_short)}

`record_fold_assignments.csv`, `record_matched_split_assignments.csv` and `record_matched_split_support.csv` fully specify it. Each proxy is tested exactly once across rotations. All source proxies remain intact. Counterfactual folds are generated solely from metadata and fixed salts; no model score was consulted.

For evaluation, first average interval probabilities within each source proxy and report source-level metrics; additionally average proxy probabilities within each state for a state-weighted sensitivity analysis. Confidence intervals, if used, must cluster by state across subsets. The five rotations reuse training material and are not five independent physical replications. Existing v3 test labels and outcomes have already been inspected, so this is a retrospective stronger sensitivity test rather than preregistered external validation. Keep binary targets as fault presence: a negative can contain the other bearing fault or rotor interference.

## Evidence and reproducibility

- `data/raw/novic_variable_speed/subsetE_segment_manifest.csv`: 101 array rows, upstream paths, state/prefix/segment fields, channel summaries.
- `data/raw/novic_variable_speed/zenodo_record_15743425_metadata.json`: saved official release description defining subset, folder and file index.
- `data/raw/novic_variable_speed/official_schema_and_pairing.json`: source-array/name paths and local channel schema.
- `data/processed/v3/novic_physical_lineage.csv`: 404 sample-to-array-row and proxy links.
- `data/processed/v3/novic_source_group_manifest.csv`: frozen 79-proxy record split.
- `results/v3/controlled_benchmark/split_assignments.csv`: all four actual v3 protocol assignments.
- `scripts/v3/run_controlled_benchmark.py`, functions `make_protocol`, `block_columns`, `fit_candidate`: split, input and calibration implementation inspected read-only.
- `results/v4/source_channel_fingerprints.csv`, `source_duplication_audit.json`, `near_duplicate_top_pairs.csv`, `near_duplicate_candidates.csv`: independent signal screen.
- `results/v4/independence_audit_summary.json`: checked input SHA256 digests and zero model/prediction counts.
- Reproduce: `python scripts/v4/audit_independence_and_split.py`. Outputs are small derived tables and this report; the raw array is memory mapped and never copied to disk.
'''
    DOC.write_text(report, encoding="utf-8")
    print(json.dumps({**summary, "duplication": duplicates, "new_support": short.to_dict("records")}, indent=2), flush=True)


if __name__ == "__main__":
    main()
