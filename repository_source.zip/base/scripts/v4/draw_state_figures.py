"""Measured-data figures from complete frozen v4 results; no fitted model changes."""
from pathlib import Path
import hashlib
import json
import shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'figures/v4'
A = ROOT / 'results/v4/analysis'
REPS = ['metadata_only', 'native_fullband', 'time_envelope', 'time_envelope_meta',
        'order_generic', 'order_generic_meta', 'order_geometry', 'mfos_repository']
NAMES = ['Metadata (8)', 'Native raw (25)', 'Time env. (111)', 'Time env. + meta (119)',
         'Order env. (99)', 'Order env. + meta (107)', 'Order + geometry (180)', 'Repository method (856)']
LAB = dict(zip(REPS, NAMES))
COL = dict(zip(REPS, ['#009E73', '#626B73', '#D55E00', '#A94B00', '#56B4E9', '#267A9D', '#0072B2', '#AA4499']))
MODELS = ['extra_trees', 'random_forest', 'state_calibrated_svm', 'logistic']
ML = ['Extra Trees', 'Random forest', 'RBF SVM', 'Logistic regression']
TASKS = ['inner_presence', 'outer_presence']
CAPTIONS, MANIFEST = {}, []


def panel(ax, letter, title):
    ax.set_title(f'{letter}  {title}', loc='left', fontsize=9, fontweight='bold', pad=8)
    ax.spines[['top', 'right']].set_visible(False)
    ax.tick_params(length=3, width=.6)


def save(fig, name, caption, tables):
    paths = []
    for ext in ('png', 'svg', 'pdf'):
        p = OUT / f'{name}.{ext}'
        fig.savefig(p, dpi=300, facecolor='white')
        paths.append({'path': str(p.relative_to(ROOT)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
    plt.close(fig)
    csvs = []
    for key, data in tables.items():
        path = OUT / 'source_data' / f'{name}_{key}.csv'
        data.to_csv(path, index=False)
        csvs.append({'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    if name in ('fig04_strong_baselines','fig07_repository_comparison'):
        caption += ' SVM points retain the frozen window-sigmoid-then-record-average rule; the disclosed post hoc record-score aggregation sensitivity is reported separately.'
    (OUT / (name + '_caption.md')).write_text(caption + '\n', encoding='utf-8')
    MANIFEST.append({'stem': name, 'outputs': paths, 'source_tables': csvs,
        'width_mm': 180, 'uncertainty': 'only where explicitly labelled; state cluster percentile conditional on fixed fitted models',
        'caption': caption})


def figure1():
    fig, axs = plt.subplots(2, 2, figsize=(180/25.4, 110/25.4), layout='constrained')
    content = [
      ('Measured evidence', ['NOVIC+: 101 four-second segments', '79 recording proxies / 33 exact states', '404 nonoverlapping eight-turn intervals', 'HUST: 21 source files / 5 conditions']),
      ('Physical representations', ['Native raw: 25.6 kHz, no low-pass', 'Fixed carrier envelopes before compression', 'Same physical intervals in time and angle', 'Metadata / geometry / repository controls']),
      ('Isolation before model selection', ['State folds fixed by salted SHA-256', 'Train / validation / unknown states disjoint', 'Known-state test: whole reserved records', 'Same selected model predicts both tests']),
      ('Claims tested against failures', ['4 classifier families; 480 selected models', '79 unknown-state OOF record predictions', 'State-cluster uncertainty; seed sensitivity', 'External condition / healthy-class failures'])]
    for k, (ax, (title, lines)) in enumerate(zip(axs.flat, content)):
        ax.set_axis_off()
        ax.text(0, .98, f'{chr(97+k)}  {title}', va='top', fontsize=10, fontweight='bold', transform=ax.transAxes)
        for j, line in enumerate(lines):
            ax.text(.02, .76-j*.19, line, va='top', fontsize=8.4, transform=ax.transAxes)
        ax.plot([0, 1], [.89, .89], color='#90979D', lw=.6, transform=ax.transAxes)
    save(fig, 'fig01_study_design', 'Figure 1. Evidence and computational design. States denote exact combinations of fault and interference codes in upstream paths, not independently identified bearings or new fault types. The same selected model supplies both known-state and unknown-state predictions. The 480 internal models include 60 exploratory matching-title repository implementations. HUST models are trained separately within HUST; no zero-shot transfer is implied.',
         {'design': pd.DataFrame([{'panel': t, 'item': s} for t, ll in content for s in ll])})


def figure2():
    states = pd.read_csv(ROOT / 'results/v4/state_support.csv').sort_values(['joint_label', 'state_id']).reset_index(drop=True)
    states['display_id'] = [f'S{i+1:02}' for i in range(len(states))]
    support = pd.read_csv(ROOT / 'results/v4/state_dual_test_support.csv')
    fig, axs = plt.subplots(1, 3, figsize=(180/25.4, 145/25.4), layout='constrained', gridspec_kw={'width_ratios': [1.15, 1, 1.6]})
    mat = states[[f'subset{c}_source_groups' for c in 'ABC']].to_numpy()
    im = axs[0].imshow(mat, aspect='auto', cmap='Blues', vmin=0, vmax=mat.max(), interpolation='nearest')
    axs[0].set(xticks=range(3), xticklabels=list('ABC'), yticks=range(33), yticklabels=states.display_id, xlabel='Acquisition regime')
    for i in range(33):
        for j in range(3):
            if mat[i,j]: axs[0].text(j, i, str(mat[i,j]), ha='center', va='center', fontsize=6.5, color='white' if mat[i,j]>mat.max()/2 else 'black')
    panel(axs[0], 'a', 'Records per state')
    axs[1].barh(np.arange(33), states.source_groups, color='#626B73', height=.65)
    axs[1].invert_yaxis(); axs[1].set(yticks=range(33), yticklabels=['']*33, xlabel='Recording proxies', xticks=[0, 5, 10, 15, 20])
    axs[1].set_ylim(axs[0].get_ylim())
    panel(axs[1], 'b', 'Unequal state support')
    normal = states.index[states.state_id.eq('inner0_outer0_misalign0_unbalance0')].tolist()
    if normal: axs[1].text(1, normal[0]-.7, 'Normal: one state', fontsize=7)
    # Complete raw counts, not pooled pseudo-independent test observations.
    pivot = support.pivot(index='protocol', columns='split', values='source_groups')
    bottom = np.zeros(5)
    for split, color, label in [('train', '#626B73', 'Train'), ('validation', '#E69F00', 'Validation'), ('test_known', '#56B4E9', 'Known-state test'), ('test_unknown', '#0072B2', 'Unknown-state test')]:
        vals = pivot[split].to_numpy()
        axs[2].bar(np.arange(5), vals, bottom=bottom, color=color, label=label, width=.62)
        for i, v in enumerate(vals): axs[2].text(i, bottom[i]+v/2, str(v), ha='center', va='center', fontsize=7, color='white' if color in ('#626B73','#0072B2') else 'black')
        bottom += vals
    axs[2].set(xticks=range(5), xticklabels=range(1,6), ylabel='Recording proxies', xlabel='Frozen rotation', ylim=(0,100))
    axs[2].legend(frameon=False, fontsize=7, loc='upper left')
    panel(axs[2], 'c', 'Same-model dual tests')
    save(fig, 'fig02_state_support', 'Figure 2. State support and frozen source partitions. (a) Counts of recording proxies for each of 33 exact states in regimes A/B/C; zeros are unobserved combinations. Source data map S01–S33 to full upstream codes. (b) Normal records belong to a single state; their multiplicity is not independent state replication. (c) Each rotation totals 79 recording proxies. Normal is assigned to state fold 1 (zero-based), so rotations 1 and 2 lack normal training records. Unknown-state OOF predictions cover each record once; known-state tests repeat some records across rotations.',
         {'states': states, 'support': support})


def figure4(summary, intervals):
    fig, axs = plt.subplots(2, 2, figsize=(180/25.4, 150/25.4), layout='constrained', sharex=True, sharey=True)
    source = intervals.copy()
    for k, (model, ax) in enumerate(zip(MODELS, axs.flat)):
        for ti, task in enumerate(TASKS):
            for ri, rep in enumerate(REPS):
                r = intervals[(intervals.task.eq(task)) & intervals.model.eq(model) & intervals.representation.eq(rep)].iloc[0]
                yy = ri + (ti-.5)*.22
                ax.plot([r.low, r.high], [yy, yy], color=COL[rep], lw=1)
                ax.scatter(r.estimate, yy, marker=['o','^'][ti], s=20, color=COL[rep], edgecolors='black', linewidths=.3, zorder=3)
        panel(ax, chr(97+k), ML[k]); ax.set(xlim=(-.03,1.04), yticks=range(8), yticklabels=NAMES)
        ax.grid(axis='x', color='#E5E7EB', lw=.5); ax.set_axisbelow(True)
        if k>=2: ax.set_xlabel('Unknown-state record macro-F1')
    axs[0,0].invert_yaxis()
    handles=[plt.Line2D([],[],marker=m,color='black',ls='None',label=l,markersize=4) for m,l in [('o','Inner presence'),('^','Outer presence')]]
    fig.legend(handles=handles,loc='outside lower center',ncol=2,frameon=False,fontsize=8)
    save(fig, 'fig04_strong_baselines', 'Figure 4. Unknown-state out-of-fold performance with adequate raw bandwidth and four classifier families. Points use the declared seed 11; error bars are 95% conditional percentile intervals from 2000 joint-label-stratified state-cluster bootstrap draws over 33 states. Circles and triangles denote inner and outer fault presence. Feature counts appear in labels. Native raw retains variable native point counts and is an adequate-bandwidth baseline, not an equal-point-budget control. Perfect observed predictions produce degenerate conditional bootstrap intervals and do not prove population certainty. The 856-feature repository implementation is exploratory.', {'intervals': source, 'all_seed_summaries': summary})


def figure5(runs):
    reps = ['native_fullband', 'time_envelope', 'order_geometry']
    fig, axs = plt.subplots(2, 3, figsize=(180/25.4, 115/25.4), layout='constrained', sharex=True, sharey=True)
    source=[]
    for ti, task in enumerate(TASKS):
        for ri, rep in enumerate(reps):
            ax=axs[ti,ri]
            f=runs[runs.task.eq(task)&runs.representation.eq(rep)&runs.model.eq('extra_trees')&runs.seed.eq(11)]
            p=f.pivot(index='protocol',columns='split',values='macro_f1')
            for j, (protocol,row) in enumerate(p.iterrows()):
                ax.plot([j+1-.10,j+1+.10],[row.test_known,row.test_unknown],color='#A7ADB3',lw=.7)
                ax.scatter(j+1-.10,row.test_known,color='#626B73',marker='o',s=26,edgecolors='black',linewidths=.3,label='Known-state test' if j==0 else None)
                ax.scatter(j+1+.10,row.test_unknown,color=COL[rep],marker='^',s=28,edgecolors='black',linewidths=.3,label='Unknown-state test' if j==0 else None)
                source.append({'task':task,'representation':rep,'protocol':protocol,'known_f1':row.test_known,'unknown_f1':row.test_unknown})
            panel(ax,chr(97+ti*3+ri),('Inner' if ti==0 else 'Outer')+' / '+LAB[rep].split(' (')[0])
            ax.set(xlim=(.6,5.4),ylim=(0,1.05),xticks=range(1,6),yticks=[0,.5,1]); ax.grid(axis='y',color='#ECEFF1',lw=.5)
            if ti==1: ax.set_xlabel('Frozen rotation')
            if ri==0: ax.set_ylabel('Record macro-F1')
    fig.legend(*axs[0,0].get_legend_handles_labels(),loc='outside lower center',ncol=2,frameon=False,fontsize=8)
    save(fig,'fig05_same_model_tests','Figure 5. Same-model diagnostic comparison of known and unknown state combinations. Every connected pair uses one selected Extra Trees model (seed 11); x positions identify five frozen rotations. Gray circles denote known-state and colored triangles unknown-state tests; fixed horizontal offsets separate their symbols without altering F1. Differences are not causal estimates of state memorization because the two test populations have different state support. Unknown-state performance remains high for signal-based features, so shared state names in earlier splits cannot be interpreted as demonstrated leakage or as the sole source of high accuracy.',{'fold_points':pd.DataFrame(source)})


def figure6(contrasts):
    pairs=[('time_envelope','native_fullband','Envelope − native'),('order_generic','time_envelope','Order − time'),
           ('time_envelope_meta','time_envelope','Metadata addition'),('order_geometry','order_generic','Geometry addition')]
    fig,axs=plt.subplots(2,2,figsize=(180/25.4,125/25.4),layout='constrained',sharex=True,sharey=True)
    used=[]
    for k,(model,ax) in enumerate(zip(MODELS,axs.flat)):
        for j,(a,b,label) in enumerate(pairs):
            for ti,task in enumerate(TASKS):
                r=contrasts[contrasts.model.eq(model)&contrasts.task.eq(task)&contrasts.a.eq(a)&contrasts.b.eq(b)].iloc[0]
                yy=j+(ti-.5)*.22
                color=['#D55E00','#0072B2'][ti]
                ax.plot([r.low,r.high],[yy,yy],color=color,lw=1)
                ax.scatter(r.macro_f1_difference,yy,color=color,marker=['o','^'][ti],s=24,edgecolors='black',linewidths=.3,zorder=3)
                used.append(r.to_dict())
        ax.axvline(0,color='#737A80',lw=.7,ls='--');ax.set(yticks=range(4),yticklabels=[p[2] for p in pairs],xlim=(-.15,.15))
        panel(ax,chr(97+k),ML[k]);ax.grid(axis='x',color='#E5E7EB',lw=.5)
        if k>=2:ax.set_xlabel('Paired difference in record macro-F1')
    axs[0,0].invert_yaxis()
    fig.legend(handles=[plt.Line2D([],[],marker=m,color=c,ls='None',label=l,markersize=4) for m,c,l in [('o','#D55E00','Inner'),('^','#0072B2','Outer')]],loc='outside lower center',ncol=2,frameon=False)
    save(fig,'fig06_paired_ablations','Figure 6. Physical and metadata ablations on identical unknown-state OOF records. Differences use seed 11 and shared state-cluster bootstrap draws; positive values favor the first representation in each label. These are exploratory, unadjusted conditional intervals, not a family of confirmatory significance tests. Generic time and order features have different fixed coordinate bins (111 versus 99 features), while the metadata addition compares each base block with exactly eight appended metadata features. Geometry adds 81 features. Most gains are small relative to the full-band native baseline.',{'paired_contrasts':pd.DataFrame(used)})


def figure7(summary):
    reps=['native_fullband','time_envelope','order_geometry','mfos_repository']
    fig,axs=plt.subplots(2,2,figsize=(180/25.4,125/25.4),layout='constrained',sharex=True)
    source=summary[summary.seed.eq(11)&summary.representation.isin(reps)].copy()
    for ti,task in enumerate(TASKS):
        for row,metric in enumerate(['macro_f1','nll']):
            ax=axs[row,ti]
            for ri,rep in enumerate(reps):
                f=source[source.task.eq(task)&source.representation.eq(rep)].set_index('model').loc[MODELS]
                xx=np.arange(4)+(ri-1.5)*.14
                ax.plot(xx,f[metric],marker=['o','^','s','D'][ri],color=COL[rep],lw=.8,ms=4,label=LAB[rep])
            panel(ax,chr(97+row*2+ti),('Inner' if ti==0 else 'Outer')+' / '+('Discrimination' if row==0 else 'Probability loss'))
            ax.set(xticks=range(4),xticklabels=['ET','RF','SVM','LR'],ylabel='Record macro-F1' if row==0 else 'Record NLL')
            if row==0:ax.set_ylim(0,1.04)
            else:ax.set_ylim(bottom=0)
            ax.grid(axis='y',color='#E5E7EB',lw=.5)
    fig.legend(*axs[0,0].get_legend_handles_labels(),loc='outside lower center',ncol=2,frameon=False,fontsize=7.5)
    save(fig,'fig07_repository_comparison','Figure 7. Adapted matching-title repository implementation against established feature blocks. All points use seed 11, identical state splits and the same validation rule; ET/RF/SVM/LR denote Extra Trees, random forest, RBF SVM and logistic regression. The original released numerical feature path is used, with NOVIC geometry and fixed settings; no proxy transform replaces it. The implementation has 856 features and is not an equal-capacity comparison. Repository authorship linkage and full-paper configuration were not independently verified, so this is not a complete journal-paper reproduction or a published SOTA ranking.',{'seed11_endpoints':source})


def figure8(pred):
    reps=['metadata_only','native_fullband','time_envelope','order_generic','order_geometry','mfos_repository']
    f=pred[pred.split.eq('test_unknown')&pred.model.eq('extra_trees')&pred.seed.eq(11)&pred.representation.isin(reps)].copy()
    states=pd.read_csv(ROOT/'results/v4/state_support.csv').sort_values(['joint_label','state_id']).reset_index(drop=True)
    states['display_id']=[f'S{i+1:02}' for i in range(33)]
    f['incorrect_class_probability']=np.where(f.label.eq(1),1-f.p1,f.p1)
    state=f.groupby(['task','representation','state_id']).incorrect_class_probability.mean().reset_index()
    fig,axs=plt.subplots(2,2,figsize=(180/25.4,135/25.4),layout='constrained')
    calibration=[]
    for ti,task in enumerate(TASKS):
        ax=axs[0,ti]
        mat=state[state.task.eq(task)].pivot(index='representation',columns='state_id',values='incorrect_class_probability').loc[reps,states.state_id].to_numpy()
        im=ax.imshow(mat,aspect='auto',cmap='magma',vmin=0,vmax=1,interpolation='nearest')
        ax.set(yticks=range(len(reps)),yticklabels=[LAB[r].split(' (')[0] for r in reps],xticks=[0,8,16,24,32],xticklabels=states.display_id.iloc[[0,8,16,24,32]],xlabel='Exact state combination')
        panel(ax,chr(97+ti),('Inner' if ti==0 else 'Outer')+' / Error probability')
        ax=axs[1,ti]
        ax.plot([0,1],[0,1],color='#8A9096',ls='--',lw=.7)
        for rep in ['metadata_only','native_fullband','time_envelope','mfos_repository']:
            sub=f[f.task.eq(task)&f.representation.eq(rep)].copy()
            sub['bin']=np.minimum((sub.p1*5).astype(int),4)
            bt=sub.groupby('bin').agg(probability=('p1','mean'),event_rate=('label','mean'),records=('p1','size')).reset_index()
            ax.scatter(bt.probability,bt.event_rate,color=COL[rep],s=17,marker=['o','s','^','D'][['metadata_only','native_fullband','time_envelope','mfos_repository'].index(rep)],label=LAB[rep].split(' (')[0])
            for _,r in bt.iterrows():calibration.append({'task':task,'representation':rep,**r.to_dict()})
        panel(ax,chr(99+ti),('Inner' if ti==0 else 'Outer')+' / Reliability')
        ax.set(xlim=(-.03,1.03),ylim=(-.03,1.03),xlabel='Mean predicted positive probability',ylabel='Observed positive fraction')
    fig.colorbar(im,ax=axs[0,:],shrink=.8,label='Mean probability of the incorrect class',orientation='horizontal',pad=.06)
    fig.legend(*axs[1,0].get_legend_handles_labels(),loc='outside lower center',ncol=2,frameon=False,fontsize=7.5)
    save(fig,'fig08_probability_and_state_errors','Figure 8. Complete state-level error probabilities and descriptive reliability. (a,b) Each cell averages the incorrect-class probability over OOF records within one exact state; labels match Fig. 2. This equal-state display differs from the equal-record endpoint. (c,d) Five fixed equal-width bins summarize 79 record probabilities; empty bins are omitted and no calibration model is fitted to these test observations. Points are descriptive; some bins contain only 1–3 records, with counts supplied in the source CSV. These points do not demonstrate probability calibration. Extra Trees seed 11 is fixed for all panels.',{'state_error':state,'record_probabilities':f,'reliability_bins':pd.DataFrame(calibration),'state_labels':states[['state_id','display_id']]})


def figure9(summary, runs):
    f=summary[summary.model.eq('extra_trees')].copy()
    fig,axs=plt.subplots(1,3,figsize=(180/25.4,100/25.4),layout='constrained',gridspec_kw={'width_ratios':[1,1.5,1]})
    ax=axs[0]
    for ti,task in enumerate(TASKS):
        for rep in REPS:
            r=f[f.task.eq(task)&f.representation.eq(rep)&f.seed.eq(11)].iloc[0]
            ax.scatter(r.macro_f1,r.state_weighted_macro_f1,color=COL[rep],marker=['o','^'][ti],s=22,edgecolors='black',linewidths=.3)
    ax.plot([0,1],[0,1],ls='--',color='#93999E',lw=.7)
    ax.set(xlim=(0,1.05),ylim=(0,1.05),xlabel='Equal-record macro-F1',ylabel='Equal-state weighted macro-F1')
    panel(ax,'a','Weighting sensitivity')
    ax=axs[1]
    for ti,task in enumerate(TASKS):
        for j,rep in enumerate(REPS):
            values=f[f.task.eq(task)&f.representation.eq(rep)].sort_values('seed').macro_f1.to_numpy()
            xx=j+(ti-.5)*.22
            ax.plot([xx,xx],[min(values),max(values)],color=COL[rep],lw=1)
            ax.scatter(xx+np.linspace(-.035,.035,3),values,color=COL[rep],marker=['o','^'][ti],s=16,edgecolors='black',linewidths=.2)
    ax.set(xticks=range(8),xticklabels=['Meta','Raw','Time','Time+M','Order','Order+M','Geom.','Repo'],ylim=(0,1.05),ylabel='Unknown-state record macro-F1')
    ax.tick_params(axis='x',rotation=55);panel(ax,'b','All three ET seeds')
    support=pd.read_csv(ROOT/'results/v4/state_dual_test_support.csv')
    tr=support[support.split.eq('train')]
    axs[2].bar(range(1,6),tr.source_groups,color=['#D55E00','#D55E00','#626B73','#626B73','#626B73'],width=.65)
    axs[2].set(xticks=range(1,6),xlabel='Frozen rotation',ylabel='Training recording proxies',ylim=(0,55))
    for i,n in enumerate(tr.source_groups):axs[2].text(i+1,n+1,str(n),ha='center',fontsize=7)
    axs[2].text(.03,.98,'Orange: normal state\nabsent from training',transform=axs[2].transAxes,va='top',fontsize=7)
    panel(axs[2],'c','Training support')
    fig.legend(handles=[plt.Line2D([],[],marker=m,color='black',ls='None',label=l,markersize=4) for m,l in [('o','Inner presence'),('^','Outer presence')]],loc='outside lower center',ncol=2,frameon=False,fontsize=8)
    save(fig,'fig09_support_and_seed_sensitivity','Figure 9. Sensitivity to evaluation weights, algorithm seed and support. Circles and triangles denote inner and outer presence; colors in (a) match the named representations in (b). (a) Equal-record versus equal-state weighted F1 on identical seed-11 OOF predictions. (b) Every Extra Trees seed (11, 22, 33) is shown; ranges describe fitting variation and are not confidence intervals. (c) The first two rotations have fewer training proxies and no normal training state because all normal records share one state fold. Other negative-class interference states remain present. State isolation changes the training problem and cannot by itself identify a causal leakage effect.',{'all_et_seed_metrics':f,'training_support':tr})


def main():
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'source_data').mkdir(exist_ok=True)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,
                         'axes.linewidth':.6,'svg.fonttype':'none','pdf.fonttype':42,'legend.fontsize':7})
    summary=pd.read_csv(A/'unknown_oof_summary.csv')
    intervals=pd.read_csv(A/'unknown_cluster_intervals.csv')
    runs=pd.read_csv(A/'fold_metrics.csv');pred=pd.read_csv(A/'record_predictions.csv')
    contrasts=pd.read_csv(A/'paired_cluster_contrasts.csv')
    figure1();figure2();figure4(summary,intervals);figure5(runs);figure6(contrasts);figure7(summary);figure8(pred);figure9(summary,runs)
    # Retain the measured physical explanation without relabelling its outputs
    # as new evidence or changing its fixed sample selection.
    stem='fig03_bandwidth_mechanism'
    for ext in ('png','svg','pdf'):
        shutil.copy2(ROOT/f'figures/v3/{stem}.{ext}',OUT/f'{stem}.{ext}')
    shutil.copy2(ROOT/f'figures/v3/{stem}_caption.md',OUT/f'{stem}_caption.md')
    caption_path=OUT/f'{stem}_caption.md'
    caption_path.write_text(caption_path.read_text(encoding='utf-8').replace('Panel d includes all 79 source groups.', 'Panel d includes all 79 source groups; black horizontal segments mark their medians.'),encoding='utf-8')
    MANIFEST.append({'stem':stem,'origin':'unchanged v3 physical verification, explicitly reused',
        'outputs':[{'path':str((OUT/f'{stem}.{ext}').relative_to(ROOT)),'sha256':hashlib.sha256((OUT/f'{stem}.{ext}').read_bytes()).hexdigest()} for ext in ('png','svg','pdf')],
        'source_manifest':'figures/v3/figure_manifest.json'})
    (OUT/'figure_manifest.json').write_text(json.dumps(MANIFEST,indent=2),encoding='utf-8')
    print('Saved nine main figures with vector exports and derived source tables',flush=True)


if __name__=='__main__':main()
