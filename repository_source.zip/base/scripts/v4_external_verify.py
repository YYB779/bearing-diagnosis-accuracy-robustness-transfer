"""Independent completed-output audit; no model fitting or target selection."""
from pathlib import Path
import json,csv,math,sys
import joblib,numpy as np
from v4_external_common import sha

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/v4_external'
summary=json.loads((OUT/'summary.json').read_text(encoding='utf8'))
reg=json.loads((OUT/'registration.json').read_text(encoding='utf8'))
splits=json.loads((OUT/'split_audit.json').read_text(encoding='utf8'))
cal=json.loads((OUT/'calibration_audit.json').read_text(encoding='utf8'))
pred=list(csv.DictReader((OUT/'heldout_record_predictions.csv').open(encoding='utf8')))
manifest=json.loads((ROOT/'data/raw/v4_external/download_manifest.json').read_text(encoding='utf8'))
assert summary['expanded_acquisition_complete'] and summary['raw_recordings']==21 and summary['windows']==168
assert len(manifest['downloads'])==12
assert sum(r['bytes'] for r in manifest['downloads'])<=180_000_000
assert reg['script_sha256']==sha(ROOT/'scripts/v4_external_run.py')
assert reg['common_sha256']==sha(ROOT/'scripts/v4_external_common.py')
assert reg['design_sha256']==sha(ROOT/'docs/v4/external_frozen_design.md')
assert summary['registration_sha256']==sha(OUT/'registration.json')
assert len(splits)==6 and len(summary['results'])==114
assert len(cal)==90
for split in splits:
    a=set(split['train_records']);b=set(split['validation_records']);c=set(split['test_records'])
    assert not(a&b or a&c or b&c)
    if split['study']=='expanded_condition_holdout':
        assert len(split['train_conditions'])==3 and len(split['validation_conditions'])==len(split['test_conditions'])==1
    else:
        assert not split['record_calibration_feasible'] and len(a)==3
for audit in cal:
    split=next(s for s in splits if s['study']=='expanded_condition_holdout' and s['fold']==audit['fold'])
    train=set(split['train_records']); held_cal=set(audit['calibration_source_records'])
    assert train==held_cal and len(held_cal)==audit['n_effective_calibration_records']
    assert not held_cal.intersection(split['validation_records']+split['test_records'])
    for fold in audit['calibration_folds']:
        assert not set(fold['fit_source_records'])&set(fold['held_source_records'])
        assert set(fold['fit_source_records'])|set(fold['held_source_records'])==train
        assert fold['fit_classes']==fold['held_classes']==[0,1,2]
    assert all(a['success'] for a in audit['sigmoid_fit'])
combos={(r['representation'],r['model'],r['seed']) for r in pred if r['study']=='expanded_condition_holdout'}
for combo in combos:
    subset=[r for r in pred if r['study']=='expanded_condition_holdout' and (r['representation'],r['model'],r['seed'])==combo]
    assert len(subset)==len({r['source_record'] for r in subset})==21
    assert all(abs(sum(float(r['prob_'+c]) for c in ['H','I','O'])-1)<1e-9 for r in subset)
svm_scaler_samples=[]
for path in OUT.glob('expanded_condition_holdout_*_SVM.joblib'):
    obj=joblib.load(path);model=obj['base_model']
    fold=next(s for s in splits if s['study']=='expanded_condition_holdout' and path.name.startswith('expanded_condition_holdout_'+s['fold']+'_'))
    expected=len(fold['train_records'])*8
    assert model[0].n_samples_seen_==expected
    svm_scaler_samples.append({'model':path.name,'scaler_fit_windows':int(model[0].n_samples_seen_),'training_source_records':len(fold['train_records'])})
assert len(svm_scaler_samples)==15
v3=json.loads((ROOT/'results/v3_hust_external/summary.json').read_text(encoding='utf8'))
comparisons=[]
for oldrep,newrep in [('raw_lowpass_180hz','raw_lowpass_33'),('three_carrier_envelopes','three_carrier_99')]:
    for seed in [11,22,33]:
        older=next(r for r in v3['selected_runs'] if r['representation']==oldrep and r['seed']==seed)
        newer=next(r for r in summary['results'] if r['study']=='original_nine_file_split' and r['representation']==newrep and r['seed']==seed)
        for metric in ['macro_f1','nll','balanced_accuracy']:
            assert abs(older['test_record_metrics'][metric]-newer['test_record_metrics'][metric])<1e-12,(newrep,seed,metric)
        assert older['selected_leaf']==newer['selected_hyperparameter']
        comparisons.append({'v3_representation':oldrep,'v4_representation':newrep,'seed':seed,'record_F1_NLL_BA_and_selected_leaf_reproduced':True})
audit={'passed':True,'source_record_count':21,'new_source_file_count':12,'new_raw_bytes':sum(r['bytes'] for r in manifest['downloads']),
       'outer_condition_folds':5,'training_only_record_sigmoid_fits_audited':len(cal),'selected_runs':114,
       'source_record_prediction_rows':len(pred),'svm_scaler_sample_counts':svm_scaler_samples,
       'v3_unchanged_result_reproductions':comparisons,
       'claim_boundaries':['No independent-bearing claim','No window-independent sample size','No calibrated Speed/order tracking','No claim that calibration universally improves F1 or NLL']}
(OUT/'verification.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
print(json.dumps({k:v for k,v in audit.items() if k not in ['svm_scaler_sample_counts','v3_unchanged_result_reproductions']},indent=2))
