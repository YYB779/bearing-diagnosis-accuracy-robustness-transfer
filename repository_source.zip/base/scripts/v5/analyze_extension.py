"""Audit all planned extension cells and build complete record-level comparisons."""
from pathlib import Path
from datetime import datetime,timezone
import json
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score,log_loss,confusion_matrix
from scripts.v4_external_common import sha

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/v5/analysis'
ARMS=['wdcnn_ce','classbd_ce','classbd_physics','wdcnn_coral','classbd_physics_coral']


def recompute(y,p):
    p=np.asarray(p,dtype=np.float64)
    error=float(np.max(abs(p.sum(1)-1)))
    assert np.isfinite(p).all() and np.all((p>=0)&(p<=1)) and error<1e-6
    pred=p.argmax(1);cm=confusion_matrix(y,pred,labels=[0,1,2])
    recall=cm.diagonal()/cm.sum(1)
    # sklearn log_loss normalizes floating posterior row-sum residuals. Keep
    # stored probabilities for Brier to reproduce the frozen calculation.
    return {'macro_f1':float(f1_score(y,pred,labels=[0,1,2],average='macro',zero_division=0)),
        'nll':float(log_loss(y,p,labels=[0,1,2])),
        'multiclass_brier':float(np.mean(np.sum((p-np.eye(3)[y])**2,axis=1))),
        'recall_H':float(recall[0]),'recall_I':float(recall[1]),'recall_O':float(recall[2]),
        'n_records':len(y),'max_probability_sum_roundoff':error}


def load_run(folder,path,feature=False):
    result=json.loads(path.read_text(encoding='utf-8'));dp=folder/'design.json'
    assert result['design_sha256']==sha(dp)
    pp=path.with_name(path.stem+'_predictions.csv');assert result['predictions_sha256']==sha(pp)
    mp=path.with_suffix('.joblib' if feature else '.pt');assert result['model_sha256']==sha(mp)
    pred=pd.read_csv(pp,float_precision='round_trip')
    if feature:pred['panel']='clean'
    records=[]
    for panel,f in pred.groupby('panel'):
        met=recompute(f.label.to_numpy(int),f[['p_H','p_I','p_O']].to_numpy())
        reference=result['test'] if feature else result['test'][panel]
        for metric in ['macro_f1','nll','multiclass_brier']:
            assert abs(met[metric]-reference[metric])<1e-6,(path,metric,met[metric],reference[metric])
        records.append({'fold':result['fold'],'panel':panel,**met})
    if not feature:
        history=result['training_history'];assert [r['update'] for r in history]==list(range(10,121,10))
        chosen=min(history,key=lambda r:(-r['validation']['macro_f1'],r['validation']['nll'],r['update']))
        assert chosen['update']==result['selected_update']
        assert chosen['validation']==result['validation']
    else:
        chosen=min(result['candidates'],key=lambda r:(-r['validation']['macro_f1'],r['validation']['nll'],r['hyperparameter']))
        assert chosen['hyperparameter']==result['chosen']
    return result,pred,records


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    folders={'feature':ROOT/'results/v5/feature_controls','neural':ROOT/'results/v5/classbd_extension'}
    lineage=pd.read_csv(ROOT/'results/v4_external/window_lineage.csv').drop_duplicates('source_record').set_index('source_record')
    allpred=[];foldrows=[];modelrows=[];audit={'created_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':sha(Path(__file__))}
    for kind,folder in folders.items():
        paths=[p for p in folder.glob('*.json') if p.name!='design.json' and not p.name.endswith('_split_and_batches.json')]
        expected=100 if kind=='feature' else 25
        assert len(paths)==expected,(kind,len(paths),expected)
        candidates=0
        for path in sorted(paths):
            result,pred,records=load_run(folder,path,feature=kind=='feature')
            name=result['representation'] if kind=='feature' else result['arm']
            family=result['family'] if kind=='feature' else 'WDCNN'
            identifiers={'kind':kind,'method':name,'family':family,'seed':result['seed']}
            for k,v in identifiers.items():pred[k]=v
            pred['fold']=result['fold'];pred['condition']=pred.source_record.map(lineage.condition)
            pred['severity']=pred.source_record.map(lineage.severity)
            for row in records:foldrows.append({**identifiers,**row})
            allpred.append(pred)
            modelrows.append({**identifiers,'fold':result['fold'],'seconds':result['seconds'],
                'selected_update_or_hyper':result.get('selected_update',result.get('chosen')),
                'parameters':result.get('parameter_count'),
                'validation_f1':result['validation']['macro_f1'],'validation_nll':result['validation']['nll']})
            candidates+=len(result['candidates']) if kind=='feature' else len(result['training_history'])
        assert candidates==(225 if kind=='feature' else 300)
        audit[kind]={'selected_models':len(paths),'validation_options':candidates,
                    'design_sha256':sha(folder/'design.json'),'all_saved_hashes_and_selection_metrics_match':True}
    prediction=pd.concat(allpred,ignore_index=True)
    summary=[]
    for key,f in prediction.groupby(['kind','method','family','seed','panel'],sort=True):
        assert len(f)==f.source_record.nunique()==21
        assert set(f.source_record)==set(lineage.index)
        summary.append(dict(zip(['kind','method','family','seed','panel'],key),**recompute(f.label.to_numpy(int),f[['p_H','p_I','p_O']].to_numpy())))
    summary=pd.DataFrame(summary);fold=pd.DataFrame(foldrows);models=pd.DataFrame(modelrows)
    prediction.to_csv(OUT/'record_predictions.csv',index=False);summary.to_csv(OUT/'pooled_summary.csv',index=False)
    fold.to_csv(OUT/'fold_summary.csv',index=False);models.to_csv(OUT/'model_cost_and_selection.csv',index=False)
    descriptive=summary.groupby(['kind','method','family','panel'],sort=True).agg(
        seeds=('seed','size'),macro_f1_mean=('macro_f1','mean'),macro_f1_min=('macro_f1','min'),macro_f1_max=('macro_f1','max'),
        nll_mean=('nll','mean'),brier_mean=('multiclass_brier','mean'),healthy_recall_mean=('recall_H','mean')).reset_index()
    descriptive.to_csv(OUT/'descriptive_summary.csv',index=False)
    # Published-score subtraction and best-test-arm selection are deliberately
    # absent. These are declared pairs, all of which are retained.
    contrasts=[]
    for panel in ['clean','AWGN0dB','AWGN-4dB']:
        f=summary[(summary.kind=='neural')&(summary.panel==panel)].set_index('method')
        for a,b in [('classbd_ce','wdcnn_ce'),('classbd_physics','classbd_ce'),('wdcnn_coral','wdcnn_ce'),
                    ('classbd_physics_coral','classbd_physics'),('classbd_physics_coral','wdcnn_ce')]:
            contrasts.append({'panel':panel,'a':a,'b':b,'delta_macro_f1':f.loc[a,'macro_f1']-f.loc[b,'macro_f1'],
                'delta_nll':f.loc[a,'nll']-f.loc[b,'nll'],'delta_healthy_recall':f.loc[a,'recall_H']-f.loc[b,'recall_H']})
    pd.DataFrame(contrasts).to_csv(OUT/'declared_neural_contrasts.csv',index=False)
    # Historical features should reproduce the frozen v4 protocol. Minor source
    # CSV round-trip changes are measured rather than silently relabelled exact.
    original=pd.read_csv(ROOT/'results/v4_external/pooled_metrics.csv')
    comparison=[]
    for method,oldrep in [('raw_lowpass_33','raw_lowpass_33'),('single_envelope_33','single_carrier_2_5khz_33')]:
        for family,oldmodel in [('ET','ET_uncalibrated'),('SVM','SVM_record_sigmoid')]:
            rows=summary[(summary.method==method)&(summary.family==family)]
            for _,r in rows.iterrows():
                old=original[(original.representation==oldrep)&(original.model==oldmodel)&(original.severity_scope=='all_records')]
                if family=='ET':old=old[old.seed.astype(str)==str(r.seed)]
                assert len(old)==1
                comparison.append({'method':method,'family':family,'seed':r.seed,
                    'f1_difference_from_v4':r.macro_f1-old.iloc[0].macro_f1,
                    'nll_difference_from_v4':r.nll-old.iloc[0].nll})
    pd.DataFrame(comparison).to_csv(OUT/'v4_replay_differences.csv',index=False)
    # Verify model batches contain only the actual training records/domains.
    patch=pd.read_csv(ROOT/'data/processed/v5/hust_neural_patch_lineage.csv')
    for foldindex in range(5):
        split=json.loads((folders['neural']/f'fold{foldindex}_split_and_batches.json').read_text(encoding='utf-8'))
        assert len(split['batch_indices'])==120
        for batch in split['batch_indices']:
            sf=patch.iloc[batch]
            assert len(sf)==18 and set(sf.source_record)<=set(split['train_records'])
            assert not set(sf.source_record)&set(split['validation_records']+split['test_records'])
            assert sf.groupby(['condition','class_id']).size().tolist()==[2]*9
    audit.update(pooled_rows=len(summary),fold_metric_rows=len(fold),unique_record_units=21,
        training_batches_checked=600,max_posterior_sum_roundoff=float(summary.max_probability_sum_roundoff.max()),
        note='Neural float32 softmax record sums differ from one by <=1e-6; log_loss normalizes row roundoff, frozen saved probabilities retained for Brier. No refitting here.',
        all_test_predictions_and_failures_retained=True,physical_bearing_ids_available=False)
    (OUT/'audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(descriptive.to_string(index=False),flush=True)


if __name__=='__main__':main()
