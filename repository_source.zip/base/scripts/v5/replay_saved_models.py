"""Independently replay every saved v5 neural checkpoint on all three panels.

This audit does not train, choose a checkpoint, recalibrate, or change any frozen
input. It deliberately rebuilds preprocessing and record aggregation rather than
calling the experiment runner's evaluation helper. An incomplete run is never a
passing audit. Only the JSON audit named below is written.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import traceback

import numpy as np
import pandas as pd
import torch

from scripts.v5.classbd_models import ClassBDWDCNN


ROOT = Path(__file__).resolve().parents[2]
RUNS = ROOT / "results/v5/classbd_extension"
AUDIT = ROOT / "results/v5/model_replay_audit.json"
CONDITIONS = ["20Hz", "30Hz", "40Hz", "60Hz", "VS_0_40_0Hz"]
ARMS = {
    "wdcnn_ce": ("baseline", False),
    "classbd_ce": ("bd_ce", False),
    "classbd_physics": ("bd_physics", False),
    "wdcnn_coral": ("baseline", True),
    "classbd_physics_coral": ("bd_physics", True),
}
PANELS = ["clean", "AWGN0dB", "AWGN-4dB"]
TOLERANCE = 1e-6


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def normalized_patches(values):
    # Match the saved float32 signal arithmetic, without fitted statistics.
    values = np.asarray(values, dtype=np.float32)
    centered = values - np.mean(values, axis=-1, keepdims=True)
    scale = np.sqrt(np.mean(centered * centered, axis=-1, keepdims=True))
    return centered / np.maximum(scale, 1e-8)


def noise_panel(values, snr):
    rng = np.random.default_rng(5102026 + abs(snr))
    noise = rng.normal(size=values.shape)
    signal = np.asarray(values, dtype=np.float64)
    noise -= noise.mean(axis=-1, keepdims=True)
    centered = signal - signal.mean(axis=-1, keepdims=True)
    factor = np.sqrt(
        np.mean(centered * centered, axis=-1, keepdims=True)
        / np.maximum(np.mean(noise * noise, axis=-1, keepdims=True), 1e-30)
    ) * 10 ** (-float(snr) / 20)
    return (signal + noise * factor).astype(np.float32)


def infer_record_probabilities(model, values, indices, frame):
    batches = []
    with torch.no_grad():
        for start in range(0, len(indices), 48):
            selected = indices[start : start + 48]
            inputs = torch.from_numpy(normalized_patches(values[selected])[:, None, :])
            logits = model(inputs)["logits"]
            require(not logits.requires_grad, "evaluation created an autograd graph")
            batches.append(torch.softmax(logits, dim=1).cpu().numpy())
    patch_probabilities = np.concatenate(batches)
    require(np.isfinite(patch_probabilities).all(), "nonfinite patch probability")
    subset = frame.iloc[indices]
    names = sorted(subset.source_record.unique().tolist())
    labels, probabilities = [], []
    for name in names:
        mask = subset.source_record.to_numpy() == name
        local_labels = subset.class_id.to_numpy(dtype=int)[mask]
        require(len(set(local_labels)) == 1, f"mixed labels within {name}")
        require(int(mask.sum()) == 32, f"unexpected patch count for {name}")
        labels.append(int(local_labels[0]))
        probabilities.append(patch_probabilities[mask].mean(axis=0))
    return names, np.asarray(labels), np.stack(probabilities)


def write_audit(report):
    AUDIT.parent.mkdir(parents=True, exist_ok=True)
    temp = AUDIT.with_suffix(".tmp")
    temp.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    temp.replace(AUDIT)


def execute(report):
    expected = [
        RUNS / f"fold{fold}_{arm}_s11{suffix}"
        for fold in range(5)
        for arm in ARMS
        for suffix in (".pt", ".json", "_predictions.csv")
    ]
    expected += [RUNS / "design.json"]
    expected += [RUNS / f"fold{fold}_split_and_batches.json" for fold in range(5)]
    missing = [str(path.relative_to(ROOT)) for path in expected if not path.is_file()]
    if missing:
        report.update(status="incomplete", missing_files=missing, success=False)
        return 2

    design_path = RUNS / "design.json"
    design_hash = digest(design_path)
    design = json.loads(design_path.read_text(encoding="utf-8"))
    require(design["planned_selected_models"] == 25, "design model count changed")
    require(design["steps"] == 120, "design training budget changed")
    require(design["seed"] == 11, "design seed changed")
    require(design["test_panels"] == PANELS, "design test panels changed")
    for arm, (variant, coral) in ARMS.items():
        require(design["arms"][arm] == {"variant": variant, "source_coral": coral},
                f"design arm mismatch: {arm}")
    source_checks = []
    for relative, expected_hash in design["sha256"].items():
        path = ROOT / relative
        require(path.is_file(), f"missing frozen input {relative}")
        actual_hash = digest(path)
        require(actual_hash == expected_hash, f"frozen input SHA mismatch: {relative}")
        source_checks.append({"path": relative, "sha256": actual_hash})
    report.update(design_sha256=design_hash, frozen_input_hash_checks=source_checks)

    patch_path = ROOT / "data/processed/v5/hust_neural_patches.npz"
    lineage_path = ROOT / "data/processed/v5/hust_neural_patch_lineage.csv"
    frame = pd.read_csv(lineage_path)
    with np.load(patch_path, allow_pickle=False) as archive:
        values = archive["x"]
        require(values.shape == (672, 2048), "patch array shape changed")
        require(values.dtype == np.float32, "patch dtype changed")
        require(np.array_equal(archive["patch_id"], frame.patch_id.to_numpy(str)),
                "patch/lineage identifiers differ")
        require(int(archive["fs"]) == 25600, "sample frequency changed")
        require(np.array_equal(archive["offsets"], [0, 7850, 15701, 23552]),
                "patch offsets changed")
    require(np.isfinite(values).all(), "nonfinite input signal")
    require(len(frame) == 672 and frame.source_record.nunique() == 21,
            "lineage dimensions changed")
    require(frame.patch_id.is_unique, "duplicate patch identifiers")
    frame["domain_id"] = frame.condition.map(dict(zip(CONDITIONS, range(5))))
    require(frame.domain_id.notna().all(), "unknown condition")
    panels = {"clean": values, "AWGN0dB": noise_panel(values, 0),
              "AWGN-4dB": noise_panel(values, -4)}

    details = []
    checked_models = 0
    global_maxdiff = 0.0
    global_saved_residual = 0.0
    global_replay_residual = 0.0
    for fold in range(5):
        test_indices = np.flatnonzero(frame.domain_id.to_numpy() == fold)
        validation_indices = np.flatnonzero(frame.domain_id.to_numpy() == (fold + 1) % 5)
        train_indices = np.flatnonzero(
            (frame.domain_id.to_numpy() != fold)
            & (frame.domain_id.to_numpy() != (fold + 1) % 5)
        )
        split = json.loads((RUNS / f"fold{fold}_split_and_batches.json").read_text(encoding="utf-8"))
        for key, indices in [("train_records", train_indices),
                             ("validation_records", validation_indices),
                             ("test_records", test_indices)]:
            require(sorted(frame.iloc[indices].source_record.unique().tolist()) == split[key],
                    f"fold{fold} {key} differs from lineage")
        for arm, (variant, coral) in ARMS.items():
            stem = f"fold{fold}_{arm}_s11"
            result_path = RUNS / f"{stem}.json"
            result = json.loads(result_path.read_text(encoding="utf-8"))
            model_path = RUNS / f"{stem}.pt"
            prediction_path = RUNS / f"{stem}_predictions.csv"
            require(result["design_sha256"] == design_hash, f"{stem} design mismatch")
            require(result["model_sha256"] == digest(model_path), f"{stem} checkpoint SHA mismatch")
            require(result["predictions_sha256"] == digest(prediction_path), f"{stem} CSV SHA mismatch")
            require(result["fold"] == fold and result["arm"] == arm
                    and result["seed"] == 11 and result["variant"] == variant
                    and result["coral"] == coral, f"{stem} result identity mismatch")
            history = result["training_history"]
            require([row["update"] for row in history] == list(range(10, 121, 10)),
                    f"{stem} incomplete validation history")
            selected = max(history, key=lambda row: (row["validation"]["macro_f1"],
                                                    -row["validation"]["nll"], -row["update"]))
            require(result["selected_update"] == selected["update"],
                    f"{stem} checkpoint violates frozen validation selection rule")
            require(result["validation"] == selected["validation"], f"{stem} validation mismatch")
            checkpoint = torch.load(model_path, map_location="cpu", weights_only=True)
            require(checkpoint["design_sha256"] == design_hash
                    and checkpoint["arm"] == arm and checkpoint["variant"] == variant
                    and checkpoint["selected_update"] == result["selected_update"],
                    f"{stem} checkpoint identity mismatch")
            require(set(checkpoint) == {"model_state", "objective_state", "variant", "arm",
                                        "selected_update", "design_sha256"},
                    f"{stem} unexpected checkpoint fields")
            model = ClassBDWDCNN(variant=variant)
            model.load_state_dict(checkpoint["model_state"], strict=True)
            require(sum(parameter.numel() for parameter in model.parameters()) == result["parameter_count"],
                    f"{stem} parameter count mismatch")
            model.eval()
            require(not any(module.training for module in model.modules()),
                    f"{stem} model contains a training-mode module")
            bn_before = {key: value.clone() for key, value in model.named_buffers()
                         if key.endswith(("running_mean", "running_var", "num_batches_tracked"))}
            require(len(bn_before) >= 18, f"{stem} missing BatchNorm buffers")
            stored = pd.read_csv(prediction_path)
            require(sorted(stored.panel.unique()) == sorted(PANELS), f"{stem} CSV panels mismatch")
            require(not stored.duplicated(["panel", "source_record"]).any(), f"{stem} duplicate record posterior")
            require(len(stored) == 3 * len(split["test_records"]), f"{stem} posterior count mismatch")
            for panel, signal in panels.items():
                names, labels, probabilities = infer_record_probabilities(model, signal, test_indices, frame)
                panel_stored = stored.loc[stored.panel.eq(panel)].set_index("source_record").loc[names]
                require(np.array_equal(labels, panel_stored.label.to_numpy(int)),
                        f"{stem}/{panel} record labels differ")
                saved = panel_stored[["p_H", "p_I", "p_O"]].to_numpy(float)
                require(np.isfinite(saved).all() and (saved >= 0).all() and (saved <= 1).all(),
                        f"{stem}/{panel} invalid saved probability")
                saved_residual = float(np.max(np.abs(saved.sum(axis=1) - 1)))
                replay_residual = float(np.max(np.abs(probabilities.sum(axis=1) - 1)))
                maxdiff = float(np.max(np.abs(saved - probabilities)))
                require(saved_residual <= TOLERANCE and replay_residual <= TOLERANCE,
                        f"{stem}/{panel} row sum exceeds float32 tolerance")
                require(maxdiff <= TOLERANCE, f"{stem}/{panel} replay mismatch {maxdiff:.12g}")
                details.append({"fold": fold, "arm": arm, "panel": panel,
                                "records": len(names), "selected_update": result["selected_update"],
                                "max_absolute_probability_difference": maxdiff,
                                "saved_max_row_sum_residual": saved_residual,
                                "replay_max_row_sum_residual": replay_residual})
                global_maxdiff = max(global_maxdiff, maxdiff)
                global_saved_residual = max(global_saved_residual, saved_residual)
                global_replay_residual = max(global_replay_residual, replay_residual)
            bn_after = dict(model.named_buffers())
            require(all(torch.equal(buffer, bn_after[key]) for key, buffer in bn_before.items()),
                    f"{stem} BatchNorm state changed during evaluation")
            checked_models += 1
            report["checked_models"] = checked_models
            report["checked_model_panels"] = len(details)
            report["details"] = details
            print(f"REPLAY PASS {stem}: 3 panels; {len(bn_before)} BatchNorm buffers unchanged", flush=True)
    require(checked_models == 25 and len(details) == 75, "incomplete checkpoint/panel replay")
    grouped = []
    for arm in ARMS:
        for panel in PANELS:
            rows = [row for row in details if row["arm"] == arm and row["panel"] == panel]
            require(len(rows) == 5, f"incomplete {arm}/{panel} folds")
            grouped.append({"arm": arm, "panel": panel, "folds": 5,
                            "source_record_predictions": sum(row["records"] for row in rows),
                            "max_absolute_probability_difference": max(
                                row["max_absolute_probability_difference"] for row in rows)})
    report.update(success=True, status="passed", checked_models=25, checked_model_panels=75,
                  batchnorm_buffers_unchanged_for_all_models=True,
                  maximum_absolute_probability_difference=global_maxdiff,
                  maximum_saved_row_sum_residual=global_saved_residual,
                  maximum_replayed_row_sum_residual=global_replay_residual,
                  by_arm_and_panel=grouped, details=details)
    return 0


def main():
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    report = {"created_utc": datetime.now(timezone.utc).isoformat(),
              "success": False, "status": "started", "planned_models": 25,
              "planned_model_panels": 75, "absolute_probability_tolerance": TOLERANCE,
              "audit_script_sha256": digest(Path(__file__)),
              "implementation": "independent NumPy normalization/noise/record aggregation; frozen model core; CPU eval/no_grad",
              "scope": "saved numerical prediction and state integrity replay; not an independent dataset, experiment, or reproduction of published performance",
              "software": {"torch": torch.__version__, "numpy": np.__version__,
                           "pandas": pd.__version__, "threads": 2}}
    try:
        code = execute(report)
    except Exception as exc:
        report.update(success=False, status="failed", error=f"{type(exc).__name__}: {exc}",
                      traceback=traceback.format_exc())
        code = 1
    write_audit(report)
    print(json.dumps({key: value for key, value in report.items()
                      if key not in {"details", "traceback", "frozen_input_hash_checks", "by_arm_and_panel"}},
                     indent=2), flush=True)
    return code


if __name__ == "__main__":
    sys.exit(main())
