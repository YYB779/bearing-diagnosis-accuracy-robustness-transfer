"""Render the complete, audited v5 extension without selecting favourable arms.

All three figures are provisional general manuscript figures at 170 mm width;
they do not imply acceptance by or compliance with a particular journal.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator
import numpy as np
import pandas as pd
from PIL import Image


ROOT = Path(__file__).resolve().parents[2]
ANALYSIS = ROOT / "results/v5/analysis"
NEURAL = ROOT / "results/v5/classbd_extension"
OUT = ROOT / "figures/v5"
REPS = ["raw_lowpass_33", "single_envelope_33", "native_fullband_25",
        "native_shape_25", "native_envelope_fusion_124"]
REP_LABELS = ["Low-pass (33)", "Envelope (33)", "Native band (25)",
              "Native shape (25)", "Native + envelopes (124)"]
ARMS = ["wdcnn_ce", "classbd_ce", "classbd_physics", "wdcnn_coral",
        "classbd_physics_coral"]
ARM_LABELS = ["A  WDCNN", "B  BD CE", "C  BD Physics", "D  WDCNN + CORAL",
              "E  BD Physics + CORAL"]
ARM_SHORT = ["A", "B", "C", "D", "E"]
PANELS = ["clean", "AWGN0dB", "AWGN-4dB"]
PANEL_LABELS = ["Clean", "AWGN 0 dB", "AWGN −4 dB"]
CONDITIONS = ["20 Hz", "30 Hz", "40 Hz", "60 Hz", "Variable speed"]
BLUE, ORANGE, GREEN, PURPLE, BLACK = "#0072B2", "#C45A00", "#007A5C", "#805687", "#333333"
ARM_COLORS = [BLUE, ORANGE, GREEN, PURPLE, BLACK]
ARM_STYLES = ["-", "--", "-.", ":", (0, (5, 2, 1, 2))]
MARKERS = ["o", "s", "^", "D", "v"]
WIDTH = 170 / 25.4


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def panel(ax, letter, title):
    ax.set_title(title, loc="left", fontsize=8, pad=9)
    ax.text(-.19, 1.10, letter, transform=ax.transAxes, fontsize=10,
            weight="bold", va="top", ha="left")


def clean_axis(ax, axis="x"):
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(length=2.4, width=.65, pad=2.5)
    ax.grid(axis=axis, color="#E4E4E4", linewidth=.45, zorder=0)
    ax.set_axisbelow(True)


def full_unit_axis(ax, axis="x"):
    getattr(ax, f"set_{axis}lim")(-.025, 1.025)
    getattr(ax, f"set_{axis}ticks")([0, .25, .5, .75, 1])


def save(fig, stem, source, caption, alt, inputs, transformations):
    OUT.mkdir(parents=True, exist_ok=True)
    source_dir = OUT / "source_data"
    source_dir.mkdir(exist_ok=True)
    source_path = source_dir / f"{stem}.csv"
    source.to_csv(source_path, index=False)
    caption_path = OUT / f"{stem}_caption.md"
    caption_path.write_text(caption.strip() + "\n\nAlt text: " + alt + "\n", encoding="utf-8")
    outputs = []
    for extension in ["png", "pdf", "svg"]:
        path = OUT / f"{stem}.{extension}"
        fig.savefig(path, dpi=300, facecolor="white", transparent=False,
                    bbox_inches=None)
        outputs.append(path)
    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "script_sha256": sha(Path(__file__)),
        "intended_width_mm": 170,
        "intended_height_mm": fig.get_size_inches()[1] * 25.4,
        "destination": "Provisional general manuscript figure; journal-specific requirements pending verification",
        "estimator": "Record-level scores pooled over all 21 held-out records; fold scores separately labelled; negative log likelihood in nats",
        "unit": "Source recording; independent physical-bearing identifiers unavailable",
        "uncertainty": "No confidence intervals. Feature ET seed points are repeated algorithm seeds, not independent biological or physical replicates",
        "missing_values": "No planned arm or condition omitted; plotting aborts if any expected result is absent",
        "transformations": transformations,
        "alt_text": alt,
        "inputs": {str(p.relative_to(ROOT)): sha(p) for p in inputs},
        "source_data": {"path": str(source_path.relative_to(ROOT)), "sha256": sha(source_path), "rows": len(source)},
        "caption": {"path": str(caption_path.relative_to(ROOT)), "sha256": sha(caption_path)},
        "outputs": {str(p.relative_to(ROOT)): {"sha256": sha(p), "bytes": p.stat().st_size} for p in outputs},
        "matplotlib_version": matplotlib.__version__, "pandas_version": pd.__version__, "numpy_version": np.__version__,
        "fonts": "Arial; PDF Type 42, SVG editable text (external font availability required)",
    }
    with Image.open(OUT / f"{stem}.png") as im:
        manifest["raster_metadata"] = {"pixels": list(im.size), "mode": im.mode, "dpi": list(im.info.get("dpi", ())) }
        assert abs(im.width - WIDTH * 300) < 1
        assert im.info.get("dpi", (0,))[0] > 299
    (OUT / f"{stem}_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    plt.close(fig)
    return manifest


def feature_figure(summary):
    data = summary[summary.kind.eq("feature")].copy()
    assert len(data) == 20 and set(data.method) == set(REPS)
    metrics = [("macro_f1", "Macro-F1"), ("nll", "Negative log likelihood"),
               ("recall_H", "Healthy recall")]
    fig, axes = plt.subplots(1, 3, figsize=(WIDTH, 91 / 25.4))
    fig.subplots_adjust(left=.275, right=.98, bottom=.23, top=.82, wspace=.29)
    y = np.arange(5)
    allsource = []
    for col, (metric, title) in enumerate(metrics):
        ax = axes[col]
        for index, rep in enumerate(REPS):
            et = data[data.method.eq(rep) & data.family.eq("ET")].sort_values("seed")
            svm = data[data.method.eq(rep) & data.family.eq("SVM")]
            assert et.seed.tolist() == [11, 22, 33] and len(svm) == 1
            offsets = [-.16, -.04, .08]
            for si, (_, row) in enumerate(et.iterrows()):
                ax.plot(row[metric], index + offsets[si], marker=["o", "s", "^"][si],
                        color=BLUE, markerfacecolor="white", markersize=4, markeredgewidth=.85, zorder=3)
                allsource.append({"panel": chr(97 + col), "metric": metric, "representation": rep,
                                  "family": "ET", "seed": int(row.seed), "value": row[metric],
                                  "display_y": index + offsets[si], "n_records": 21})
            row = svm.iloc[0]
            ax.plot(row[metric], index + .24, marker="D", color=ORANGE, markersize=3.8,
                    markeredgewidth=.7, markerfacecolor=ORANGE, zorder=3)
            allsource.append({"panel": chr(97 + col), "metric": metric, "representation": rep,
                              "family": "SVM", "seed": int(row.seed), "value": row[metric],
                              "display_y": index + .24, "n_records": 21})
        ax.set_ylim(4.65, -.6)
        ax.set_yticks(y, REP_LABELS if col == 0 else [""] * 5)
        ax.tick_params(axis="y", length=0)
        if metric != "nll":
            full_unit_axis(ax)
        else:
            ax.set_xlim(0, max(1.15, data.nll.max() * 1.08))
            ax.xaxis.set_major_locator(MultipleLocator(.5))
        panel(ax, chr(97 + col), title)
        clean_axis(ax)
    handles = [Line2D([], [], color=BLUE, marker=m, linestyle="none", markerfacecolor="white",
                      markersize=4, label=f"ET seed {s}") for m, s in zip(["o", "s", "^"], [11, 22, 33])]
    handles.append(Line2D([], [], color=ORANGE, marker="D", linestyle="none", markersize=4,
                          label="SVM (deterministic)"))
    fig.legend(handles=handles, ncol=4, frameon=False, loc="lower center", bbox_to_anchor=(.53, .065),
               columnspacing=1.0, handletextpad=.35, fontsize=6.9)
    fig.text(.5, .015, "21 held-out recordings · five condition rotations · seed points are not confidence intervals",
             ha="center", fontsize=6.8)
    return save(fig, "fig13_native_bandwidth_controls", pd.DataFrame(allsource),
                "Figure 13. Adequate-bandwidth controls. (a) Macro-F1, (b) negative log likelihood and (c) healthy-class recall are computed after pooling the same 21 held-out source recordings from five HUST condition rotations. Open circles, squares and triangles show three Extra Trees (ET) seeds (11, 22 and 33); filled diamonds show the deterministic record-calibrated support-vector machine (SVM). Seed offsets only prevent overplotting and do not define confidence intervals. Numbers in parentheses denote feature dimensions. Native-band features retain the 25.6 kHz sampled signal; native-shape features use per-window centring/scaling with theoretical constants canonicalized; the native-plus-envelopes control concatenates 25 native features and 99 envelope features. These controls deliberately expose different physical signal bandwidths, and therefore do not have identical information budgets; the comparison diagnoses preprocessing adequacy rather than isolating a new algorithm. All planned representations and both classifier families are retained, including the fusion control. Healthy recall is based on five held-out healthy recordings; physical-bearing independence is not established. Lower negative log likelihood is preferable; higher F1 and recall are preferable.",
                "Three aligned dot plots compare five feature representations on record-level F1, negative log likelihood and healthy recall. All ET seeds and deterministic SVM outcomes are shown separately, including native-plus-envelope fusion.",
                [ANALYSIS / "pooled_summary.csv", ANALYSIS / "audit.json"],
                ["Select all 20 predeclared feature pooled rows", "Plot all ET seed values separately with fixed vertical offsets", "No averaging, interval estimation, smoothing, test-based selection or omitted arms"])


def neural_figure(summary, costs):
    data = summary[summary.kind.eq("neural")].copy()
    assert len(data) == 15 and set(data.method) == set(ARMS)
    model = costs[costs.kind.eq("neural")].copy()
    assert len(model) == 25
    fig = plt.figure(figsize=(WIDTH, 153 / 25.4))
    grid = fig.add_gridspec(2, 6, left=.27, right=.98, bottom=.18, top=.90,
                            hspace=.54, wspace=.6, height_ratios=[1, 1])
    axes = [fig.add_subplot(grid[0, i:i + 2]) for i in [0, 2, 4]]
    metrics = [("macro_f1", "Macro-F1"), ("nll", "Negative log likelihood"), ("recall_H", "Healthy recall")]
    source = []
    challenge_colors = [BLUE, ORANGE, BLACK]
    for col, (metric, title) in enumerate(metrics):
        ax = axes[col]
        for ai, arm in enumerate(ARMS):
            for pi, p in enumerate(PANELS):
                row = data[data.method.eq(arm) & data.panel.eq(p)]
                assert len(row) == 1
                value = row.iloc[0][metric]
                ax.plot(value, ai + [-.18, 0, .18][pi], color=challenge_colors[pi], marker=["o", "s", "^"][pi],
                        markersize=4, markerfacecolor="white" if pi == 0 else challenge_colors[pi],
                        markeredgewidth=.8, zorder=3)
                source.append({"panel": chr(97 + col), "metric": metric, "method": arm,
                               "challenge": p, "seed": 11, "fold": "pooled", "value": value, "n_records": 21})
        ax.set_ylim(4.55, -.55)
        ax.set_yticks(range(5), ARM_LABELS if col == 0 else [""] * 5)
        ax.tick_params(axis="y", length=0)
        if metric != "nll":
            full_unit_axis(ax)
        else:
            ax.set_xlim(0, max(1.2, data.nll.max() * 1.07))
            ax.xaxis.set_major_locator(MultipleLocator(1))
        panel(ax, chr(97 + col), title)
        clean_axis(ax)
    param_ax = fig.add_subplot(grid[1, :3])
    time_ax = fig.add_subplot(grid[1, 3:])
    for ai, arm in enumerate(ARMS):
        rows = model[model.method.eq(arm)].sort_values("fold")
        assert len(rows) == 5 and rows.parameters.nunique() == 1
        count = int(rows.parameters.iloc[0])
        param_ax.barh(ai, count / 1e6, height=.49, facecolor="#D6E5ED", edgecolor=BLUE, linewidth=.7)
        param_ax.text(count / 1e6 + .045, ai, f"{count / 1e6:.3f}", va="center", fontsize=6.5)
        for _, row in rows.iterrows():
            time_ax.plot(row.seconds / 60, ai + (int(row.fold) - 2) * .07, marker=MARKERS[int(row.fold)],
                         color=BLACK, linestyle="none", markerfacecolor="white", markersize=3.4,
                         markeredgewidth=.65)
            source.append({"panel": "e", "metric": "wall_time_minutes", "method": arm,
                           "challenge": "all", "seed": 11, "fold": int(row.fold), "value": row.seconds / 60})
        median = float(rows.seconds.median() / 60)
        time_ax.plot(median, ai, marker="|", color=ORANGE, markersize=10, markeredgewidth=1.5)
        source.append({"panel": "d", "metric": "parameters_million", "method": arm,
                       "challenge": "all", "seed": 11, "fold": "all", "value": count / 1e6})
        source.append({"panel": "e", "metric": "median_wall_time_minutes", "method": arm,
                       "challenge": "all", "seed": 11, "fold": "median", "value": median})
    for ax in [param_ax, time_ax]:
        ax.set_ylim(4.6, -.6)
        ax.set_yticks(range(5), ARM_LABELS if ax is param_ax else [""] * 5)
        ax.tick_params(axis="y", length=0)
        clean_axis(ax)
    param_ax.set_xlim(0, model.parameters.max() / 1e6 * 1.19)
    param_ax.set_xlabel("Trainable parameters (million)")
    time_ax.set_xlim(left=0, right=model.seconds.max() / 60 * 1.08)
    time_ax.set_xlabel("Observed wall time (min)")
    panel(param_ax, "d", "Model size")
    panel(time_ax, "e", "Run cost: five folds")
    handles = [Line2D([], [], color=c, marker=m, linestyle="none", markersize=4,
                      markerfacecolor="white" if i == 0 else c, label=label)
               for i, (c, m, label) in enumerate(zip(challenge_colors, ["o", "s", "^"], PANEL_LABELS))]
    fig.legend(handles=handles, frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(.61, .978),
               handletextpad=.4, columnspacing=1.5, fontsize=7.2)
    fig.text(.5, .09, "BD: adapted ClassBD front end · CE: cross entropy · CORAL: source-only covariance alignment",
             fontsize=6.7, ha="center")
    fig.text(.5, .055, "One seed; 120 training updates per model. Synthetic noise is applied only after checkpoint selection.",
             fontsize=6.7, ha="center")
    fig.text(.5, .022, "Wall time includes validation and concurrent CPU execution; it is not a controlled speed benchmark.",
             fontsize=6.7, ha="center")
    return save(fig, "fig14_neural_method_ablation", pd.DataFrame(source),
                "Figure 14. Complete short-budget neural ablation. (a–c) Pooled record-level macro-F1, negative log likelihood and healthy recall are reported for all five predeclared arms under clean input and two synthetic additive-white-Gaussian-noise challenges. Each noise panel pools the same 21 held-out source records across five condition rotations. All models use seed 11, 120 training updates, identical training batches/backbone initialization, and validation-selected checkpoints. BD denotes the explicitly adapted ClassBD front end; CE denotes cross entropy; physics denotes the declared negative-log normalized fourth-moment objective and frequency objective with persistent uncertainty weights. CORAL aligns only the three training-source conditions. This is an adapted-method feasibility ablation, not a reproduction of published training budgets or evidence of state-of-the-art performance. (d) Trainable parameter counts include any active uncertainty-weight parameters. (e) Five open symbols show observed complete-fold wall times; orange ticks show their median. Wall times include checkpoint validation and concurrent CPU execution, so they are descriptive run costs rather than a controlled throughput comparison. All arms and noise failures are retained. Healthy recall has five record-level healthy units; physical-bearing identifiers are unavailable.",
                "Five panels retain all five neural arms under clean, zero-dB and minus-four-dB synthetic noise, showing record-level F1, negative log likelihood, healthy recall, trainable parameters and all five observed fold runtimes. No confidence intervals or state-of-the-art claims are shown.",
                [ANALYSIS / "pooled_summary.csv", ANALYSIS / "model_cost_and_selection.csv", ANALYSIS / "audit.json"],
                ["Retain all 15 neural pooled rows", "Display parameters in millions and seconds divided by 60", "Plot five individual fold wall times and a descriptive median", "No smoothing, confidence intervals, test-based arm selection or speedup estimation"])


def condition_and_history_figure(folds):
    data = folds[folds.panel.eq("clean")].copy()
    rows, labels, matrix, source = [], [], [], []
    for rep, label in [("native_fullband_25", "Native band + ET (3-seed mean)"),
                       ("native_shape_25", "Native shape + ET (3-seed mean)")]:
        values = []
        for f in range(5):
            sub = data[data.method.eq(rep) & data.family.eq("ET") & data.fold.eq(f)]
            assert len(sub) == 3
            values.append(sub.macro_f1.mean())
            for _, row in sub.iterrows():
                source.append({"panel": "a", "kind": "individual_fold_metric", "method": rep,
                               "fold": f, "seed": int(row.seed), "update": np.nan,
                               "metric": "test_macro_f1", "value": row.macro_f1,
                               "selected_checkpoint": False, "aggregation": "three seeds shown in source; matrix arithmetic mean"})
        matrix.append(values); rows.append(rep); labels.append(label)
    for arm, label in zip(ARMS, ARM_LABELS):
        values = []
        for f in range(5):
            sub = data[data.method.eq(arm) & data.fold.eq(f)]
            assert len(sub) == 1
            value = float(sub.macro_f1.iloc[0]); values.append(value)
            source.append({"panel": "a", "kind": "individual_fold_metric", "method": arm,
                           "fold": f, "seed": 11, "update": np.nan, "metric": "test_macro_f1", "value": value,
                           "selected_checkpoint": False, "aggregation": "single seed"})
        matrix.append(values); rows.append(arm); labels.append(label)
    matrix = np.asarray(matrix)
    fig = plt.figure(figsize=(WIDTH, 161 / 25.4))
    top = fig.add_axes([.335, .52, .54, .35])
    image = top.imshow(matrix, vmin=0, vmax=1, cmap="cividis", aspect="auto", interpolation="nearest")
    top.set_xticks(range(5), CONDITIONS, fontsize=6.8)
    top.set_yticks(range(7), labels, fontsize=6.9)
    top.tick_params(length=0, pad=5)
    top.set_xticks(np.arange(-.5, 5, 1), minor=True)
    top.set_yticks(np.arange(-.5, 7, 1), minor=True)
    top.grid(which="minor", color="white", linewidth=1.0)
    top.tick_params(which="minor", bottom=False, left=False)
    for (r, c), value in np.ndenumerate(matrix):
        top.text(c, r, f"{value:.2f}", ha="center", va="center", fontsize=7,
                 color="white" if value < .48 else "#111111")
        source.append({"panel": "a", "kind": "displayed_heatmap_metric", "method": rows[r],
                       "fold": c, "seed": "11,22,33" if r < 2 else "11", "update": np.nan,
                       "metric": "test_macro_f1", "value": value, "selected_checkpoint": False,
                       "aggregation": "arithmetic mean over 3 ET seeds" if r < 2 else "single neural seed"})
    panel(top, "a", "Clean test F1 by held-out condition")
    cbax = fig.add_axes([.895, .52, .018, .35])
    cb = fig.colorbar(image, cax=cbax, ticks=[0, .5, 1])
    cb.set_label("Macro-F1", fontsize=7, labelpad=3)
    cb.ax.tick_params(labelsize=6.5, length=2)
    inputs = [ANALYSIS / "fold_summary.csv", ANALYSIS / "audit.json"]
    for foldindex in range(5):
        ax = fig.add_axes([.087 + foldindex * .18, .175, .15, .22])
        for ai, arm in enumerate(ARMS):
            path = NEURAL / f"fold{foldindex}_{arm}_s11.json"
            result = json.loads(path.read_text(encoding="utf-8")); inputs.append(path)
            history = result["training_history"]
            assert [r["update"] for r in history] == list(range(10, 121, 10))
            updates = np.array([r["update"] for r in history])
            values = np.array([r["validation"]["macro_f1"] for r in history])
            selected = updates == result["selected_update"]
            assert selected.sum() == 1
            ax.plot(updates, values, color=ARM_COLORS[ai], linestyle=ARM_STYLES[ai], linewidth=.85,
                    marker=MARKERS[ai], markersize=2.1, markerfacecolor="white", markeredgewidth=.5,
                    label=ARM_SHORT[ai], alpha=.92)
            ax.plot(updates[selected], values[selected], marker=MARKERS[ai], color=ARM_COLORS[ai],
                    markersize=5, markerfacecolor=ARM_COLORS[ai], markeredgewidth=.7,
                    markeredgecolor="white", zorder=5)
            for i, (update, value) in enumerate(zip(updates, values)):
                source.append({"panel": chr(98 + foldindex), "kind": "validation_checkpoint", "method": arm,
                               "fold": foldindex, "seed": 11, "update": int(update), "metric": "validation_macro_f1",
                               "value": float(value), "validation_nll": history[i]["validation"]["nll"],
                               "selected_checkpoint": bool(selected[i]), "aggregation": "record-mean probabilities"})
        full_unit_axis(ax, "y")
        ax.set_xlim(5, 125); ax.set_xticks([10, 60, 120])
        ax.set_title(f"{chr(98 + foldindex)}   {CONDITIONS[foldindex]}", fontsize=7, loc="left", pad=5)
        ax.set_xlabel("Training update", fontsize=6.4)
        ax.set_yticks([0, .5, 1])
        if foldindex == 0:
            ax.set_ylabel("Validation macro-F1", fontsize=7)
        else:
            ax.tick_params(labelleft=False)
        clean_axis(ax, "y")
    handles = [Line2D([], [], color=c, linestyle=s, marker=m, markerfacecolor="white", markersize=3,
                      label=label) for c, s, m, label in zip(ARM_COLORS, ARM_STYLES, MARKERS, ARM_LABELS)]
    fig.legend(handles=handles, frameon=False, ncol=3, loc="lower center", bbox_to_anchor=(.51, .055),
               columnspacing=1.2, handlelength=2.3, fontsize=6.4, handletextpad=.4)
    fig.text(.5, .015, "All 300 validation evaluations are shown; filled symbols mark the predeclared selected checkpoints.",
             ha="center", fontsize=6.6)
    return save(fig, "fig15_condition_and_validation", pd.DataFrame(source),
                "Figure 15. Condition dependence and complete checkpoint-selection history. (a) Clean test macro-F1 for every held-out HUST condition. The native-band and native-shape ET rows show the arithmetic mean of the three separately scored seeds; the five neural rows each show seed 11. All displayed individual seed values are preserved in the source CSV. Each condition has three or five held-out source recordings, so matrix entries are descriptive and do not constitute independent-bearing estimates. (b–f) Every scheduled validation evaluation is shown: five arms × five condition rotations × twelve checkpoints = 300 evaluations. The horizontal axis is training update; lines connect successive observed evaluations without smoothing. Filled symbols identify checkpoints selected by maximum validation macro-F1, then minimum validation negative log likelihood, then earliest update. Larger filled symbols can coincide across arms; all underlying values remain in the source CSV. Validation conditions differ from the condition named above each subplot: that name denotes the corresponding outer test rotation. No checkpoint or arm was chosen using the test matrix. A–E map to the neural arms listed in the legend; all negative results remain visible.",
                "A complete clean-test F1 heatmap compares two conventional controls and all five neural arms over five held-out conditions. Five small multiples retain all 300 validation evaluations, with filled symbols indicating the selected checkpoint for each of 25 fits.",
                inputs,
                ["Heatmap includes clean fold-level F1 for both declared native ET controls and all neural arms", "ET heatmap values are arithmetic means over 3 seeds; individual seed values remain in source CSV", "Plot every validation checkpoint without smoothing", "Shared heatmap and F1 limits are zero to one; larger filled markers show validation-selected checkpoints only"])


def main():
    required = [ANALYSIS / p for p in ["pooled_summary.csv", "fold_summary.csv", "model_cost_and_selection.csv", "audit.json"]]
    assert all(p.is_file() for p in required), "Run the complete v5 numerical audit first; partial figures are prohibited"
    audit = json.loads((ANALYSIS / "audit.json").read_text(encoding="utf-8"))
    assert audit["feature"]["selected_models"] == 100 and audit["neural"]["selected_models"] == 25
    summary = pd.read_csv(required[0]); folds = pd.read_csv(required[1]); costs = pd.read_csv(required[2])
    assert len(summary) == 35 and len(folds) == 175 and len(costs) == 125
    style = {"font.family": "Arial", "font.size": 7.5, "axes.labelsize": 7.2, "axes.titlesize": 8,
             "xtick.labelsize": 6.5, "ytick.labelsize": 7, "axes.linewidth": .65,
             "pdf.fonttype": 42, "ps.fonttype": 42, "svg.fonttype": "none", "savefig.dpi": 300,
             "figure.facecolor": "white", "axes.facecolor": "white", "text.color": "#222222",
             "axes.labelcolor": "#222222", "xtick.color": "#333333", "ytick.color": "#333333"}
    with plt.rc_context(style):
        reports = [feature_figure(summary), neural_figure(summary, costs), condition_and_history_figure(folds)]
    all_outputs = list(OUT.glob("fig1[345]*")) + list((OUT / "source_data").glob("fig1[345]*"))
    index = {"created_utc": datetime.now(timezone.utc).isoformat(), "script_sha256": sha(Path(__file__)),
             "figures": len(reports), "all_planned_arms_retained": True,
             "files": {str(p.relative_to(ROOT)): sha(p) for p in sorted(all_outputs) if p.is_file()}}
    (OUT / "extension_figure_manifest.json").write_text(json.dumps(index, indent=2), encoding="utf-8")
    print(json.dumps({"figures": len(reports), "output_directory": str(OUT), "source_rows": [r["source_data"]["rows"] for r in reports]}, indent=2))


if __name__ == "__main__":
    main()
