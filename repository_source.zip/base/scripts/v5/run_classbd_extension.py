"""Bounded, explicitly adapted physical-front-end/source-only alignment pilot.

This is not a full ClassBD reproduction: short fixed CPU budget, new data/split,
positive-log time sparsity, native spaced patches, AdamW, clean training.
"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import copy
import json
import time
import numpy as np
import pandas as pd
import torch
from scripts.v5.classbd_models import ClassBDWDCNN,ClassBDObjective
from scripts.v5.source_coral import source_coral_loss
from scripts.v5.prepare_neural_patches import zscore_patch,noise_at_snr
from scripts.v4_external_common import sha,aggregate,metrics

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/v5/classbd_extension'
CONDITIONS=['20Hz','30Hz','40Hz','60Hz','VS_0_40_0Hz']
ARMS={'wdcnn_ce':('baseline',False),'classbd_ce':('bd_ce',False),
      'classbd_physics':('bd_physics',False),'wdcnn_coral':('baseline',True),
      'classbd_physics_coral':('bd_physics',True)}
STEPS=120
CHECK_EVERY=10


def balanced_batch_indices(frame,train_indices,source_domains,rng):
    """Two patches per class and source domain; recordings uniform within cell."""
    chosen=[]
    train_frame=frame.iloc[train_indices]
    for domain in source_domains:
        for label in (0,1,2):
            part=train_frame[(train_frame.domain_id==domain)&(train_frame.class_id==label)]
            if part.empty:raise ValueError('missing training class/domain cell')
            records=sorted(part.source_record.unique())
            for _ in range(2):
                record=rng.choice(records)
                chosen.append(int(rng.choice(part.index[part.source_record.eq(record)].to_numpy())))
    return np.asarray(chosen)[rng.permutation(len(chosen))]


def evaluate(model,x,frame,indices):
    model.eval();probs=[]
    with torch.no_grad():
        for start in range(0,len(indices),48):
            batch=torch.from_numpy(zscore_patch(x[indices[start:start+48]])[:,None,:])
            probs.append(torch.softmax(model(batch)['logits'],dim=1).numpy())
    p=np.concatenate(probs);sf=frame.iloc[indices]
    names,y,pr=aggregate(p,sf.class_id.to_numpy(int),sf.source_record.to_numpy())
    return metrics(y,pr),names,y,pr


def main(args):
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    OUT.mkdir(parents=True,exist_ok=True)
    xp=ROOT/'data/processed/v5/hust_neural_patches.npz';lp=ROOT/'data/processed/v5/hust_neural_patch_lineage.csv'
    frame=pd.read_csv(lp);archive=np.load(xp,allow_pickle=False);x=archive['x']
    assert x.shape==(672,2048) and np.array_equal(archive['patch_id'],frame.patch_id.to_numpy(str))
    frame['domain_id']=frame.condition.map(dict(zip(CONDITIONS,range(5))))
    paths=[xp,lp,Path(__file__),ROOT/'scripts/v5/classbd_models.py',ROOT/'scripts/v5/source_coral.py',
           ROOT/'scripts/v5/prepare_neural_patches.py',ROOT/'scripts/v4_external_common.py']
    registration={'frozen_utc':datetime.now(timezone.utc).isoformat(),
        'status':'retrospective bounded feasibility extension; v4 outcomes and partial technical-error v5 feature-control outcomes already known; no neural measured-data fitting before design',
        'question':'does an executed paper-guided learned front end or source-only covariance alignment improve condition-held-out discrimination beyond a matched WDCNN?',
        'paper':'ClassBD MSSP222(2025)111750 DOI10.1016/j.ymssp.2024.111750; author preprint2404.15341v1',
        'adaptations':['first-party released-forward-compatible implementation with autograd-correct physics losses',
            'positive -log normalized fourth-moment time sparsity, unlike published negative kurtosis; nonnegative loss for persistent uncertainty weighting',
            'clean native-rate spaced2048patches; per-patch zscore; no measured or inferred speed',
            '120optimizerupdates,AdamW lr0.001 weight_decay0.0001,cosine schedule; not original200epochs10runs SGD',
            'source-pair standardDeepCORAL on100dim WDCNN embedding including trainingdropout; lambda1; no targetforward or labels during fitting'],
        'arms':{k:{'variant':v[0],'source_coral':v[1]} for k,v in ARMS.items()},
        'seed':11,'steps':STEPS,'validation_every_updates':CHECK_EVERY,
        'batch':{'size':18,'source_conditions':3,'classes_per_condition':3,'patches_per_class_condition':2,
                 'sampling':'record uniform within class/domain, then patch uniform; with replacement; same precomputed batches for all arms'},
        'model_selection':'validation source-record macroF1,lowerNLL,earlierupdate; no model-family,testselection,ortrain+valrefit',
        'test_panels':['clean','AWGN0dB','AWGN-4dB'],'noise':'fixed per-patch zero-mean Gaussian with exact centered per-patch SNR; same perturbations for all models; synthetic stress, not newly measured noise',
        'outer_split':'samefiveheldconditionrotationsasv4;testconditioni,validationi+1,remainingthreefit',
        'primary':'cleanpooled21OOFsource-recordmacroF1,healthyrecall,NLL; fourpatches persecond are repeated measurements, unknownbearingIDs',
        'limitations':['singlealgorithmseed;shortbudgetmayundertrainoriginal4Mparamfront','no benefit inferred from literature, hybrid is an unvalidated adaptation before these experiments','patches cover32% of first8seconds; nativefeaturecontrolusesall8seconds; notmatchedinformationbudget','all21filesalreadyobserved;newdesignnotindependentconfirmation','no test-based temperature or probability recalibration'],
        'planned_selected_models':25,'planned_validation_checkpoints':300,
        'sha256':{str(p.relative_to(ROOT)):sha(p) for p in paths},
        'software':{'torch':torch.__version__,'numpy':np.__version__,'pandas':pd.__version__,'threads':2}}
    dp=OUT/'design.json'
    if dp.exists():
        old=json.loads(dp.read_text(encoding='utf-8'));registration['frozen_utc']=old['frozen_utc'];assert old==registration,'frozen neural design changed'
    else:dp.write_text(json.dumps(registration,indent=2),encoding='utf-8')
    print('Neural design frozen',flush=True)
    if args.freeze_only:return
    folds=args.fold if args.fold else list(range(5))
    noisy={}
    for snr in [0,-4]:
        # All signals/IDs are read only; perturbation seed does not depend on labels.
        rng=np.random.default_rng(5102026+abs(snr))
        noisy[snr]=noise_at_snr(x,rng.normal(size=x.shape),snr)
    for fold in folds:
        test=frame.domain_id.eq(fold).to_numpy();val=frame.domain_id.eq((fold+1)%5).to_numpy();train=~(test|val)
        train_indices=np.flatnonzero(train);vi=np.flatnonzero(val);ti=np.flatnonzero(test)
        domains=sorted(frame.loc[train,'domain_id'].unique().tolist())
        for a,b in [(train,val),(train,test),(val,test)]:assert not set(frame.loc[a,'source_record'])&set(frame.loc[b,'source_record'])
        rng=np.random.default_rng(11+1000*fold)
        batches=[balanced_batch_indices(frame,train_indices,domains,rng) for _ in range(STEPS)]
        split_audit={'train_records':sorted(frame.loc[train,'source_record'].unique().tolist()),
            'validation_records':sorted(frame.loc[val,'source_record'].unique().tolist()),'test_records':sorted(frame.loc[test,'source_record'].unique().tolist()),
            'train_domains':domains,'updates':STEPS,'batch_indices':np.stack(batches).tolist()}
        (OUT/f'fold{fold}_split_and_batches.json').write_text(json.dumps(split_audit,indent=2),encoding='utf-8')
        for arm,(variant,use_coral) in ARMS.items():
            stem=f'fold{fold}_{arm}_s11';rp=OUT/(stem+'.json')
            if rp.exists():continue
            started=time.perf_counter();torch.manual_seed(11)
            model=ClassBDWDCNN(variant=variant);objective=ClassBDObjective(mode='positive_log')
            parameters=list(model.parameters())+(list(objective.parameters()) if variant=='bd_physics' else [])
            optimizer=torch.optim.AdamW(parameters,lr=.001,weight_decay=.0001)
            scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=STEPS)
            best=(-1.,-np.inf);selected_state=None;history=[]
            for step,idx in enumerate(batches,1):
                model.train();optimizer.zero_grad(set_to_none=True)
                batch=torch.from_numpy(zscore_patch(x[idx])[:,None,:]);target=torch.from_numpy(frame.iloc[idx].class_id.to_numpy(np.int64))
                output=model(batch);losses=objective(output,target)
                coral=source_coral_loss(output['embedding'],torch.from_numpy(frame.iloc[idx].domain_id.to_numpy(np.int64)),source_domains=domains) if use_coral else losses['loss'].new_zeros(())
                total=losses['loss']+coral
                if not torch.isfinite(total):raise RuntimeError(f'nonfinite objective {stem} step{step}')
                total.backward()
                gradnorm=torch.nn.utils.clip_grad_norm_(parameters,max_norm=10.)
                if not torch.isfinite(gradnorm):raise RuntimeError('nonfinite gradient')
                optimizer.step();scheduler.step()
                if step%CHECK_EVERY==0:
                    vm,_,_,_=evaluate(model,x,frame,vi)
                    row={'update':step,'train_total':float(total.detach()),'train_ce':float(losses['ce'].detach()),
                        'train_time':float(losses['time'].detach()),'train_frequency':float(losses['frequency'].detach()),
                        'train_coral':float(coral.detach()),'gradient_norm_before_clip':float(gradnorm),
                        'log_variances':objective.log_variances.detach().tolist(),'validation':vm}
                    history.append(row);key=(vm['macro_f1'],-vm['nll'])
                    if key>best:
                        best=key;selected_state=copy.deepcopy(model.state_dict());selected_objective=copy.deepcopy(objective.state_dict());chosen_update=step;selected_vm=vm
                    print(f'{stem} update{step}/{STEPS} valF1={vm["macro_f1"]:.3f}',flush=True)
            model.load_state_dict(selected_state);objective.load_state_dict(selected_objective)
            metrics_test={};prediction_rows=[]
            for panel,signals in [('clean',x),('AWGN0dB',noisy[0]),('AWGN-4dB',noisy[-4])]:
                met,names,labels,p=evaluate(model,signals,frame,ti);metrics_test[panel]=met
                for name,label,proba in zip(names,labels,p):
                    prediction_rows.append({'source_record':name,'panel':panel,'label':int(label),
                        'p_H':float(proba[0]),'p_I':float(proba[1]),'p_O':float(proba[2])})
            pp=OUT/(stem+'_predictions.csv');pd.DataFrame(prediction_rows).to_csv(pp,index=False)
            mp=OUT/(stem+'.pt');torch.save({'model_state':selected_state,'objective_state':selected_objective,
                'variant':variant,'arm':arm,'selected_update':chosen_update,'design_sha256':sha(dp)},mp)
            result={'fold':fold,'arm':arm,'seed':11,'variant':variant,'coral':use_coral,
                'selected_update':chosen_update,'validation':selected_vm,'test':metrics_test,
                'training_history':history,'parameter_count':sum(p.numel() for p in model.parameters()),
                'training_records':len(split_audit['train_records']),'validation_records':len(split_audit['validation_records']),
                'test_records':len(split_audit['test_records']),'seconds':time.perf_counter()-started,
                'design_sha256':sha(dp),'model_sha256':sha(mp),'predictions_sha256':sha(pp)}
            rp.write_text(json.dumps(result,indent=2),encoding='utf-8')
            print(f'DONE {stem} cleanF1={metrics_test["clean"]["macro_f1"]:.3f} selected_update={chosen_update}',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fold',type=int,choices=range(5),action='append')
    parser.add_argument('--freeze-only',action='store_true')
    main(parser.parse_args())
