"""Label-blind native-rate patches for an adapted ClassBD comparison.

Four nonoverlapping 2048-point crops per existing one-second window. The
statistical unit remains the complete measured source recording.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'data/processed/v5'
FS=25600
LENGTH=2048
OFFSETS=np.linspace(0,FS-LENGTH,4,dtype=int)


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def noise_at_snr(x,z,snr_db):
    """Centered per-patch signal/noise powers; output noise has exact set SNR."""
    x=np.asarray(x,float);z=np.asarray(z,float)
    signal=x-x.mean(axis=-1,keepdims=True)
    z=z-z.mean(axis=-1,keepdims=True)
    signal_power=np.mean(signal**2,axis=-1,keepdims=True)
    noise_power=np.mean(z**2,axis=-1,keepdims=True)
    scale=np.sqrt(signal_power/np.maximum(noise_power,1e-30))*10**(-float(snr_db)/20)
    return (x+z*scale).astype(np.float32)


def zscore_patch(x):
    x=np.asarray(x,np.float32)
    centered=x-x.mean(axis=-1,keepdims=True)
    scale=np.sqrt(np.mean(centered**2,axis=-1,keepdims=True))
    return centered/np.maximum(scale,1e-8)


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    old=json.loads((ROOT/'data/raw/v3_external/hust_subset_download_manifest.json').read_text(encoding='utf-8'))['downloads']
    new=json.loads((ROOT/'data/raw/v4_external/download_manifest.json').read_text(encoding='utf-8'))['downloads']
    source_map={r['name']:r for r in old+new}
    lineage_path=ROOT/'results/v4_external/window_lineage.csv'
    lineage=pd.read_csv(lineage_path)
    assert len(lineage)==168 and lineage.source_record.nunique()==21
    patches=[];rows=[];audits=[]
    for name,window_frame in lineage.groupby('source_record',sort=False):
        record=source_map[name];path=Path(record['local_path'])
        assert sha(path)==record['sha256']
        with path.open(encoding='utf-8') as stream:
            for line in stream:
                if line.strip()=='Data':break
            array=np.loadtxt(stream,delimiter='\t',dtype=np.float64)
        assert array.shape==(262144,5) and np.isfinite(array).all()
        raw=array[:8*FS,2].astype(np.float32)
        for wi,row in window_frame.iterrows():
            start,stop=int(row.start_sample),int(row.stop_sample_exclusive)
            assert stop-start==FS
            for pi,offset in enumerate(OFFSETS):
                a=start+int(offset);b=a+LENGTH
                assert start<=a<b<=stop
                patches.append(raw[a:b].copy())
                rows.append({'patch_id':f'hust_native_w{wi:03d}_p{pi}',
                    'source_record':name,'window_row':int(wi),'window_index':int(row.window_index),
                    'patch_index':pi,'start_sample':a,'stop_sample_exclusive':b,
                    'condition':row.condition,'class_id':int(row.class_id),'class_name':row.class_name,
                    'severity':row.severity})
        audits.append({'source_record':name,'source_sha256':record['sha256'],'raw_column':2,
                       'source_shape':list(array.shape),'float32_quantization':'same as v4 external'})
    # Preserve row order exactly as the frozen parent lineage, regardless of
    # grouping order. Identifiers/labels are in lineage, never in signal values.
    frame=pd.DataFrame(rows)
    order=np.lexsort((frame.patch_index,frame.window_row))
    frame=frame.iloc[order].reset_index(drop=True)
    x=np.stack(patches)[order]
    assert x.shape==(672,LENGTH) and np.isfinite(x).all()
    pp=OUT/'hust_neural_patches.npz';lp=OUT/'hust_neural_patch_lineage.csv'
    np.savez_compressed(pp,x=x,patch_id=frame.patch_id.to_numpy(str),fs=np.array(FS),offsets=OFFSETS)
    frame.to_csv(lp,index=False)
    audit={'created_utc':datetime.now(timezone.utc).isoformat(),'patches':672,'source_records':21,
        'one_second_windows':168,'patches_per_window':4,'patches_per_record':32,
        'native_fs':FS,'points_per_patch':LENGTH,'duration_s':LENGTH/FS,
        'offsets_within_one_second':OFFSETS.tolist(),'overlap':False,
        'filtering':'none','resampling':'none','auxiliary_speed_used':False,
        'normalization':'none saved; per-patch zscore in model runner; no test-batch statistics',
        'independence':'672 patches remain repeated measurements from21 sourcefiles, unknown physical-bearing IDs',
        'sha256':{str(p.relative_to(ROOT)):sha(p) for p in [pp,lp,lineage_path,Path(__file__)]},'sources':audits}
    (OUT/'hust_neural_patch_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in audit.items() if k!='sources'}),flush=True)


if __name__=='__main__':main()
