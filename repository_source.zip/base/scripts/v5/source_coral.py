"""First-party source-only CORAL loss, with no loader, labels or training loop.

Pair loss follows Sun & Saenko, arXiv:1607.01719v1, equations 1--3:
    ||Cov(A) - Cov(B)||_F^2 / (4 * d**2), using unbiased sample covariance.
The multi-source extension averages every unordered pair of declared training
domains. It is a mature DG control, not a new algorithm from the 2024 RESS
benchmark. Unlike that benchmark's utils.py implementation, centering is across
examples (dim=0) and covariance includes the n-1 divisor. See the audit document.
"""
from itertools import combinations
from numbers import Integral

import torch


def _covariance(features):
    if not isinstance(features, torch.Tensor) or features.ndim != 2:
        raise ValueError("Features must be a two-dimensional torch tensor")
    if not features.is_floating_point() or features.shape[1] < 1:
        raise ValueError("Features must have a positive width and real floating dtype")
    if features.shape[0] < 2:
        raise ValueError("Each domain needs at least two examples for sample covariance")
    centered = features - features.mean(dim=0, keepdim=True)
    return centered.transpose(0, 1).matmul(centered) / (features.shape[0] - 1)


def coral_pair_loss(features_a, features_b):
    """Original covariance-only CORAL scalar, retaining gradients in both inputs.

    Inputs are [examples, embedding dimensions] from two training domains.
    Their sample counts may differ. No mean-alignment term is included.
    """
    covariance_a = _covariance(features_a)
    covariance_b = _covariance(features_b)
    if (features_a.shape[1] != features_b.shape[1]
            or features_a.dtype != features_b.dtype
            or features_a.device != features_b.device):
        raise ValueError("Both domains must share embedding width, dtype and device")
    return (covariance_a - covariance_b).square().sum() / (4 * features_a.shape[1] ** 2)


def source_coral_loss(embeddings, domain_ids, *, source_domains):
    """Average CORAL over every pair of explicitly authorized training domains.

    ``embeddings`` is [N,d]; integer ``domain_ids`` is [N]. ``source_domains``
    must list every training domain exactly once. Missing or extra domains fail
    closed, so an accidentally included validation/test condition is rejected.
    The caller must construct this list from its frozen training split; this
    helper cannot detect data whose condition identifiers were mislabelled.

    For three training conditions this is (L01 + L02 + L12) / 3. The caller
    adds lambda * this scalar to its classification/physics objective. There
    are no labels, fitting state, BatchNorm updates, or target-domain inputs.
    """
    if not isinstance(embeddings, torch.Tensor) or embeddings.ndim != 2:
        raise ValueError("Embeddings must be a two-dimensional torch tensor")
    if (not isinstance(domain_ids, torch.Tensor) or domain_ids.ndim != 1
            or len(domain_ids) != len(embeddings)
            or domain_ids.dtype not in (torch.int8, torch.int16, torch.int32, torch.int64, torch.uint8)
            or domain_ids.device != embeddings.device):
        raise ValueError("Domain identifiers must be matching integer tensor rows on the same device")
    declared = tuple(source_domains)
    if (len(declared) < 2 or any(not isinstance(item, Integral) for item in declared)
            or len(set(declared)) != len(declared)):
        raise ValueError("Declare at least two distinct integer source domains")
    if set(domain_ids.unique().tolist()) != set(declared):
        raise ValueError("Observed domains must equal the declared source domains")
    covariances = [_covariance(embeddings[domain_ids == item]) for item in declared]
    dimension = embeddings.shape[1]
    pair_losses = [(a - b).square().sum() / (4 * dimension ** 2)
                   for a, b in combinations(covariances, 2)]
    return torch.stack(pair_losses).mean()
