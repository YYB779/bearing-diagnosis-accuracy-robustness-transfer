"""Extract label-blind native HUST features; no model fitting or target tuning.

Keep the exact v4 168-row lineage, X column and float32 round-trip precision.
Every one-second window is cropped before any statistic; no filtering,
interpolation, demodulation, speed channel or cross-window context is used.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
FS = 25600
BINS = [(0., 500.), (500., 2000.), (2000., 5000.), (5000., 12800.)]
BASE_PATH = ROOT / "scripts/v3/prepare_novic_physical_features.py"
spec = importlib.util.spec_from_file_location("hust_v5_novic_feature_block", BASE_PATH)
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024*1024), b""):
            h.update(block)
    return h.hexdigest()


def read_time_and_x(path):
    """Read the documented Time and X columns only; Speed is never parsed."""
    with Path(path).open(encoding="utf-8") as stream:
        for line in stream:
            if line.strip() == "Data":
                break
        else:
            raise ValueError("HUST source has no Data boundary")
        array = np.loadtxt(stream, delimiter="\t", dtype=np.float64, usecols=(0, 2), ndmin=2)
    if array.shape[1] != 2 or not np.isfinite(array).all():
        raise ValueError("Time/X source columns must be finite")
    return array[:, 0], array[:, 1]


def native_window(x, start, stop):
    """Exact v4 [start,stop) sample boundaries, one second, first eight seconds."""
    x = np.asarray(x)
    if not np.isfinite([start, stop]).all() or int(start) != start or int(stop) != stop:
        raise ValueError("Window boundaries must be finite integer sample indices")
    start, stop = int(start), int(stop)
    if x.ndim != 1 or start < 0 or stop - start != FS or stop > min(len(x), 8*FS):
        raise ValueError("Window must be exactly one native second inside the first eight seconds")
    cropped = x[start:stop]
    if not np.isfinite(cropped).all():
        raise ValueError("Vibration window is not finite")
    return cropped


def extract_window_features(x):
    x = np.asarray(x, dtype=np.float64)
    if x.shape != (FS,):
        raise ValueError("Native HUST input must have 25600 samples")
    values, _ = base.feature_block(x, float(FS), "Hz", "source_X_unit", BINS)
    result = {"native_fullband__" + key: value for key, value in values.items()}
    if len(result) != 25 or not np.isfinite(list(result.values())).all():
        raise ValueError("Native HUST feature row must have 25 finite values")
    return result


def extract_shape_features(x):
    """Same 25 formulas after within-window centering/population scaling.

    This label-blind control discards absolute offset and positive gain. No
    statistic is estimated across windows or source recordings.
    """
    x = np.asarray(x, dtype=np.float64)
    if x.shape != (FS,) or not np.isfinite(x).all():
        raise ValueError("Shape input must have 25600 finite native samples")
    centered = x - np.mean(x)
    population_std = float(np.std(x, ddof=0))
    normalized = centered / population_std if population_std > base.EPS else np.zeros_like(x)
    values, _ = base.feature_block(normalized, float(FS), "Hz", "dimensionless", BINS)
    # Exact mathematical invariants: do not let downstream StandardScaler turn
    # 1e-17 round-off in the theoretical zero mean into a unit-scale predictor.
    # The earlier partial modelling attempt is preserved as an aborted run.
    values['mean'] = 0.
    values['std'] = values['rms'] = 1. if population_std > base.EPS else 0.
    result = {"native_shape__" + key: value for key, value in values.items()}
    if len(result) != 25 or not np.isfinite(list(result.values())).all():
        raise ValueError("Shape feature row must have 25 finite values")
    return result


def features_for_lineage(signals, lineage, *, shape=False):
    """Only recording lookup and sample boundaries are consumed from metadata."""
    required = {"source_record", "window_index", "start_sample", "stop_sample_exclusive"}
    if not required <= set(lineage):
        raise ValueError("Lineage lacks source/sample boundary fields")
    rows = []
    for position, row in enumerate(lineage.itertuples(index=False)):
        x = native_window(signals[row.source_record], row.start_sample, row.stop_sample_exclusive)
        extract = extract_shape_features if shape else extract_window_features
        rows.append({"sample_id": f"hust_v4_{position:03d}", **extract(x)})
    return pd.DataFrame(rows)


def main():
    output = ROOT / "data/processed/v5"
    output.mkdir(parents=True, exist_ok=True)
    lineage_path = ROOT / "results/v4_external/window_lineage.csv"
    old_path = ROOT / "data/raw/v3_external/hust_subset_download_manifest.json"
    new_path = ROOT / "data/raw/v4_external/download_manifest.json"
    structure_path = ROOT / "data/raw/v4_external/structure_audit.json"
    frozen_paths = [lineage_path, old_path, new_path, structure_path, BASE_PATH]
    before = {str(path.relative_to(ROOT)): sha(path) for path in frozen_paths}
    lineage = pd.read_csv(lineage_path)
    downloads = json.loads(old_path.read_text(encoding="utf-8"))["downloads"] + json.loads(new_path.read_text(encoding="utf-8"))["downloads"]
    by_name = {row["name"]: row for row in downloads}
    structure = {row["name"]: row for row in json.loads(structure_path.read_text(encoding="utf-8"))["records"]}
    if not len(downloads) == len(by_name) == 21:
        raise ValueError("Source manifest must contain 21 unique raw files")
    assert len(downloads) == len(by_name) == len(structure) == 21
    assert len(lineage) == 168
    assert set(lineage.source_record) == set(by_name)
    assert not lineage.duplicated(["source_record", "window_index"]).any()
    for _, rows in lineage.groupby("source_record", sort=False):
        assert rows.window_index.tolist() == list(range(8))
        assert rows.start_sample.tolist() == list(range(0, 8*FS, FS))
        assert rows.stop_sample_exclusive.tolist() == list(range(FS, 9*FS, FS))
    signals, sources, energy_fractions = {}, [], []
    for name in lineage.source_record.drop_duplicates():
        metadata = by_name[name]
        source_path = ROOT / metadata["local_path"]
        observed = sha(source_path)
        assert observed == metadata["sha256"] == structure[name]["sha256"]
        time, x = read_time_and_x(source_path)
        assert len(x) == len(time) == 262144
        assert np.all(np.diff(time) > 0)
        measured_fs = (len(time) - 1) / (time[-1] - time[0])
        assert abs(measured_fs - FS) < .01
        # Deliberately match the frozen v4 external numerical input precision.
        # This changes no time coordinate or sampling point; it is not filtering.
        signals[name] = x[:8*FS].astype(np.float32).astype(np.float64)
        sources.append(dict(source_record=name, source_path=str(source_path), sha256=observed,
                            bytes=source_path.stat().st_size, measured_shape=[len(x), 5],
                            endpoint_fs=float(measured_fs), first_eight_seconds_points=8*FS))
    table = features_for_lineage(signals, lineage)
    shape_table = features_for_lineage(signals, lineage, shape=True)
    assert table.shape == (168, 26)
    assert shape_table.shape == table.shape
    assert table.sample_id.tolist() == [f"hust_v4_{i:03d}" for i in range(168)]
    assert shape_table.sample_id.tolist() == table.sample_id.tolist()
    # Actual-data label/covariate perturbation is a code-path invariant, not a
    # classifier negative control. Features consume none of these columns.
    changed = lineage.copy()
    for field in ("class_id", "class_name", "severity", "condition", "new_v4_file"):
        changed[field] = "sentinel_unrelated_metadata"
    changed_features = features_for_lineage(signals, changed)
    assert np.array_equal(table.to_numpy(), changed_features.to_numpy())
    changed_shape_features = features_for_lineage(signals, changed, shape=True)
    assert np.array_equal(shape_table.to_numpy(), changed_shape_features.to_numpy())
    sample_rows = []
    for index, row in enumerate(lineage.itertuples(index=False)):
        x = native_window(signals[row.source_record], row.start_sample, row.stop_sample_exclusive)
        frequency, density = base.spectrum(x, FS)
        total = float(density.sum() * (frequency[1] - frequency[0]))
        below180 = base.integrated_energy(frequency, density, 0., 180.)
        fraction = below180 / max(total, base.EPS)
        energy_fractions.append(fraction)
        sample_rows.append(dict(sample_id=f"hust_v4_{index:03d}", v4_row=index,
                               source_record=row.source_record, window_index=int(row.window_index),
                               start_sample=int(row.start_sample), stop_sample_exclusive=int(row.stop_sample_exclusive),
                               native_points=FS, native_sample_rate_hz=FS,
                               input_window_sha256=hashlib.sha256(x.tobytes()).hexdigest(),
                               diagnostic_raw_spectral_energy=total,
                               diagnostic_raw_energy_fraction_below_180hz=float(fraction)))
    features_path = output / "hust_native_features.csv"
    shape_path = output / "hust_native_shape_features.csv"
    audit_path = output / "native_audit.json"
    table.to_csv(features_path, index=False)
    shape_table.to_csv(shape_path, index=False)
    _, definitions = base.feature_block(np.zeros(FS), FS, "Hz", "source_X_unit", BINS)
    definitions = {"native_fullband__" + key: value for key, value in definitions.items()}
    _, shape_definitions = base.feature_block(np.zeros(FS), FS, "Hz", "dimensionless", BINS)
    shape_definitions = {"native_shape__" + key: value for key, value in shape_definitions.items()}
    after = {str(path.relative_to(ROOT)): sha(path) for path in frozen_paths}
    assert before == after
    audit = dict(status="complete: label-blind features only, zero model fits", schema_version="hust-native-v5.2",
        sample_count=168, source_record_count=21, feature_count=25,
        sample_id_policy="hust_v4_{row_index:03d}; v4 lineage has no original sample_id; exact 168-row order and source/window boundaries are authoritative",
        feature_columns=table.columns.drop("sample_id").tolist(), feature_definitions=definitions,
        shape_branch=dict(path=str(shape_path.relative_to(ROOT)), feature_count=25,
            feature_columns=shape_table.columns.drop("sample_id").tolist(), feature_definitions=shape_definitions,
            transformation="Per window: (x-mean(x))/std(x,ddof=0); use all zeros if population std <= inherited feature-block EPS",
            zero_std_epsilon=float(base.EPS), normalization_is_per_window=True,
            across_window_statistics_fitted=False, labels_or_conditions_used=False,
            amplitude_information_discarded=True,
            interpretation="Conventional normalization control, not a new method; mean/std/RMS-like descriptors become constants on nonconstant windows.",
            output_sha256=sha(shape_path), output_bytes=shape_path.stat().st_size,
            actual_data_label_and_metadata_perturbation_bitwise_invariant=True),
        native_sample_rate_hz=FS, native_nyquist_hz=FS/2, points_per_interval=FS,
        interval_rule="Each original [start_sample,stop_sample_exclusive) v4 window, first eight one-second windows per raw file",
        source_columns_read=[0, 2], source_vibration_column=2,
        precision_policy="Parse raw X as float64 then float32-to-float64 round-trip, exactly matching frozen v4 external input quantization",
        filtering="none", resampling="none", interpolation="none", demodulation="none",
        cross_interval_context_used=False, physical_bins_hz=BINS,
        spectral_estimator="Hann window, constant detrend, one-sided density periodogram; integrate density times frequency-bin width",
        exact_nyquist_policy="12800-Hz bin remains in total spectral statistics but not the upper-exclusive [5000,12800) fixed band",
        units="Source X numerical unit; no unverified g/calibrated-sensor-unit claim",
        labels_in_classifier_feature_columns=False, condition_in_classifier_feature_columns=False,
        rpm_or_auxiliary_speed_read_or_used=False, identifiers_are_not_features=True,
        actual_data_label_and_metadata_perturbation_bitwise_invariant=True,
        source_checksums_verified=21, source_content_hashes_unique=len({row["sha256"] for row in sources}),
        no_raw_files_copied=True, source_location="input acquisition manifests",
        diagnostic_energy_fraction_below_180hz=dict(min=float(np.min(energy_fractions)), median=float(np.median(energy_fractions)), max=float(np.max(energy_fractions)),
            interpretation="Label-blind bandwidth-support description, not diagnostic information content or model accuracy; native spectral energy can be task-irrelevant."),
        inspected_v4_and_v3_inputs_unchanged=True, input_sha256=before,
        output_features_sha256=sha(features_path), output_features_bytes=features_path.stat().st_size,
        extraction_script_sha256=sha(Path(__file__)), models_fitted=0, test_predictions_computed=0,
        sources=sources, sample_lineage=sample_rows,
        limitations=["21 source recordings with unknown bearing identities; no new independent specimen is created.",
                     "Native 25-feature representation differs in bandwidth, point count and descriptor count from legacy low-pass 33-feature representation.",
                     "The same 21 records were already examined in v4; a new design on them is retrospective, even if frozen before new fits.",
                     "No calibrated RPM is available; no order tracking is inferred from the filename condition or ignored Speed column.",
                     "No model is trained or evaluated in this extraction script."])
    audit_path.write_text(json.dumps(audit, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    print(json.dumps({key: audit[key] for key in ["status", "sample_count", "source_record_count", "feature_count", "source_checksums_verified", "output_features_sha256", "diagnostic_energy_fraction_below_180hz", "models_fitted"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
