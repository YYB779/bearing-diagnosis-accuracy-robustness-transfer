"""Adequate-bandwidth and gain-shape controls before attributing new-method gains."""
from pathlib import Path
from datetime import datetime,timezone
import json
import time
import numpy as np
import pandas as pd
import joblib
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from scripts.v4_external_common import sha,aggregate,metrics,RecordSigmoid

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/v5/feature_controls'
CONDITIONS=['20Hz','30Hz','40Hz','60Hz','VS_0_40_0Hz']
REPS=['raw_lowpass_33','single_envelope_33','native_fullband_25','native_shape_25','native_envelope_fusion_124']


def load():
    lp=ROOT/'results/v4_external/window_lineage.csv';f=pd.read_csv(lp)
    paths=[lp,Path(__file__),ROOT/'scripts/v4_external_common.py']
    inputs={}
    for name,path in [('raw_lowpass_33',ROOT/'results/v4_external/raw_lowpass_33_features.csv'),
                      ('single_envelope_33',ROOT/'results/v4_external/single_carrier_2_5khz_33_features.csv'),
                      ('three_envelope',ROOT/'results/v4_external/three_carrier_99_features.csv')]:
        table=pd.read_csv(path,float_precision='round_trip')
        assert len(table)==len(f) and table.source_record.equals(f.source_record) and table.window_index.equals(f.window_index)
        inputs[name]=table[[c for c in table if c not in f.columns]].to_numpy(float);paths.append(path)
    for name,file in [('native_fullband_25','hust_native_features.csv'),('native_shape_25','hust_native_shape_features.csv')]:
        path=ROOT/'data/processed/v5'/file;table=pd.read_csv(path,float_precision='round_trip')
        assert table.sample_id.tolist()==[f'hust_v4_{i:03d}' for i in range(168)]
        inputs[name]=table.drop(columns='sample_id').to_numpy(float);paths.append(path)
    inputs['native_envelope_fusion_124']=np.c_[inputs['native_fullband_25'],inputs['three_envelope']]
    for k in REPS:assert np.isfinite(inputs[k]).all()
    return f,inputs,paths


def run():
    OUT.mkdir(parents=True,exist_ok=True)
    f,inputs,paths=load()
    config={'frozen_utc':datetime.now(timezone.utc).isoformat(),
        'status':'retrospective extension; v4 test results already observed; frozen before fitting these controls',
        'technical_correction':'earlier partial v5 run preserved in feature_controls_aborted_numeric_v1; shape theoretical mean/std/rms canonicalized before this complete rerun to prevent amplification of round-off; some earlier partial test outcomes already seen',
        'purpose':'test adequate native bandwidth and amplitude/shape separation; established controls, not newly invented methods',
        'conditions':CONDITIONS,'outer_split':'test condition i, validation next cyclic condition, remaining three train',
        'representations':{k:inputs[k].shape[1] for k in REPS},
        'models':{'ET':{'trees':200,'leaf':[1,3],'seeds':[11,22,33]},'SVM':{'C':[.1,1,10],'seed':'deterministic','probability':'three training-condition record-OOF OVR Platt sigmoid'}},
        'selection':'validation equal-record macro-F1, then lower record NLL, then smaller leaf/C; no refit train+validation',
        'ET_weighting':'equal windows; eight windows per source, hence equal source weights; exact v4 matching for historical reps',
        'capacity':'25 native features vs33 legacy vs124 fusion; nonequivalent point/context/dimension budgets explicitly disclosed',
        'primary':'pooled21OOF recording macro-F1, healthy recall and NLL; no inferred independent bearings',
        'planned_selected_models':100,'planned_candidates':225,
        'sha256':{str(p.relative_to(ROOT)):sha(p) for p in paths}}
    dp=OUT/'design.json'
    if dp.exists():
        old=json.loads(dp.read_text(encoding='utf-8'));config['frozen_utc']=old['frozen_utc']
        assert config==old,'frozen feature design changed'
    else:dp.write_text(json.dumps(config,indent=2),encoding='utf-8')
    print('Frozen feature control design',flush=True)
    y=f.class_id.to_numpy(int);groups=f.source_record.to_numpy();conditions=f.condition.to_numpy()
    for fold,held in enumerate(CONDITIONS):
        test=conditions==held;val=conditions==CONDITIONS[(fold+1)%5];train=~(test|val)
        for a,b in [(train,val),(train,test),(val,test)]:assert not set(groups[a])&set(groups[b])
        for rep in REPS:
            x=inputs[rep]
            for family,seeds,grid in [('ET',[11,22,33],[1,3]),('SVM',[11],[.1,1,10])]:
                for seed in seeds:
                    stem=f'fold{fold}_{rep}_{family}_s{seed}';rp=OUT/(stem+'.json')
                    if rp.exists():continue
                    start=time.perf_counter();candidates=[];best=(-1.,-np.inf);selected=None
                    for hyper in grid:
                        if family=='ET':
                            model=ExtraTreesClassifier(n_estimators=200,min_samples_leaf=hyper,max_features=1.,class_weight=None,random_state=seed,n_jobs=2)
                            cal=None
                        else:
                            model=make_pipeline(StandardScaler(),SVC(C=hyper,kernel='rbf',gamma='scale',probability=False,decision_function_shape='ovr'))
                            scores=[];labels=[];audits=[]
                            for ca in CONDITIONS:
                                if not np.any(train&(conditions==ca)):continue
                                ca_mask=train&(conditions==ca);fit_mask=train&~ca_mask
                                base=make_pipeline(StandardScaler(),SVC(C=hyper,kernel='rbf',gamma='scale',probability=False,decision_function_shape='ovr'))
                                assert set(y[fit_mask])==set(y[ca_mask])=={0,1,2}
                                base.fit(x[fit_mask],y[fit_mask])
                                names,yy,ss=aggregate(base.decision_function(x[ca_mask]),y[ca_mask],groups[ca_mask])
                                scores.extend(ss);labels.extend(yy)
                                audits.append({'fit_records':sorted(set(groups[fit_mask])),'calibration_records':names})
                            cal=RecordSigmoid().fit(np.asarray(scores),np.asarray(labels))
                        model.fit(x[train],y[train])
                        if cal is None:names,yy,vp=aggregate(model.predict_proba(x[val]),y[val],groups[val])
                        else:
                            names,yy,vs=aggregate(model.decision_function(x[val]),y[val],groups[val]);vp=cal.predict_proba(vs)
                        vm=metrics(yy,vp);key=(vm['macro_f1'],-vm['nll'])
                        candidates.append({'hyperparameter':hyper,'validation':vm,'calibration_audit':audits if cal is not None else []})
                        if key>best:best=key;selected=(model,cal,hyper,vm)
                    model,cal,hyper,vm=selected
                    if cal is None:names,yy,tp=aggregate(model.predict_proba(x[test]),y[test],groups[test])
                    else:
                        names,yy,ts=aggregate(model.decision_function(x[test]),y[test],groups[test]);tp=cal.predict_proba(ts)
                    result={'fold':fold,'test_condition':held,'representation':rep,'family':family,'seed':seed,
                        'chosen':hyper,'candidates':candidates,'validation':vm,'test':metrics(yy,tp),
                        'design_sha256':sha(dp),'seconds':time.perf_counter()-start}
                    rows=[]
                    for name,label,p in zip(names,yy,tp):rows.append({'source_record':name,'label':int(label),'p_H':float(p[0]),'p_I':float(p[1]),'p_O':float(p[2])})
                    pp=OUT/(stem+'_predictions.csv');pd.DataFrame(rows).to_csv(pp,index=False)
                    mp=OUT/(stem+'.joblib');joblib.dump({'model':model,'record_calibrator':cal},mp,compress=3)
                    result.update(predictions_sha256=sha(pp),model_sha256=sha(mp))
                    rp.write_text(json.dumps(result,indent=2),encoding='utf-8')
                    print(f"DONE {stem} F1={result['test']['macro_f1']:.3f} NLL={result['test']['nll']:.3f}",flush=True)
    results=[]
    for rep in REPS:
        for family,seeds in [('ET',[11,22,33]),('SVM',[11])]:
            for seed in seeds:
                rows=[]
                for fold in range(5):
                    pp=OUT/f'fold{fold}_{rep}_{family}_s{seed}_predictions.csv'
                    rows.append(pd.read_csv(pp,float_precision='round_trip'))
                pooled=pd.concat(rows,ignore_index=True);assert len(pooled)==pooled.source_record.nunique()==21
                results.append({'representation':rep,'family':family,'seed':seed,**{k:v for k,v in metrics(pooled.label.to_numpy(),pooled[['p_H','p_I','p_O']].to_numpy()).items() if k!='confusion_matrix'}})
    pd.DataFrame(results).to_csv(OUT/'pooled_summary.csv',index=False)
    print(pd.DataFrame(results).to_string(index=False),flush=True)


if __name__=='__main__':run()
