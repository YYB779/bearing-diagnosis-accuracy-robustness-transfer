"""First-party, paper-guided ClassBD adaptation, not an unmodified reproduction.

Primary: Liao et al., MSSP 222 (2025) 111750,
DOI 10.1016/j.ymssp.2024.111750; arXiv:2404.15341v1 section 3.
The released amplitude/dense/analytic-mask/IFFT-magnitude forward route is
retained. Physics losses retain autograd and use per-record reductions. The
stable positive_log time loss is -log(K), unlike the published negative K.
No measured data, loaders, splitting, calibration or training loop is here.
"""
import math
import torch
from torch import nn
from torch.nn import functional as F


def analytic_multiplier(length, reference):
    """Hilbert analytic-spectrum multiplier, with DC/Nyquist un-doubled."""
    h=reference.new_zeros(length)
    h[0]=1
    h[1:(length+1)//2]=2
    if length % 2 == 0:
        h[length//2]=1
    return h


def envelope_spectrum(time_signal):
    """Magnitude of the non-DC envelope spectrum, computed per record."""
    spec=torch.fft.fft(time_signal,dim=-1)
    analytic=torch.fft.ifft(spec*analytic_multiplier(time_signal.shape[-1],time_signal),dim=-1)
    envelope=analytic.abs()
    envelope=envelope-envelope.mean(dim=-1,keepdim=True)
    return torch.fft.fft(envelope,dim=-1).abs()


class QuadraticConvolution(nn.Module):
    """Equation-8 product plus squared-input term, released kernel/init."""
    def __init__(self,in_channels,out_channels,kernel_size=63):
        super().__init__()
        self.linear=nn.Conv1d(in_channels,out_channels,kernel_size,padding="same")
        self.gate=nn.Conv1d(in_channels,out_channels,kernel_size,padding="same")
        self.squared=nn.Conv1d(in_channels,out_channels,kernel_size,padding="same")
        nn.init.normal_(self.linear.weight,std=8*math.sqrt(0.25/(in_channels*kernel_size)))
        nn.init.uniform_(self.linear.bias,-1/math.sqrt(in_channels*kernel_size),1/math.sqrt(in_channels*kernel_size))
        nn.init.zeros_(self.gate.weight);nn.init.ones_(self.gate.bias)
        nn.init.zeros_(self.squared.weight);nn.init.zeros_(self.squared.bias)
    def forward(self,x):
        return self.linear(x)*self.gate(x)+self.squared(x.square())


class ClassBDFrontEnd(nn.Module):
    def __init__(self,input_length=2048,fs=25600):
        super().__init__()
        self.input_length=input_length
        self.fs=fs
        self.time_filter=nn.Sequential(
            QuadraticConvolution(1,16),nn.BatchNorm1d(16),nn.ReLU(),
            QuadraticConvolution(16,1),nn.BatchNorm1d(1),nn.ReLU(),nn.Sigmoid())
        self.frequency_filter=nn.Linear(input_length,input_length)
    def forward(self,x):
        if x.ndim!=3 or x.shape[1:]!=(1,self.input_length):
            raise ValueError("ClassBD requires [batch,1,input_length] input")
        y=self.time_filter(x)
        magnitude=torch.fft.fft(y-y.mean(dim=-1,keepdim=True),dim=-1).abs()
        dense=self.frequency_filter(magnitude)
        # The released helper mutates dense by applying this analytic mask.
        # Apply it explicitly, without mutating a tensor needed by autograd.
        masked=dense*analytic_multiplier(self.input_length,dense)
        complex_time=torch.fft.ifft(masked,dim=-1)
        recovered=complex_time.abs()
        return {"time_filtered":y,"frequency_filtered":recovered,
                "frequency_spectrum":masked,"frequency_complex":complex_time}


class WDCNN(nn.Module):
    """The released six-convolution 2048-point backend with raw logits."""
    def __init__(self,num_classes):
        super().__init__()
        layers=[nn.Conv1d(1,16,64,stride=8,padding=28),nn.BatchNorm1d(16),nn.ReLU(),nn.MaxPool1d(2)]
        for ci,co,pad in [(16,32,1),(32,64,1),(64,64,1),(64,64,1),(64,64,0)]:
            layers.extend([nn.Conv1d(ci,co,3,padding=pad),nn.BatchNorm1d(co),nn.ReLU(),nn.MaxPool1d(2)])
        self.features=nn.Sequential(*layers)
        self.hidden=nn.Linear(192,100)
        self.dropout=nn.Dropout(0.5)
        self.classifier=nn.Linear(100,num_classes)
    def forward(self,x):
        hidden=F.relu(self.hidden(self.features(x).flatten(1)))
        embedding=self.dropout(hidden)
        return self.classifier(embedding),embedding


class ClassBDWDCNN(nn.Module):
    def __init__(self,num_classes=3,variant="bd_physics",input_length=2048,fs=25600):
        super().__init__()
        if variant not in {"baseline","bd_ce","bd_physics"}:
            raise ValueError("Unknown ClassBD variant")
        if input_length!=2048:
            raise ValueError("The matched released WDCNN backend requires 2048 points")
        self.variant=variant
        # Backend initialized first: a shared seed gives matched backend weights.
        self.backbone=WDCNN(num_classes)
        self.frontend=None if variant=="baseline" else ClassBDFrontEnd(input_length,fs)
    def forward(self,x):
        if x.ndim!=3 or x.shape[1:]!=(1,2048):
            raise ValueError("Expected [batch,1,2048]")
        if self.frontend is None:
            stages={"time_filtered":x,"frequency_filtered":x,
                    "frequency_spectrum":torch.fft.fft(x,dim=-1),
                    "frequency_complex":x.to(torch.complex64 if x.dtype==torch.float32 else torch.complex128)}
        else:
            stages=self.frontend(x)
        logits,embedding=self.backbone(stages["frequency_filtered"])
        return {"logits":logits,"embedding":embedding,"variant":self.variant,**stages}


def physics_terms(time_filtered,frequency_filtered,mode="positive_log",reduction="mean",eps=1e-12):
    """Eq10/Eq25-style per-record losses; positive_log is an explicit adaptation.

    The published K lies in [1/N,1] for a nonzero real vector. Replacing -K
    with -log(K) keeps its minimization direction but makes the time loss
    nonnegative for uncertainty weighting. Zero input has neutral K=1/N.
    """
    if mode not in {"positive_log","paper_exact"}:
        raise ValueError("Unknown physics objective mode")
    x=time_filtered.flatten(1)
    energy=x.square().sum(-1)
    fourth=x.pow(4).sum(-1)
    k=torch.where(energy>eps,fourth/energy.square().clamp_min(eps),torch.full_like(energy,1/x.shape[-1]))
    if mode=="paper_exact":
        time=-k
    else:
        time=-torch.log(k.clamp(min=eps,max=1.0))
    es=envelope_spectrum(frequency_filtered).flatten(1)
    numerator=es.square().sum(-1)
    denominator=es.pow(4).sum(-1).clamp_min(eps**2).sqrt()
    frequency=torch.where(denominator>eps,numerator/denominator.clamp_min(eps),torch.ones_like(numerator))
    if reduction=="none":
        return time,frequency
    if reduction!="mean":
        raise ValueError("reduction must be mean or none")
    return time.mean(),frequency.mean()


class ClassBDObjective(nn.Module):
    def __init__(self,mode="positive_log",uncertainty_weighting=True):
        super().__init__()
        if mode not in {"positive_log","paper_exact"}:
            raise ValueError("Unknown physics objective mode")
        self.mode=mode
        self.uncertainty_weighting=uncertainty_weighting
        self.log_variances=nn.Parameter(torch.full((3,),-0.5))
    def forward(self,output,target):
        ce=F.cross_entropy(output["logits"],target)
        zero=ce.new_zeros(())
        if output.get("variant","bd_physics")!="bd_physics":
            return {"loss":ce,"ce":ce,"time":zero,"frequency":zero,"uncertainty_regularizer":zero}
        lt,lf=physics_terms(output["time_filtered"],output["frequency_filtered"],mode=self.mode)
        terms=torch.stack((ce,lt,lf))
        if self.uncertainty_weighting:
            regularizer=0.5*self.log_variances.sum()
            total=(torch.exp(-self.log_variances)*terms).sum()+regularizer
        else:
            regularizer=zero
            total=terms.sum()
        return {"loss":total,"ce":ce,"time":lt,"frequency":lf,"uncertainty_regularizer":regularizer}


def make_optimizer(model,objective,lr=0.01,momentum=0.9):
    """One persistent optimizer includes persistent uncertainty parameters."""
    params=list(model.parameters())
    if model.variant=="bd_physics" and objective.uncertainty_weighting:
        params+=list(objective.parameters())
    return torch.optim.SGD(params,lr=lr,momentum=momentum)
