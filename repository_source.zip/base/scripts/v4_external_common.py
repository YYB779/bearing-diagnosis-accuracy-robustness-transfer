"""Fixed generic features and source-record-only sigmoid calibration."""
from pathlib import Path
import csv, hashlib
import numpy as np
from scipy.signal import periodogram
from scipy.stats import skew, kurtosis
from scipy.special import expit
from scipy.optimize import minimize
from sklearn.metrics import f1_score, log_loss, balanced_accuracy_score, confusion_matrix

LOW_FS = 400
CLASSES = ['H', 'I', 'O']

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def csv_write(path, rows):
    rows = list(rows)
    assert rows
    with Path(path).open('w', encoding='utf8', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def generic(x):
    a = np.abs(x); eps = 1e-20; rms = np.sqrt(np.mean(x*x)); am = a.mean(); peak = a.max()
    f, p = periodogram(x, fs=LOW_FS, window='hann', detrend='constant', scaling='spectrum')
    p = np.maximum(p, 0); prob = p/(p.sum()+eps); centroid = np.sum(f*prob)
    d = {'mean':x.mean(), 'std':x.std(), 'rms':rms, 'absolute_mean':am, 'peak_to_peak':np.ptp(x),
         'crest_factor':peak/(rms+eps), 'impulse_factor':peak/(am+eps), 'shape_factor':rms/(am+eps),
         'clearance_factor':peak/(np.sqrt(a).mean()**2+eps), 'skewness':skew(x), 'kurtosis_pearson':kurtosis(x,fisher=False),
         'zero_crossing_fraction':np.mean(np.signbit(x[1:])!=np.signbit(x[:-1])),
         'mean_absolute_difference':np.mean(np.abs(np.diff(x))), 'mean_squared_difference':np.mean(np.diff(x)**2),
         'spectral_centroid_hz':centroid, 'spectral_spread_hz':np.sqrt(np.sum((f-centroid)**2*prob)),
         'spectral_entropy_normalized':-np.sum(prob*np.log(prob+eps))/np.log(len(prob)),
         'spectral_flatness':np.exp(np.log(p+eps).mean())/(p.mean()+eps), 'dominant_frequency_hz':f[np.argmax(p)],
         'spectral_rolloff95_hz':f[min(int(np.searchsorted(np.cumsum(prob),.95)),len(f)-1)],
         'spectral_fraction_above_100hz':np.sum(prob[f>=100])}
    bands = np.geomspace(1,180,13)
    for i, (lo,hi) in enumerate(zip(bands[:-1],bands[1:])):
        d[f'band_fraction_{i+1:02d}'] = np.sum(prob[(f>=lo)&(f<hi)])
    assert len(d)==33 and np.isfinite(list(d.values())).all()
    return d

def metrics(y, p):
    p = np.asarray(p, dtype=float)
    assert np.isfinite(p).all() and np.allclose(p.sum(axis=1), 1)
    pred = np.argmax(p, axis=1)
    cm = confusion_matrix(y,pred,labels=[0,1,2])
    recalls = np.divide(cm.diagonal(), cm.sum(axis=1), out=np.full(3,np.nan), where=cm.sum(axis=1)>0)
    return {'macro_f1':float(f1_score(y,pred,labels=[0,1,2],average='macro',zero_division=0)),
            'balanced_accuracy':float(balanced_accuracy_score(y,pred)),
            'nll':float(log_loss(y,p,labels=[0,1,2])),
            'multiclass_brier':float(np.mean(np.sum((p-np.eye(3)[y])**2,axis=1))),
            'confusion_matrix':cm.tolist(),
            'recall_H':float(recalls[0]) if np.isfinite(recalls[0]) else None,
            'recall_I':float(recalls[1]) if np.isfinite(recalls[1]) else None,
            'recall_O':float(recalls[2]) if np.isfinite(recalls[2]) else None,
            'n_records':len(y)}

def aggregate(values, labels, groups):
    unique = sorted(set(groups))
    yy=[]; vv=[]
    for name in unique:
        mask = groups==name
        assert len(set(labels[mask]))==1
        yy.append(labels[mask][0]); vv.append(values[mask].mean(axis=0))
    return unique, np.array(yy), np.asarray(vv)

class RecordSigmoid:
    """OVR Platt sigmoids on held-training-record scores; no window pseudo-n."""
    def fit(self, scores, y):
        assert len(scores)==len(y) and set(y)=={0,1,2}
        self.center = scores.mean(axis=0)
        self.scale = scores.std(axis=0)
        self.scale[self.scale<1e-12]=1
        z = (scores-self.center)/self.scale
        self.coef=[]; self.audit=[]
        for k in range(3):
            positive=y==k; npos=int(positive.sum()); nneg=int((~positive).sum())
            target=np.where(positive,(npos+1)/(npos+2),1/(nneg+2))
            def objective(theta):
                logits=theta[0]*z[:,k]+theta[1]
                loss=np.sum(np.logaddexp(0,logits)-target*logits)
                error=expit(logits)-target
                return float(loss),np.array([np.sum(error*z[:,k]),np.sum(error)])
            result=minimize(objective,[0.,np.log((npos+1)/(nneg+1))],jac=True,method='L-BFGS-B',options={'maxiter':1000,'ftol':1e-12})
            assert result.success, result.message
            self.coef.append(result.x)
            self.audit.append({'class':CLASSES[k],'positive_source_records':npos,'negative_source_records':nneg,
                               'success':bool(result.success),'iterations':int(result.nit),'A':float(result.x[0]),'B':float(result.x[1])})
        self.coef=np.array(self.coef)
        return self

    def predict_proba(self, scores):
        z=(scores-self.center)/self.scale
        p=expit(z*self.coef[:,0]+self.coef[:,1])
        p=np.clip(p,1e-12,1-1e-12)
        return p/p.sum(axis=1,keepdims=True)
