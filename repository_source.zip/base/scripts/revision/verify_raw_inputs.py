"""Check separately acquired input files against the study's recorded SHA-256 and sizes.

Run one dataset at a time. --input-dir points to the directory containing
the original filenames. No files are written and no network requests are made.
"""
import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
FOLDERS = {
    "novic": "data/raw/novic_variable_speed",
    "hust": "data/raw/hust",
    "paderborn": "data/raw/v7_paderborn",
}


def read(relative):
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def expected(source):
    if source == "novic":
        names = ["test_data_4s_clf_subsetE.npy", "test_npy_name_4s_clf_subsetE.npy"]
        return [(name, read(f"{FOLDERS[source]}/{name}.metadata.json")) for name in names]
    if source == "hust":
        manifests = ("data/raw/v3_external/hust_subset_download_manifest.json",
                     "data/raw/v4_external/download_manifest.json")
        return [(row["name"], row) for rel in manifests for row in read(rel)["downloads"]]
    return [(Path(row["archive"]).name, row) for row in read("docs/v7/data/download_manifest.json")]


def verify(source, directory):
    inputs = expected(source)
    if len({name for name, _ in inputs}) != {"novic": 2, "hust": 21, "paderborn": 18}[source]:
        raise ValueError("Source manifest count differs from the study's recorded scope")
    total = 0
    for name, row in inputs:
        path = directory / name
        if not path.is_file():
            raise FileNotFoundError(path)
        if path.stat().st_size != row["bytes"]:
            raise ValueError(f"Source size mismatch: {name}")
        digest = hashlib.sha256()
        with path.open("rb") as stream:
            for block in iter(lambda: stream.read(1 << 22), b""):
                digest.update(block)
        if digest.hexdigest() != row["sha256"]:
            raise ValueError(f"Source SHA-256 mismatch: {name}")
        total += row["bytes"]
    return {"dataset": source, "verified_original_files": len(inputs), "bytes": total}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", choices=FOLDERS)
    parser.add_argument("--input-dir", type=Path, help="Directory containing the original measurement files or archives")
    args = parser.parse_args()
    print(json.dumps(verify(args.source, args.input_dir or (ROOT / FOLDERS[args.source])), indent=2))

