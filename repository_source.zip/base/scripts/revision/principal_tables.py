"""Rebuild numeric endpoint tables at the unit and seed levels used in the paper."""
import argparse
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
TABLES = [
    ("novic_state_held_out","results/v4/analysis/unknown_oof_summary.csv", ["task","representation","model"]),
    ("hust_historical_arms","results/v6/analysis/pooled_summary.csv", ["arm","panel"]),
    ("hust_patch_controls","results/v7/classical/pooled_summary.csv", ["representation","family","panel"]),
    ("hust_excluded_corruption","results/v7/analysis/pooled_summary.csv",["excluded","arm","panel"]),
    ("paderborn_bearings","results/v7/paderborn_specimen/seed_summary.csv",["representation","model","timing","condition"]),
    ("transfer_historical","results/v7/zero_shot/v6/seed_summary.csv",["excluded","arm","timing"]),
    ("transfer_mixed","results/v7/zero_shot/v7/seed_summary.csv",["excluded","arm","timing"]),
]
METRICS=["macro_f1","balanced_accuracy","nll","multiclass_brier","brier","auroc","recall_H","recall_I","recall_O"]

def main(out):
    out.mkdir(parents=True,exist_ok=True)
    for name, path, groups in TABLES:
        frame = pd.read_csv(ROOT/path)
        if frame.duplicated(groups+["seed"]).any():
            raise ValueError(f"Multiple observations per seed for {name}")
        metrics = [m for m in METRICS if m in frame]
        summary = frame.groupby(groups)[metrics].agg(["mean","min","max"])
        summary.columns = ["_".join(col) for col in summary.columns]
        summary["algorithm_seeds"] = frame.groupby(groups).seed.nunique()
        summary.to_csv(out/(name+".csv"))

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output",type=Path)
    main(parser.parse_args().output)
