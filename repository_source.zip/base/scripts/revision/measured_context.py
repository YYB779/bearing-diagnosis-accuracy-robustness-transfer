"""Stratify the archived NOVIC+ native Extra Trees scores by measured co-fault conditions."""
import argparse
import csv
from collections import defaultdict
from pathlib import Path
from statistics import mean


def load(path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def summaries(root):
    meta = {}
    for row in load(root/"data/raw/novic_variable_speed/subsetE_segment_manifest.csv"):
        key = row["inferred_source_group"]
        context = int(row["misalignment_code"]) != 0 or int(row["unbalance_code"]) != 0
        assert key not in meta or meta[key] == context
        meta[key] = context
    observed = defaultdict(dict)
    for row in load(root/"results/v4/analysis/record_predictions.csv"):
        if (row["representation"],row["model"],row["split"]) != ("native_fullband","extra_trees","test_unknown"):
            continue
        group = row["inferred_source_group"]
        key = row["task"], row["seed"], meta[group]
        assert group not in observed[key]
        observed[key][group] = int(row["label"]), int(float(row["p1"]) > 0.5)
        assert float(row["p1"]) != 0.5
    for task in ["inner_presence","outer_presence"]:
        for active in [False, True]:
            values = []
            for seed in ["11","22","33"]:
                records = observed[task,seed,active]
                assert len(records) == sum(v == active for v in meta.values())
                pairs = list(records.values())
                scores = []
                for label in (0,1):
                    tp=sum(a==b==label for a,b in pairs)
                    denom=sum(int(a==label)+int(b==label) for a,b in pairs)
                    assert denom
                    scores.append(2*tp/denom)
                values.append(mean(scores))
            yield [task, "misalignment or unbalance" if active else "neither annotated",
                   len(pairs), sum(a for a,_ in pairs), *values,mean(values)]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project",type=Path)
    parser.add_argument("out",type=Path)
    args=parser.parse_args()
    with args.out.open("w",newline="",encoding="utf8") as stream:
        writer=csv.writer(stream)
        writer.writerow(["task","measured_context","proxies","positive","F1_s11","F1_s22","F1_s33","mean_F1"])
        writer.writerows(summaries(args.project))
