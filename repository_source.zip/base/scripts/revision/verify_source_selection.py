"""Replay source-validation checkpoint selection and label-blind external pooling."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
PROB = ["p_H", "p_I", "p_O"]
BASE = ["cohort", "excluded", "arm", "seed", "timing"]

def check(condition, reason):
    if not condition:
        raise ValueError(reason)

def choices(cohort):
    folder = ROOT / "results/v7/zero_shot" / cohort
    frozen = json.loads((folder / "design.json").read_text())["sha256"]
    weights = {n: h for n, h in frozen.items() if n.endswith(".pt")}
    check(len(weights) == {"v6": 60, "v7": 120}[cohort], "Unexpected model count")
    for name, digest in weights.items():
        weight = ROOT / name.replace(chr(92), "/")
        history = json.loads(weight.with_suffix(".json").read_text())
        check(hashlib.sha256(weight.read_bytes()).hexdigest() == digest == history["model_sha256"],
              "Source checkpoint differs from transfer design")
        options = []
        for row in history["history"]:
            if cohort == "v6":
                panels = [row["validation"][k] for k in ("clean", "AWGN6dB")]
            else:
                panels = [row["validation_clean"]]
            options.append((np.mean([p["macro_f1"] for p in panels]),
                            -np.mean([p["nll"] for p in panels]), -row["update"]))
        check(sorted(-x[2] for x in options) == [120, 240, 360, 480], "Incomplete history")
        check(-max(options)[2] == history["selected_update"], "Checkpoint choice differs")
    return len(weights)

def pool(frame, include_label):
    fields = BASE + ["file_id", "bearing_id", "condition"]
    if include_label:
        fields.append("label")
    for remove in (None, "file_id", "condition"):
        if remove:
            fields.remove(remove)
        frame = frame.groupby(fields, as_index=False)[PROB].mean()
    result = frame.sort_values(BASE + ["bearing_id"])[PROB].to_numpy()
    return result / result.sum(axis=1, keepdims=True)

def probabilities(cohort):
    folder = ROOT / "results/v7/zero_shot" / cohort
    fold = pd.read_csv(folder / "fold_record_predictions.csv")
    frozen = pd.read_csv(folder / "bearing_predictions.csv")
    check(fold.groupby("bearing_id").label.nunique().eq(1).all(), "Inconsistent bearing label")
    check(fold.groupby(BASE + ["file_id"]).fold.nunique().eq(5).all(), "Incomplete ensemble")
    check(fold.groupby(BASE).bearing_id.nunique().eq(9).all(), "Incomplete bearing support")
    expected = frozen.sort_values(BASE + ["bearing_id"])[PROB].to_numpy()
    blind = pool(fold.drop(columns="label"), False)
    # Cycle all three labels. The historical hierarchy uses the constant
    # label as a redundant grouping key for each physical unit.
    permuted = pool(fold.assign(label=(fold.label + 1) % 3), True)
    error = float(np.max(np.abs(blind - expected)))
    change = float(np.max(np.abs(permuted - blind)))
    check(error < 2e-12 and change < 2e-12, "Label invariance or replay failed")
    return dict(fold_record_rows=len(fold), bearing_probabilities=len(frozen),
                maximum_error_vs_archived=error, maximum_permutation_change=change)

if __name__ == "__main__":
    result = {c: dict(selected_checkpoints=choices(c), **probabilities(c)) for c in ("v6", "v7")}
    print(json.dumps({"passed": True, "cohorts": result}, indent=2))
