"""Independently rebuild bearing scores from fold-record probabilities and check both AUCs.

python verify_healthy_ranking.py --project REPLICATION_ROOT --ranking RESULTS_DIRECTORY
Requires NumPy, pandas and scikit-learn. The calculation uses no target labels until
after probability aggregation, then uses roc_auc_score independently of the pair-count code.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

PROB = ["p_H", "p_I", "p_O"]
INDEX = ["cohort", "excluded", "arm", "seed", "timing"]

def fold_to_bearings(project):
    root=project/"results/v7/zero_shot"
    fold=pd.concat([pd.read_csv(root/c/"fold_record_predictions.csv") for c in ("v6","v7")], ignore_index=True)
    if len(fold)!=51480:
        raise ValueError("Expected 51,480 fold-record observations")
    records=fold.groupby(INDEX+["bearing_id","condition","file_id"])[PROB].mean()
    if len(records)!=10296:
        raise ValueError("Expected 143 measurement files in each configuration")
    cond=records.groupby(INDEX+["bearing_id","condition"])[PROB].mean()
    if len(cond)!=2592:
        raise ValueError("Expected four operating conditions per bearing")
    bearings=cond.groupby(INDEX+["bearing_id"])[PROB].mean()
    return bearings.div(bearings.sum(axis=1),axis=0)

def verify(project, ranking):
    rebuilt=fold_to_bearings(project)
    supplied=pd.read_csv(ranking/"healthy_ranking_bearings.csv").set_index(INDEX+["bearing_id"]).sort_index()
    stats=pd.read_csv(ranking/"healthy_ranking_cells.csv").set_index(INDEX)
    difference=np.abs(rebuilt-supplied[PROB]).to_numpy().max()
    if difference>5e-15:
        raise ValueError(f"Probability reconstruction mismatch {difference}")
    largest=0.0
    cell_count=0
    for key, cell in rebuilt.groupby(INDEX):
        labels=supplied.loc[cell.index,"true_class"].eq("H")
        if len(cell)!=9 or labels.sum()!=3: raise ValueError("Invalid nine-bearing set")
        frozen=np.argmax(cell[PROB].to_numpy(),axis=1)
        np.testing.assert_array_equal([("H","I","O")[j] for j in frozen],
                                      supplied.loc[cell.index,"predicted_class"].to_numpy())
        for score, column in [(cell.p_H,"p_H_auc"),(cell.p_H/cell[["p_I","p_O"]].max(axis=1),"H_to_strongest_fault_ratio_auc")]:
            largest=max(largest, abs(roc_auc_score(labels,score)-stats.loc[key,column]))
        cell_count+=1
    if cell_count!=72 or largest>1e-14:raise ValueError(f"AUC disagreement: {largest}, {cell_count}")
    result={"checks":"Direct forward-archive fold-record reaggregation without label and sklearn roc_auc_score",
            "fold_record_rows":51480,"bearing_rows":len(rebuilt),"cells":cell_count,"auc_comparisons":cell_count*2,
            "maximum_probability_difference":float(difference),"maximum_auc_difference":float(largest)}
    print(json.dumps(result,indent=2))
    (ranking/"healthy_ranking_verification.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project",required=True,type=Path)
    parser.add_argument("--ranking",required=True,type=Path)
    args=parser.parse_args()
    verify(args.project,args.ranking)
