"""Compare feature-table refits to the archived NOVIC+ and HUST conventional models.

Run from an intact release after fitting in a separate working extraction:
python scripts/revision/verify_feature_refits.py --project . --refit PATH --output REPORT.json
"""
import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


def check(project, refit):
    reference = pd.read_csv(project / "results/revision/feature_refit_selections.csv")
    hust_table = pd.read_csv(project / "results/v5/analysis/record_predictions.csv", float_precision="round_trip")
    hust_table = hust_table[hust_table.kind.eq("feature")]
    groups = {}
    for key, values in hust_table.groupby(["method","family","seed","fold"]):
        method, family, seed, fold = key
        groups[f"fold{fold}_{method}_{family}_s{seed}"] = values
    summaries = defaultdict(lambda: dict(selected=0,candidates=0,rows=0,identical_configurations=0,
                    maximum_probability_difference=0.,individual_prediction_changes=0,
                    heldout_unit_prediction_changes=0,heldout_unit_rows=0))
    for row in reference.itertuples():
        is_hust = row.branch == "v5/feature_controls"
        stem = row.fit
        folder = Path("results") / row.branch
        new = json.loads((refit / folder / (stem + ".json")).read_text(encoding="utf-8"))
        if new["chosen"] != json.loads(row.choice_json):
            raise ValueError(f"Model selection changed for {stem}")
        if len(new["candidates"]) != row.candidates:
            raise ValueError(f"Candidate count changed for {stem}")
        pred = pd.read_csv(refit / folder / (stem + "_predictions.csv"),float_precision="round_trip")
        if is_hust:
            old = groups[stem].reset_index(drop=True)
            columns = ["source_record","label"]
            prob = ["p_H","p_I","p_O"]
        else:
            old = pd.read_csv(project / folder / (stem + "_predictions.csv"),float_precision="round_trip")
            columns = ["sample_id","inferred_source_group","state_id","state_fold","subset","split","label"]
            prob = ["p1"]
        pd.testing.assert_frame_equal(pred[columns],old[columns],check_dtype=False)
        a=pred[prob].to_numpy(float); b=old[prob].to_numpy(float)
        diff = float(np.abs(a-b).max())
        summary=summaries[row.branch]
        summary["maximum_probability_difference"]=max(diff,summary["maximum_probability_difference"])
        if diff > 1e-12:
            raise ValueError(f"{stem} probabilities differ by {diff}")
        if is_hust:
            y,x = a.argmax(axis=1), b.argmax(axis=1)
            changes=int((y!=x).sum())
            unit_changes=changes
            n_units=len(old)
        else:
            changes=int(((a>=.5)!=(b>=.5)).sum())
            keys=["split","inferred_source_group"]
            aa=pred[pred.split.eq("test_unknown")].groupby(keys).p1.mean()
            bb=old[old.split.eq("test_unknown")].groupby(keys).p1.mean()
            unit_changes=int(((aa>=.5)!=(bb>=.5)).sum())
            n_units=len(aa)
        summary["selected"] += 1
        summary["candidates"] += int(row.candidates)
        summary["identical_configurations"] += 1
        summary["rows"] += len(pred)
        summary["individual_prediction_changes"] += changes
        summary["heldout_unit_prediction_changes"] += unit_changes
        summary["heldout_unit_rows"] += n_units
    for branch,selected,ncandidates in [("v4/state_benchmark",420,980),("v4/repository_benchmark",60,140),("v5/feature_controls",100,225)]:
        if (summaries[branch]["selected"],summaries[branch]["candidates"]) != (selected,ncandidates):
            raise ValueError("Incomplete refit: "+branch)
    return dict(inputs="Frozen feature tables, source-group assignments and hyperparameter grids",
                novic_rows="Interval predictions across selection and both test partitions; scored held-out unit is the recording proxy",
                hust_rows="Condition-held-out acquisition files; a state-associated bearing recurs across speeds",
                branches=dict(summaries))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project",type=Path,required=True)
    parser.add_argument("--refit",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    result=check(args.project,args.refit)
    args.output.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2))
