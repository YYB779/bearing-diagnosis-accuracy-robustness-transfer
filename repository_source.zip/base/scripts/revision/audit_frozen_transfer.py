"""Check the frozen HUST model list and reconstruct Paderborn probabilities without labels.

Run with the original project directory as the first argument. Prints a JSON audit.
No training, target-based selection or use of class labels during aggregation.
"""
from collections import defaultdict
import argparse
import csv
import hashlib
import json
from pathlib import Path
from statistics import fmean


def rows(path):
    with path.open(encoding="utf-8-sig", newline="") as src:
        yield from csv.DictReader(src)


def group_average(groups):
    return {key: tuple(map(fmean, zip(*values))) for key, values in groups.items()}


def audit(root):
    model_count = 0
    row_count = 0
    max_error = 0.0
    preliminary_matching = 0
    for cohort in ["v6", "v7"]:
        folder = root / "results/v7/zero_shot" / cohort
        design = json.loads((folder / "design.json").read_text(encoding="utf8"))
        expected = {}
        families = ["none"] if cohort == "v6" else ["awgn", "colored", "impulse", "tone"]
        arms = (["clean_ce", "awgn_ce", "response_ce", "response_jsd"]
                if cohort == "v6" else ["mixed_erm", "mixed_dro"])
        for family in families:
            for arm in arms:
                for seed in (11, 22, 33):
                    for fold in range(5):
                        name = f"fold{fold}_{arm}_s{seed}.pt"
                        path = (root / "results/v6/robustness" / name if cohort == "v6"
                                else root / "results/v7/lofo" / (family + "_" + name))
                        key = path.relative_to(root).as_posix()
                        expected[key] = hashlib.sha256(path.read_bytes()).hexdigest()
        actual = {k.replace(chr(92), "/"): v for k, v in design["sha256"].items() if k.endswith(".pt")}
        assert expected == actual
        model_count += len(actual)
        preliminary = folder / "preliminary_failed_design.json"
        if preliminary.exists():
            old = json.loads(preliminary.read_text(encoding="utf8"))
            prior = {k.replace(chr(92), "/"): v for k,v in old["sha256"].items() if k.endswith(".pt")}
            assert prior == actual
            preliminary_matching += len(prior)
        by_file = defaultdict(list)
        policy = ("cohort","excluded","arm","seed","timing","bearing_id")
        probabilities = ("p_H","p_I","p_O")
        for r in rows(folder / "fold_record_predictions.csv"):
            key = tuple(r[k] for k in (*policy, "condition", "file_id"))
            by_file[key].append(tuple(float(r[k]) for k in probabilities))
        assert all(len(v) == 5 for v in by_file.values())
        by_condition = defaultdict(list)
        for key, prob in group_average(by_file).items():
            by_condition[key[:-1]].append(prob)
        by_bearing = defaultdict(list)
        for key, prob in group_average(by_condition).items():
            by_bearing[key[:-1]].append(prob)
        assert all(len(v) == 4 for v in by_bearing.values())
        observed = group_average(by_bearing)
        seen = set()
        for r in rows(folder / "bearing_predictions.csv"):
            key = tuple(r[k] for k in policy)
            assert key not in seen
            seen.add(key)
            prob = observed[key]
            error = max(abs(a/sum(prob)-float(r[k])) for a,k in zip(prob,probabilities))
            max_error = max(max_error, error)
        assert seen == set(observed)
        row_count += len(seen)
    assert model_count == 180 and row_count == 648 and max_error < 1e-12
    return dict(frozen_weight_hashes_verified=model_count,
                weights_matching_preserved_preliminary_manifest=preliminary_matching,
                target_label_free_bearing_probability_vectors=row_count,
                maximum_absolute_probability_difference=max_error)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("project", type=Path)
    print(json.dumps(audit(parser.parse_args().project),indent=2))
