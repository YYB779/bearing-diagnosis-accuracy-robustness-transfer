"""Local post hoc HUST wall-clock check on one fixed 32-patch recording.

python benchmark_inference.py --study-root STUDY --output latency.json
The timing excludes acquisition, disk reads and model loading. Only load trusted
local model files. Compare medians within this benchmark on the same machine.
"""
import argparse
import json
import platform
import sys
import time
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
import torch
from threadpoolctl import threadpool_limits


def measure(fn):
    for _ in range(3):
        p = fn()
    assert p.shape == (3,) and np.isfinite(p).all() and np.isclose(p.sum(), 1)
    times = []
    for _ in range(15):
        started = time.perf_counter_ns()
        fn()
        times.append((time.perf_counter_ns() - started)/1e6)
    return {"median_ms": float(np.median(times)), "raw_ms": times}


def main(root, destination):
    sys.path.insert(0, str(root.resolve()))
    from scripts.v5.classbd_models import ClassBDWDCNN
    from scripts.v5.prepare_neural_patches import zscore_patch
    from scripts.v7.run_matched_classical import extract_features

    directory = root / "data/processed/v5"
    frame = pd.read_csv(directory / "hust_neural_patch_lineage.csv")
    with np.load(directory / "hust_neural_patches.npz",allow_pickle=False) as archive:
        assert np.array_equal(archive["patch_id"],frame.patch_id.to_numpy(str))
        record = frame.loc[frame.class_name.eq("H"),"source_record"].min()
        raw = archive["x"][frame.source_record.eq(record).to_numpy()]
    assert raw.shape == (32,2048)
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    timings = {}
    capacities = {}
    with threadpool_limits(1), torch.inference_mode():
        for representation in ["native25","shape25"]:
            for classifier in ["extra_trees","logistic_regression"]:
                name = f"{representation}__{classifier}"
                path = root/"results/v7/classical/runs"/f"{name}__fold0__seed11"/"selected_model.joblib"
                pipeline = joblib.load(path)
                clf = pipeline.named_steps["classifier"]
                capacities[name] = ({"trees": len(clf.estimators_), "nodes": sum(t.tree_.node_count for t in clf.estimators_)}
                                    if classifier == "extra_trees" else
                                    {"coefficients_and_intercepts": int(clf.coef_.size + clf.intercept_.size)})
                def predict_classical():
                    feat,_ = extract_features(raw,representation)
                    return pipeline.predict_proba(feat).mean(0)
                timings[name] = measure(predict_classical)
        model_sets = {
            "WDCNN":[root/"results/v6/robustness/fold0_clean_ce_s11.pt"],
            "BD_WDCNN":[root/"results/v5/classbd_extension/fold0_classbd_ce_s11.pt"],
            "five_WDCNN":[root/f"results/v6/robustness/fold{fold}_clean_ce_s11.pt" for fold in range(5)]}
        for name, paths in model_sets.items():
            models = []
            for path in paths:
                saved = torch.load(path,map_location="cpu",weights_only=True)
                model = ClassBDWDCNN(variant=saved.get("variant","baseline"))
                model.load_state_dict(saved["model_state"])
                models.append(model.eval())
            capacities[name] = {"inference_model_parameters": sum(p.numel() for model in models for p in model.parameters())}
            def predict_neural():
                batch = torch.from_numpy(zscore_patch(raw)[:,None,:])
                pred = [torch.softmax(model(batch)["logits"],dim=1).numpy().astype(float).mean(0) for model in models]
                return np.mean(pred,axis=0)
            timings[name] = measure(predict_neural)
    result = {"record":record, "patch_shape":list(raw.shape), "software":{"python":platform.python_version(),
              "os":platform.platform(),"numpy":np.__version__,"sklearn":sklearn.__version__,"torch":torch.__version__},
              "threads":1,"warmup":3,"timed_replicates":15,"capacities":capacities,"timings":timings}
    destination.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({k:round(v["median_ms"],3) for k,v in timings.items()}))


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-root",required=True,type=Path)
    parser.add_argument("--output",required=True,type=Path)
    args=parser.parse_args()
    main(args.study_root,args.output)
