"""Check acquisition separation and state reuse in the ten published HUST rotations.

For each V6/V7 fold, all three algorithm seeds use identical acquisition assignments.
Interpret state reuse using the source-provider's October 29 2026 README clarification.
This script does not infer serial IDs across different fault states.
"""
import argparse
import csv
import json
from pathlib import Path


def inspect(project):
    with (project / "data/processed/v5/hust_neural_patch_lineage.csv").open(encoding="utf-8-sig",newline="") as stream:
        groups = {}
        for row in csv.DictReader(stream):
            group=(row["class_name"],row["severity"])
            assert groups.setdefault(row["source_record"],group)==group
    assert len(groups)==21 and len(set(groups.values()))==5
    output=[]
    for version in ("v6/robustness","v7/lofo"):
        coverage=[]
        for fold in range(5):
            sets=[]
            for seed in (11,22,33):
                split=json.loads((project/f"results/{version}/fold{fold}_s{seed}_split.json").read_text(encoding="utf8"))
                sets.append(tuple(set(split[k]) for k in ("train_records","validation_records","test_records")))
            assert sets[0]==sets[1]==sets[2]
            train,val,test=sets[0]
            assert train|val|test==set(groups)
            assert not ((train&val)|(train&test)|(val&test))
            states={groups[r] for r in train}
            assert all(groups[r] in states for r in val|test)
            coverage.extend(test)
            output.append(dict(cohort=version,fold=fold,training_files=len(train),validation_files=len(val),
                               test_files=len(test),test_acquisitions_also_in_training=len(test&train),
                               test_acquisitions_matching_a_training_state=sum(groups[r] in states for r in test),
                               distinct_train_state_severity_groups=len(states)))
        assert len(coverage)==21 and set(coverage)==set(groups)
    return output


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("project",type=Path)
    parser.add_argument("out_csv",type=Path)
    args=parser.parse_args()
    results=inspect(args.project)
    with args.out_csv.open("w",encoding="utf8",newline="") as out:
        writer=csv.DictWriter(out,fieldnames=list(results[0]))
        writer.writeheader()
        writer.writerows(results)
