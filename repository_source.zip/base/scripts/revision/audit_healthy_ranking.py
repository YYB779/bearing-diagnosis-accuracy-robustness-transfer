"""Describe held-out healthy-class scores in the frozen HUST-to-Paderborn evaluation.

python audit_healthy_ranking.py --project ROOT_OF_REPLICATION_SOFTWARE --output NEW_OUTPUT_DIR

Each policy, algorithm seed and timing interpretation is evaluated separately on the
same three healthy and six damaged target IDs. This post hoc descriptive analysis
fits no parameters, selects no policy or threshold and estimates no sampling interval.
"""
import argparse
import csv
import hashlib
import json
import math
from collections import defaultdict
from itertools import product
from pathlib import Path

LABELS = {"K004": 0, "K005": 0, "K006": 0, "KI16": 1, "KI18": 1, "KI21": 1,
          "KA15": 2, "KA16": 2, "KA30": 2}
SEEDS = (11, 22, 33)
TIMINGS = ("nominal", "timestamp_sensitive")
POLICIES = ([("v6", "none", a) for a in ("clean_ce", "awgn_ce", "response_ce", "response_jsd")]
            + [("v7", e, a) for e in ("awgn", "colored", "impulse", "tone")
               for a in ("mixed_erm", "mixed_dro")])
KEYS = ("cohort", "excluded", "arm", "seed", "timing")


def load(project):
    groups = defaultdict(dict)
    hashes = {}
    for cohort in ("v6", "v7"):
        rel = Path("results/v7/zero_shot") / cohort / "bearing_predictions.csv"
        path = project / rel
        hashes[rel.as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
        with path.open(encoding="utf-8-sig", newline="") as stream:
            for row in csv.DictReader(stream):
                key = (cohort, row["excluded"], row["arm"], int(row["seed"]), row["timing"])
                bearing = row["bearing_id"]
                probs = tuple(float(row["p_"+c]) for c in "HIO")
                if row["cohort"] != cohort or LABELS.get(bearing) != int(row["label"]):
                    raise ValueError(f"Unexpected cohort, bearing or class in {rel}: {key}, {bearing}")
                if bearing in groups[key] or not all(math.isfinite(x) and 0 <= x <= 1 for x in probs):
                    raise ValueError(f"Duplicate bearing or invalid probabilities: {key}, {bearing}")
                if abs(sum(probs)-1) > 1e-10 or max(probs[1:]) <= 0:
                    raise ValueError(f"Invalid probability vector for the planned scores: {key}, {bearing}")
                groups[key][bearing] = probs
    expected = {(*policy, seed, timing) for policy, seed, timing in product(POLICIES, SEEDS, TIMINGS)}
    if set(groups)!=expected or any(set(g)!=set(LABELS) for g in groups.values()):
        raise ValueError("Archived predictions do not match the 12 × 3 × 2 × 9 design")
    return groups, hashes


def compare(scores):
    pairs = list(product((s for b,s in scores.items() if LABELS[b]==0),
                         (s for b,s in scores.items() if LABELS[b]!=0)))
    wins = sum(h>d for h,d in pairs)
    ties = sum(h==d for h,d in pairs)
    return wins, ties, (wins+0.5*ties)/len(pairs)


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as out:
        w = csv.DictWriter(out, fieldnames=list(rows[0]), lineterminator="\n")
        w.writeheader()
        w.writerows(rows)


def audit(project, output):
    groups, hashes = load(project)
    cells, bearings = [], []
    for key, group in sorted(groups.items()):
        design = dict(zip(KEYS,key))
        healthy = {b:p[0] for b,p in group.items()}
        # Scaling only the healthy probability by a fixed positive multiplier leaves
        # the three-way decision boundary at a cutoff on this score.
        ratios = {b:p[0]/max(p[1:]) for b,p in group.items()}
        cell = design.copy()
        cell["healthy_correct_argmax"] = sum(p.index(max(p))==0 for b,p in group.items() if LABELS[b]==0)
        for name, scores in (("p_H", healthy), ("H_to_strongest_fault_ratio", ratios)):
            wins, ties, auc = compare(scores)
            cell.update({name+"_wins_of_18":wins, name+"_ties_of_18":ties, name+"_auc":auc})
        cells.append(cell)
        for b,p in sorted(group.items()):
            bearings.append({**design,"bearing_id":b,"true_class":"HIO"[LABELS[b]],
                             "predicted_class":"HIO"[p.index(max(p))],"p_H":p[0],"p_I":p[1],"p_O":p[2],
                             "H_to_strongest_fault_ratio":ratios[b],
                             "p_H_rank_desc_midrank":1+sum(x>p[0] for x in healthy.values())
                                 +0.5*(sum(x==p[0] for x in healthy.values())-1)})
    summary = {"input_sha256": hashes, "distinct_target_bearings":len(LABELS), "configurations":len(cells),
               "method":"AUC = (pairs in which the healthy bearing has the higher score + half the tied pairs)/18. Each cell uses the same three healthy and six damaged IDs. No target threshold or class weight is selected.",
               "by_timing":{}}
    for t in TIMINGS:
        rows = [r for r in cells if r["timing"]==t]
        stats = {"policy_seed_cells":len(rows), "correct_healthy_argmax_decisions":sum(r["healthy_correct_argmax"] for r in rows)}
        for name in ("p_H", "H_to_strongest_fault_ratio"):
            vals = [r[name+"_auc"] for r in rows]
            stats[name] = {"minimum_auc":min(vals),"maximum_auc":max(vals),
                           "minimum_wins":min(r[name+"_wins_of_18"] for r in rows),
                           "maximum_wins":max(r[name+"_wins_of_18"] for r in rows),
                           "perfect_order_cells":sum(x==1 for x in vals),
                           "below_half_cells":sum(x<0.5 for x in vals),
                           "half_cells":sum(x==0.5 for x in vals),
                           "above_half_cells":sum(x>0.5 for x in vals),
                           "total_exact_ties":sum(r[name+"_ties_of_18"] for r in rows)}
        summary["by_timing"][t]=stats
    output.mkdir(exist_ok=True, parents=True)
    write_csv(output/"healthy_ranking_cells.csv", cells)
    write_csv(output/"healthy_ranking_bearings.csv", bearings)
    (output/"healthy_ranking_summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
    return summary

if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(audit(args.project,args.output),indent=2))
