"""Quantify HUST state overlap and paired influence of omitting a damage-state group.

Usage: python audit_hust_state_overlap.py --project STUDY --output NEW_DIRECTORY
Reads archived inputs and fixed predictions only. No fitting. The October 29,
2026 dataset clarification is pinned in the JSON output.
"""
import argparse
from collections import Counter, defaultdict
import csv
import json
from pathlib import Path
from statistics import mean


SOURCE = ("https://github.com/CHAOZHAO-1/HUSTbearing-dataset/blob/"
          "554fe1269055660c41e9011fe97b971348bdec7f/README.md")
LABELS = {"H":0, "I":1, "O":2}


def read(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write(path, rows):
    with path.open("w", encoding="utf-8", newline="") as f:
        out = csv.DictWriter(f, fieldnames=rows[0])
        out.writeheader()
        out.writerows(rows)


def states_and_splits(project, out):
    lineage = read(project/"data/processed/v5/hust_neural_patch_lineage.csv")
    records = {}
    for r in lineage:
        cl = r["class_name"]
        sev = {"medium":"moderate", "healthy":"healthy", "severe":"severe"}[r["severity"]]
        state = "healthy" if cl=="H" else {"I":"inner","O":"outer"}[cl]+"_"+sev
        file = r["source_record"]
        assert int(r["class_id"]) == LABELS[cl]
        assert file.startswith("0.5X_") == (sev=="moderate")
        row = dict(source_record=file,condition=r["condition"],true_class=cl,damage_state=state)
        assert file not in records or records[file] == row
        records[file] = row
    counts = Counter(r["source_record"] for r in lineage)
    assert len(counts)==21 and set(counts.values())=={32}
    support = Counter(r["damage_state"] for r in records.values())
    assert support == {"healthy":5,"inner_moderate":3,"outer_moderate":3,
                       "inner_severe":5,"outer_severe":5}
    write(out/"hust_state_records.csv",[records[k] for k in sorted(records)])
    roles = ("train","validation","test")
    overlap=[]
    for fold in range(5):
        plan = json.loads((project/f"results/v5/classbd_extension/fold{fold}_split_and_batches.json").read_text("utf-8-sig"))
        sets = {role:set(plan[role+"_records"]) for role in roles}
        assert set().union(*sets.values()) == set(records)
        assert sum(map(len,sets.values()))==21
        for stage in ("v6/robustness","v7/lofo"):
            for seed in (11,22,33):
                j=json.loads((project/f"results/{stage}/fold{fold}_s{seed}_split.json").read_text("utf-8-sig"))
                assert all(sets[role]==set(j[role+"_records"]) for role in roles)
        train, val, test = ({records[k]["damage_state"] for k in sets[role]} for role in roles)
        overlap.append(dict(fold=fold,test_condition=",".join(sorted({records[k]["condition"] for k in sets["test"]})),
                            n_fit_files=len(sets["train"]),n_validation_files=len(sets["validation"]),n_test_files=len(sets["test"]),
                            fit_states="|".join(sorted(train)),validation_states="|".join(sorted(val)),test_states="|".join(sorted(test)),
                            n_test_states=len(test),n_test_states_seen_in_fit=len(test&train),
                            n_test_files_with_state_in_fit=sum(records[k]["damage_state"] in train for k in sets["test"]),
                            n_validation_states=len(val),n_validation_states_seen_in_fit=len(val&train)))
    write(out/"hust_state_split_overlap.csv",overlap)
    return records,overlap


def macro_f1(rows):
    true=[x[0] for x in rows]
    pred=[x[1] for x in rows]
    assert set(true)=={0,1,2}
    return mean(2*sum(t==p==c for t,p in rows)/(true.count(c)+pred.count(c)) for c in [0,1,2])


def fixed_predictions(project,records,rel,cohort):
    cells=defaultdict(dict)
    for r in read(project/rel):
        if cohort=="classical":
            if r["family"]!="extra_trees":continue
            policy=r["representation"]
        elif cohort=="exposure":
            if r["role"]!="test":continue
            policy=r["arm"]
        else:
            if r["panel"]!={"awgn":"AWGN-4dB","colored":"colored-4dB",
                             "impulse":"impulse-4dB","tone":"tone-4dB"}[r["excluded"]]:continue
            policy=r["arm"]
        file=r["source_record"]
        label=int(r.get("label",r.get("class_id")))
        assert label==LABELS[records[file]["true_class"]]
        probs=[float(r["p_"+c]) for c in "HIO"]
        assert abs(sum(probs)-1)<1e-10
        predicted=probs.index(max(probs))
        k=(r["panel"],policy,int(r["seed"]))
        assert file not in cells[k]
        cells[k][file]=(label,predicted)
    assert all(set(files)==set(records) for files in cells.values())
    return cells


def run(project,out):
    out.mkdir(parents=True,exist_ok=True)
    records,overlap=states_and_splits(project,out)
    info=[("classical","results/v7/classical/record_predictions.csv",[("native25","shape25")]),
          ("exposure","results/v6/analysis/record_predictions.csv",[("awgn_ce","clean_ce"),("response_ce","awgn_ce"),("response_jsd","response_ce")]),
          ("excluded","results/v7/analysis/record_predictions.csv",[("mixed_dro","mixed_erm")])]
    rows=[]
    for cohort,rel,pairs in info:
        cells=fixed_predictions(project,records,rel,cohort)
        for panel in sorted({k[0] for k in cells}):
            for first,second in pairs:
                for omitted in ["none"]+sorted({r["damage_state"] for r in records.values()}):
                    keep=sorted(k for k,r in records.items() if r["damage_state"]!=omitted)
                    support=Counter(records[k]["true_class"] for k in keep)
                    diffs=[]
                    if len(support)==3:
                        for seed in (11,22,33):
                            a,b=(cells[panel,arm,seed] for arm in (first,second))
                            diffs.append(macro_f1([a[k] for k in keep])-macro_f1([b[k] for k in keep]))
                    rows.append(dict(cohort=cohort,panel=panel,first_model=first,second_model=second,
                                     omitted_state=omitted,remaining_n=len(keep),
                                     n_H=support["H"],n_I=support["I"],n_O=support["O"],
                                     mean_paired_delta=mean(diffs) if diffs else "",
                                     status="all_three_classes_supported" if diffs else "three_class_comparison_unavailable_no_healthy_support"))
    assert len(rows)==168
    write(out/"hust_state_deletion.csv",rows)
    result=dict(metadata_source=SOURCE,source_update="2026-10-29",
                recorded_files=len(records),matched_rotations=len(overlap),
                state_groups=dict(Counter(v["damage_state"] for v in records.values())),
                test_files_with_state_in_fit=sum(v["n_test_files_with_state_in_fit"] for v in overlap),
                interpretation="Paired re-scoring after removing an observed state group; models are not refitted. "
                               "This is a sensitivity to test composition and reused state-associated bearings. "
                               "It does not estimate transfer to unobserved physical bearings.")
    (out/"hust_state_audit.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project",required=True,type=Path)
    parser.add_argument("--output",required=True,type=Path)
    args=parser.parse_args()
    run(args.project,args.output)
