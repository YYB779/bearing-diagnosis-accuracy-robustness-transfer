"""Compare a fresh run against the frozen study observations and model choices."""
import argparse
import csv
import hashlib
import json
from pathlib import Path


TABLES = {
    "paderborn": ("results/v7/paderborn_specimen", [
        "bearing_predictions", "condition_bearing_predictions", "measurement_predictions",
        "development_oof_bearing_predictions", "seed_summary", "descriptive_summary"]),
    "hust": ("results/v7/classical", [
        "record_predictions", "fold_summary", "pooled_summary", "descriptive_summary"]),
    "transfer-v6": ("results/v7/zero_shot/v6", [
        "fold_record_predictions", "ensemble_record_predictions", "bearing_condition_predictions",
        "bearing_predictions", "seed_summary", "descriptive_summary"]),
    "transfer-v7": ("results/v7/zero_shot/v7", [
        "fold_record_predictions", "ensemble_record_predictions", "bearing_condition_predictions",
        "bearing_predictions", "seed_summary", "descriptive_summary"]),
}


def choices(folder, dataset):
    if dataset == "paderborn":
        rows = json.loads((folder / "selection_manifest.json").read_text())["selected_models"]
        keys = ("representation", "family", "seed", "config_index", "config", "development_cv")
    elif dataset == "hust":
        rows = json.loads((folder / "selected_models.json").read_text())
        keys = ("representation", "family", "fold", "seed", "config_index", "parameters")
    else:
        return []
    return [{key: row[key] for key in keys} for row in rows]


def compare(reference, rerun, dataset):
    folder, tables = TABLES[dataset]
    old, new = reference / folder, rerun / folder
    frozen = choices(old, dataset)
    if frozen != choices(new, dataset):
        raise ValueError(f"Candidate selection differs for {dataset}")
    result = {"dataset": dataset, "selected_configurations_compared": len(frozen), "tables": {}}
    for name in tables:
        a, b = [(root / (name + ".csv")).read_bytes() for root in (old, new)]
        with (old / (name + ".csv")).open(encoding="utf-8-sig", newline="") as stream:
            rows = sum(1 for _ in csv.DictReader(stream))
        if a != b:
            raise ValueError(f"CSV bytes differ: {folder}/{name}.csv")
        result["tables"][name] = {"rows": rows, "sha256": hashlib.sha256(a).hexdigest(),
                                  "byte_identical": True}
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("dataset", choices=TABLES)
    parser.add_argument("--reference", type=Path, required=True)
    parser.add_argument("--rerun", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(compare(args.reference, args.rerun, args.dataset), indent=2))

