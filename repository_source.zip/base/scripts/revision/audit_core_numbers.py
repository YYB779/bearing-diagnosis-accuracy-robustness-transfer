"""Independent standard-library recomputation of the primary estimates from saved probabilities."""
import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean

def read(project, path):
    with (project/path).open(encoding="utf-8-sig", newline="") as stream:
        yield from csv.DictReader(stream)

def score(y_p, nclass):
    return mean(2*sum(y==c and p==c for y,p in y_p) /
                sum(int(y==c)+int(p==c) for y,p in y_p) for c in range(nclass))

def group(rows, cols, label, unit, n):
    result=defaultdict(dict)
    for r in rows:
        k=tuple(r[c] for c in cols)
        assert r[unit] not in result[k]
        if "p1" in r:
            prob = float(r["p1"])
            assert 0 <= prob <= 1
            pred=int(prob >= .5)
        else:
            probs=[float(r[c]) for c in ("p_H","p_I","p_O")]
            assert abs(sum(probs)-1)<2e-5 and min(probs)>=0
            pred=probs.index(max(probs))
        result[k][r[unit]]=(int(r[label]), pred)
    assert all(len(x)==n for x in result.values())
    return result

def means(g, nclass):
    out=defaultdict(list)
    for k, v in g.items():
        out[k[:-1]].append(score(list(v.values()),nclass))
    assert all(len(v)==3 for v in out.values())
    return {"/".join(k):mean(v) for k,v in sorted(out.items())}

def run(p):
    nova=group((r for r in read(p,"results/v4/analysis/record_predictions.csv") if
                r["representation"] in ("native_fullband","time_envelope") and r["model"]=="extra_trees"
                and r["split"]=="test_unknown"),("task","representation","seed"),"label","inferred_source_group",79)
    cls=group((r for r in read(p,"results/v7/classical/record_predictions.csv") if
               r["family"]=="extra_trees"),("panel","representation","seed"),"class_id","source_record",21)
    hist=group((r for r in read(p,"results/v6/analysis/record_predictions.csv") if r["role"]=="test"),
               ("panel","arm","seed"),"label","source_record",21)
    match={"awgn":"AWGN-4dB","colored":"colored-4dB","impulse":"impulse-4dB","tone":"tone-4dB"}
    lofo=group((r for r in read(p,"results/v7/analysis/record_predictions.csv") if
                r["panel"]==match[r["excluded"]]),("arm","excluded","seed"),"label","source_record",21)
    within=group((r for r in read(p,"results/v7/paderborn_specimen/bearing_predictions.csv") if r["timing"]=="nominal"),
                 ("representation","model","seed"),"class_id","bearing_id",9)
    tr_all=[r for cohort in ["v6","v7"] for r in read(p,f"results/v7/zero_shot/{cohort}/bearing_predictions.csv")]
    frozen=group(tr_all,("timing","cohort","excluded","arm","seed"),"label","bearing_id",9)
    assert len(frozen)==72 and {x for g in frozen.values() for x in g}=={x for g in within.values() for x in g}
    assert all(sum(y==0 for y,pred in g.values())==3 and not any(y==pred==0 for y,pred in g.values())
               for g in frozen.values())
    healthy_fault_calls=defaultdict(Counter)
    all_healthy_calls=Counter()
    for k,g in frozen.items():
        if k[0] != "nominal": continue
        for bearing,(label,pred) in g.items():
            if label==0: healthy_fault_calls[bearing][pred]+=1
            if pred==0: all_healthy_calls[bearing]+=1
    assert all_healthy_calls=={"KA16":13} and sum(sum(v.values()) for v in healthy_fault_calls.values())==108
    nscore=means(nova,2)
    cscore=means(cls,3)
    hscore=means(hist,3)
    loscore=means(lofo,3)
    lomean={arm:mean(v for k,v in loscore.items() if k.startswith(arm+"/")) for arm in ("mixed_dro","mixed_erm")}
    cf= sum(y==0 for k,g in cls.items() if k[0]!="clean" and k[1]=="native25" for y,pr in g.values())
    cf_misses=sum(y==0 and pr!=y for k,g in cls.items() if k[0]!="clean" and k[1]=="native25" for y,pr in g.values())
    assert cf==cf_misses==75
    ws=means(within,3)
    ts=means(frozen,3)
    paths=["development","test"]
    acq={}
    for role in paths:
        m=defaultdict(Counter)
        for r in read(p,f"data/processed/v7/paderborn_specimen_{role}_patch_lineage.csv"):
            m[r["bearing_id"]][r["file_id"]]+=1
        assert all(n==16 for counts in m.values() for n in counts.values()) and len(m)==9
        acq[role]={b:len(f) for b,f in sorted(m.items())}
    assert not set(acq["development"]) & set(acq["test"])
    return {"NOVIC_ET":nscore,"HUST_clean_ET":{k:v for k,v in cscore.items() if k.startswith("clean/")},
            "HUST_corrupted_ET_healthy_file_seed_calls":cf,"HUST_corrupted_ET_healthy_misses":cf_misses,
            "HUST_white_minus_clean_CE_at_minus4dB":hscore["AWGN-4dB/awgn_ce"]-hscore["AWGN-4dB/clean_ce"],
            "HUST_excluded_panel_F1":loscore,"HUST_means_four_excluded_panels":lomean,
            "Paderborn_nominal_within":ws, "Paderborn_nominal_frozen":{k:v for k,v in ts.items() if k.startswith("nominal/")},
            "Paderborn_healthy_nominal_false_calls":healthy_fault_calls,"Paderborn_nominal_called_healthy":all_healthy_calls,
            "Paderborn_eligible_files_by_bearing":acq}

if __name__=="__main__":
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument("project",type=Path)
    a.add_argument("out",type=Path)
    x=a.parse_args()
    x.out.write_text(json.dumps(run(x.project),indent=2,sort_keys=True)+"\n",encoding="utf-8")
