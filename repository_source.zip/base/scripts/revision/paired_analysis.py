"""Paired sensitivity analyses using saved, unit-level predictions.

python paired_analysis.py --project PROJECT_ROOT --output OUTPUT_DIRECTORY
"""
import argparse
from itertools import product
from pathlib import Path
import numpy as np
import pandas as pd


def paired_arrays(left, right, unit, label):
    def prepare(frame, name):
        frame = frame.copy()
        if "p1" in frame:
            frame[name] = (frame.p1 >= .5).astype(int)
        else:
            frame[name] = frame[["p_H","p_I","p_O"]].to_numpy().argmax(axis=1)
        return frame[["seed",unit,label,name]]
    both = prepare(left,"a").merge(prepare(right,"b"),on=["seed",unit,label],
                                   how="outer",validate="one_to_one",indicator=True)
    assert both["_merge"].eq("both").all()
    a = both.pivot(index="seed",columns=unit,values="a")
    b = both.pivot(index="seed",columns=unit,values="b").reindex_like(a)
    y = both.pivot(index="seed",columns=unit,values=label).reindex_like(a)
    assert y.nunique().eq(1).all() and len(a)==3
    return a.columns,y.iloc[0].to_numpy(int),a.to_numpy(int),b.to_numpy(int)


def paired_deltas(y, a, b, weights):
    """Seed-specific paired macro-F1 differences for each set of unit counts."""
    def scores(predictions):
        by_seed = []
        for pred in predictions:
            scores = []
            for c in np.unique(y):
                denom = weights @ ((y==c).astype(float) + (pred==c))
                numer = weights @ (2*((y==c)&(pred==c)))
                scores.append(np.divide(numer,denom,out=np.zeros_like(denom),where=denom>0))
            by_seed.append(np.mean(scores,axis=0))
        return np.array(by_seed)
    return scores(a)-scores(b)


def run(project, out):
    out.mkdir(exist_ok=True,parents=True)
    def read(rel):
        return pd.read_csv(project/"results"/rel)
    rows=[]
    def summarize(left,right,unit,label,contrast,panel,kind,states=None,joint_labels=None):
        ids,y,a,b=paired_arrays(left,right,unit,label)
        n=len(y)
        assert n=={"NOVIC":79,"HUST":21,"Paderborn":9}[kind] and set(np.unique(y))==set(range(2 if kind=="NOVIC" else 3))
        seed_delta=paired_deltas(y,a,b,np.ones((1,n))).ravel()
        if kind=="NOVIC":
            group_ids=states.loc[ids].to_numpy()
            groups=np.unique(group_ids)
            assert len(groups)==33
            rng=np.random.default_rng(20261120)
            strata = joint_labels.loc[groups].to_numpy()
            counts = np.zeros((10000,len(groups)), dtype=int)
            for stratum in np.unique(strata):
                loc = np.flatnonzero(strata==stratum)
                counts[:,loc] = rng.multinomial(len(loc),np.full(len(loc),1/len(loc)),10000)
            w=counts[:,np.searchsorted(groups,group_ids)]
            assert all(np.all(w[:,y==c].sum(axis=1)>0) for c in np.unique(y))
            method="central 95% of 10000 paired joint-label-stratified state-cluster bootstrap draws"
        elif kind=="Paderborn":
            groups=[np.where(y==c)[0] for c in np.unique(y)]
            assert [len(g) for g in groups]==[3,3,3]
            draws=np.array(list(product(*(list(product(g,repeat=3)) for g in groups)))).reshape(-1,n)
            assert len(draws)==19683
            w=np.column_stack([(draws==i).sum(axis=1) for i in range(n)])
            method="central 95% of all 19683 paired within-class bootstrap draws"
        else:
            w=np.ones((n,n))-np.eye(n)
            method="range after omitting each single paired file"
        delta=paired_deltas(y,a,b,w).mean(axis=0)
        lo,hi=(delta.min(),delta.max()) if kind=="HUST" else np.quantile(delta,[.025,.975],method="inverted_cdf")
        rows.append(dict(dataset=kind,contrast=contrast,panel=panel,unit_count=n,delta=seed_delta.mean(),
                         seed_min=seed_delta.min(),seed_max=seed_delta.max(),lower=lo,upper=hi,interpretation=method))
    novic=read("v4/analysis/record_predictions.csv").query("split=='test_unknown' and model=='extra_trees'")
    by_state=novic[["state_id","task","label"]].drop_duplicates().pivot(index="state_id",columns="task",values="label")
    joint=by_state["inner_presence"]+2*by_state["outer_presence"]
    for task,g in novic.groupby("task"):
        states=g[["inferred_source_group","state_id"]].drop_duplicates().set_index("inferred_source_group").state_id
        summarize(g.query("representation=='time_envelope'"),g.query("representation=='native_fullband'"),
                  "inferred_source_group","label","Time envelope minus native",task,"NOVIC",states,joint)
    for panel,g in read("v7/classical/record_predictions.csv").query("family=='extra_trees'").groupby("panel"):
        summarize(g.query("representation=='native25'"),g.query("representation=='shape25'"),"source_record",
                  "class_id","Native minus shape Extra Trees",panel,"HUST")
    for panel,g in read("v6/analysis/record_predictions.csv").query("role=='test'").groupby("panel"):
        for a,b in [("awgn_ce","clean_ce"),("response_ce","awgn_ce"),("response_jsd","response_ce")]:
            summarize(g[g.arm==a],g[g.arm==b],"source_record","label",a+" minus "+b,panel,"HUST")
    excluded=read("v7/analysis/record_predictions.csv")
    for family,panel in [("awgn","AWGN-4dB"),("colored","colored-4dB"),("impulse","impulse-4dB"),("tone","tone-4dB")]:
        g=excluded[(excluded.excluded==family)&(excluded.panel==panel)]
        summarize(g[g.arm=="mixed_dro"],g[g.arm=="mixed_erm"],"source_record","label","DRO minus ERM",panel,"HUST")
    for model,g in read("v7/paderborn_specimen/bearing_predictions.csv").query("timing=='nominal'").groupby("model"):
        summarize(g[g.representation=="shape25"],g[g.representation=="native25"],"bearing_id",
                  "class_id","Shape minus native "+model,"nominal","Paderborn")
    pd.DataFrame(rows).to_csv(out/"paired_contrasts.csv",index=False)
    tr=pd.concat([read(f"v7/zero_shot/{v}/bearing_predictions.csv") for v in ["v6","v7"]])
    tr["pred"]=tr[["p_H","p_I","p_O"]].to_numpy().argmax(axis=1)
    assert tr.groupby(["cohort","excluded","arm","seed","timing"]).size().eq(9).all()
    tr.groupby(["timing","label","bearing_id","pred"]).size().rename("predictions").reset_index().to_csv(
        out/"transfer_class_errors.csv",index=False)
    print(pd.DataFrame(rows).drop(columns="interpretation").round(4).to_string(index=False))


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    run(args.project,args.output)
