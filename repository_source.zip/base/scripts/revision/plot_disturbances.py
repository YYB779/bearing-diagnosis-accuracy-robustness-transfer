"""Rebuild Supplementary Figure S9 using one retrieved original HUSTbearing text-format .xls file.

python plot_disturbances.py --source-file H_20Hz.xls --output OUTPUT
Use the author dataset https://github.com/CHAOZHAO-1/HUSTbearing-dataset (Zhao et al.,
doi:10.1016/j.ress.2024.109964). No study repository, local private archive or model weights
are needed in this mode. Requires numpy (tested 2.2.6), scipy, matplotlib and pandas.
Alternatively use --study-root STUDY for all-six-panel checks against the original design.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.signal import welch


ROW_HASHES = {
    "clean":"6cf452c52cebba86008a4d5f74f38711f15146605f9e421e346d0fab8de057fd",
    "AWGN0dB":"1fe854a85ff1bee4af59bd07049dd6544a3e59c14cc0319ca73b5dbe6317c87e",
    "AWGN-4dB":"eee5cd75744c34b761f094253f93a454422ca84f8350d391b729ac74458a5b29",
    "colored-4dB":"26879fcc51f4c4b60ec2ffa5bf7a4c121d4151ed5d9c2661ef583dedd4036999",
    "impulse-4dB":"94d8017cdd2997068f44775c64857eb04d0ae86f06bd14cefeeb3473953f369c",
    "tone-4dB":"bbd2f062dd926fa36032ac79937c8f04433e0fa8e2352a4983ec4f0c59c0c127"}


def load_full(root):
    sys.path.insert(0, str(root.resolve()))
    from scripts.v6.consistency import apply_response, test_panels
    data = root / "data/processed/v5"
    with np.load(data / "hust_neural_patches.npz", allow_pickle=False) as patches:
        x = patches["x"]
        patch_ids = patches["patch_id"]
    frame = pd.read_csv(data / "hust_neural_patch_lineage.csv")
    assert x.shape == (672, 2048)
    assert np.array_equal(patch_ids, frame.patch_id.to_numpy(str))
    row = frame[frame.class_name.eq("H")].sort_values(["source_record", "start_sample"]).iloc[0]
    index = int(row.name)
    panels = test_panels(x)
    recorded = json.loads((root / "results/v6/robustness/design.json").read_text(encoding="utf-8"))
    hashes = {k: hashlib.sha256(np.ascontiguousarray(v).tobytes()).hexdigest()
              for k, v in panels.items()}
    assert hashes == recorded["test_noise_array_sha256"], "Frozen test panel differs"
    return row,{k:v[index] for k,v in panels.items()},hashes,apply_response


def frozen_row(signal):
    """Project the frozen all-array RNG draws onto row 192 in the original patch order."""
    index, shape = 192, (672,2048)
    signal = np.asarray(signal,np.float32)
    def add(z,snr):
        x = np.asarray(signal,float)
        z = np.asarray(z,float) - z.mean()
        scale = np.sqrt(np.mean((x-x.mean())**2)/max(np.mean(z**2),1e-30))
        return (x+z*scale*10**(-snr/20)).astype(np.float32)
    rows = {"clean":signal}
    for snr in [0,-4]:
        noise = np.random.default_rng(5102026+abs(snr)).normal(size=shape)[index]
        rows[f"AWGN{snr}dB"] = add(noise,snr)
    freq = np.fft.rfftfreq(2048,1/25600)
    z = np.random.default_rng(6601).normal(size=shape)[index]
    z = np.fft.irfft(np.fft.rfft(z)/np.sqrt(np.maximum(freq,12.5)),n=2048)
    rows["colored-4dB"] = add(z,-4)
    rng = np.random.default_rng(6602)
    z = rng.normal(size=shape)[index]*(rng.random(size=shape)[index] < .005)
    rows["impulse-4dB"] = add(z,-4)
    rng = np.random.default_rng(6603)
    freq = rng.uniform(300,10000,size=(672,1))[index]
    phase = rng.uniform(0,2*np.pi,size=(672,1))[index]
    rows["tone-4dB"] = add(np.sin(2*np.pi*freq*np.arange(2048)/25600+phase),-4)
    return rows


def load_source(path):
    expected="8d6088da2cbfa51b10cd9c39f6e1533fb91fa85b86d0ee828c41721181f69ae0"
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected, "Unexpected original file hash"
    with path.open(encoding="utf-8") as f:
        for line in f:
            if line.strip()=="Data":
                break
        signal=np.loadtxt(f,delimiter="\t",max_rows=2048,usecols=2).astype(np.float32)
    assert signal.shape==(2048,)
    row=SimpleNamespace(source_record="H_20Hz.xls",patch_id="hust_native_w048_p0",
                        start_sample=0,stop_sample_exclusive=2048)
    def response(x,g):
        gain=np.interp(np.linspace(0,1,1025),np.array([0,2000,4000,8000,12800])/12800,g[0])
        return np.fft.irfft(np.fft.rfft(x,axis=-1)*np.exp(gain),n=2048,axis=-1)
    return row,frozen_row(signal),None,response


def main(root, out, source_file=None):
    row,panels,hashes,apply_response = load_source(source_file) if source_file else load_full(root)

    fs = 25600
    clean = panels["clean"].astype(float)
    reference = clean.std()
    plotted = {"Measured": clean}
    definitions = [
        ("White Gaussian, 0 dB", "AWGN0dB"),
        ("White Gaussian, −4 dB", "AWGN-4dB"),
        ("Colored Gaussian, −4 dB", "colored-4dB"),
        ("Sparse impulses, −4 dB", "impulse-4dB"),
        ("Sinusoid, −4 dB", "tone-4dB"),
    ]
    snr = {}
    for label, key in definitions:
        plotted[label] = panels[key].astype(float)
        snr[key] = float(20*np.log10(reference / (plotted[label]-clean).std()))
        assert abs(snr[key] - (0 if key == "AWGN0dB" else -4)) < 1e-5
    # Separately audit the row hashes for reproduction from the original source file.
    row_hashes = {k: hashlib.sha256(np.ascontiguousarray(v).tobytes()).hexdigest()
                  for k,v in panels.items()}
    assert row_hashes == ROW_HASHES, "Selected row differs from the archived HUST corruption arrays"
    # Component illustration only; no optimizer or reported test endpoint used this view.
    response_seed = 66016
    gains = np.clip(np.random.default_rng(response_seed).normal(0,.35,(1,5)), -.7,.7)
    plotted["Spectral response alone"] = apply_response(clean[None,:],gains)[0]
    colors = ["#147A80", "#147A80", "#416D91", "#A55732", "#76528C", "#79632C"]
    time = np.arange(len(clean)) * (1000 / fs)

    def spectral(signal):
        f, psd = welch(signal/reference, fs=fs, window="hann", nperseg=512, noverlap=256,
                       nfft=512, detrend="constant", scaling="density")
        assert (psd > 0).all()
        return f / 1000, 10*np.log10(psd)

    spectra = {key: spectral(signal) for key, signal in plotted.items()}
    amplitudes = {key: (signal-clean.mean()) / reference for key, signal in plotted.items()}
    impulse_label = "Sparse impulses, −4 dB"
    ordinary_max = max(np.abs(a).max() for k,a in amplitudes.items() if k != impulse_label)*1.06
    impulse_max = max(ordinary_max,np.abs(amplitudes[impulse_label]).max()*1.06)
    db_lo = 10*np.floor(min(y.min() for f,y in spectra.values())/10)
    db_hi = 10*np.ceil(max(y.max() for f,y in spectra.values())/10)
    with plt.rc_context({"font.family":"DejaVu Sans","font.size":8,"axes.linewidth":.6,
                         "axes.spines.top":False,"axes.spines.right":False}):
        fig, grid = plt.subplots(6,2,figsize=(7.1,8.25),sharex="col")
        fig.subplots_adjust(left=.11,right=.98,bottom=.067,top=.912,wspace=.28,hspace=.52)
        fig.text(.11,.983,"a   Time waveform",fontsize=12,weight="bold",va="top")
        fig.text(.60,.983,"b   Power spectrum",fontsize=12,weight="bold",va="top")
        fig.text(.11,.95,"Gray = measured patch     Color = the same patch after perturbation",fontsize=9)
        fig.text(.012,.48,"Amplitude / clean standard deviation",rotation=90,va="center",fontsize=9)
        fig.text(.526,.48,"PSD (dB re 1 clean variance / Hz)",rotation=90,va="center",fontsize=9)
        for i,(label,color) in enumerate(zip(list(plotted)[1:],colors)):
            left,right = grid[i]
            title = label + "  (wider vertical scale)" if label == impulse_label else label
            left.text(0,1.06,title,transform=left.transAxes,fontsize=8.5,weight="bold")
            for key,stroke,width,z in [(label,color,.65,2),("Measured","#303030",.42,3)]:
                left.plot(time,amplitudes[key],color=stroke,lw=width,zorder=z,alpha=.85)
                f,y = spectra[key]
                right.plot(f,y,color=stroke,lw=1 if key==label else .75,
                           ls="-" if key==label else "--",zorder=z)
            limit = impulse_max if label == impulse_label else ordinary_max
            left.set(xlim=(0,80),ylim=(-limit,limit),xticks=[0,20,40,60,80])
            right.set(xlim=(0,12.8),ylim=(db_lo,db_hi),xticks=[0,3.2,6.4,9.6,12.8])
            for ax in [left,right]:
                ax.tick_params(length=2.5,width=.6,pad=2)
                ax.grid(axis="y",color="#E4E4E4",lw=.5,zorder=0)
        grid[-1,0].set_xlabel("Time (ms)")
        grid[-1,1].set_xlabel("Frequency (kHz)")
        out.mkdir(exist_ok=True,parents=True)
        fig.savefig(out/"disturbances.png",dpi=340,facecolor="white")
        plt.close(fig)
    details = {"source":row.source_record,"patch_id":row.patch_id,"start":int(row.start_sample),
               "stop_exclusive":int(row.stop_sample_exclusive),"sample_rate_hz":fs,
               "sha256_all_original_panels":hashes,"sha256_selected_rows":row_hashes,
               "snr_db":snr,"response_seed":response_seed,
               "response_log_gains":gains.ravel().tolist(),"sample_sd":float(reference),
               "welch":{"window":"periodic Hann","samples":512,"overlap":256,"fft":512,
                        "bin_spacing_hz":50,"segments":7}}
    (out/"disturbance_checks.json").write_text(json.dumps(details,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(details,ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    source=parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--study-root",type=Path)
    source.add_argument("--source-file",type=Path)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    main(args.study_root,args.output,args.source_file)
