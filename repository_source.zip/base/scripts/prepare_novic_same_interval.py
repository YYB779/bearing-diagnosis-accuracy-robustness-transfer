"""Prepare a small measured NOVIC+ paired-view audit without training a model.

Filename-derived acquisition groups are stratified BEFORE new windows are
extracted. Misalignment/unbalance are retained; labels are IR/OR presence bits,
not pure-fault classes. No physical-bearing independence is asserted.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.signal import resample_poly
from sklearn.model_selection import StratifiedShuffleSplit

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from src.data.order_tracking import resample_paired_interval
from src.figures.style import apply_publication_style


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""): h.update(chunk)
    return h.hexdigest()


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-dir",type=Path,required=True)
    parser.add_argument("--output-dir",type=Path,required=True)
    parser.add_argument("--label-manifest",type=Path,default=Path("data/raw/novic_variable_speed/subsetE_segment_manifest.csv"))
    parser.add_argument("--seed",type=int,default=20261017)
    args=parser.parse_args(); args.output_dir.mkdir(parents=True,exist_ok=True)
    data_path=args.raw_dir/"test_data_4s_clf_subsetE.npy"
    metadata=json.loads(data_path.with_suffix(".npy.metadata.json").read_text())
    if not metadata.get("checksum_verified"): raise RuntimeError("A verified complete official download is required")
    data=np.load(data_path,mmap_mode="r",allow_pickle=False)
    frame=pd.read_csv(args.label_manifest)
    if data.shape!=(len(frame),102400,9): raise ValueError(f"Unexpected data shape {data.shape}")
    # This is a new sample registry, not a reuse of upstream segment splits.
    groups=frame.groupby("inferred_source_group",sort=True).agg(inner_presence=("inner_presence","first"),outer_presence=("outer_presence","first"))
    for bit in ["inner_presence","outer_presence"]:
        if (frame.groupby("inferred_source_group")[bit].nunique()>1).any(): raise ValueError("Inconsistent labels within a source group")
    strata=groups.inner_presence.astype(str)+"_"+groups.outer_presence.astype(str)
    splitter=StratifiedShuffleSplit(n_splits=1,test_size=.2,random_state=args.seed)
    remainder,test=next(splitter.split(groups,strata))
    inner=StratifiedShuffleSplit(n_splits=1,test_size=.25,random_state=args.seed+1)
    train_sub,val_sub=next(inner.split(groups.iloc[remainder],strata.iloc[remainder]))
    assignment={**{groups.index[i]:"train" for i in remainder[train_sub]},**{groups.index[i]:"validation" for i in remainder[val_sub]},**{groups.index[i]:"test" for i in test}}
    group_manifest=groups.reset_index();group_manifest["split"]=group_manifest.inferred_source_group.map(assignment)
    split_path=args.output_dir/"source_group_split_manifest.csv";group_manifest.to_csv(split_path,index=False)
    split_hash=sha256(split_path)
    # Manifest is now on disk, before any derived window is extracted.
    fs=25600.;down=8;fs_out=fs/down;source_count=16384;output_count=2048
    raw_views=[];order_views=[];speed_views=[];bits=[];lineage=[];excluded=[]
    for rec in frame.to_dict("records"):
        index=int(rec["array_row"]); segment=data[index]
        for start in [0,25600,51200,76800]:
            stop=start+source_count
            vibration=np.asarray(segment[start:stop,0],dtype=float)
            speed=np.asarray(segment[start:stop,8],dtype=float)
            if not np.isfinite(vibration).all() or not np.isfinite(speed).all() or np.any(speed<=0):
                excluded.append({"array_row":index,"start_sample":start,"reason":"nonfinite vibration/speed or nonpositive measured after-gearbox rpm"});continue
            filtered=resample_poly(vibration,up=1,down=down,padtype="line")
            # resample_poly compensates FIR group delay. Output k corresponds to
            # source coordinate start + k*down; no unobserved final period added.
            decimated_coordinates=np.arange(filtered.size)*down
            aligned_speed=np.interp(decimated_coordinates,np.arange(source_count),speed)
            paired=resample_paired_interval(filtered,aligned_speed/60.,fs_out,time_output_samples=output_count,order_output_samples=output_count,start_time_seconds=start/fs)
            if abs(paired.raw_time_seconds[0]-paired.order_time_seconds[0])>1e-12 or abs(paired.raw_time_seconds[-1]-paired.order_time_seconds[-1])>1e-12: raise AssertionError("Mismatched physical endpoints")
            raw_views.append(paired.raw_values.astype(np.float32));order_views.append(paired.order_values.astype(np.float32));speed_views.append(aligned_speed.astype(np.float32))
            bits.append([int(rec["inner_presence"]),int(rec["outer_presence"])])
            lineage.append({"sample_id":f"novic_E_{index:03d}_{start:06d}_strict_v1","array_row":index,"upstream_name":rec["upstream_name"],"subset":rec["subset"],"inferred_source_group":rec["inferred_source_group"],"split":assignment[rec["inferred_source_group"]],"inner_presence":rec["inner_presence"],"outer_presence":rec["outer_presence"],"misalignment_code":rec["misalignment_code"],"unbalance_code":rec["unbalance_code"],"source_start_sample":start,"source_filter_stop_exclusive":stop,"selected_last_original_sample":start+int(decimated_coordinates[-1]),"physical_start_s_in_upstream_segment":paired.physical_start_seconds,"physical_stop_s_in_upstream_segment":paired.physical_stop_seconds,"actual_revolutions":paired.actual_revolutions,"input_sample_rate_hz":fs,"filtered_sample_rate_hz":fs_out,"view_samples":output_count,"vibration_channel":0,"measured_rpm_channel":8,"rpm_min":float(aligned_speed.min()),"rpm_max":float(aligned_speed.max()),"rpm_mean":float(aligned_speed.mean()),"normalization":"none; calibrated source values retained","anti_alias":"scipy.signal.resample_poly(up=1,down=8,padtype=line)","angular_api":"resample_paired_interval; inclusive same physical endpoints","source_sha256":metadata["sha256"],"split_manifest_sha256":split_hash})
    if not lineage: raise RuntimeError("No valid same-interval window")
    table=pd.DataFrame(lineage)
    if table.groupby("inferred_source_group").split.nunique().max()!=1: raise AssertionError("Source group crosses split")
    dataset_path=args.output_dir/"novic_subsetE_same_interval_v1.npz"
    np.savez_compressed(dataset_path,time=np.asarray(raw_views),order=np.asarray(order_views),speed_rpm=np.asarray(speed_views),inner_outer_presence=np.asarray(bits,dtype=np.int64),actual_revolutions=table.actual_revolutions.to_numpy())
    lineage_path=args.output_dir/"novic_subsetE_same_interval_v1_lineage.csv";table.to_csv(lineage_path,index=False)
    exclusions_path=args.output_dir/"novic_subsetE_same_interval_v1_exclusions.json";exclusions_path.write_text(json.dumps(excluded,indent=2))
    # A descriptive, non-selected example per source speed profile.
    import matplotlib;matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    apply_publication_style()
    fig,axes=plt.subplots(3,3,figsize=(10.4,6.8),constrained_layout=True)
    examples=[];source_rows=[]
    for col,subset in enumerate(["subsetA","subsetB","subsetC"]):
        candidates=frame[(frame.subset==subset)&(frame.coarse_bearing_label=="healthy")]
        rec=candidates.sort_values("array_row").iloc[0];index=int(rec.array_row)
        selected=table[(table.array_row==index)].iloc[0];j=int(selected.name)
        source=np.asarray(data[index]);t=np.arange(source.shape[0])/fs
        axes[0,col].plot(t[::32],source[::32,7],label="Before gearbox",color="#777777",lw=.8)
        axes[0,col].plot(t[::32],source[::32,8],label="After gearbox (used)",color="#246B8E",lw=1.1)
        axes[0,col].axvspan(selected.physical_start_s_in_upstream_segment,selected.physical_stop_s_in_upstream_segment,color="#B9D7EA",alpha=.35)
        axes[0,col].set_title(f"({chr(97+col)}) {subset}: measured speed",loc="left",fontweight="bold")
        axes[0,col].set_xlabel("Time in upstream segment (s)");axes[0,col].set_ylabel("Measured speed (rpm)")
        if col==0:axes[0,col].legend(fontsize=6,frameon=False)
        axes[1,col].plot(np.linspace(selected.physical_start_s_in_upstream_segment,selected.physical_stop_s_in_upstream_segment,output_count),raw_views[j],color="#246B8E",lw=.65)
        axes[1,col].set_xlabel("Time in upstream segment (s)");axes[1,col].set_ylabel("Vibration (source g)");axes[1,col].set_title(f"({chr(100+col)}) Anti-aliased time view",loc="left",fontweight="bold")
        phase=np.linspace(0,selected.actual_revolutions,output_count)
        axes[2,col].plot(phase,order_views[j],color="#528A63",lw=.65)
        axes[2,col].set_xlabel("Measured accumulated revolutions");axes[2,col].set_ylabel("Vibration (source g)");axes[2,col].set_title(f"({chr(103+col)}) Same interval: {selected.actual_revolutions:.2f} turns",loc="left",fontweight="bold")
        examples.append({"subset":subset,"array_row":index,"upstream_name":rec.upstream_name,"sample_id":selected.sample_id,"actual_revolutions":float(selected.actual_revolutions)})
        for k in range(0,len(t),32):source_rows.append({"subset":subset,"array_row":index,"time_s":float(t[k]),"rpm_before":float(source[k,7]),"rpm_after":float(source[k,8])})
    for ax in axes.flat:ax.spines[["top","right"]].set_visible(False)
    figure=args.output_dir/"novic_measured_speed_and_pairing.pdf";fig.savefig(figure,bbox_inches="tight");fig.savefig(figure.with_suffix(".png"),bbox_inches="tight",dpi=300);plt.close(fig)
    plot_source=args.output_dir/"novic_representative_speed_traces.csv";pd.DataFrame(source_rows).to_csv(plot_source,index=False)
    report={"status":"measured public-data preprocessing audit; no performance experiment","source_doi":"10.5281/zenodo.15743425","source_data_path":str(data_path.resolve()),"source_sha256":metadata["sha256"],"original_upstream_container":"test subsetE; not our final test set","groups":len(group_manifest),"segments":len(frame),"derived_windows":len(table),"excluded_windows":len(excluded),"group_counts_by_split":group_manifest.split.value_counts().to_dict(),"window_counts_by_split":table.split.value_counts().to_dict(),"labels":"two binary outputs: inner_presence, outer_presence; misalignment/unbalance retained","normalization":"none","physical_bearing_independence":"unknown; source recording-group isolation only","same_rig_limitation":True,"example_selection":"first available healthy segment by source array index per subset; no model-based selection","examples":examples,"artifacts":[{"path":str(path.resolve()),"sha256":sha256(path)} for path in [dataset_path,lineage_path,split_path,exclusions_path,figure,figure.with_suffix('.png'),plot_source]]}
    report_path=args.output_dir/"novic_same_interval_preprocessing_audit.json";report_path.write_text(json.dumps(report,indent=2),encoding="utf-8")
    pointer=Path("data/novic_same_interval_preprocessing.json");pointer.write_text(json.dumps({"status":report["status"],"report_path":str(report_path.resolve()),"report_sha256":sha256(report_path),"groups":len(group_manifest),"segments":len(frame),"derived_windows":len(table),"data_path":str(dataset_path.resolve()),"figure_path":str(figure.resolve())},indent=2),encoding="utf-8")
    print(json.dumps({"report":str(report_path),"derived_windows":len(table),"groups":len(group_manifest),"exclusions":len(excluded)},indent=2),flush=True)


if __name__=="__main__":main()
