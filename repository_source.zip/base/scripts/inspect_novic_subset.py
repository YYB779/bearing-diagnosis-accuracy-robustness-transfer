"""Audit official NOVIC+ subset labels, source groups, schema and downloaded data.

This script never accepts the upstream segment-level split as our split. It
does not train a model. Filename-derived source-group IDs are explicitly marked
as inferred; no physical-bearing independence is inferred from them.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

import numpy as np


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def verify_source(path: Path) -> None:
    """Match size and SHA-256 to the original acquisition record in this package."""
    root = Path(__file__).resolve().parents[1]
    expected_path = root / "data/raw/novic_variable_speed" / (path.name + ".metadata.json")
    expected = json.loads(expected_path.read_text(encoding="utf-8"))
    if path.stat().st_size != expected["bytes"] or digest(path) != expected["sha256"]:
        raise ValueError(f"Source file differs from the recorded acquisition: {path.name}")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--raw-dir", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True,
                   help="A separate directory for rebuilt metadata, including a labels-only manifest when waveforms are absent.")
    args = p.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    label_path = args.raw_dir / "test_npy_name_4s_clf_subsetE.npy"
    data_path = args.raw_dir / "test_data_4s_clf_subsetE.npy"
    verify_source(label_path)
    if data_path.exists():
        verify_source(data_path)
    if (args.output_dir / "subsetE_segment_manifest.csv").resolve() == (Path(__file__).resolve().parents[1] / "data/raw/novic_variable_speed/subsetE_segment_manifest.csv").resolve():
        raise ValueError("Write the audit to a separate output directory to preserve the supplied reference manifest")
    names = np.load(label_path, allow_pickle=False)
    data = np.load(data_path, mmap_mode="r", allow_pickle=False) if data_path.exists() else None
    if data is not None and data.shape != (len(names), 102400, 9):
        raise ValueError(f"Unexpected official data shape: {data.shape}")
    rows = []
    for index, value in enumerate(names):
        name = str(value)
        parts = name.split("/")
        subset, state = parts[2], parts[-2]
        recording, segment = Path(parts[-1]).stem.split("_")
        labels = {"inner": "0", "outer": "0", "misalign": "0", "unbalance": "0"}
        if state != "normal":
            match = re.fullmatch(r"inner(?P<inner>\d+)_outer(?P<outer>\d+)_misalign(?P<misalign>\d+)_unbalance(?P<unbalance>\d+)", state)
            if not match:
                raise ValueError(f"Unknown source state: {state}")
            labels = match.groupdict()
        ir, out = labels["inner"] != "0", labels["outer"] != "0"
        nuisance = labels["misalign"] != "0" or labels["unbalance"] != "0"
        coarse = "combined" if ir and out else "inner" if ir else "outer" if out else "no_bearing_fault_other_anomaly" if nuisance else "healthy"
        row = {"array_row": index, "upstream_name": name, "subset": subset, "upstream_split": "test (sampling container only; not our evaluation split)",
            "record_prefix": recording, "segment_index": int(segment),
            "inferred_source_group": "/".join(parts[2:-1]) + "/" + recording,
            "group_status": "filename-derived acquisition candidate; not a unique physical bearing ID",
            "state": state, "coarse_bearing_label": coarse, "inner_presence": int(ir), "outer_presence": int(out),
            "misalignment_code": labels["misalign"], "unbalance_code": labels["unbalance"],
            "pure_bearing_or_healthy": int(not nuisance), "sample_rate_hz": 25600, "samples": 102400, "duration_s": 4,
            "vibration_channel_indices": "0,1,2,3", "before_gearbox_rpm_channel": 7, "after_gearbox_rpm_channel": 8,
            "recommended_order_speed_channel": 8,
            "rpm_pairing_status": "inference from primary-paper test-rig placement: both bearing housings are after gearbox; verify measured ratio"}
        if data is not None:
            segment_data = np.asarray(data[index])
            row["finite_all_channels"] = bool(np.isfinite(segment_data).all())
            for channel in [7, 8]:
                speed = segment_data[:, channel]
                row[f"channel{channel}_min_rpm"] = float(np.min(speed))
                row[f"channel{channel}_max_rpm"] = float(np.max(speed))
                row[f"channel{channel}_mean_rpm"] = float(np.mean(speed))
                row[f"channel{channel}_sd_rpm"] = float(np.std(speed))
            for channel in range(4):
                vibration = segment_data[:, channel]
                row[f"vibration{channel}_rms"] = float(np.sqrt(np.mean(vibration ** 2)))
            positive = np.isfinite(segment_data[:,7]) & np.isfinite(segment_data[:,8]) & (segment_data[:,8] > 1)
            row["median_before_after_rpm_ratio"] = float(np.median(segment_data[positive,7] / segment_data[positive,8])) if np.any(positive) else None
        rows.append(row)
    manifest = args.output_dir / "subsetE_segment_manifest.csv"
    with manifest.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)
    schema = {"dataset_doi": "10.5281/zenodo.15743425", "dataset_version": "v2", "license": "CC BY 4.0", "official_metadata_url": "https://zenodo.org/api/records/15743425", "primary_paper": {"doi": "10.1016/j.ymssp.2025.113786", "author_manuscript_url": "https://arxiv.org/pdf/2505.24001", "setup_section": "5.1, pp. 11-13"},
        "data_path": str(Path("data/raw/novic_variable_speed", data_path.name).as_posix()), "names_path": str(Path("data/raw/novic_variable_speed",label_path.name).as_posix()), "dimensions": [len(names),102400,9], "sample_rate_hz": 25600, "segment_duration_s": 4,
        "channels": {"0": "bearing housing A vibration, perpendicular to ground", "1": "bearing housing A vibration, parallel to ground", "2": "bearing housing B vibration, perpendicular to ground", "3": "bearing housing B vibration, parallel to ground", "4": "bearing housing A temperature", "5": "bearing housing B temperature", "6": "torque", "7": "measured rpm before gearbox", "8": "measured rpm after gearbox"},
        "geometry_from_primary_paper": {"bearing": "NSK6205", "n_balls": 9, "ball_diameter_mm": 7.90, "pitch_diameter_mm": 38.5, "contact_angle_degrees": 0, "gear_ratio": 2.07, "inner_outer_artificial_crack_mm": 0.2},
        "grouping_rule": "Never split segments sharing subset/state/record_prefix. Prefer group-wise cross-validation; record_prefix semantics are inferred from author filenames and do not imply a new physical bearing.",
        "nuisance_rule": "IR/OR are binary presence labels; misalignment/unbalance remain explicit covariates. Do not relabel a compound fault as a pure single fault.",
        "download_status": "complete_verified_official_checksum" if data is not None else "pending_no_complete_data_file"}
    (args.output_dir / "official_schema_and_pairing.json").write_text(json.dumps(schema, indent=2), encoding="utf-8")
    audit = {"data_status": schema["download_status"], "data_path": str(Path("data/raw/novic_variable_speed", data_path.name).as_posix()), "name_array_shape": list(names.shape), "data_shape": list(data.shape) if data is not None else None,
        "segments": len(rows), "inferred_source_groups": len({r["inferred_source_group"] for r in rows}), "physical_bearing_count": None,
        "subset_counts": dict(Counter(r["subset"] for r in rows)), "coarse_bearing_counts": dict(Counter(r["coarse_bearing_label"] for r in rows)),
        "pure_class_counts": dict(Counter(r["coarse_bearing_label"] for r in rows if r["pure_bearing_or_healthy"])),
        "finite_all_records": all(r.get("finite_all_channels", False) for r in rows) if data is not None else None,
        "manifest_path": manifest.name, "manifest_sha256": digest(manifest), "labels_sha256": digest(label_path),
        "restrictions": ["This is a 101-segment subset of the original upstream test container, not the full NOVIC+ benchmark.", "The number of pure IR examples is insufficient for a reliable held-out pure-three-class benchmark.", "A source-group split must be written before extracting any new windows; upstream test labels must not be treated as our final untouched test set."]}
    (args.output_dir / "subsetE_access_and_label_audit.json").write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(json.dumps(audit, indent=2), flush=True)


if __name__ == "__main__":
    main()
