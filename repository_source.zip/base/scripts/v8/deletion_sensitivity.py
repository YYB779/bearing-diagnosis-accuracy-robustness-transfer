"""Descriptive sensitivity to deleting one of nine fixed test bearings.

No training, tuning, resampling or specimen-population confidence interval.
Primary nine-bearing results are never replaced by a deletion endpoint.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/v8/deletion_sensitivity'
FIG = ROOT / 'figures/v8'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def manual_f1(y, pred):
    values = []
    for c in [0, 1, 2]:
        tp = int(((y == c) & (pred == c)).sum())
        fp = int(((y != c) & (pred == c)).sum())
        fn = int(((y == c) & (pred != c)).sum())
        values.append(2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.)
    return float(np.mean(values))


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    FIG.mkdir(parents=True, exist_ok=True)
    source = ROOT / 'results/v7/paderborn_specimen/bearing_predictions.csv'
    table = pd.read_csv(source)
    assert len(table) == 216
    groups = ['representation', 'model', 'seed', 'timing']
    rows = []
    errors = []
    max_difference = 0.
    bearing_set = {'K004', 'K005', 'K006', 'KI16', 'KI18', 'KI21', 'KA15', 'KA16', 'KA30'}
    for key, data in table.groupby(groups, sort=True):
        data = data.sort_values('bearing_id').reset_index(drop=True)
        assert set(data.bearing_id) == bearing_set and len(data) == 9
        y = data.class_id.to_numpy(dtype=int)
        prob = data[['p_H', 'p_I', 'p_O']].to_numpy(float)
        assert np.isfinite(prob).all() and (prob >= 0).all()
        assert np.max(np.abs(prob.sum(axis=1) - 1)) < 1e-10
        pred = np.argmax(prob, axis=1)
        full = manual_f1(y, pred)
        max_difference = max(max_difference, abs(full - f1_score(y, pred, labels=[0, 1, 2], average='macro', zero_division=0)))
        for index, bearing in enumerate(data.bearing_id):
            keep = np.arange(9) != index
            value = manual_f1(y[keep], pred[keep])
            max_difference = max(max_difference, abs(value - f1_score(y[keep], pred[keep], labels=[0, 1, 2], average='macro', zero_division=0)))
            rows.append(dict(zip(groups, key)) | {
                'deleted_bearing': bearing, 'deleted_class': int(y[index]),
                'full_nine_bearing_f1': full, 'remaining_bearings': 8,
                'deleted_bearing_f1': value, 'difference_from_primary': value - full,
                'full_correct_bearings': int((y == pred).sum())})
            errors.append(dict(zip(groups, key)) | {
                'bearing_id': bearing, 'true_class': int(y[index]),
                'predicted_class': int(pred[index]), 'correct': bool(y[index] == pred[index])})
    points = pd.DataFrame(rows)
    points.to_csv(OUT / 'deletion_points.csv', index=False)
    pd.DataFrame(errors).to_csv(OUT / 'bearing_decisions.csv', index=False)
    # Average algorithm seeds for each specific omitted bearing. This leaves
    # exactly nine points per model/timing, not 27 independent specimens.
    means = points.groupby(['representation', 'model', 'timing', 'deleted_bearing'], as_index=False).agg(
        primary_f1=('full_nine_bearing_f1', 'mean'),
        deletion_f1=('deleted_bearing_f1', 'mean'))
    means.to_csv(OUT / 'seed_averaged_deletion_points.csv', index=False)
    summary = means.groupby(['representation', 'model', 'timing'], as_index=False).agg(
        primary_f1=('primary_f1', 'first'), deletion_min=('deletion_f1', 'min'),
        deletion_max=('deletion_f1', 'max'))
    summary.to_csv(OUT / 'summary.csv', index=False)
    assert len(points) == 216 and len(means) == 72 and len(summary) == 8
    assert max_difference < 1e-14
    style = {'font.family': 'Arial', 'font.size': 8, 'axes.labelsize': 8,
             'xtick.labelsize': 7.2, 'ytick.labelsize': 7.5, 'pdf.fonttype': 42,
             'svg.fonttype': 'none', 'axes.spines.top': False,
             'axes.spines.right': False, 'figure.facecolor': 'white'}
    policies = [('native25', 'extra_trees', 'Native 25 / Extra Trees'),
                ('shape25', 'extra_trees', 'Shape 25 / Extra Trees'),
                ('native25', 'logistic', 'Native 25 / Logistic'),
                ('shape25', 'logistic', 'Shape 25 / Logistic')]
    with plt.rc_context(style):
        fig, axes = plt.subplots(1, 2, figsize=(170/25.4, 99/25.4), sharey=True)
        for j, (ax, timing, title) in enumerate(zip(axes, ['nominal', 'timestamp_sensitive'],
                ['a  Nominal sampling', 'b  Timestamp sensitivity'])):
            for i, (representation, model, label) in enumerate(policies):
                data = means[(means.representation == representation) & (means.model == model) & (means.timing == timing)].sort_values('deleted_bearing')
                assert len(data) == 9
                ax.plot([data.deletion_f1.min(), data.deletion_f1.max()], [i, i], c='#89959C', lw=.8, zorder=2)
                for k, (_, row) in enumerate(data.iterrows()):
                    ax.scatter(row.deletion_f1, i + (k - 4)*.035, s=15,
                               facecolors='white', edgecolors='#0072B2', lw=.75, zorder=3)
                ax.scatter(data.primary_f1.iloc[0], i, s=31, marker='D', c='#D55E00', edgecolors='white', linewidths=.5, zorder=4)
            ax.set_title(title, loc='left', weight='bold', fontsize=8.5, pad=10)
            ax.set(xlim=(-.02, 1.02), xticks=[0, .25, .5, .75, 1], xlabel='Macro-F1 across declared classes')
            ax.grid(axis='x', lw=.5, c='#E2E6E9'); ax.set_axisbelow(True)
        axes[0].set_yticks(range(4), [p[2] for p in policies]); axes[0].invert_yaxis()
        handles=[plt.Line2D([], [], color='#0072B2', marker='o', fillstyle='none', linestyle='none', label='Delete one fixed test bearing'),
                 plt.Line2D([], [], color='#D55E00', marker='D', linestyle='none', label='Primary nine-bearing result')]
        fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.54, .015), ncol=1, frameon=False, fontsize=7.5)
        fig.subplots_adjust(left=.29, right=.98, top=.85, bottom=.26, wspace=.18)
        stem = FIG / 'fig_bearing_deletion'
        for ext in ['pdf', 'svg', 'png']:
            fig.savefig(str(stem)+'.'+ext, dpi=300, facecolor='white')
        plt.close(fig)
    means.to_csv(FIG / 'fig_bearing_deletion.source.csv', index=False)
    caption = ('Sensitivity to deleting one fixed test bearing. Panels a and b retain nominal and timestamp-sensitive inputs for every development-selected conventional model. '
        'Each open circle is the three-algorithm-seed mean after omitting one of the nine test-bearing prediction rows and recomputing macro-F1 over the remaining eight bearings with all three class labels fixed. '
        'All nine omissions are displayed per model; small vertical offsets distinguish coincident points. Orange diamonds retain the primary nine-bearing endpoint. '
        'Horizontal segments span observed deletion minima and maxima; they are not confidence intervals. No model is fitted again, recalibrated or selected by these results. '
        'Each omission changes class composition from 3/3/3 to a permutation of 2/3/3, so the displacement reflects both bearing influence and class composition in a nonlinear metric. '
        'These retrospective finite-sample diagnostics neither create new bearings nor estimate population performance. The two timing paths and algorithm seeds reuse the same nine bearing IDs.')
    (FIG / 'fig_bearing_deletion.caption.txt').write_text(caption+'\n', encoding='utf-8')
    artifact_paths = [p for p in OUT.glob('*.csv')] + list(FIG.glob('fig_bearing_deletion.*'))
    audit = {'passed': True, 'utc': datetime.now(timezone.utc).isoformat(),
             'source': str(source.relative_to(ROOT)), 'source_sha256': sha(source),
             'script_sha256': sha(__file__), 'nine_bearing_groups': 24,
             'deletion_endpoints': len(points), 'seed_averaged_deletion_endpoints': len(means),
             'independent_manual_vs_sklearn_max_difference': max_difference,
             'models_refitted': 0, 'population_confidence_interval': False,
             'artifact_sha256': {str(p.relative_to(ROOT)): sha(p) for p in artifact_paths}}
    (OUT / 'audit.json').write_text(json.dumps(audit, indent=2), encoding='utf-8')
    print(summary.to_string(index=False), flush=True)
    print(json.dumps({'passed': True, 'deletion_endpoints': len(points), 'max_metric_difference': max_difference}), flush=True)


if __name__ == '__main__':
    main()
