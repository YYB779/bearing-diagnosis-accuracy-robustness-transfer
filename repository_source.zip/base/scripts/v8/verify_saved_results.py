"""Portable offline verification of saved probabilities and V8 deletion results.

Requires only NumPy and pandas. Does not load signals, models, Word, local page
PNGs or any author-machine paths. This is arithmetic replay, not model inference.
"""
from pathlib import Path
import argparse
import hashlib
import json
import numpy as np
import pandas as pd


SPECS = [
    ('results/v6/analysis/record_predictions.csv', 'results/v6/analysis/pooled_summary.csv',
     ['arm', 'seed', 'panel'], 'label', 'source_record', 21, False),
    ('results/v7/classical/record_predictions.csv', 'results/v7/classical/pooled_summary.csv',
     ['representation', 'family', 'seed', 'panel'], 'class_id', 'source_record', 21, False),
    ('results/v7/analysis/record_predictions.csv', 'results/v7/analysis/pooled_summary.csv',
     ['excluded', 'arm', 'seed', 'panel'], 'label', 'source_record', 21, False),
    ('results/v7/paderborn_specimen/bearing_predictions.csv', 'results/v7/paderborn_specimen/seed_summary.csv',
     ['representation', 'model', 'seed', 'timing'], 'class_id', 'bearing_id', 9, True),
    ('results/v7/zero_shot/v6/bearing_predictions.csv', 'results/v7/zero_shot/v6/seed_summary.csv',
     ['cohort', 'excluded', 'arm', 'seed', 'timing'], 'label', 'bearing_id', 9, False),
    ('results/v7/zero_shot/v7/bearing_predictions.csv', 'results/v7/zero_shot/v7/seed_summary.csv',
     ['cohort', 'excluded', 'arm', 'seed', 'timing'], 'label', 'bearing_id', 9, False),
]
EXPECTED_GROUPS = [72, 72, 144, 24, 24, 48]
METRICS = ['macro_f1', 'balanced_accuracy', 'nll', 'multiclass_brier', 'recall_H', 'recall_I', 'recall_O']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require_finite(frame, columns, label):
    values = frame[columns].apply(pd.to_numeric, errors='raise').to_numpy(float)
    if not np.isfinite(values).all():
        raise ValueError('Nonfinite numeric field: '+label)


def metrics(y, p):
    if not np.isfinite(p).all() or (p < 0).any() or (p > 1).any():
        raise ValueError('Invalid saved class probabilities')
    if np.max(np.abs(p.sum(axis=1)-1)) >= 1e-10:
        raise ValueError('Saved probabilities do not sum to one')
    if set(np.unique(y)) != {0, 1, 2}:
        raise ValueError('Each audited endpoint must contain all declared classes')
    pred = p.argmax(axis=1)
    cm = np.zeros((3, 3), dtype=int)
    np.add.at(cm, (y, pred), 1)
    f1 = []
    for c in range(3):
        den = cm[c].sum()+cm[:, c].sum()
        f1.append(2*cm[c, c]/den if den else 0.)
    recall = np.diag(cm)/cm.sum(axis=1)
    return {'macro_f1': float(np.mean(f1)), 'balanced_accuracy': float(recall.mean()),
            'nll': float(-np.log(np.clip(p[np.arange(len(y)), y], np.finfo(np.float64).eps, 1.)).mean()),
            'multiclass_brier': float(np.square(p-np.eye(3)[y]).sum(axis=1).mean()),
            'recall_H': float(recall[0]), 'recall_I': float(recall[1]), 'recall_O': float(recall[2])}


def run(root):
    hashes, reports, errors = {}, [], []
    for spec_index, (pred_name, summary_name, keys, label_col, unit, expected_n, pooled_only) in enumerate(SPECS):
        pred_path, summary_path = root/pred_name, root/summary_name
        pred, saved = pd.read_csv(pred_path), pd.read_csv(summary_path)
        hashes[pred_name], hashes[summary_name] = sha(pred_path), sha(summary_path)
        if pooled_only:
            saved = saved[saved.condition == 'pooled'].copy()
        require_finite(saved, METRICS, summary_name)
        if len(saved) != EXPECTED_GROUPS[spec_index]:
            raise ValueError('Incorrect declared cohort size: '+summary_name)
        if saved.duplicated(keys).any():
            raise ValueError('Duplicate summary keys: '+summary_name)
        rows = []
        for key, data in pred.groupby(keys, sort=True, dropna=False):
            if len(data) != expected_n or data[unit].nunique() != expected_n:
                raise ValueError('Wrong independent/source-unit denominator: '+pred_name)
            key = key if isinstance(key, tuple) else (key,)
            rows.append(dict(zip(keys, key)) | metrics(data[label_col].to_numpy(int), data[['p_H', 'p_I', 'p_O']].to_numpy(float)))
        replay = pd.DataFrame(rows)
        joined = saved.merge(replay, on=keys, suffixes=('_saved', '_replay'), validate='one_to_one')
        if len(joined) != len(saved) or len(joined) != len(replay):
            raise ValueError('Missing or extra metric groups: '+pred_name)
        differences = {}
        for metric in METRICS:
            differences[metric] = float(np.max(np.abs(joined[metric+'_saved']-joined[metric+'_replay'])))
        maximum = max(differences.values())
        if maximum > 2e-12:
            errors.append({'source': pred_name, 'metric_differences': differences})
        reports.append({'source': pred_name, 'prediction_rows': len(pred), 'metric_groups': len(replay),
                        'unit': unit, 'units_per_group': expected_n, 'maximum_metric_difference': maximum})
    # All 216 omission endpoints, then all 72 means and eight min/max summaries.
    bearing = pd.read_csv(root/'results/v7/paderborn_specimen/bearing_predictions.csv')
    deletion_path = root/'results/v8/deletion_sensitivity/deletion_points.csv'
    endpoints = pd.read_csv(deletion_path)
    require_finite(endpoints, ['seed', 'full_nine_bearing_f1', 'deleted_bearing_f1',
        'remaining_bearings', 'difference_from_primary', 'deleted_class', 'full_correct_bearings'], str(deletion_path))
    hashes[str(deletion_path.relative_to(root))] = sha(deletion_path)
    keys = ['representation', 'model', 'seed', 'timing']
    expected_ids = {'K004', 'K005', 'K006', 'KI16', 'KI18', 'KI21', 'KA15', 'KA16', 'KA30'}
    if len(endpoints) != 216 or endpoints.duplicated(keys+['deleted_bearing']).any():
        raise ValueError('Deletion endpoints must be 216 distinct group/bearing omissions')
    omission_groups = list(endpoints.groupby(keys, dropna=False))
    if len(omission_groups) != 24 or any(set(part.deleted_bearing) != expected_ids or len(part) != 9 for _, part in omission_groups):
        raise ValueError('Every deletion group must contain each of the nine bearing omissions exactly once')
    deletion_error = 0.
    for _, row in endpoints.iterrows():
        group = bearing.copy()
        for k in keys:
            group = group[group[k] == row[k]]
        if len(group) != 9 or group.bearing_id.nunique() != 9:
            raise ValueError('Deletion source must retain nine bearing IDs')
        kept = group[group.bearing_id != row.deleted_bearing]
        if len(kept) != 8 or int(row.remaining_bearings) != 8:
            raise ValueError('Deletion must remove exactly one bearing')
        removed = group[group.bearing_id == row.deleted_bearing]
        if len(removed) != 1 or int(removed.class_id.iloc[0]) != row.deleted_class:
            raise ValueError('Omitted bearing label mismatch')
        primary = metrics(group.class_id.to_numpy(int), group[['p_H', 'p_I', 'p_O']].to_numpy(float))['macro_f1']
        value = metrics(kept.class_id.to_numpy(int), kept[['p_H', 'p_I', 'p_O']].to_numpy(float))['macro_f1']
        deletion_error = max(deletion_error, abs(primary-row.full_nine_bearing_f1), abs(value-row.deleted_bearing_f1))
        deletion_error = max(deletion_error, abs(value-primary-row.difference_from_primary))
        correct = int((group[['p_H', 'p_I', 'p_O']].to_numpy(float).argmax(axis=1) == group.class_id.to_numpy(int)).sum())
        if correct != row.full_correct_bearings:
            raise ValueError('Incorrect count of primary correctly classified bearings')
    mean_keys = ['representation', 'model', 'timing', 'deleted_bearing']
    means = endpoints.groupby(mean_keys, as_index=False).agg(primary_f1=('full_nine_bearing_f1', 'mean'), deletion_f1=('deleted_bearing_f1', 'mean'))
    mean_path = root/'results/v8/deletion_sensitivity/seed_averaged_deletion_points.csv'
    saved_means = pd.read_csv(mean_path)
    require_finite(saved_means, ['primary_f1', 'deletion_f1'], str(mean_path))
    m = means.merge(saved_means, on=mean_keys, validate='one_to_one', suffixes=('_replay', '_saved'))
    if not (len(m) == len(means) == len(saved_means) == 72):
        raise ValueError('There must be 72 complete seed-averaged omission endpoints')
    deletion_error = max(deletion_error, float(np.max(np.abs(m.deletion_f1_replay-m.deletion_f1_saved))),
                         float(np.max(np.abs(m.primary_f1_replay-m.primary_f1_saved))))
    summary = means.groupby(['representation', 'model', 'timing'], as_index=False).agg(
        primary_f1=('primary_f1', 'first'), deletion_min=('deletion_f1', 'min'), deletion_max=('deletion_f1', 'max'))
    summary_path = root/'results/v8/deletion_sensitivity/summary.csv'
    saved_summary = pd.read_csv(summary_path)
    require_finite(saved_summary, ['primary_f1', 'deletion_min', 'deletion_max'], str(summary_path))
    s = summary.merge(saved_summary, on=['representation', 'model', 'timing'], validate='one_to_one', suffixes=('_replay', '_saved'))
    if not (len(s) == len(summary) == len(saved_summary) == 8):
        raise ValueError('There must be eight deletion summaries')
    for name in ['primary_f1', 'deletion_min', 'deletion_max']:
        deletion_error = max(deletion_error, float(np.max(np.abs(s[name+'_replay']-s[name+'_saved']))))
    if deletion_error > 2e-12:
        errors.append({'source': 'deletion diagnostic', 'maximum_metric_difference': deletion_error})
    for path in [mean_path, summary_path]:
        hashes[str(path.relative_to(root))] = sha(path)
    result = {'passed': not errors, 'scope': 'offline arithmetic replay of saved three-class predictions and V8 deletion diagnostic; no raw-signal or model replay',
              'datasets': reports, 'metric_groups_recomputed': sum(r['metric_groups'] for r in reports),
              'deletion_endpoints_recomputed': len(endpoints), 'deletion_maximum_metric_difference': deletion_error,
              'seed_averaged_deletion_endpoints': len(m), 'deletion_summaries': len(s),
              'input_sha256': hashes, 'errors': errors}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument('--output', type=Path, help='Optional audit JSON; no files written by default')
    args = parser.parse_args()
    result = run(args.root.resolve())
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2), flush=True)
    raise SystemExit(0 if result['passed'] else 1)


if __name__ == '__main__':
    main()
