"""Supplement: three fixed noise realizations, no additional model fitting."""
from pathlib import Path
import json,hashlib
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import pandas as pd
import numpy as np
import fitz
from PIL import Image
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'figures/v7'
FAMILIES=['awgn','colored','impulse','tone'];LABELS=['Gaussian −4 dB','Colored −4 dB','Impulse −4 dB','Tone −4 dB']
METHODS=[('v6','clean_ce','Clean CE','#666666'),('v6','awgn_ce','AWGN CE','#D55E00'),('v6','response_ce','Response CE','#009E73'),('v6','response_jsd','Response JSD','#CC79A7'),('v7','mixed_erm','MixERM (omitted)','#0072B2'),('v7','mixed_dro','MixDRO (omitted)','#E69F00')]
SEEDS=[11,22,33];DRAWS=[7201,7202,7203]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 path=ROOT/'results/v7/noise_sensitivity/pooled_summary.csv';audit=ROOT/'docs/v7/noise_sensitivity_independent_audit.json';assert json.loads(audit.read_text())['passed']
 allresults=pd.read_csv(path);rows=[]
 for study,arm,label,color in METHODS:
  for family in FAMILIES:
   frame=allresults[(allresults.study==study)&(allresults.arm==arm)&(allresults.family==family)]
   if study=='v7':frame=frame[frame.excluded==family]
   assert len(frame)==9 and frame.n_records.eq(21).all()
   for r in frame.to_dict('records'):
    for metric in ['macro_f1','recall_H']:rows.append({'method':label,'study':study,'arm':arm,'family':family,'seed':r['seed'],'draw':r['draw'],'metric':metric,'value':r[metric],'n_source_files':21,'n_healthy_source_files':5,'omitted_family_endpoint':study=='v7'})
 source=pd.DataFrame(rows);assert len(source)==432;stem=OUT/'fig_noise_realization_sensitivity';source.to_csv(stem.with_suffix('.source.csv'),index=False)
 plt.rcParams.update({'font.family':'Arial','font.size':7.2,'axes.linewidth':.6,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,'legend.frameon':False,'xtick.labelsize':7.,'ytick.labelsize':7.})
 fig,axes=plt.subplots(4,2,figsize=(6.692913385826772,5.905511811023622));fig.subplots_adjust(left=.27,right=.98,top=.82,bottom=.075,hspace=.65,wspace=.2)
 fig.text(.03,.98,'Sensitivity to three new noise realizations',fontsize=8.5,va='top');fig.text(.03,.94,'Frozen checkpoints; the same 21 measured files in every pooled point',fontsize=7.2,va='top')
 handles=[Line2D([],[],color='#444444',marker=marker,markerfacecolor='white',markeredgewidth=.6,markersize=3,linestyle='none',label=f'Algorithm seed {seed}') for seed,marker in zip(SEEDS,['o','s','^'])]
 fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.02,.918),ncol=3,fontsize=7.,handletextpad=.4,columnspacing=1.,borderaxespad=0.)
 fig.text(.43,.86,'Record macro-F1',ha='center',fontsize=8.);fig.text(.83,.86,'Healthy recall',ha='center',fontsize=8.)
 for fi,(family,label) in enumerate(zip(FAMILIES,LABELS)):
  for col,metric in enumerate(['macro_f1','recall_H']):
   ax=axes[fi,col]
   for mi,(_,_,method,color) in enumerate(METHODS):
    for seed,offset,marker in zip(SEEDS,[-.23,0.,.23],['o','s','^']):
     subset=source[(source.method==method)&(source.family==family)&(source.metric==metric)&(source.seed==seed)].sort_values('draw');values=subset.value.to_numpy();y=5-mi+offset
     ax.plot([values.min(),values.max()],[y,y],color=color,lw=.65)
     for value,delta in zip(values,[-.05,0.,.05]):ax.plot(value,y+delta,marker=marker,color=color,markerfacecolor='white',markersize=2.4,markeredgewidth=.55,linestyle='none')
   ax.set_xlim(-.04,1.04);ax.set_xticks([0,.5,1]);ax.set_ylim(-.65,5.65);ax.set_yticks(np.arange(6)[::-1]);ax.set_yticklabels([m[2] for m in METHODS] if col==0 else []);ax.spines['left'].set_visible(False);ax.tick_params(axis='y',length=0,pad=4.);ax.tick_params(axis='x',length=2.,pad=2.);ax.grid(axis='x',color='#E6E6E6',lw=.5);ax.axhline(1.5,color='#AAAAAA',ls=(0,(2,2)),lw=.6);ax.set_title(f'{chr(97+2*fi+col)}  {label}',loc='left',fontsize=7.6,fontweight='bold',pad=5.)
 fig.text(.03,.022,'Three draws per algorithm seed; line = observed draw range, not a population CI.',fontsize=7.,va='bottom')
 fig.savefig(stem.with_suffix('.pdf'),facecolor='white',bbox_inches=None)
 fig.savefig(stem.with_suffix('.svg'),facecolor='white',bbox_inches=None)
 fig.savefig(stem.with_suffix('.png'),dpi=300,facecolor='white',bbox_inches=None);plt.close(fig)
 caption=('Supplementary Fig. S7 | Variation across additional synthetic-noise realizations. The same fixed v6 and v7 checkpoints are evaluated without fitting, checkpoint selection or calibration. Panels a,c,e,g show record macro-F1 and b,d,f,h show healthy recall for Gaussian, colored Gaussian, sparse impulse and sinusoidal interference at −4 dB. Each row has three algorithm seeds (circle, square, triangle), each with three new noise draws; points retain all draws and short horizontal segments span the three draw values within an algorithm seed. Small vertical offsets distinguish coincident marks. All pooled points use the same 21 source files, including five healthy files. Algorithm seeds and noise draws are computational variation, not independent bearings or physical-population confidence intervals. The four upper rows are frozen v6 procedures with their original training and selection histories. In each lower row and family column, the displayed v7 MixERM or MixDRO model is the separately trained procedure that omitted that complete family during fitting and used clean-only validation. Thus no single universal omitted-family model is implied. The remaining seen-family v7 endpoints are retained in the complete source results, but not pooled into this omitted-family plot. All four families had been inspected historically, so this remains a retrospective sensitivity study. New draw labels are7201,7202,7203 with family-specific SeedSequence initialization; historical fixed panels remain separate. No model parameter or BatchNorm buffer changes during evaluation; no new measured sample or physical independence is introduced.')
 stem.with_suffix('.caption.txt').write_text(caption.replace('are7201','are 7201')+'\n',encoding='utf-8');stem.with_suffix('.alt.txt').write_text('Eight dot plots show macro-F1 and healthy recall for six fixed diagnostic procedures across four noise families. Every algorithm seed has three new noise realizations. Within-seed ranges describe noise variation. Mixed-noise models are shown only on the family each omitted in training. Strong Gaussian results do not guarantee robust colored, impulse or sinusoidal results; healthy misses remain visible.\n',encoding='utf-8')
 with fitz.open(stem.with_suffix('.pdf')) as pdf:
  page=pdf[0];spans=[s for b in page.get_text('dict')['blocks'] if b.get('type')==0 for line in b['lines'] for s in line['spans']];minimum=min(s['size'] for s in spans);clipped=[s['text'] for s in spans if s['bbox'][0]<-.1 or s['bbox'][1]<-.1 or s['bbox'][2]>page.rect.width+.1 or s['bbox'][3]>page.rect.height+.1];width=page.rect.width*25.4/72;height=page.rect.height*25.4/72;assert minimum>=6.99 and not clipped
 with Image.open(stem.with_suffix('.png')) as im:
  png={'size':list(im.size),'dpi':list(im.info.get('dpi',[]))};assert im.mode!='RGBA' or im.getextrema()[-1]==(255,255)
 report={'passed':True,'width_mm':width,'height_mm':height,'minimum_pdf_font_pt':minimum,'out_of_page_text':clipped,'png':png,'source_rows':len(source),'all_displayed_draws_retained':True,'historical_fixed_draws_pooled':False,'visual_review':'pending actual rendered inspection','inputs_sha256':{str(p.relative_to(ROOT)):sha(p) for p in [path,audit,Path(__file__)]},'output_sha256':{p.name:sha(p) for p in OUT.glob(stem.name+'.*') if p.suffix!='json'}}
 stem.with_suffix('.qa.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if 'sha256' not in k},indent=2))
if __name__=='__main__':main()
