"""Restyle frozen information-retention and internal-control figures only.

All scientific values come from retained V3/V4 figure source tables. No fitting,
bootstrap, signal selection, filtering, PSD or feature computation is rerun.
"""
from pathlib import Path
import hashlib
import json
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
import fitz
import numpy as np
import pandas as pd
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'figures/v7'
WIDTH = 170 / 25.4
COL = {'native': '#666666', 'time': '#D55E00', 'order': '#0072B2', 'metadata': '#009E73'}
STYLE = {'font.family': 'Arial', 'font.size': 7.2, 'axes.labelsize': 7.4,
         'axes.titlesize': 8., 'xtick.labelsize': 7.2, 'ytick.labelsize': 7.2,
         'legend.fontsize': 7.1, 'axes.linewidth': .6, 'lines.linewidth': .8,
         'axes.spines.top': False, 'axes.spines.right': False, 'pdf.fonttype': 42,
         'svg.fonttype': 'none', 'figure.facecolor': 'white', 'axes.facecolor': 'white',
         'savefig.facecolor': 'white', 'legend.frameon': False}


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def panel(ax, letter, title):
    ax.set_title(f'{letter}  {title}', loc='left', fontsize=8., fontweight='bold', pad=7.)
    ax.tick_params(length=2.5, width=.6, pad=3.)


def plain_log_ticks(ax, axis, values, labels):
    obj = ax.xaxis if axis == 'x' else ax.yaxis
    obj.set_major_locator(FixedLocator(values)); obj.set_major_formatter(FixedFormatter(labels))
    obj.set_minor_locator(NullLocator())


def save(fig, stem, caption, alt, sources, details):
    fig.canvas.draw(); renderer = fig.canvas.get_renderer()
    text_overlaps = []
    for i, ax in enumerate(fig.axes):
        for tickset in [ax.get_xticklabels(), ax.get_yticklabels()]:
            visible = [t for t in tickset if t.get_visible() and t.get_text()]
            for left, right in zip(visible, visible[1:]):
                if left.get_window_extent(renderer).overlaps(right.get_window_extent(renderer)):
                    text_overlaps.append({'axis': i, 'labels': [left.get_text(), right.get_text()]})
    if text_overlaps: raise RuntimeError(text_overlaps)
    base = OUT / stem
    for ext in ['pdf', 'svg', 'png']:
        fig.savefig(base.with_suffix('.' + ext), dpi=300, bbox_inches=None, facecolor='white')
    plt.close(fig)
    base.with_suffix('.caption.txt').write_text(caption + '\n', encoding='utf-8')
    base.with_suffix('.alt.txt').write_text(alt + '\n', encoding='utf-8')
    copied = []
    for key, source in sources.items():
        target = OUT / f'{stem}.source_{key}.csv'
        shutil.copyfile(source, target)
        assert sha(target) == sha(source)
        copied.append({'path': target.relative_to(ROOT).as_posix(), 'sha256': sha(target), 'source': source.relative_to(ROOT).as_posix()})
    with fitz.open(base.with_suffix('.pdf')) as pdf:
        page = pdf[0]
        spans = [s for b in page.get_text('dict')['blocks'] if b.get('type') == 0 for line in b['lines'] for s in line['spans']]
        minimum = min(s['size'] for s in spans)
        clipped = [s['text'] for s in spans if s['bbox'][0] < -.1 or s['bbox'][1] < -.1 or s['bbox'][2] > page.rect.width + .1 or s['bbox'][3] > page.rect.height + .1]
        width = page.rect.width * 25.4 / 72; height = page.rect.height * 25.4 / 72
        fonts = sorted({s['font'] for s in spans})
    assert abs(width - 170) < .01 and minimum >= 6.99 and not clipped, (width, minimum, clipped)
    assert all('Arial' in font for font in fonts), fonts
    with Image.open(base.with_suffix('.png')) as image:
        png = {'size': list(image.size), 'dpi': list(image.info.get('dpi', [])), 'mode': image.mode}
        if image.mode == 'RGBA': assert image.getextrema()[-1] == (255, 255)
    report = {'passed': True, 'target': 'General manuscript figure; no journal selected',
              'width_mm': width, 'height_mm': height, 'pdf_min_font_pt': minimum,
              'pdf_fonts': fonts, 'out_of_page_text': clipped, 'tick_label_overlaps': text_overlaps,
              'png': png, 'source_tables': copied, 'scientific_changes': 'none; frozen tables reused byte-for-byte',
              'script_path': Path(__file__).relative_to(ROOT).as_posix(), 'script_sha256': sha(Path(__file__)),
              'input_sha256': {p.relative_to(ROOT).as_posix(): sha(p) for p in sources.values()},
              'outputs_sha256': {base.with_suffix('.' + e).name: sha(base.with_suffix('.' + e)) for e in ['pdf', 'svg', 'png', 'caption.txt', 'alt.txt']},
              'visual_review': 'pending full-size rendered inspection', **details}
    base.with_suffix('.qa.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps({k: report[k] for k in ['width_mm', 'height_mm', 'pdf_min_font_pt', 'pdf_fonts', 'out_of_page_text']}), flush=True)


def bandwidth():
    parent = ROOT / 'figures/v3/source_data'
    sources = {key: parent / f'fig03_{name}.csv' for key, name in [('psd', 'raw_psd'), ('filters', 'filter_responses'), ('spectra', 'envelope_spectra'), ('rms', 'group_envelope_rms')]}
    psd, filters, spectra, rms = [pd.read_csv(sources[key]) for key in ['psd', 'filters', 'spectra', 'rms']]
    assert [len(psd), len(filters), len(spectra), len(rms)] == [51201, 15000, 2050, 237]
    audit = json.loads((ROOT / 'data/processed/v3/preprocessing_audit.json').read_text(encoding='utf-8'))
    fig, axs = plt.subplots(2, 2, figsize=(WIDTH, 143 / 25.4))
    fig.subplots_adjust(left=.115, right=.985, bottom=.12, top=.94, wspace=.36, hspace=.54)
    ax = axs[0, 0]; panel(ax, 'a', 'Native carrier spectrum')
    ax.semilogy(psd.frequency_hz, np.maximum(psd.psd_g2_per_hz, 1e-14), color=COL['native'], lw=.5, rasterized=False)
    for low, high in [(500, 2000), (2000, 5000), (5000, 10000)]: ax.axvspan(low, high, color=COL['time'], alpha=.08)
    ax.axvline(180, color='black', ls='--', lw=.7)
    ax.set(xlim=(0, 11000), ylim=(1e-13, .03), xlabel='Frequency (kHz)', ylabel='PSD (g²/Hz)')
    ax.set_xticks([0, 5000, 10000], ['0', '5', '10'])
    plain_log_ticks(ax, 'y', [1e-12, 1e-9, 1e-6, 1e-3], ['1e-12', '1e-9', '1e-6', '1e-3'])
    ax.text(.97, .96, 'Dashed: 180-Hz cutoff', ha='right', va='top', transform=ax.transAxes, fontsize=7.)
    ax = axs[0, 1]; panel(ax, 'b', 'Zero-phase filter responses')
    filter_meta = [('Raw LP 180', COL['native'], '--', 'Raw LP: 180 Hz'), ('Carrier', COL['time'], '-', 'Carrier: 2–5 kHz'), ('Envelope', COL['order'], '-.', 'Envelope LP: 1 kHz')]
    for start, color, style, label in filter_meta:
        data = filters[filters['filter'].str.startswith(start)]
        assert len(data) == 5000
        ax.plot(data.frequency_hz, data.zero_phase_amplitude_db, color=color, ls=style, label=label)
    ax.set(xscale='log', xlim=(20, 12000), ylim=(-100, 3), xlabel='Frequency (Hz)', ylabel='Amplitude gain (dB)', yticks=[-100, -50, 0])
    plain_log_ticks(ax, 'x', [20, 100, 1000, 10000], ['20', '100', '1,000', '10,000'])
    ax.legend(loc='lower left', fontsize=7., handlelength=2., borderaxespad=.35, labelspacing=.3,
              frameon=True, facecolor='white', edgecolor='none', framealpha=.96)
    ax = axs[1, 0]; panel(ax, 'c', 'Same envelope, two coordinates')
    for rep, color, style, label in [('time_envelope', COL['time'], '-', 'Time: mean-speed equivalent'), ('order_envelope', COL['order'], '--', 'Order: measured integration')]:
        data = spectra[spectra.representation == rep]
        ax.plot(data.order, data.normalized_bin_energy, color=color, ls=style, lw=.85, label=label)
    for name in ['bpfo', 'bpfi']:
        for harmonic in [1, 2, 3]: ax.axvline(audit['characteristic_orders'][name] * harmonic, color='black', ls=':', lw=.6, alpha=.6)
    ax.set(xlim=(0, 20), ylim=(-.005, .173), xlabel='Cycles per shaft revolution', ylabel='Fraction of spectral energy', xticks=[0, 10, 20], yticks=[0, .08, .16])
    ax.legend(loc='upper right', fontsize=7., handlelength=1.6, handletextpad=.4, labelspacing=.3,
              frameon=True, facecolor='white', edgecolor='none', framealpha=.96)
    ax = axs[1, 1]; panel(ax, 'd', 'Envelope support: all sources')
    bands = ['time_envelope__b500_2000__rms', 'time_envelope__b2000_5000__rms', 'time_envelope__b5000_10000__rms']
    for j, band in enumerate(bands):
        values = rms[rms.band == band].mean_envelope_rms_g.to_numpy()
        assert len(values) == 79 and np.isfinite(values).all() and (values > 0).all()
        x = np.full(len(values), j) + np.linspace(-.1, .1, len(values))
        ax.scatter(x, values, s=7, color=COL['time'], alpha=.45, edgecolors='none')
        ax.plot([j-.17, j+.17], [np.median(values)]*2, color='black', lw=.9)
    ax.set(xlim=(-.5, 2.5), ylim=(.02, 2.2), yscale='log', xticks=[0, 1, 2], xticklabels=['0.5–2', '2–5', '5–10'], xlabel='Carrier band (kHz)', ylabel='Mean envelope RMS (g)')
    plain_log_ticks(ax, 'y', [.03, .1, .3, 1.], ['0.03', '0.1', '0.3', '1.0'])
    caption = ('Fig. 3 | Retaining carrier information before forming a compact input. '
               '(a) Native vibration PSD from the full four-second source of the lexicographically first inner-positive interval, novic_E_008_turn00_08_physical_v3, selected without its prediction. The shaded ranges are the three carrier bands; the dashed line marks the 180-Hz raw low-pass cutoff. '
               '(b) Declared zero-phase filter amplitude responses. Forward–backward gain is the square of the single-pass magnitude; responses below −100 dB are outside the displayed scale, with every value retained in Source Data. '
               '(c) Fixed 2–5-kHz carrier envelopes from the identical eight-turn physical interval, represented using mean-speed-equivalent time and integrated measured order. Dotted lines are ideal BPFO/BPFI harmonics, not identified measured fault peaks. '
               '(d) Mean envelope RMS for all 79 inferred recording proxies in each band; black segments denote medians. Small deterministic horizontal offsets separate points and do not alter values. These are recording proxies, not independently verified bearings. '
               'The original low-band input contains 256 points and the envelopes 2,048; the figure does not imply equal input capacity or isolate bandwidth as a causal effect. Frozen V3 source tables are reused unchanged; no signal selection, transformation, model or bootstrap was rerun for this restyling.')
    alt = ('Four panels show native measured carrier PSD, declared zero-phase filter responses, the same interval in time and measured-order coordinates, and every one of 79 recording-proxy envelope amplitudes in three carrier bands. Carrier information extends beyond the 180-Hz raw cutoff; retained envelope amplitudes vary widely. Ideal harmonic guides are illustrative, and source identities and input sizes limit interpretation.')
    save(fig, 'fig_bandwidth_controls', caption, alt, sources,
         {'panels': 4, 'source_row_counts': {k: len(pd.read_csv(p)) for k, p in sources.items()},
          'uncertainty': 'No inferential interval; all79 recording proxies and band medians shown',
          'additional_input_sha256': {'data/processed/v3/preprocessing_audit.json': sha(ROOT / 'data/processed/v3/preprocessing_audit.json')}})


def internal():
    parent = ROOT / 'figures/v4/source_data'
    sources = {'intervals': parent / 'fig04_strong_baselines_intervals.csv', 'all_seed_summaries': parent / 'fig04_strong_baselines_all_seed_summaries.csv'}
    data = pd.read_csv(sources['intervals']); summary = pd.read_csv(sources['all_seed_summaries'])
    assert len(data) == 64 and len(summary) == 96
    assert data.seed.eq(11).all() and data.n_records.eq(79).all() and data.n_states.eq(33).all() and data.bootstrap_draws.eq(2000).all()
    reps = ['metadata_only', 'native_fullband', 'time_envelope', 'time_envelope_meta', 'order_generic', 'order_generic_meta', 'order_geometry', 'mfos_repository']
    names = ['Metadata (8)', 'Native raw (25)', 'Time envelope (111)', 'Time env. + meta (119)', 'Order envelope (99)', 'Order env. + meta (107)', 'Order + geometry (180)', 'Repository (856)']
    colors = ['#009E73', '#666666', '#D55E00', '#E69F00', '#56B4E9', '#0072B2', '#CC79A7', '#000000']
    models = [('extra_trees', 'Extra Trees'), ('random_forest', 'Random forest'), ('state_calibrated_svm', 'RBF SVM'), ('logistic', 'Logistic regression')]
    tasks = ['inner_presence', 'outer_presence']
    fig, axs = plt.subplots(2, 2, figsize=(WIDTH, 145 / 25.4), sharex=True, sharey=True)
    fig.subplots_adjust(left=.285, right=.98, bottom=.155, top=.94, wspace=.25, hspace=.35)
    for k, (model, title) in enumerate(models):
        ax = axs.flat[k]; panel(ax, chr(97+k), title)
        for ti, task in enumerate(tasks):
            for ri, rep in enumerate(reps):
                rows = data[(data.model == model) & (data.task == task) & (data.representation == rep)]
                assert len(rows) == 1
                row = rows.iloc[0]; y = ri + (ti-.5)*.24
                ax.plot([row.low, row.high], [y, y], color=colors[ri], lw=.9)
                ax.scatter(row.estimate, y, marker=['o', '^'][ti], s=18, color=colors[ri], edgecolors='black', linewidths=.35, zorder=4)
        ax.set(xlim=(-.035, 1.035), ylim=(7.5, -.5), yticks=np.arange(8), xticks=[0, .5, 1.], xticklabels=['0', '0.5', '1.0'])
        if k % 2 == 0: ax.set_yticklabels(names)
        ax.tick_params(axis='y', length=0, pad=5.)
        ax.grid(axis='x', color='#E5E5E5', lw=.5); ax.set_axisbelow(True)
        if k >= 2: ax.set_xlabel('Unknown-state record macro-F1', labelpad=5.)
    legend = [Line2D([], [], ls='none', marker=marker, color='black', markersize=4., label=label) for marker, label in [('o', 'Inner presence'), ('^', 'Outer presence')]]
    fig.legend(handles=legend, loc='lower center', bbox_to_anchor=(.59, .035), ncol=2, fontsize=7.2, handletextpad=.45, columnspacing=1.3)
    caption = ('Fig. 4 | Unknown-state performance with adequate raw bandwidth and four classifier families. '
               'Panels a–d contain every frozen seed-11 estimate and interval for eight representations and the Extra Trees, random forest, RBF SVM and logistic classifiers. Circles indicate inner-fault presence and triangles outer-fault presence; horizontal offsets are not used. Numbers in representation labels are feature counts. '
               'Horizontal segments are 95% conditional percentile intervals from 2,000 joint-inner/outer-label-stratified state-cluster bootstrap draws over 33 states, retaining all recording proxies within each sampled state. They condition on the fixed selected models, split and inferred acquisition grouping and do not resample training, hyperparameter selection or independent physical bearings. All 79 unknown-state out-of-fold recording proxies contribute once to each pooled estimate. '
               'Observed perfect predictions can produce degenerate intervals and do not establish population certainty. Native raw retains variable native point counts and is an adequate-bandwidth baseline, not an equal-point-budget control. The 856-feature repository implementation is exploratory. SVM retains the frozen window-sigmoid-then-record-average rule; the disclosed post hoc record-score aggregation sensitivity remains separate. '
               'Source Data retain all 64 displayed estimate/interval rows and all 96 previously computed seed-summary rows. Only presentation is revised; no bootstrap, model fitting, selection, interval or result was recomputed.')
    alt = ('Four aligned forest plots show all eight representations with two fault-presence tasks for each of four classifier families. Full-band raw and envelope features produce strong unknown-state performance, while metadata-only estimates are weaker. Native raw and compressed envelopes use different input budgets. The error segments describe conditional state-cluster resampling rather than independent-bearing uncertainty.')
    save(fig, 'fig_internal_controls', caption, alt, sources,
         {'panels': 4, 'displayed_estimates': 64, 'retained_seed_summary_rows': 96,
          'classifier_families': 4, 'representations': 8, 'fault_presence_tasks': 2,
          'uncertainty': '95% conditional percentile intervals; frozen2000 joint-label-stratified state-cluster draws; no new bootstrap'})


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    with plt.rc_context(STYLE): bandwidth(); internal()


if __name__ == '__main__': main()
