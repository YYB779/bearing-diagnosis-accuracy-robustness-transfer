"""Independent read-only artifact and probability audit for matched controls."""
from pathlib import Path
import hashlib
import json
import joblib
import numpy as np
import pandas as pd
from scripts.v7.run_matched_classical import extract_features
from scripts.v6.consistency import test_panels

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/v7/classical'
DEST=ROOT/'docs/v7/classical_independent_audit.json'
PROBS=['p_H','p_I','p_O']


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def direct_metrics(frame):
    y=frame.class_id.to_numpy(int);p=frame[PROBS].to_numpy(float);pred=p.argmax(1)
    cm=np.zeros((3,3),int)
    for true,guess in zip(y,pred):cm[true,guess]+=1
    f1=[]
    for k in range(3):
        d=cm[k].sum()+cm[:,k].sum();f1.append(2*cm[k,k]/d if d else 0.)
    recall=np.diag(cm)/cm.sum(1)
    return {'macro_f1':float(np.mean(f1)),'balanced_accuracy':float(np.mean(recall)),
        'nll':float(-np.log(np.clip(p[np.arange(len(y)),y],np.finfo(float).eps,1.)).mean()),
        'multiclass_brier':float(np.mean(np.sum((p-np.eye(3)[y])**2,axis=1))),
        **dict(zip(['recall_H','recall_I','recall_O'],map(float,recall)))}


def main():
    DEST.write_text(json.dumps({'passed':False,'status':'audit running'}),encoding='utf-8')
    frozen=json.loads((OUT/'design.json').read_text(encoding='utf-8'))
    runtime=json.loads((OUT/'audit.json').read_text(encoding='utf-8'))
    hashes={**frozen['sha256'],**runtime['sha256']}
    for relative,expected in hashes.items():assert sha(ROOT/relative)==expected,relative
    lineage=pd.read_csv(ROOT/'data/processed/v5/hust_neural_patch_lineage.csv')
    x=np.load(ROOT/'data/processed/v5/hust_neural_patches.npz',allow_pickle=False)['x']
    panels=test_panels(x)
    features={(representation,panel):extract_features(values,representation)[0]
        for representation in ['native25','shape25'] for panel,values in panels.items()}
    records=pd.read_csv(OUT/'record_predictions.csv');pooled=pd.read_csv(OUT/'pooled_summary.csv')
    candidate=json.loads((OUT/'candidate_validation.json').read_text(encoding='utf-8'))
    assert len(candidate)==270 and len(pooled)==72 and len(records)==1512
    maxprob=0.;maxmetric=0.;models=0;cells=0;patch_count=0
    for metadata_path in sorted((OUT/'runs').glob('*/metadata.json')):
        m=json.loads(metadata_path.read_text(encoding='utf-8'));run=metadata_path.parent
        train=set(m['train_source_records']);val=set(m['validation_source_records']);test=set(m['test_source_records'])
        assert not train&val and not train&test and not val&test
        local=json.loads((run/'candidate_validation.json').read_text(encoding='utf-8'))
        winner=min(local,key=lambda row:(-row['macro_f1'],row['nll'],row['config_index']))
        assert winner['config_index']==m['selected_config_index']
        for row in local:
            assert row['warnings']==[]
            frame=pd.DataFrame(row['validation_predictions']);metrics=direct_metrics(frame)
            assert set(frame.source_record)==val
            for key,value in metrics.items():maxmetric=max(maxmetric,abs(row[key]-value))
        model=joblib.load(run/'selected_model.joblib');models+=1
        patches=pd.read_csv(run/'patch_test_predictions.csv');saved=pd.read_csv(run/'record_test_predictions.csv')
        for panel,part in patches.groupby('panel',sort=False):
            expected=lineage[lineage.source_record.isin(test)]
            assert part.patch_id.tolist()==expected.patch_id.tolist()
            assert part.class_id.tolist()==expected.class_id.tolist()
            index=np.flatnonzero(lineage.source_record.isin(test).to_numpy())
            new=model.predict_proba(features[(m['representation'],panel)][index])
            maxprob=max(maxprob,float(np.max(np.abs(new-part[PROBS].to_numpy(float)))))
            for source,g in part.groupby('source_record'):
                assert len(g)==32 and g.class_id.nunique()==1
                pp=g[PROBS].to_numpy(float).mean(0);pp/=pp.sum()
                savedp=saved[(saved.panel==panel)&(saved.source_record==source)][PROBS].to_numpy(float)
                assert savedp.shape==(1,3)
                maxprob=max(maxprob,float(np.max(np.abs(pp-savedp[0]))))
            cells+=1;patch_count+=len(part)
    for row in pooled.to_dict(orient='records'):
        mask=np.ones(len(records),bool)
        for key in ['representation','family','seed','panel']:mask&=records[key].eq(row[key]).to_numpy()
        frame=records[mask];assert len(frame)==21 and frame.source_record.nunique()==21
        for key,value in direct_metrics(frame).items():maxmetric=max(maxmetric,abs(row[key]-value))
    assert models==60 and cells==360 and patch_count==48384
    assert maxprob<1e-14 and maxmetric<1e-12
    result={'passed':True,'status':'completed fresh independent process audit','checked_sha256_entries':len(hashes),
        'candidate_validation_selections':60,'candidate_fit_metrics_recomputed':270,'selected_models_reopened':models,
        'selected_model_panel_replays':cells,'patch_predictions_replayed':patch_count,'pooled_metric_cells_recomputed':72,
        'max_abs_probability_difference_after_CSV_roundtrip':maxprob,'max_abs_direct_metric_difference':maxmetric,
        'design_sha256':sha(OUT/'design.json'),'training_audit_sha256':sha(OUT/'audit.json'),
        'audit_script_sha256':sha(Path(__file__)),'scope':'Shared frozen feature formulas and noise panels; independent selection and metric arithmetic; no physical-independence claim'}
    DEST.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps(result,indent=2))


if __name__=='__main__':main()
