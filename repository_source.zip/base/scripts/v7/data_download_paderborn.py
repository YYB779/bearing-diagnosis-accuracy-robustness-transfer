"""Download newly reserved Paderborn specimens from an identified third-party deposit.

The Zenodo depositor is not the original data producer. All archives are checked
against the bundled MD5, SHA-256 and byte count; no claim of official mirroring
or independent experimental replication is made.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

import requests


IDS = ("K004", "K005", "K006", "KA15", "KA16", "KA30", "KI16", "KI18", "KI21")
DEV_IDS = ("K001", "K002", "K003", "KA01", "KA04", "KA22", "KI01", "KI04", "KI14")
ALL_IDS = IDS + DEV_IDS
ROOT = Path(__file__).resolve().parents[2]
RAW = ROOT / "data/raw/v7_paderborn"
DOC = ROOT / "docs/v7/data"
API = "https://zenodo.org/api/records/15845309"


def hashes(path):
    md5 = hashlib.md5()
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            md5.update(block)
            sha.update(block)
    return md5.hexdigest(), sha.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", nargs="+", choices=ALL_IDS, default=list(IDS))
    parser.add_argument("--archive-dir", type=Path, default=RAW)
    args = parser.parse_args()
    args.archive_dir.mkdir(parents=True, exist_ok=True)
    expected = {row["bearing_id"]: row for row in
                json.loads((DOC / "download_manifest.json").read_text(encoding="utf-8"))}
    session = requests.Session()
    response = session.get(API, timeout=60)
    response.raise_for_status()
    record = response.json()
    index = {item["key"]: item for item in record["files"]}
    for bearing in args.ids:
        entry = index[f"{bearing}.rar"]
        target = args.archive_dir / entry["key"]
        reference = expected[bearing]
        expected_md5 = entry["checksum"].removeprefix("md5:")
        if entry["size"] != reference["bytes"] or expected_md5 != reference["deposit_md5"]:
            raise RuntimeError(f"Source record differs from the archived checksum manifest: {bearing}")
        if target.exists():
            md5, sha = hashes(target)
            if target.stat().st_size != entry["size"] or md5 != expected_md5 or sha != reference["sha256"]:
                raise RuntimeError(f"Existing archive fails deposit integrity: {target}")
            print(json.dumps({"bearing": bearing, "status": "existing_verified", "sha256": sha}), flush=True)
            continue
        if shutil.disk_usage(args.archive_dir).free < entry["size"] + 1024 ** 3:
            raise RuntimeError("Less than archive size plus 1 GiB remaining; refusing download")
        temporary = target.with_suffix(".rar.part")
        if temporary.exists():
            raise RuntimeError(f"Partial archive requires explicit inspection: {temporary}")
        with session.get(entry["links"]["self"], stream=True, timeout=(30, 120)) as download:
            download.raise_for_status()
            with temporary.open("wb") as stream:
                for block in download.iter_content(2 ** 20):
                    if block:
                        stream.write(block)
        md5, sha = hashes(temporary)
        if temporary.stat().st_size != entry["size"] or md5 != expected_md5 or sha != reference["sha256"]:
            raise RuntimeError(f"Downloaded archive fails deposit integrity: {temporary}")
        temporary.rename(target)
        print(json.dumps({"bearing": bearing, "status": "downloaded_verified",
                          "bytes": target.stat().st_size, "sha256": sha}), flush=True)


if __name__ == "__main__":
    main()
