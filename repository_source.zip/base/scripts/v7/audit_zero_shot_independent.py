"""Independent frozen-model replay and hierarchical external probability audit.

Does not import the external evaluation runner or modify its artifacts. The only
experiment-code import is the frozen architecture; normalization and scoring use
the earlier independent verifier. No fitting, checkpoint selection or calibration.
"""
from __future__ import annotations

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

import numpy as np
import pandas as pd
import torch

from scripts.v5.classbd_models import ClassBDWDCNN
from scripts.v6.analyze_results import normalized_patch, scores, require


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/v7/zero_shot'
MODES = ['nominal', 'timestamp_sensitive']
FAMILIES = ['awgn', 'colored', 'impulse', 'tone']
SEEDS = [11, 22, 33]
IDS = ['K004', 'K005', 'K006', 'KA15', 'KA16', 'KA30', 'KI16', 'KI18', 'KI21']
LABELS = {b: 0 if b.startswith('K00') else 1 if b.startswith('KI') else 2 for b in IDS}
CONDITIONS = {'N09_M07_F10', 'N15_M01_F10', 'N15_M07_F04', 'N15_M07_F10'}
P = ['p_H', 'p_I', 'p_O']


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(2 ** 20), b''): h.update(block)
    return h.hexdigest()


def read(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def specs(cohort):
    if cohort == 'v6':
        for arm in ['clean_ce', 'awgn_ce', 'response_ce', 'response_jsd']:
            for seed in SEEDS:
                for fold in range(5):
                    yield 'none', arm, seed, fold, ROOT / f'results/v6/robustness/fold{fold}_{arm}_s{seed}.pt'
    else:
        for family in FAMILIES:
            for arm in ['mixed_erm', 'mixed_dro']:
                for seed in SEEDS:
                    for fold in range(5):
                        yield family, arm, seed, fold, ROOT / f'results/v7/lofo/{family}_fold{fold}_{arm}_s{seed}.pt'


def check_table(actual, path, keys):
    stored = pd.read_csv(path)
    require(not stored.duplicated(keys).any(), 'Duplicate stored table cell: ' + str(path))
    actual = actual.sort_values(keys).reset_index(drop=True)
    stored = stored.sort_values(keys).reset_index(drop=True)
    require(len(actual) == len(stored), 'Table row count differs: ' + str(path))
    for key in keys: require(actual[key].tolist() == stored[key].tolist(), 'Table key differs: ' + key)
    left, right = actual[P].to_numpy(float), stored[P].to_numpy(float)
    require(np.isfinite(right).all() and (right >= 0).all() and (right <= 1).all(), 'Bad stored probability')
    require(np.max(abs(right.sum(1) - 1)) < 1e-10, 'Stored probability row not normalized')
    delta = float(np.max(abs(left - right)))
    require(delta < 1e-6, 'Independent hierarchy mismatch: ' + str(path))
    return delta


def manual_average(frame, group_keys, normalization=False):
    """Explicit group iteration and NumPy mean, separate from runner aggregation."""
    rows = []
    for key, values in frame.groupby(group_keys, sort=True):
        if not isinstance(key, tuple): key = (key,)
        mean = values[P].to_numpy(np.float64).mean(axis=0)
        if normalization: mean = mean / mean.sum()
        rows.append(dict(zip(group_keys, key)) | dict(zip(P, mean)))
    return pd.DataFrame(rows)


def main():
    torch.set_num_threads(2); torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    audit_path = OUT / 'independent_audit.json'
    audit_path.write_text(json.dumps({'passed': False, 'status': 'running', 'started_utc': datetime.now(timezone.utc).isoformat()}, indent=2), encoding='utf-8')
    xp = ROOT / 'data/processed/v7/paderborn_specimen_test_patches.npz'
    lp = ROOT / 'data/processed/v7/paderborn_specimen_test_patch_lineage.csv'
    source_paths = [xp, lp, Path(__file__), ROOT / 'scripts/v5/classbd_models.py', ROOT / 'scripts/v6/analyze_results.py', ROOT / 'docs/v7/zero_shot_design.md', ROOT / 'docs/v7/zero_shot_deviations.md']
    for cohort in ['v6', 'v7']:
        folder = OUT / cohort
        require((folder / 'audit.json').exists(), 'Producer evaluation still incomplete: ' + cohort)
        producer = read(folder / 'audit.json'); design = read(folder / 'design.json')
        require(producer['passed'] and producer['external_fitting'] is False and producer['external_selection'] is False, 'Producer evaluation not complete')
        require(producer['design_sha256'] == sha(folder / 'design.json'), 'Producer design binding differs')
        require(design['models'] == (60 if cohort == 'v6' else 120), 'Wrong model count')
        for path, digest in design['sha256'].items(): require(sha(ROOT / path) == digest, 'Changed external design input: ' + path)
        source_paths.extend([folder / 'audit.json', folder / 'design.json'])
        for name, digest in producer['output_sha256'].items():
            require(sha(folder / name) == digest, 'Producer output hash mismatch')
            source_paths.append(folder / name)
        for _, _, _, _, model_path in specs(cohort): source_paths.extend([model_path, model_path.with_suffix('.json')])
    raw_rows = []
    for bearing in IDS:
        folder = ROOT / 'data/raw/v7_paderborn/derived_by_specimen' / bearing
        rp = folder / 'records.csv'; ep = folder / 'extraction_audit.json'
        source_paths.extend([rp, ep]); extraction = read(ep)
        entry = next(e for e in extraction['outputs'] if e['path'].endswith('/records.csv'))
        require(sha(rp) == entry['sha256'], 'Raw record metadata changed')
        frame = pd.read_csv(rp); require(set(frame.bearing_id) == {bearing} and set(frame.label) == {LABELS[bearing]}, 'Raw class mapping disagrees')
        raw_rows.append(frame)
    before = {str(p.relative_to(ROOT)): sha(p) for p in dict.fromkeys(source_paths)}
    archive = np.load(xp, allow_pickle=False); lineage = pd.read_csv(lp)
    require(len(lineage) == 2288 and lineage.patch_id.is_unique and np.array_equal(archive['patch_id'], lineage.patch_id.to_numpy(str)), 'Canonical patch lineage mismatch')
    require(set(archive.files) == {'nominal', 'timestamp_sensitive', 'patch_id', 'sample_rate_hz'} and int(archive['sample_rate_hz']) == 25600, 'Wrong canonical archive schema')
    require(set(lineage.bearing_id) == set(IDS) and set(lineage.condition) == CONDITIONS and set(lineage.role) == {'test'}, 'Wrong fresh specimen/condition cohort')
    require((lineage.class_id == lineage.label).all() and all(LABELS[r.bearing_id] == r.class_id for r in lineage.itertuples()), 'Class labels disagree')
    raw = pd.concat(raw_rows, ignore_index=True)
    eligible = raw[(raw.run <= 4) & (raw.sample_count >= 256000) & (raw.timestamp_duration_s >= (256000-1)/64000) & (raw.timestamp_nonpositive_intervals == 0)]
    require(len(eligible) == 143 and set(eligible.file_id) == set(lineage.file_id), 'Wrong metadata-selected source MAT members')
    files = sorted(lineage.file_id.unique())
    indices = {name: np.flatnonzero(lineage.file_id.to_numpy() == name) for name in files}
    metadata = lineage[['file_id', 'bearing_id', 'condition', 'class_id']].drop_duplicates().set_index('file_id')
    for name, ids in indices.items():
        part = lineage.iloc[ids]
        require(len(ids) == 16 and part.patch_index.tolist() == list(range(16)), 'Wrong within-record patches')
        require(part.second.tolist() == np.repeat(np.arange(4), 4).tolist() and part.offset_25k.tolist() == np.tile([0, 7850, 15701, 23552], 4).tolist(), 'Wrong fixed patch offsets')
        require(np.all(part.start_25k == part.second * 25600 + part.offset_25k) and np.all(part.stop_25k_exclusive == part.start_25k + 2048), 'Wrong patch support')
    input_arrays = {mode: archive[mode] for mode in MODES}
    for mode, values in input_arrays.items(): require(values.shape == (2288, 2048) and values.dtype == np.float32 and np.isfinite(values).all(), 'Invalid external array')
    total_models = 0; bn_checks = 0; differences = {}; metric_max = 0.; seed_metrics = []
    for cohort in ['v6', 'v7']:
        rows = []; folder = OUT / cohort
        for count, (family, arm, seed, fold, path) in enumerate(specs(cohort), 1):
            result = read(path.with_suffix('.json'))
            require(result['model_sha256'] == before[str(path.relative_to(ROOT))], 'Model hash differs from fitting result')
            checkpoint = torch.load(path, map_location='cpu', weights_only=False)
            for key, value in [('arm', arm), ('seed', seed), ('fold', fold)]: require(checkpoint[key] == result[key] == value, 'Wrong selected-model identity')
            require(checkpoint['design_sha256'] == result['design_sha256'] and checkpoint['selected_update'] == result['selected_update'], 'Wrong source-selected checkpoint')
            if cohort == 'v7': require(checkpoint['excluded'] == result['excluded'] == family, 'Wrong omitted family')
            model = ClassBDWDCNN(variant='baseline'); model.load_state_dict(checkpoint['model_state']); model.eval()
            require(sum(p.numel() for p in model.parameters()) == 66083, 'Unexpected architecture')
            bn_before = {k: v.clone() for k, v in model.state_dict().items() if 'running_' in k or 'num_batches_tracked' in k}
            for mode in MODES:
                chunks = []
                with torch.no_grad():
                    for offset in range(0, len(lineage), 48):
                        values = normalized_patch(input_arrays[mode][offset:offset+48])
                        logits = model(torch.from_numpy(values[:, None, :]))['logits']
                        chunks.append(torch.softmax(logits, dim=1).numpy().astype(np.float64))
                patch_probability = np.concatenate(chunks)
                for name in files:
                    probability = patch_probability[indices[name]].mean(axis=0); probability /= probability.sum()
                    m = metadata.loc[name]
                    rows.append({'cohort': cohort, 'excluded': family, 'arm': arm, 'seed': seed, 'fold': fold, 'timing': mode, 'file_id': name, 'bearing_id': m.bearing_id, 'condition': m.condition, 'label': int(m.class_id), **dict(zip(P, probability))})
                require(all(torch.equal(v, model.state_dict()[k]) for k, v in bn_before.items()), 'External replay mutated BatchNorm')
                bn_checks += len(bn_before)
            total_models += 1
            if count % 10 == 0: print(f'INDEPENDENT ZERO-SHOT {cohort}: {count} weights replayed', flush=True)
        fold_frame = pd.DataFrame(rows)
        fold_keys = ['cohort', 'excluded', 'arm', 'seed', 'fold', 'timing', 'file_id', 'bearing_id', 'condition', 'label']
        differences[cohort + '/fold'] = check_table(fold_frame, folder / 'fold_record_predictions.csv', fold_keys)
        ensemble_keys = [k for k in fold_keys if k != 'fold']
        for _, group in fold_frame.groupby(ensemble_keys): require(group.fold.tolist() == list(range(5)), 'Incomplete or unequal model ensemble')
        ensemble = manual_average(fold_frame, ensemble_keys)
        differences[cohort + '/measurement'] = check_table(ensemble, folder / 'ensemble_record_predictions.csv', ensemble_keys)
        condition_keys = ['cohort', 'excluded', 'arm', 'seed', 'timing', 'bearing_id', 'condition', 'label']
        condition = manual_average(ensemble, condition_keys)
        differences[cohort + '/condition'] = check_table(condition, folder / 'bearing_condition_predictions.csv', condition_keys)
        bearing_keys = [k for k in condition_keys if k != 'condition']
        for _, group in condition.groupby(bearing_keys): require(set(group.condition) == CONDITIONS and len(group) == 4, 'Wrong condition averaging denominator')
        bearing = manual_average(condition, bearing_keys, normalization=True)
        differences[cohort + '/bearing'] = check_table(bearing, folder / 'bearing_predictions.csv', bearing_keys)
        stored_metrics = pd.read_csv(folder / 'seed_summary.csv')
        for key, group in bearing.groupby(['excluded', 'arm', 'seed', 'timing']):
            family, arm, seed, timing = key
            require(len(group) == 9 and group.bearing_id.nunique() == 9 and group.groupby('label').size().tolist() == [3, 3, 3], 'Wrong independent specimen support')
            metric = scores(group.label.to_numpy(int), group[P].to_numpy(float))
            stored = stored_metrics[(stored_metrics.excluded == family) & (stored_metrics.arm == arm) & (stored_metrics.seed == seed) & (stored_metrics.timing == timing)]
            require(len(stored) == 1, 'Missing seed summary')
            for name, value in metric.items():
                if name == 'confusion_matrix': continue
                delta = abs(float(stored.iloc[0][name]) - value); metric_max = max(metric_max, delta)
                require(delta < 1e-10, 'Independent external score mismatch')
            seed_metrics.append({'cohort': cohort, 'excluded': family, 'arm': arm, 'seed': int(seed), 'timing': timing, **metric})
    require(total_models == 180 and bn_checks == 6480 and len(seed_metrics) == 72, 'Incomplete independent replay')
    after = {path: sha(ROOT / path) for path in before}
    require(before == after, 'Original inputs or evaluation outputs changed during independent replay')
    report = {'passed': True, 'status': 'all canonical selected weights and hierarchy independently replayed', 'completed_utc': datetime.now(timezone.utc).isoformat(), 'models': total_models, 'model_mode_replays': total_models * 2, 'independent_specimens': 9, 'classes': {'healthy': 3, 'inner_ring': 3, 'outer_ring': 3}, 'eligible_measurements': 143, 'patches': 2288, 'unchanged_BN_buffer_checks': bn_checks, 'max_probability_differences': differences, 'max_metric_difference': metric_max, 'all_consumed_original_hashes_unchanged': True, 'input_output_sha256_before': before, 'input_output_sha256_after': after, 'independent_seed_metrics': seed_metrics, 'external_fitting': False, 'external_checkpoint_selection': False, 'limitations': ['Retrospective exploratory corrections followed preliminary failed evaluations; not pristine preregistration.', 'Healthy/manufacturer confounding persists.', 'HostService timestamps are not proven ADC sampling times.', 'Three per-class specimens limit generalization; seeds and repeated records are not independent specimens.']}
    audit_path.write_text(json.dumps(report, indent=2, allow_nan=False), encoding='utf-8')
    print(json.dumps({k: report[k] for k in ['passed', 'models', 'model_mode_replays', 'unchanged_BN_buffer_checks', 'max_probability_differences', 'max_metric_difference', 'all_consumed_original_hashes_unchanged']}), flush=True)


if __name__ == '__main__': main()
