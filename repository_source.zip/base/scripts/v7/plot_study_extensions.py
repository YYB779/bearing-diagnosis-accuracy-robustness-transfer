"""Data-bound general scientific figures; journal choice is deferred."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'figures/v7';OUT.mkdir(parents=True,exist_ok=True)
STYLE={'font.family':'Arial','font.size':8,'axes.titlesize':8.5,'axes.labelsize':8,
       'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'ps.fonttype':42,
       'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,
       'savefig.facecolor':'white','figure.facecolor':'white'}
COLORS=['#0072B2','#D55E00'];MARKERS=['o','s','^']


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def export(fig,stem,caption,source=None):
    fig.canvas.draw()
    for suffix in ['pdf','svg','png']:
        fig.savefig(OUT/(stem+'.'+suffix),dpi=300,facecolor='white')
    (OUT/(stem+'_caption.md')).write_text(caption+'\n',encoding='utf-8')
    if source is not None:source.to_csv(OUT/(stem+'_source.csv'),index=False)
    plt.close(fig)


def overview():
    with plt.rc_context(STYLE):
        # Journal-style evidence framework: quiet white cards, restrained
        # accents and a clear source -> question -> unit reading order.
        fig,ax=plt.subplots(figsize=(170/25.4,111/25.4)); ax.set_axis_off(); ax.set_xlim(0,1); ax.set_ylim(0,1)
        cards=[
            (.025,'a','Information retention','#0072B2','NOVIC+ vibration + measured RPM',
             ['101 segments to 404 intervals','8 turns per interval','79 recording proxies / 33 states'],
             ['Native vs envelope input','Whole-state exclusion','Bearing identity unavailable']),
            (.352,'b','Corruption transfer','#D55E00','HUSTbearing source files',
             ['21 files to 672 disjoint patches','32 patches per file','2.56 s retained signal'],
             ['Matched conventional controls','Exact-view augmentation pairs','Excluded-construction evaluation']),
            (.679,'c','Specimen identity','#009E73','Paderborn bearing profiles',
             ['9 development / 9 fresh test IDs','4 conditions per bearing','Measurement runs 1-4 fixed'],
             ['Whole-bearing validation','Paired timing sensitivity','Frozen cross-rig prediction'])]
        # Reusable geometry is intentionally compact; empty space is reserved
        # for the arrows that connect evidence to the tested question.
        for x,letter,title,color,source,details,questions in cards:
            w=.296
            # panel number and title
            ax.add_patch(plt.Circle((x+.015,.945),.012,color=color,zorder=4))
            ax.text(x+.015,.945,letter,ha='center',va='center',color='white',weight='bold',fontsize=7.5,zorder=5)
            ax.text(x+.038,.945,title,ha='left',va='center',color='#17232B',weight='bold',fontsize=8.8,zorder=5)
            ax.plot([x,.321+x], [.918,.918], color=color, lw=2.2, solid_capstyle='round', zorder=3)
            # source panel
            ax.add_patch(FancyBboxPatch((x,.59),w,.285,boxstyle='round,pad=.006,rounding_size=.008',facecolor='#F7F9FA',edgecolor='#B8C3C9',lw=.65,zorder=2))
            ax.add_patch(plt.Rectangle((x,.59),.006,.285,color=color,zorder=3))
            ax.text(x+.018,.842,'MEASURED SOURCE',ha='left',va='top',color=color,weight='bold',fontsize=7.0,zorder=4)
            ax.text(x+.018,.802,source,ha='left',va='top',color='#17232B',weight='bold',fontsize=7.6,zorder=4)
            ax.text(x+.018,.755,'\n'.join('- '+v for v in details),ha='left',va='top',color='#4B5961',fontsize=7.1,linespacing=1.42,zorder=4)
            # explicit analysis arrow
            ax.annotate('',xy=(x+w/2,.525),xytext=(x+w/2,.565),arrowprops={'arrowstyle':'-|>','lw':.9,'color':color,'mutation_scale':8},zorder=4)
            # question panel
            ax.add_patch(FancyBboxPatch((x,.25),w,.235,boxstyle='round,pad=.006,rounding_size=.008',facecolor='white',edgecolor='#B8C3C9',lw=.65,zorder=2))
            ax.add_patch(plt.Rectangle((x,.25),.006,.235,color=color,zorder=3))
            ax.text(x+.018,.455,'QUESTION TESTED',ha='left',va='top',color=color,weight='bold',fontsize=7.0,zorder=4)
            ax.text(x+.018,.413,'\n'.join('- '+v for v in questions),ha='left',va='top',color='#35434B',fontsize=7.1,linespacing=1.52,zorder=4)
        # one shared denominator statement, separated from the three pathways
        ax.add_patch(FancyBboxPatch((.025,.055),.95,.115,boxstyle='round,pad=.008,rounding_size=.008',facecolor='#F7F9FA',edgecolor='#B8C3C9',lw=.65,zorder=2))
        ax.text(.04,.142,'REPLICATION UNITS',ha='left',va='center',color='#263238',weight='bold',fontsize=7.2,zorder=4)
        ax.text(.04,.108,'recording proxies   /   source files   /   identified bearing IDs',ha='left',va='center',color='#4B5961',fontsize=7.1,zorder=4)
        ax.text(.04,.077,'Patches, optimizer seeds, noise draws and repeated conditions are not physical specimens.',ha='left',va='center',color='#66737A',fontsize=7.0,zorder=4)
        fig.subplots_adjust(left=.005,right=.995,top=.995,bottom=.005)
        export(fig,'fig_evidence_chain','Study design and evidence units. The three studies test information retention, corruption transfer and bearing-identity separation with different measured sources and independent-unit definitions. The development and fresh Paderborn groups each contain nine source-documented bearing IDs. Conditions repeat within bearing. Unknown physical identities in NOVIC+/HUST, manufacturer-class confounding in Paderborn, prior source inspection and synthetic interference remain explicit limitations. Arrows describe analysis, not causal identification.\n\nAlt text: Three editorial columns connect measured sources to tested questions and declare the replication units used for each analysis.')

def lofo():
    path=ROOT/'results/v7/analysis/pooled_summary.csv';p=pd.read_csv(path)
    contrast=pd.read_csv(ROOT/'results/v7/analysis/contrasts.csv')
    primary={'awgn':'AWGN-4dB','colored':'colored-4dB','impulse':'impulse-4dB','tone':'tone-4dB'}
    titles={'awgn':'Excluded white Gaussian','colored':'Excluded colored Gaussian','impulse':'Excluded sparse impulse','tone':'Excluded sinusoid'}
    source=[]
    with plt.rc_context(STYLE):
        fig=plt.figure(figsize=(170/25.4,145/25.4));gs=fig.add_gridspec(3,2,height_ratios=[1,1,1.15],hspace=.62,wspace=.28)
        for i,(fam,panel) in enumerate(primary.items()):
            ax=fig.add_subplot(gs[i//2,i%2])
            for ai,arm in enumerate(['mixed_erm','mixed_dro']):
                for mi,seed in enumerate([11,22,33]):
                    for yy,name in [(1,'clean'),(0,panel)]:
                        row=p[(p.excluded==fam)&(p.arm==arm)&(p.seed==seed)&(p.panel==name)].iloc[0]
                        y=yy+(-.10 if ai==0 else .10)+(mi-1)*.035
                        ax.scatter(row.macro_f1,y,s=23,marker=MARKERS[mi],facecolors='none',edgecolors=COLORS[ai],linewidths=.9)
                        source.append({'display':'F1','excluded':fam,'arm':arm,'seed':seed,'panel':name,'value':row.macro_f1})
            ax.set(xlim=(-.03,1.03),ylim=(-.35,1.35),yticks=[0,1],yticklabels=['Excluded','Clean'],xlabel='Pooled 21-file macro-F1')
            ax.set_title(chr(97+i)+'  '+titles[fam],loc='left',weight='bold',pad=6)
            ax.set_xticks([0,.25,.5,.75,1]);ax.grid(axis='x',color='#E3E6E8',lw=.5);ax.set_axisbelow(True)
        ax=fig.add_subplot(gs[2,:])
        for i,fam in enumerate(primary):
            s=contrast[(contrast.excluded==fam)&(contrast.panel==primary[fam])].sort_values('seed')
            x=s.dro_minus_erm_macro_f1.to_numpy();ax.plot([x.min(),x.max()],[i,i],color='#777777',lw=.8)
            for j,(_,row) in enumerate(s.iterrows()):
                ax.scatter(row.dro_minus_erm_macro_f1,i+(j-1)*.08,s=23,marker=MARKERS[j],facecolors='none',edgecolors='#333333')
                source.append({'display':'Delta F1','excluded':fam,'arm':'DRO minus ERM','seed':int(row.seed),'panel':primary[fam],'value':row.dro_minus_erm_macro_f1})
        ax.axvline(0,color='#777777',lw=.8,linestyle='--');ax.set(xlim=(-1,1),yticks=range(4),yticklabels=['White Gaussian','Colored Gaussian','Impulse','Sinusoid'],xlabel='DRO minus ERM on the excluded construction')
        ax.invert_yaxis();ax.set_title('e  Paired effects on identical records and algorithm seeds',loc='left',weight='bold',pad=6)
        handles=[plt.Line2D([],[],color=COLORS[j],marker='o',fillstyle='none',linestyle='none',label=x) for j,x in enumerate(['Mixed ERM','Source-condition DRO'])]
        fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.52,.998),ncol=2,frameon=False,fontsize=8)
        fig.subplots_adjust(left=.14,right=.98,top=.90,bottom=.09)
        export(fig,'fig_excluded_corruptions','Complete excluded-construction comparison. (a–d) Clean and excluded-construction macro-F1 retain both training arms and all three algorithm seeds (circle 11, square 22, triangle 33). One named construction is entirely absent from fitting and clean-only validation; excluding white Gaussian still allows colored Gaussian. (e) Every paired DRO-minus-ERM contrast is shown on a common difference scale. Thin segments span algorithm-seed minima/maxima, not confidence intervals. Each point pools the same 21 held-out files across condition rotations. All 120 fits share the 480-update, three-view training budget; ERM/DRO share exact input arrays. DRO weights source conditions, not noise families. This extension was informed by historical corruption outcomes and is exploratory.\n\nAlt text: Four paired panels show clean and excluded-noise results for ERM and DRO, followed by all seed-specific differences; adverse differences remain visible.',pd.DataFrame(source))


def zero_shot():
    files=[ROOT/f'results/v7/zero_shot/{cohort}/seed_summary.csv' for cohort in ['v6','v7']]
    p=pd.concat([pd.read_csv(f) for f in files],ignore_index=True)
    policies=[('v6','none',a) for a in ['clean_ce','awgn_ce','response_ce','response_jsd']]+[('v7',f,a) for f in ['awgn','colored','impulse','tone'] for a in ['mixed_erm','mixed_dro']]
    labels=['Clean CE','AWGN CE','Response CE','Response JSD']+[f'{f.title()} excluded / '+('ERM' if a=='mixed_erm' else 'DRO') for _,f,a in policies[4:]]
    source=[]
    with plt.rc_context(STYLE):
        fig,axes=plt.subplots(1,2,figsize=(170/25.4,140/25.4),sharey=True)
        for ax,timing,title in zip(axes,['nominal','timestamp_sensitive'],['a  Nominal sampling','b  Timestamp sensitivity']):
            for i,(cohort,fam,arm) in enumerate(policies):
                s=p[(p.cohort==cohort)&(p.excluded==fam)&(p.arm==arm)&(p.timing==timing)].sort_values('seed')
                assert len(s)==3
                color='#666666' if cohort=='v6' else COLORS[int(arm=='mixed_dro')]
                for j,(_,r) in enumerate(s.iterrows()):
                    ax.scatter(r.macro_f1,i+(j-1)*.10,s=25,marker=MARKERS[j],facecolors='none',edgecolors=color,lw=.9)
                    source.append({'cohort':cohort,'excluded':fam,'arm':arm,'timing':timing,'seed':int(r.seed),'macro_f1':r.macro_f1,'nll':r.nll,'recall_H':r.recall_H,'recall_I':r.recall_I,'recall_O':r.recall_O})
            ax.axhline(3.5,color='#999999',ls='--',lw=.65)
            ax.set(xlim=(-.02,1.02),xticks=[0,.25,.5,.75,1],xlabel='Nine-bearing macro-F1',title=title)
            ax.grid(axis='x',color='#E3E6E8',lw=.5);ax.set_axisbelow(True)
        axes[0].set_yticks(range(len(labels)),labels);axes[0].invert_yaxis()
        fig.subplots_adjust(left=.34,right=.98,top=.93,bottom=.12,wspace=.18)
        export(fig,'fig_zero_shot','Complete HUST-to-Paderborn frozen-weight evaluation. Each point is a fixed algorithm seed and an equal-probability ensemble of all five HUST condition-fold models, scored on nine fresh Paderborn bearing IDs. Four conditions and available preselected measurements are averaged within bearing; they are repeated observations. No Paderborn fitting, calibration or model selection occurs. Both nominal and HostService timestamp-sensitive inputs are retained. The historical four arms and all eight mixed-training policies are reported without selecting an external winner. Manufacturer/class confounding, host-clock ambiguity, only three bearings per class and cross-rig shift limit interpretation. A five-model ensemble is not a single-model cost-matched comparison with Paderborn-trained conventional models.\n\nAlt text: All twelve source-training policies and all three seeds are shown under both external time interpretations, including low transfer scores.',pd.DataFrame(source))


def historical_corruption():
    path=ROOT/'results/v6/analysis/pooled_summary.csv';p=pd.read_csv(path)
    panels=['clean','AWGN0dB','AWGN-4dB','colored-4dB','impulse-4dB','tone-4dB']
    titles=['Clean','Gaussian 0 dB','Gaussian −4 dB','Colored −4 dB','Impulse −4 dB','Sinusoid −4 dB']
    arms=['clean_ce','awgn_ce','response_ce','response_jsd'];colors=['#666666','#0072B2','#009E73','#D55E00']
    metrics=[('macro_f1','Macro-F1'),('recall_H','Healthy recall'),('nll','NLL (nats)')]
    source=[]
    with plt.rc_context(STYLE):
        fig,axes=plt.subplots(6,3,figsize=(170/25.4,180/25.4))
        for i,panel in enumerate(panels):
            for j,(metric,label) in enumerate(metrics):
                ax=axes[i,j]
                if i>=3:ax.set_facecolor('#F5F6F7')
                for a,arm in enumerate(arms):
                    d=p[(p.panel==panel)&(p.arm==arm)].sort_values('seed');assert len(d)==3
                    for k,(_,r) in enumerate(d.iterrows()):
                        ax.scatter(r[metric],a+(k-1)*.15,s=14,marker=MARKERS[k],facecolors='white',edgecolors=colors[a],lw=.7,zorder=3)
                        source.append({'panel':panel,'arm':arm,'seed':int(r.seed),'metric':metric,'value':r[metric]})
                ax.set_ylim(3.5,-.5);ax.set_yticks(range(4),['A','B','C','D'] if j==0 else ['']*4);ax.tick_params(axis='y',length=0)
                ax.set_title(f'{chr(97+i*3+j)}  '+(titles[i]+' / '+label if j==0 else label),loc='left',fontsize=7.5,pad=4)
                if metric=='nll':
                    limit=np.ceil(p.nll.max()*1.1);ax.set_xlim(0,limit);ax.set_xticks([0,limit/2,limit])
                else:ax.set_xlim(-.03,1.03);ax.set_xticks([0,.5,1])
                ax.grid(axis='x',color='#DFE3E5',lw=.5);ax.set_axisbelow(True)
        handles=[plt.Line2D([],[],color=c,lw=1,label=x) for c,x in zip(colors,['A Clean CE','B AWGN CE','C Response CE','D Response JSD'])]
        fig.legend(handles=handles,ncol=2,frameon=False,loc='upper center',bbox_to_anchor=(.53,.998),fontsize=8)
        fig.subplots_adjust(left=.09,right=.98,top=.91,bottom=.055,hspace=.9,wspace=.36)
        cap=(ROOT/'figures/v6/fig17_corruption_robustness_caption.md').read_text(encoding='utf-8').split('\n\nAlt text:')[0]
        import re
        cap=re.sub(r'^Figure\s+\d+\.\s*','',cap)
        export(fig,'fig_historical_corruption',cap+'\n\nAlt text: Eighteen aligned point plots show every historical arm, seed and panel with common metric scales; no failures are omitted.',pd.DataFrame(source))


if __name__=='__main__':
    import sys
    task=sys.argv[1] if len(sys.argv)>1 else 'all'
    if task in ['overview','all']:overview()
    if task in ['lofo','all']:lofo()
    if task in ['zero','all']:zero_shot()
    if task in ['historical','all']:historical_corruption()
    manifest={p.name:sha(p) for p in OUT.glob('*') if p.is_file() and p.suffix in ['.png','.pdf','.svg','.csv','.md']}
    (OUT/'extension_figure_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
