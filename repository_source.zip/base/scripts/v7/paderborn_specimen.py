"""Whole-bearing Paderborn controls with a fixed paired timing sensitivity.

Specimen grouping, not signal windows, determines validation and primary score.
No original or derived label enters resampling or feature construction.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.signal import resample_poly
from scripts.v7.run_matched_classical import (extract_features, build_model, fit_model,
    record_metrics, independent_metrics_check, select_candidate, CONFIGS, PROBS)

DEV_BY_CLASS={0:['K001','K002','K003'],1:['KI01','KI04','KI14'],2:['KA01','KA04','KA22']}
TEST_BY_CLASS={0:['K004','K005','K006'],1:['KI16','KI18','KI21'],2:['KA15','KA16','KA30']}
DEV_IDS=[b for cls in [0,1,2] for b in DEV_BY_CLASS[cls]]
TEST_IDS=[b for cls in [0,1,2] for b in TEST_BY_CLASS[cls]]
LABELS={b:c for group in [DEV_BY_CLASS,TEST_BY_CLASS] for c,ids in group.items() for b in ids}
CONDITIONS=['N09_M07_F10','N15_M01_F10','N15_M07_F04','N15_M07_F10']
NATIVE_FS=64000
NATIVE_PREFIX=256000
TARGET_FS=25600
OFFSETS=[0,7850,15701,23552]


def screen_record(values,times):
    v=np.asarray(values);t=np.asarray(times,dtype=np.float64)
    reasons=[]
    if v.ndim!=1 or t.ndim!=1 or v.shape!=t.shape:
        return {'eligible':False,'reasons':['shape_mismatch'],'sample_count':int(v.size)}
    if len(v)<NATIVE_PREFIX:reasons.append('fewer_than_256000_native_samples')
    if not np.isfinite(v).all():reasons.append('nonfinite_vibration')
    if not np.isfinite(t).all():reasons.append('nonfinite_timestamps')
    relative=t-t[0] if len(t) else t
    if len(t)<2 or not np.all(np.diff(t)>0):reasons.append('nonmonotonic_timestamps')
    end=float(relative[-1]) if len(t) else None
    if end is None or end<(NATIVE_PREFIX-1)/NATIVE_FS:
        reasons.append('insufficient_relative_timestamp_coverage')
    return {'eligible':not reasons,'reasons':reasons,'sample_count':len(v),
        'relative_timestamp_last_s':end,'nominal_required_last_s':(NATIVE_PREFIX-1)/NATIVE_FS,
        'timestamp_first_s':float(t[0]) if len(t) else None}


def make_patch_views(values,times):
    report=screen_record(values,times)
    if not report['eligible']:raise ValueError('Record fails fixed gate: '+','.join(report['reasons']))
    v=np.asarray(values,np.float32);relative=np.asarray(times,np.float64)-times[0]
    nominal=np.asarray(v[:NATIVE_PREFIX],np.float32)
    corrected=np.interp(np.arange(NATIVE_PREFIX,dtype=np.float64)/NATIVE_FS,relative,v).astype(np.float32)
    arrays=[]
    for source in [nominal,corrected]:
        resampled=resample_poly(source,2,5,padtype='constant').astype(np.float32)
        if resampled.shape!=(4*TARGET_FS,) or not np.isfinite(resampled).all():
            raise ValueError('Fixed-rate resampling output is not four complete seconds')
        patches=np.stack([resampled[second*TARGET_FS+offset:second*TARGET_FS+offset+2048]
            for second in range(4) for offset in OFFSETS])
        if patches.shape!=(16,2048):raise ValueError('Patch support changed')
        arrays.append(patches)
    return tuple(arrays)


def load_timestamps(path,key):
    with np.load(path,allow_pickle=False) as z:value=z[key]
    if value.dtype==np.uint8 and value.ndim==2 and value.shape[0]==8:
        return value.T.copy().view('<f8').reshape(-1)
    if value.dtype==np.float64 and value.ndim==1:return value
    raise ValueError('Unsupported exact timestamp encoding')


def eligible_specimens(frame):
    keep=[];rows=[]
    for bearing,part in frame.groupby('bearing_id',sort=True):
        conditions=set(part.condition)
        valid=conditions==set(CONDITIONS)
        if valid:keep.append(bearing)
        rows.append({'bearing_id':bearing,'eligible':valid,'conditions':sorted(conditions),
            'missing_conditions':sorted(set(CONDITIONS)-conditions)})
    return keep,rows


def development_partition(frame,fold):
    if fold not in range(3) or set(frame.bearing_id)!=set(DEV_IDS):
        raise ValueError('CV requires exactly the nine fixed development specimens')
    if 'role' in frame and set(frame.role)!={'development'}:
        raise ValueError('New test specimens cannot enter development CV')
    val_ids={DEV_BY_CLASS[c][fold] for c in [0,1,2]}
    val=frame.bearing_id.isin(val_ids).to_numpy();train=~val
    if not set(frame.loc[train,'bearing_id']).isdisjoint(frame.loc[val,'bearing_id']):
        raise ValueError('Bearing identity crossed CV split')
    return np.flatnonzero(train),np.flatnonzero(val)


def training_weights(frame):
    if frame.groupby('bearing_id').condition.nunique().ne(4).any():
        raise ValueError('Every training bearing must retain all four conditions')
    if not frame.groupby('bearing_id').class_id.nunique().eq(1).all():raise ValueError('Mixed bearing labels')
    sizes=frame.groupby(['bearing_id','condition']).bearing_id.transform('size').to_numpy(float)
    weights=1/sizes
    return weights/weights.mean()


def aggregate_hierarchical(p,frame):
    p=np.asarray(p,np.float64);frame=frame.reset_index(drop=True)
    if p.shape!=(len(frame),3) or not np.isfinite(p).all() or (p<0).any() or not np.allclose(p.sum(1),1):
        raise ValueError('Invalid patch probability array')
    rows=[]
    for file_id,idx in frame.groupby('file_id',sort=True).indices.items():
        q=frame.iloc[idx]
        if len(q)!=16 or q.bearing_id.nunique()!=1 or q.class_id.nunique()!=1 or q.condition.nunique()!=1:
            raise ValueError('Measurement must contain exactly16 patches from one labelled bearing/condition')
        v=p[idx].mean(0);v/=v.sum()
        rows.append({'file_id':file_id,'bearing_id':q.bearing_id.iloc[0],'class_id':int(q.class_id.iloc[0]),
            'condition':q.condition.iloc[0],'run':int(q.run.iloc[0]),'patch_count':16,**dict(zip(PROBS,v))})
    measurements=pd.DataFrame(rows);conds=[]
    for (bearing,condition),q in measurements.groupby(['bearing_id','condition'],sort=True):
        if q.class_id.nunique()!=1:raise ValueError('Inconsistent specimen label')
        v=q[PROBS].to_numpy().mean(0);v/=v.sum()
        conds.append({'bearing_id':bearing,'class_id':int(q.class_id.iloc[0]),'condition':condition,
            'measurement_count':len(q),**dict(zip(PROBS,v))})
    conditions=pd.DataFrame(conds);bearings=[]
    for bearing,q in conditions.groupby('bearing_id',sort=True):
        if set(q.condition)!=set(CONDITIONS):raise ValueError('Primary specimen needs all four conditions')
        v=q[PROBS].to_numpy().mean(0);v/=v.sum()
        bearings.append({'bearing_id':bearing,'class_id':int(q.class_id.iloc[0]),'condition_count':4,
            'measurement_count':int(q.measurement_count.sum()),**dict(zip(PROBS,v))})
    return measurements,conditions,pd.DataFrame(bearings)
