"""Complete same-source/new-specimen classical controls; no hidden seed or timing path."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from scripts.v7.paderborn_specimen import TEST_IDS,LABELS
from scripts.v7.paderborn_prepare import sha,write_json

ROOT=Path(__file__).resolve().parents[2];SRC=ROOT/'results/v7/paderborn_specimen';OUT=ROOT/'figures/v7';OUT.mkdir(parents=True,exist_ok=True)
STEM='fig_paderborn_specimens';SEEDS=[11,22,33]
GROUPS=[('native25','extra_trees'),('shape25','extra_trees'),('native25','logistic'),('shape25','logistic')]
LABEL=['Native ET','Shape ET','Native LR','Shape LR'];COLORS=['#0072B2','#009E73','#D55E00','#CC79A7']


def main():
    audit=json.loads((SRC/'audit.json').read_text());assert audit['passed']
    data=pd.read_csv(SRC/'seed_summary.csv');pooled=data[data.condition=='pooled'];bearing=pd.read_csv(SRC/'bearing_predictions.csv')
    assert len(pooled)==24 and len(bearing)==216
    plt.rcParams.update({'font.family':'Arial','font.size':7.5,'axes.titlesize':8.5,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
    fig=plt.figure(figsize=(170/25.4,178/25.4),facecolor='white')
    gs=fig.add_gridspec(2,2,left=.13,right=.98,bottom=.21,top=.91,height_ratios=[.9,1.4],hspace=.48,wspace=.36)
    a=fig.add_subplot(gs[0,0]);b=fig.add_subplot(gs[0,1]);c=fig.add_subplot(gs[1,:])
    for k,(rep,model)in enumerate(GROUPS):
        q=pooled[(pooled.representation==rep)&(pooled.model==model)]
        for j,seed in enumerate(SEEDS):
            nom=q[(q.seed==seed)&(q.timing=='nominal')].iloc[0];tim=q[(q.seed==seed)&(q.timing=='timestamp_sensitive')].iloc[0]
            for ax,metric in [(a,'macro_f1'),(b,'nll')]:
                x=k+(j-1)*.13
                ax.plot([x,x],[nom[metric],tim[metric]],color=COLORS[k],lw=.7,alpha=.7,zorder=1)
                ax.scatter(x,nom[metric],s=22,marker='o',edgecolor=COLORS[k],facecolor='white',linewidth=.9,zorder=3)
                ax.scatter(x,tim[metric],s=22,marker='x',color=COLORS[k],linewidth=.9,zorder=4)
    for ax in [a,b]:
        ax.set_xticks(range(4),['Native\nET','Shape\nET','Native\nLR','Shape\nLR']);ax.set_xlim(-.5,3.5);ax.grid(axis='y',alpha=.18,lw=.5);ax.tick_params(length=2)
    a.set_ylim(-.03,1.03);a.set_ylabel('Nine-bearing macro-F1');a.set_title('a  All three algorithm seeds',loc='left',fontweight='bold')
    b.set_ylabel('Nine-bearing NLL');b.set_title('b  Probability loss',loc='left',fontweight='bold');b.set_ylim(bottom=0)
    a.scatter([],[],s=20,facecolor='white',edgecolor='#333333',label='Nominal clock');a.scatter([],[],s=20,marker='x',color='#333333',label='Timestamp sensitivity')
    a.legend(loc='lower left',bbox_to_anchor=(-.15,1.12),ncol=2,frameon=False,columnspacing=1,handletextpad=.4)
    matrix=[];letters=[];row_labels=[]
    for k,(rep,model)in enumerate(GROUPS):
        for seed in SEEDS:
            q=bearing[(bearing.representation==rep)&(bearing.model==model)&(bearing.seed==seed)]
            row=[];chars=[]
            for timing in ['nominal','timestamp_sensitive']:
                part=q[q.timing==timing].set_index('bearing_id')
                for specimen in TEST_IDS:
                    y=LABELS[specimen];prediction=int(np.argmax(part.loc[specimen,['p_H','p_I','p_O']].to_numpy(float)))
                    row.append(int(prediction==y));chars.append('HIO'[prediction])
            matrix.append(row);letters.append(chars);row_labels.append(LABEL[k]+f' {seed}')
    matrix=np.asarray(matrix);c.imshow(matrix,aspect='auto',interpolation='nearest',cmap=ListedColormap(['#f2d6cb','#d2e5e2']),vmin=0,vmax=1)
    for i in range(12):
        for j in range(18):c.text(j,i,letters[i][j],ha='center',va='center',fontsize=7,color='#222222')
    c.set_yticks(range(12),row_labels);c.set_xticks(range(18),TEST_IDS*2,rotation=90);c.tick_params(length=0,pad=3)
    c.axvline(8.5,color='white',lw=3)
    for y in [2.5,5.5,8.5]:c.axhline(y,color='white',lw=1.4)
    c.set_title('c  Every held-out bearing: predicted H / I / O',loc='left',fontweight='bold',pad=20)
    c.text(4,-.9,'Nominal clock',ha='center',va='bottom',fontsize=8)
    c.text(13,-.9,'Timestamp sensitivity',ha='center',va='bottom',fontsize=8)
    fig.text(.13,.025,'True classes: K004/5/6 H; KI16/18/21 I; KA15/16/30 O.\nCell fill: correct / incorrect; letters retain predicted class.\n9 development and 9 distinct test bearings; 143/144 selected test measurements pass.\nHealthy test bearings: IBU; damaged: FAG/MTK (manufacturer confounded).\nHost timing is a sensitivity proxy; conditions and seeds do not add bearing units.',ha='left',va='bottom',fontsize=7.5,linespacing=1.3)
    outputs=[]
    for ext in ['pdf','svg','png']:
        p=OUT/f'{STEM}.{ext}';fig.savefig(p,dpi=300,facecolor='white',transparent=False);outputs.append(p)
    plt.close(fig)
    source=OUT/'source_data';source.mkdir(exist_ok=True)
    points=source/f'{STEM}_points.csv';pooled.to_csv(points,index=False)
    cells=source/f'{STEM}_bearing_predictions.csv';bearing.to_csv(cells,index=False)
    caption=('Independent-specimen conventional controls on the Paderborn source. All models fit only nine development bearings; threefold development validation holds one complete specimen per class. The nine distinct test bearings supply 143 passing preselected measurements across four conditions. (a,b) All 12 selected pipelines are shown for nominal sampling (open circles) and the fixed HostService timestamp sensitivity (crosses), with connecting segments pairing the same pipeline; the three seed offsets are descriptive optimization repeats, not confidence intervals. (c) All predicted bearing classes are printed for every model and timing path. Green-gray cells indicate correct and pale-orange cells incorrect predictions; class letters provide a color-independent reading. Probabilities average 16 patches per measurement, passing measurements equally within condition, then four conditions equally per bearing. Test labels select no model or timing path. Manufacturer is confounded: all healthy test bearings are IBU, damaged bearings FAG/MTK. Timing sensitivity is not verified clock correction and this test contains no measured field-noise challenge.')
    alt='Two paired-point panels show macro-F1 and negative log likelihood for every seed/model under nominal and timestamp-sensitive inputs. A 12 by 18 matrix prints all bearing-level predicted classes across both timing paths, including every failure.'
    cp=OUT/f'{STEM}_caption.txt';cp.write_text(caption+'\n\nAlt text: '+alt+'\n',encoding='utf-8')
    import fitz
    pdf=fitz.open(OUT/f'{STEM}.pdf');page=pdf[0];fonts=[span['size'] for block in page.get_text('dict')['blocks']for line in block.get('lines',[])for span in line['spans']]
    check={'width_mm':page.rect.width*25.4/72,'height_mm':page.rect.height*25.4/72,'minimum_text_points':min(fonts),'all_models_and_timings':len(pooled),'bearing_cells':int(matrix.size),'passed_automated':min(fonts)>=7 and len(pooled)==24 and int(matrix.size)==216,'visual_review':'pending render inspection'}
    write_json(OUT/f'{STEM}_manifest.json',{'figure':STEM,'source_sha256':{str(p.relative_to(ROOT)):sha(p)for p in [SRC/'audit.json',SRC/'seed_summary.csv',SRC/'bearing_predictions.csv',Path(__file__)]},'output_sha256':{str(p.relative_to(ROOT)):sha(p)for p in outputs+[points,cells,cp]},'checks':check,'caption':caption,'alt_text':alt})
    print(json.dumps(check,indent=2),flush=True)


if __name__=='__main__':main()
