"""Extract audited full-native vibration arrays from reserved bearing archives.

The original RAR is retained. Temporary full MAT extraction is removed only after
all 80 files have been parsed, traced and saved. The raw float64 channel is cast
to float32 without resampling, filtering, cropping, normalization or model use.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import zlib
from datetime import datetime, timezone
from pathlib import Path

import fitz
import numpy as np
import pandas as pd
import rarfile

from scripts.v7.data_download_paderborn import IDS, DEV_IDS, ALL_IDS, ROOT, RAW, DOC, hashes
from src.data.paderborn import load_paderborn_mat, parse_filename, signal_sampling_rate_hz


LABELS = {"K004": (0, "healthy", "none", 0), "K005": (0, "healthy", "none", 0), "K006": (0, "healthy", "none", 0), "KA15": (2, "outer_ring", "plastic_deformation_indentation", 1), "KA16": (2, "outer_ring", "fatigue_pitting", 2), "KA30": (2, "outer_ring", "plastic_deformation_indentation", 1), "KI16": (1, "inner_ring", "fatigue_pitting", 3), "KI18": (1, "inner_ring", "fatigue_pitting", 2), "KI21": (1, "inner_ring", "fatigue_pitting", 1)}
LABELS.update({"K001": (0, "healthy", "none", 0), "K002": (0, "healthy", "none", 0), "K003": (0, "healthy", "none", 0), "KA01": (2, "outer_ring", "artificial_electrical_discharge_machining", 1), "KA04": (2, "outer_ring", "fatigue_pitting", 1), "KA22": (2, "outer_ring", "fatigue_pitting", 1), "KI01": (1, "inner_ring", "artificial_electrical_discharge_machining", 1), "KI04": (1, "inner_ring", "fatigue_pitting", 1), "KI14": (1, "inner_ring", "fatigue_pitting", 1)})
CONDITIONS = {"N15_M07_F10", "N09_M07_F10", "N15_M01_F10", "N15_M07_F04"}
def seven_zip_executable():
    for name in ("7zz", "7z", "7za"):
        executable = shutil.which(name)
        if executable:
            return executable
    installed = Path("C:/Program Files/7-Zip/7z.exe")
    if installed.is_file():
        return str(installed)
    raise FileNotFoundError("Install 7-Zip or pass its executable with --seven-zip.")


def digest(path):
    return hashes(path)[1]


def load_timestamps(path, key):
    """Read exact source float64 times; byte shuffling is lossless compression only."""
    with np.load(path, allow_pickle=False) as stored:
        value = stored[key]
    if value.dtype == np.uint8 and value.ndim == 2 and value.shape[0] == 8:
        return value.T.copy().view("<f8").reshape(-1)
    if value.dtype == np.float64 and value.ndim == 1:
        return value
    raise ValueError("Unknown timestamp encoding")


def extract(bearing, archive_dir=RAW, seven_zip=None):
    RAW.mkdir(parents=True, exist_ok=True)
    archive = archive_dir / f"{bearing}.rar"
    if not archive.exists():
        raise FileNotFoundError(archive)
    expected = next(item for item in json.loads((DOC / "download_manifest.json").read_text(encoding="utf-8")) if item["bearing_id"] == bearing)
    md5, sha = hashes(archive)
    if md5 != expected["deposit_md5"] or sha != expected["sha256"]:
        raise RuntimeError("Archive checksum mismatch")
    target = RAW / "derived_by_specimen" / bearing
    if (target / "extraction_audit.json").exists():
        report = json.loads((target / "extraction_audit.json").read_text())
        for item in report["outputs"]:
            if digest(ROOT / item["path"]) != item["sha256"]:
                raise RuntimeError("Existing derived output mismatch")
        print(json.dumps({"bearing": bearing, "status": "existing_derived_verified"}), flush=True)
        return report
    infos = rarfile.RarFile(archive).infolist()
    for info in infos:
        member = Path(info.filename.replace("\\", "/"))
        if member.is_absolute() or ".." in member.parts or member.parts[0] != bearing:
            raise RuntimeError(f"Unsafe or unexpected archive member {info.filename}")
    if shutil.disk_usage(RAW).free < sum(info.file_size for info in infos) + 1024 ** 3:
        raise RuntimeError("Insufficient free space for bounded temporary extraction")
    work = RAW / "working" / bearing
    if work.exists():
        # A failed parse may leave this script's complete extraction. Resume only
        # after every existing member is checked against the archive CRC and size.
        expected_members = {info.filename.replace("\\", "/"): info for info in infos if not info.isdir()}
        found_members = {p.relative_to(work).as_posix(): p for p in work.rglob("*") if p.is_file()}
        if set(found_members) != set(expected_members):
            raise RuntimeError(f"Partial/unexpected extraction needs inspection: {work}")
        for name, path in found_members.items():
            info = expected_members[name]
            crc = 0
            with path.open("rb") as stream:
                for block in iter(lambda: stream.read(2 ** 20), b""):
                    crc = zlib.crc32(block, crc)
            if path.stat().st_size != info.file_size or crc != info.CRC:
                raise RuntimeError(f"Existing extracted member fails CRC: {name}")
    else:
        work.mkdir(parents=True)
        subprocess.run([str(seven_zip or seven_zip_executable()), "x", "-y", "-bso0", "-bsp0", f"-o{work}", str(archive)], check=True, capture_output=True)
    folder = work / bearing
    paths = sorted(folder.glob("*.mat"), key=lambda p: (parse_filename(p)["condition"], parse_filename(p)["run"]))
    if len(paths) != 80:
        raise RuntimeError(f"Expected 80 measurement records, observed {len(paths)}")
    target.mkdir(parents=True, exist_ok=True)
    vibration_rows = []
    vibration_times = {}
    speed_rows = {}
    rows = []
    original_hashes = []
    max_roundoff = 0.0
    offset = 0
    for row_index, path in enumerate(paths):
        meta = parse_filename(path)
        if meta["bearing_id"] != bearing or meta["condition"] not in CONDITIONS:
            raise RuntimeError("Filename identity mismatch")
        parsed = load_paderborn_mat(path)
        values = np.asarray(parsed["signals"]["vibration_1"])
        rate = signal_sampling_rate_hz(parsed, "vibration_1")
        raster = parsed["raster_by_name"]["vibration_1"]
        times = parsed["time_vectors"][raster]
        if values.ndim != 1 or not np.isfinite(values).all() or not np.isfinite(times).all() or len(times) != len(values) or not np.isfinite(rate) or rate <= 0:
            raise RuntimeError("Unexpected vibration shape, finiteness or sample rate")
        converted = values.astype(np.float32)
        vibration_rows.append(converted)
        vibration_times[f"record_{row_index:03d}"] = np.ascontiguousarray(times, dtype="<f8").view(np.uint8).reshape(-1, 8).T.copy()
        max_roundoff = max(max_roundoff, float(np.max(np.abs(values - converted.astype(np.float64)))))
        speed = np.asarray(parsed["signals"]["speed"], dtype=np.float64)
        speed_rows[f"record_{row_index:03d}"] = speed
        mat_sha = digest(path)
        original_hashes.append({"member": path.relative_to(work).as_posix(), "bytes": path.stat().st_size, "sha256": mat_sha})
        label, name, mechanism, extent = LABELS[bearing]
        intervals = np.diff(times)
        rows.append({"row_index": row_index, "bearing_id": bearing, "label": label, "label_name": name, "damage_mechanism": mechanism, "damage_extent_level": extent, "condition": meta["condition"], "run": meta["run"], "file_id": meta["file_id"], "original_archive_member": path.relative_to(work).as_posix(), "original_mat_sha256": mat_sha, "nominal_sample_rate_hz": 64000, "timestamp_mean_sample_rate_hz": rate, "packed_array_start": offset, "sample_count": len(values), "nominal_record_duration_s": len(values) / 64000, "timestamp_duration_s": float(times[-1] - times[0]), "time_first_s": float(times[0]), "time_last_s": float(times[-1]), "timestamp_min_dt_s": float(intervals.min()), "timestamp_max_dt_s": float(intervals.max()), "timestamp_median_dt_s": float(np.median(intervals)), "timestamp_nonpositive_intervals": int((intervals <= 0).sum()), "timestamp_off_nominal_5pct_intervals": int((np.abs(intervals * 64000 - 1) > .05).sum()), "timestamp_max_abs_nominal_grid_error_s": float(np.max(np.abs(times - (times[0] + np.arange(len(times))/64000)))), "vibration_native_raster": raster, "speed_sample_rate_hz": signal_sampling_rate_hz(parsed, "speed"), "speed_min": float(np.min(speed)), "speed_max": float(np.max(speed)), "speed_mean": float(np.mean(speed)), "vibration_min": float(np.min(values)), "vibration_max": float(np.max(values)), "vibration_rms": float(np.sqrt(np.mean(values ** 2))), "array_file": (target / "vibration.npy").relative_to(ROOT).as_posix(), "array_dtype": "float32", "timestamp_array_key": f"record_{row_index:03d}", "label_source": "Lessmeier et al. 2016 " + ("Table 4" if mechanism.startswith("artificial") else "Table 7" if label == 0 else "Table 5") + "; archive bearing profile"})
        offset += len(values)
    np.save(target / "vibration.npy", np.concatenate(vibration_rows))
    frame = pd.DataFrame(rows)
    counts = frame.groupby("condition")["run"].apply(lambda s: sorted(s.tolist())).to_dict()
    if set(counts) != CONDITIONS or any(runs != list(range(1, 21)) for runs in counts.values()):
        raise RuntimeError("Incomplete condition/run grid")
    frame.to_csv(target / "records.csv", index=False)
    np.savez_compressed(target / "speed.npz", **speed_rows)
    np.savez_compressed(target / "vibration_timestamps.npz", **vibration_times)
    profile_dir = DOC / "profiles" / bearing
    profile_dir.mkdir(parents=True, exist_ok=True)
    profiles = []
    for source in sorted(folder.glob("*.pdf")):
        output = profile_dir / source.name
        shutil.copyfile(source, output)
        document = fitz.open(output)
        text = "\n".join(page.get_text() for page in document)
        output.with_suffix(".txt").write_text(text, encoding="utf-8")
        profiles.append({"path": output.relative_to(ROOT).as_posix(), "sha256": digest(output), "text_path": output.with_suffix(".txt").relative_to(ROOT).as_posix()})
    outputs = [{"path": p.relative_to(ROOT).as_posix(), "sha256": digest(p), "bytes": p.stat().st_size} for p in [target / "vibration.npy", target / "records.csv", target / "speed.npz", target / "vibration_timestamps.npz"]]
    report = {"status": "PASS", "bearing_id": bearing, "archive": archive.name, "archive_sha256": sha, "archive_deposit_md5": md5, "record_count": len(rows), "condition_run_grid": counts, "transformation": "vibration_1 float64 to float32 cast only; full native records; no crop/filter/resampling/normalization", "timestamp_encoding": "lossless little-endian float64 byteplanes: uint8[8,N]; transpose-copy then view <f8", "max_absolute_float32_roundoff": max_roundoff, "independent_bearing_units": 1, "recordings_are_not_independent_bearings": True, "label": LABELS[bearing], "original_files": original_hashes, "profile_files": profiles, "outputs": outputs, "completed_utc": datetime.now(timezone.utc).isoformat()}
    (target / "extraction_audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    # Delete only this script's checked temporary extraction, after outputs pass.
    resolved = work.resolve()
    allowed = (RAW / "working").resolve()
    if resolved.parent != allowed or resolved.name != bearing:
        raise RuntimeError("Temporary cleanup target is outside the intended extraction root")
    shutil.rmtree(resolved)
    print(json.dumps({"bearing": bearing, "records": len(rows), "packed_shape": [offset], "nominal_rate_hz": 64000, "sample_count_min": int(frame.sample_count.min()), "sample_count_max": int(frame.sample_count.max()), "timestamp_nonpositive_intervals": int(frame.timestamp_nonpositive_intervals.sum()), "max_float32_roundoff": max_roundoff, "status": "PASS"}), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ids", nargs="+", choices=ALL_IDS, default=list(IDS))
    parser.add_argument("--archive-dir", type=Path, default=RAW,
                        help="Directory containing the source RAR files; raw archives are read only.")
    parser.add_argument("--seven-zip", type=Path, help="Path to the 7-Zip executable.")
    args = parser.parse_args()
    for bearing in args.ids:
        extract(bearing, args.archive_dir, args.seven_zip)


if __name__ == "__main__":
    main()
