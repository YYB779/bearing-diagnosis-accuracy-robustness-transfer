"""Prepare only fixed eligible Paderborn measurements; no model prediction."""
from pathlib import Path
import argparse,json,hashlib
import numpy as np
import pandas as pd
from scripts.v7.paderborn_specimen import (DEV_IDS,TEST_IDS,LABELS,CONDITIONS,
    screen_record,make_patch_views,load_timestamps,eligible_specimens,OFFSETS,TARGET_FS)

ROOT=Path(__file__).resolve().parents[2]
RAW=ROOT/'data/raw/v7_paderborn/derived_by_specimen'
OUT=ROOT/'data/processed/v7'
DOC=ROOT/'docs/v7'


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def write_json(path,value):
    Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')


def prepare(role):
    ids=DEV_IDS if role=='development' else TEST_IDS
    OUT.mkdir(parents=True,exist_ok=True);DOC.mkdir(parents=True,exist_ok=True)
    nominal=[];timestamp=[];rows=[];availability=[];source={}
    for bearing in ids:
        folder=RAW/bearing
        for name in ['records.csv','vibration.npy','vibration_timestamps.npz','extraction_audit.json']:
            p=folder/name
            if not p.exists():raise FileNotFoundError(p)
            source[str(p.relative_to(ROOT))]=sha(p)
        extracted=json.loads((folder/'extraction_audit.json').read_text(encoding='utf-8'))
        for record in extracted['outputs']:
            p=ROOT/record['path']
            if p.name in ['records.csv','vibration.npy','vibration_timestamps.npz']:
                assert source[str(p.relative_to(ROOT))]==record['sha256']
        frame=pd.read_csv(folder/'records.csv');packed=np.load(folder/'vibration.npy',mmap_mode='r',allow_pickle=False)
        for condition in CONDITIONS:
            for run in range(1,5):
                selected=frame[(frame.condition==condition)&(frame.run==run)]
                base={'bearing_id':bearing,'class_id':LABELS[bearing],'condition':condition,'run':run,'role':role}
                if len(selected)!=1:
                    availability.append({**base,'file_id':f'{condition}_{bearing}_{run}','eligible':False,'reasons':'missing_or_ambiguous_selected_measurement'})
                    continue
                record=selected.iloc[0]
                assert record.bearing_id==bearing and int(record.label)==LABELS[bearing] and int(record.nominal_sample_rate_hz)==64000
                a=int(record.packed_array_start);n=int(record.sample_count)
                v=packed[a:a+n];t=load_timestamps(folder/'vibration_timestamps.npz',record.timestamp_array_key)
                gate=screen_record(v,t)
                availability.append({**base,'file_id':str(record.file_id),**gate,'reasons':'|'.join(gate['reasons'])})
                if not gate['eligible']:continue
                x,y=make_patch_views(v,t);nominal.extend(x);timestamp.extend(y)
                for patch in range(16):
                    second=patch//4;offset=OFFSETS[patch%4]
                    rows.append({**base,'file_id':str(record.file_id),'source_record':str(record.file_id),
                        'label':LABELS[bearing],'patch_index':patch,'second':second,'offset_25k':offset,
                        'start_25k':second*TARGET_FS+offset,'stop_25k_exclusive':second*TARGET_FS+offset+2048,
                        'patch_id':f'{record.file_id}_p{patch:02d}'})
        print(f'PREPARED {role} {bearing}',flush=True)
    lineage=pd.DataFrame(rows);availability=pd.DataFrame(availability)
    keep,bearing_report=eligible_specimens(lineage)
    for b in ids:
        if b not in set(lineage.bearing_id):bearing_report.append({'bearing_id':b,'eligible':False,'conditions':[],'missing_conditions':CONDITIONS})
    retain=lineage.bearing_id.isin(keep).to_numpy();lineage=lineage.loc[retain].reset_index(drop=True)
    x=np.asarray(nominal,np.float32)[retain];y=np.asarray(timestamp,np.float32)[retain]
    if role=='development' and set(keep)!=set(DEV_IDS):
        write_json(DOC/'paderborn_specimen_development_unavailable.json',{'availability':availability.to_dict('records'),'bearings':bearing_report})
        raise RuntimeError('Fixed development bearing grid unavailable; do not redraw CV')
    if not len(lineage) or set(lineage.class_id)!={0,1,2}:raise RuntimeError('No class-complete eligible specimen analysis')
    assert x.shape==y.shape==(len(lineage),2048) and not lineage.patch_id.duplicated().any()
    npz=OUT/f'paderborn_specimen_{role}_patches.npz';csv=OUT/f'paderborn_specimen_{role}_patch_lineage.csv'
    np.savez_compressed(npz,nominal=x,timestamp_sensitive=y,patch_id=lineage.patch_id.to_numpy(str),sample_rate_hz=np.array(25600))
    lineage.to_csv(csv,index=False)
    ap=DOC/f'paderborn_specimen_{role}_availability.csv';availability.to_csv(ap,index=False)
    report={'status':'PASS: feature input preparation only; no model fitting/prediction','role':role,
        'selected_specimens':ids,'eligible_specimens':sorted(keep),'selected_measurements':len(availability),
        'passing_measurements':int(availability.eligible.sum()),'patches':len(lineage),
        'bearings':bearing_report,'input_sha256':source,'outputs':{str(p.relative_to(ROOT)):sha(p) for p in [npz,csv,ap]},
        'timing_policy':'primary nominal64k prefix256000 resample2/5; pairedexactrelativeHostService interpolation sensitivity; not a validated physicalclock correction',
        'nominal_array_sha256':hashlib.sha256(x.tobytes()).hexdigest(),'timestamp_array_sha256':hashlib.sha256(y.tobytes()).hexdigest()}
    write_json(DOC/f'paderborn_specimen_{role}_preparation.json',report)
    print(json.dumps({k:report[k]for k in ['role','eligible_specimens','selected_measurements','passing_measurements','patches']},indent=2),flush=True)
    return report


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--role',choices=['development','test','all'],default='all');a=p.parse_args()
    for role in ['development','test'] if a.role=='all' else [a.role]:prepare(role)
