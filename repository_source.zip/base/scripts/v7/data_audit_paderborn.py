"""Fail-closed audit of newly acquired Paderborn specimens, without model access."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

from scripts.v7.data_download_paderborn import IDS, DEV_IDS, ALL_IDS, ROOT, RAW, DOC, hashes
from scripts.v7.data_extract_paderborn import LABELS, CONDITIONS, load_timestamps


def sha(path):
    return hashes(path)[1]


def audit(scope):
    selected = {"fresh": IDS, "development": DEV_IDS, "all": ALL_IDS}[scope]
    downloads = {row["bearing_id"]: row for row in json.loads((DOC / "download_manifest.json").read_text(encoding="utf-8"))}
    records = []
    specimen_reports = []
    for bearing in selected:
        folder = RAW / "derived_by_specimen" / bearing
        audit_path = folder / "extraction_audit.json"
        report = json.loads(audit_path.read_text(encoding="utf-8"))
        assert report["status"] == "PASS"
        md5, archive_sha = hashes(RAW / f"{bearing}.rar")
        assert archive_sha == downloads[bearing]["sha256"] == report["archive_sha256"]
        assert md5 == downloads[bearing]["deposit_md5"] == report["archive_deposit_md5"]
        for item in report["outputs"]:
            path = ROOT / item["path"]
            assert path.stat().st_size == item["bytes"] and sha(path) == item["sha256"], path
        for item in report["profile_files"]:
            assert sha(ROOT / item["path"]) == item["sha256"]
        frame = pd.read_csv(folder / "records.csv")
        assert len(frame) == 80 and frame.file_id.is_unique
        assert set(frame.bearing_id) == {bearing}
        assert set(frame.condition) == CONDITIONS
        assert all(sorted(g.run.tolist()) == list(range(1, 21)) for _, g in frame.groupby("condition"))
        assert set(frame.label) == {LABELS[bearing][0]}
        assert frame.original_mat_sha256.tolist() == [item["sha256"] for item in report["original_files"]]
        values = np.load(folder / "vibration.npy", mmap_mode="r", allow_pickle=False)
        assert values.ndim == 1 and values.dtype == np.float32 and np.isfinite(values).all()
        assert frame.packed_array_start.tolist() == [0] + np.cumsum(frame.sample_count.to_numpy())[:-1].tolist()
        assert int(frame.sample_count.sum()) == len(values)
        with np.load(folder / "vibration_timestamps.npz", allow_pickle=False) as timestamp_file:
            assert set(timestamp_file.files) == set(frame.timestamp_array_key)
        for row in frame.itertuples():
            times = load_timestamps(folder / "vibration_timestamps.npz", row.timestamp_array_key)
            assert len(times) == row.sample_count and np.isfinite(times).all()
            dt = np.diff(times)
            assert int((dt <= 0).sum()) == row.timestamp_nonpositive_intervals
            assert abs((times[-1] - times[0]) - row.timestamp_duration_s) < 1e-12
            actual_error = np.max(np.abs(times - (times[0] + np.arange(len(times))/64000)))
            assert abs(actual_error - row.timestamp_max_abs_nominal_grid_error_s) < 1e-12
        frame["specimen_role"] = "fresh_external" if bearing in IDS else "historically_exposed_development"
        records.append(frame)
        specimen_reports.append({"bearing_id": bearing, "label": LABELS[bearing][0], "specimen_role": frame.specimen_role.iloc[0], "records": len(frame), "samples_min": int(frame.sample_count.min()), "samples_max": int(frame.sample_count.max()), "timestamps_nonpositive_total": int(frame.timestamp_nonpositive_intervals.sum()), "mean_timestamp_fs_min": float(frame.timestamp_mean_sample_rate_hz.min()), "mean_timestamp_fs_max": float(frame.timestamp_mean_sample_rate_hz.max()), "float32_max_roundoff": report["max_absolute_float32_roundoff"], "extraction_audit_path": audit_path.relative_to(ROOT).as_posix(), "extraction_audit_sha256": sha(audit_path), "outputs": report["outputs"]})
    combined = pd.concat(records, ignore_index=True)
    assert combined.file_id.is_unique
    assert combined.original_mat_sha256.is_unique
    old_ids = set(pd.read_csv(ROOT / "data/processed/paderborn_curated_dataset.csv").bearing_id)
    assert set(IDS).isdisjoint(old_ids)
    assert set(DEV_IDS).issubset(old_ids)
    output = DOC / f"{scope}_records.csv"
    combined.to_csv(output, index=False)
    result = {"status": "PASS", "scope": scope, "model_access": False, "independent_specimens": len(selected), "recordings": len(combined), "classes": sorted(combined.label.unique().tolist()), "specimens_per_class": {str(k): int(v) for k, v in combined.groupby("label").bearing_id.nunique().items()}, "fresh_ids_disjoint_from_previous_subset": True, "development_ids_previously_exposed": True, "old_subset_ids": sorted(old_ids), "recordings_are_not_independent_specimens": True, "primary_original_data_license": "CC-BY-NC-4.0", "third_party_deposit_license_conflict": "Zenodo metadata says CC-BY-4.0; original noncommercial restriction preserved", "specimens": specimen_reports, "combined_records": {"path": output.relative_to(ROOT).as_posix(), "sha256": sha(output)}, "timestamp_caveat": "HostService raster interpretation unresolved; nominal64kHz from primary paper; all exact original timestamps retained", "completed_utc": datetime.now(timezone.utc).isoformat()}
    (DOC / f"{scope}_specimens_audit.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: result[k] for k in ["status", "scope", "independent_specimens", "recordings", "specimens_per_class"]}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", choices=["fresh", "development", "all"], default="fresh")
    audit(parser.parse_args().scope)
