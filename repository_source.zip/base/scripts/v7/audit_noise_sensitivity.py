"""Independent noise-array, record-lineage and metric reconciliation."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
from scripts.v7.noise_sensitivity import make_panel
from scripts.v7.audit_matched_classical import direct_metrics
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'results/v7/noise_sensitivity'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
 audit=json.loads((OUT/'audit.json').read_text());design=json.loads((OUT/'design.json').read_text());assert audit['passed']
 count=0
 for manifest in [audit['sha256'],design['sha256']]:
  for relative,expected in manifest.items():assert sha(ROOT/relative)==expected,relative;count+=1
 for item in design['models']:
  for suffix in ['weight','metadata']:assert sha(ROOT/item[suffix+'_path'])==item[suffix+'_sha256'];count+=1
 x=np.load(ROOT/'data/processed/v5/hust_neural_patches.npz',allow_pickle=False)['x'];arrays=json.loads((OUT/'noise_arrays.json').read_text())
 for row in arrays:assert hashlib.sha256(make_panel(x,row['family'],row['draw']).tobytes()).hexdigest()==row['array_sha256']
 records=pd.read_csv(OUT/'record_predictions.csv');pooled=pd.read_csv(OUT/'pooled_summary.csv');folds=pd.read_csv(OUT/'fold_summary.csv');checks=0;error=0.
 keys=['study','arm','seed','excluded','draw','family'];lineage=pd.read_csv(ROOT/'data/processed/v5/hust_neural_patch_lineage.csv');expected=lineage[['source_record','class_id','condition']].drop_duplicates().sort_values('source_record')
 for row in pooled.to_dict('records'):
  mask=np.ones(len(records),bool)
  for key in keys:mask&=records[key].eq(row[key]).to_numpy()
  sub=records[mask].sort_values('source_record');assert len(sub)==21
  assert sub.source_record.tolist()==expected.source_record.tolist() and sub.class_id.tolist()==expected.class_id.tolist() and sub.condition.tolist()==expected.condition.tolist()
  for k,v in direct_metrics(sub).items():error=max(error,abs(row[k]-v))
  assert sub.patch_count.eq(32).all();assert row['omitted_family_endpoint']==(row['study']=='v7' and row['excluded']==row['family']);checks+=1
 for row in folds.to_dict('records'):
  mask=np.ones(len(records),bool)
  for key in keys+['fold']:mask&=records[key].eq(row[key]).to_numpy()
  sub=records[mask]
  for k,v in direct_metrics(sub).items():error=max(error,abs(row[k]-v))
 assert error<1e-12 and checks==432
 bn=json.loads((OUT/'batchnorm_audit.json').read_text());assert len(bn)==180 and all(r['unchanged'] for r in bn)
 result={'passed':True,'checked_file_sha256':count,'regenerated_new_noise_arrays':len(arrays),'record_predictions':len(records),'pooled_cells':checks,'fold_cells':len(folds),'max_abs_direct_metric_difference':error,'batchnorm_unchanged_models':180,'model_weight_hashes_unchanged':180,'historical_panels_in_new_repeats':0,'script_sha256':sha(Path(__file__)),'analysis_audit_sha256':sha(OUT/'audit.json')}
 (ROOT/'docs/v7/noise_sensitivity_independent_audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
