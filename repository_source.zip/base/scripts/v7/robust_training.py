"""Mixed synthetic corruptions and source-condition Group DRO.

Group DRO follows Sagawa et al., ICLR 2020, arXiv:1911.08731.
This is a controlled adaptation, not a new optimization algorithm.
"""
import numpy as np
import torch
from scripts.v6.consistency import add_noise
from scripts.v5.prepare_neural_patches import zscore_patch

FAMILIES = ('awgn', 'colored', 'impulse', 'tone')


def synthetic_noise(shape, family, rng, fs=25600):
    if family not in FAMILIES:
        raise ValueError('Unknown corruption family')
    n, length = shape
    if family == 'awgn':
        return rng.normal(size=shape)
    if family == 'colored':
        z = rng.normal(size=shape)
        frequency = np.fft.rfftfreq(length, 1 / fs)
        weight = 1 / np.sqrt(np.maximum(frequency, fs / length))
        return np.fft.irfft(np.fft.rfft(z, axis=-1) * weight, n=length, axis=-1)
    if family == 'impulse':
        # A zero-impulse patch is deterministically given one Gaussian impulse.
        # This rare implementation guard is label-blind and explicitly logged.
        z = rng.normal(size=shape) * (rng.random(size=shape) < .005)
        empty = np.flatnonzero(np.sum(z * z, axis=-1) == 0)
        for row in empty:
            z[row, int(rng.integers(length))] = 1.
        return z
    frequency = rng.uniform(300, 10000, size=(n, 1))
    phase = rng.uniform(0, 2 * np.pi, size=(n, 1))
    return np.sin(2 * np.pi * frequency * np.arange(length)[None, :] / fs + phase)


def mixed_views(x, rng, excluded):
    """One clean and two iid mixed-family views, never using excluded family."""
    if excluded not in FAMILIES:
        raise ValueError('An entire named family must be excluded')
    allowed = [f for f in FAMILIES if f != excluded]
    views = [zscore_patch(x)]
    assignments = []
    for _ in range(2):
        choice = rng.integers(0, len(allowed), size=len(x))
        family_names = np.asarray(allowed)[choice]
        noise = np.empty(x.shape, dtype=float)
        for family in allowed:
            mask = family_names == family
            if mask.any():
                noise[mask] = synthetic_noise((int(mask.sum()), x.shape[-1]), family, rng)
        snr = rng.uniform(-4, 12, size=len(x))
        views.append(zscore_patch(add_noise(x, noise, snr).astype(np.float32)))
        assignments.append(family_names)
    return np.stack(views), np.stack(assignments)


def group_mean_losses(example_losses, group_ids, n_groups=3):
    if example_losses.ndim != 1 or group_ids.shape != example_losses.shape:
        raise ValueError('Per-example losses and group IDs must align')
    if set(group_ids.detach().cpu().tolist()) != set(range(n_groups)):
        raise ValueError('All source-condition groups must be present')
    return torch.stack([example_losses[group_ids == i].mean() for i in range(n_groups)])


def update_adversarial_weights(log_q, group_losses, step_size=.01):
    if log_q.shape != group_losses.shape or step_size <= 0:
        raise ValueError('One positive-step weight per group required')
    # Stable equivalent of q <- q * exp(eta * detached group loss), normalized.
    with torch.no_grad():
        updated = torch.log_softmax(log_q + step_size * group_losses.detach(), dim=0)
    return updated
