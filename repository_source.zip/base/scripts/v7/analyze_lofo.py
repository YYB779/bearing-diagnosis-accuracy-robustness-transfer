"""Fail-closed audit, independent selected-weight replay and complete LOFO tables.

Reuses the independent V6 audit's metrics, panel generator and normalizer;
never imports either measured-data fitting loop or training augmentation.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import numpy as np
import pandas as pd
import torch
from scripts.v5.classbd_models import ClassBDWDCNN
from scripts.v6.analyze_results import (independent_panels, normalized_patch, scores,
    compare_metrics, require, sha, array_sha, noise_scaled_to_snr, history_confusion_check)

ROOT=Path(__file__).resolve().parents[2]
RUN=ROOT/'results/v7/lofo'
OUT=ROOT/'results/v7/analysis'
FAMILIES=['awgn','colored','impulse','tone']
ARMS=['mixed_erm','mixed_dro']
SEEDS=[11,22,33]
PRIMARY={'awgn':'AWGN-4dB','colored':'colored-4dB','impulse':'impulse-4dB','tone':'tone-4dB'}


def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,obj):Path(p).write_text(json.dumps(obj,indent=2,allow_nan=False),encoding='utf-8')


def independent_mixed_views(values,excluded,fold,seed,step):
    """Rebuild every source augmentation without importing the training recipe."""
    rng=np.random.default_rng(700000+seed*1000+fold*10000+step)
    allowed=[f for f in FAMILIES if f!=excluded]
    views=[normalized_patch(values)];assignments=[]
    length=values.shape[1]
    for _ in range(2):
        choice=rng.integers(0,len(allowed),size=len(values))
        names=np.asarray(allowed)[choice]
        disturbances=np.empty(values.shape,dtype=float)
        for family in allowed:
            mask=names==family;n=int(mask.sum())
            if not n:continue
            shape=(n,length)
            if family=='awgn':noise=rng.normal(size=shape)
            elif family=='colored':
                white=rng.normal(size=shape)
                frequency=np.fft.rfftfreq(length,1/25600)
                weight=1/np.sqrt(np.maximum(frequency,25600/length))
                noise=np.fft.irfft(np.fft.rfft(white,axis=-1)*weight,n=length,axis=-1)
            elif family=='impulse':
                noise=rng.normal(size=shape)*(rng.random(size=shape)<.005)
                for row in np.flatnonzero((noise*noise).sum(axis=-1)==0):
                    noise[row,int(rng.integers(length))]=1.
            elif family=='tone':
                frequency=rng.uniform(300,10000,size=(n,1))
                phase=rng.uniform(0,2*np.pi,size=(n,1))
                noise=np.sin(2*np.pi*frequency*np.arange(length)[None,:]/25600+phase)
            else:raise AssertionError('Unexpected family')
            disturbances[mask]=noise
        snr=rng.uniform(-4,12,size=len(values))
        noisy=noise_scaled_to_snr(values,disturbances,snr).astype(np.float32)
        views.append(normalized_patch(noisy));assignments.append(names)
    assignments=np.stack(assignments)
    require(excluded not in set(assignments.ravel()),'Excluded family entered training')
    return {'views':array_sha(np.stack(views)),'families':array_sha(assignments.astype('U8'))}


def independent_inference(model,x,frame,indices):
    model.eval();chunks=[]
    before={k:v.clone() for k,v in model.state_dict().items() if 'running_' in k or 'num_batches_tracked' in k}
    with torch.no_grad():
        for start in range(0,len(indices),48):
            z=normalized_patch(x[indices[start:start+48]])
            logits=model(torch.from_numpy(z[:,None,:]))['logits']
            chunks.append(torch.softmax(logits,dim=1).numpy().astype(np.float64))
    after=model.state_dict()
    require(all(torch.equal(v,after[k]) for k,v in before.items()),'Evaluation mutated BN buffers')
    p=np.concatenate(chunks);sub=frame.iloc[indices]
    rows=[]
    for name in sorted(sub.source_record.unique()):
        mask=sub.source_record.to_numpy()==name
        labels=sub.loc[mask,'class_id'].unique()
        require(len(labels)==1,'Record has conflicting labels')
        pr=p[mask].mean(0);pr/=pr.sum()
        rows.append({'source_record':name,'label':int(labels[0]),'p_H':pr[0],'p_I':pr[1],'p_O':pr[2]})
    return pd.DataFrame(rows),len(before)


def main(args):
    torch.set_num_threads(2);torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    OUT.mkdir(parents=True,exist_ok=True)
    write(OUT/'audit.json',{'passed':False,'status':'running','started_utc':datetime.now(timezone.utc).isoformat()})
    design=read(RUN/'design.json')
    require(design['arms']==ARMS and design['excluded_families']==FAMILIES and design['seeds']==SEEDS,'Unexpected factorial design')
    require(design['updates']==480 and design['planned_models']==120,'Unexpected experiment size')
    for path,digest in design['sha256'].items():require(sha(ROOT/path)==digest,'Frozen input changed: '+path)
    archive=np.load(ROOT/'data/processed/v5/hust_neural_patches.npz',allow_pickle=False)
    x=archive['x'];frame=pd.read_csv(ROOT/'data/processed/v5/hust_neural_patch_lineage.csv')
    conditions=['20Hz','30Hz','40Hz','60Hz','VS_0_40_0Hz']
    frame['domain_id']=frame.condition.map(dict(zip(conditions,range(5))))
    panels,_=independent_panels(x)
    for name,z in panels.items():require(array_sha(z)==design['test_panel_sha256'][name],'Panel hash mismatch')
    rows=[];model_hashes={};artifact_hashes={};maximum_metric=0.;maximum_probability=0.;buffers=0;paired_steps=0;regenerated_steps=0;count=0
    for excluded in FAMILIES:
        for fold in range(5):
            ti=np.flatnonzero(frame.domain_id.eq(fold));vi=np.flatnonzero(frame.domain_id.eq((fold+1)%5))
            for seed in SEEDS:
                split=read(RUN/f'fold{fold}_s{seed}_split.json')
                sets=[set(split[k]) for k in ['train_records','validation_records','test_records']]
                expected_sets=[set(frame.loc[~frame.domain_id.isin([fold,(fold+1)%5]),'source_record']),set(frame.iloc[vi].source_record),set(frame.iloc[ti].source_record)]
                require(sets==expected_sets and set.union(*sets)==set(frame.source_record),'Wrong source/validation/test file assignment')
                require(split['fold']==fold and split['seed']==seed,'Wrong split identity')
                require(all(not sets[a]&sets[b] for a,b in [(0,1),(0,2),(1,2)]),'File leakage')
                batches=np.asarray(split['batch_indices'],int)
                require(batches.shape==(480,18),'Wrong training budget')
                for idx in batches:
                    sf=frame.iloc[idx]
                    require(set(sf.source_record)<=sets[0],'Non-source training batch')
                    counts=sf.groupby(['domain_id','class_id']).size()
                    require(len(counts)==9 and counts.eq(2).all(),'Batch class/domain balance changed')
                paired=[]
                for arm in ARMS:
                    stem=f'{excluded}_fold{fold}_{arm}_s{seed}'
                    rp=RUN/(stem+'.json');r=read(rp);count+=1
                    require(all(r[k]==v for k,v in [('excluded',excluded),('fold',fold),('seed',seed),('arm',arm)]),'Wrong result identity')
                    require(r['design_sha256']==sha(RUN/'design.json'),'Wrong design binding')
                    require(r['split_sha256']==sha(RUN/f'fold{fold}_s{seed}_split.json'),'Wrong split binding')
                    for key,suffix in [('model_sha256','.pt'),('predictions_sha256','_predictions.csv'),('views_sha256','_views.json')]:
                        require(r[key]==sha(RUN/(stem+suffix)),'Corrupt artifact: '+stem+suffix)
                        artifact_hashes[str((RUN/(stem+suffix)).relative_to(ROOT))]=r[key]
                    paired.append(read(RUN/(stem+'_views.json')))
                    require(len(paired[-1])==480,'Incomplete view trace')
                    require(len(r['trajectory'])==480,'Incomplete group trace')
                    q=np.full(3,1/3.)
                    for i,t in enumerate(r['trajectory'],1):
                        require(t['update']==i,'Unordered group trace')
                        gl=np.asarray(t['group_ce'],float);logged=np.asarray(t['q'],float)
                        require(gl.shape==(3,) and np.isfinite(gl).all(),'Bad group losses')
                        require(logged.shape==(3,) and np.isfinite(logged).all() and (logged>0).all() and abs(logged.sum()-1)<1e-5,'Invalid group weights')
                        require(np.isfinite(t['gradient_norm']) and t['gradient_norm']>=0,'Invalid gradient norm')
                        if arm=='mixed_dro':
                            lq=np.log(np.maximum(q,np.finfo(float).tiny))+.01*gl
                            q=np.exp(lq-lq.max());q/=q.sum()
                        require(np.max(abs(logged-q))<2e-5,'DRO weight update mismatch')
                        expected=float(gl@logged) if arm=='mixed_dro' else float(gl.mean())
                        require(abs(t['loss']-expected)<2e-5,'Group objective mismatch')
                    history=r['history']
                    require([a['update'] for a in history]==[120,240,360,480],'Wrong checkpoint options')
                    for entry in history:history_confusion_check(entry['validation_clean'],len(sets[1]),stem+'/validation/'+str(entry['update']))
                    chosen=max(history,key=lambda a:(a['validation_clean']['macro_f1'],-a['validation_clean']['nll'],-a['update']))
                    require(chosen['update']==r['selected_update'],'Wrong selected checkpoint')
                    stored=pd.read_csv(RUN/(stem+'_predictions.csv'))
                    require(not stored.duplicated(['role','panel','source_record']).any(),'Duplicated prediction records')
                    require(set(zip(stored.role,stored.panel))=={('validation','clean')}|{('test',p) for p in panels},'Unexpected prediction panels')
                    model=ClassBDWDCNN(variant='baseline')
                    checkpoint=torch.load(RUN/(stem+'.pt'),map_location='cpu',weights_only=False)
                    model.load_state_dict(checkpoint['model_state'])
                    require(checkpoint['design_sha256']==r['design_sha256'],'Weight metadata mismatch')
                    require(all(checkpoint[k]==v for k,v in [('excluded',excluded),('fold',fold),('seed',seed),('arm',arm),('selected_update',r['selected_update'])]),'Wrong weight identity')
                    require(sum(p.numel() for p in model.parameters())==r['model_parameters']==66083,'Wrong architecture size')
                    for role,panel,z,indices in [('validation','clean',x,vi)]+[('test',n,z,ti) for n,z in panels.items()]:
                        sub=stored[(stored.role==role)&(stored.panel==panel)].sort_values('source_record').reset_index(drop=True)
                        require(sub.source_record.tolist()==sorted(frame.iloc[indices].source_record.unique()),'Wrong evaluation files')
                        y=sub.label.to_numpy(int);pr=sub[['p_H','p_I','p_O']].to_numpy(float)
                        expected_labels=frame.iloc[indices].groupby('source_record').class_id.first().reindex(sub.source_record).to_numpy(int)
                        require(np.array_equal(y,expected_labels),'Prediction labels disagree with frozen lineage')
                        met=scores(y,pr)
                        expected=r['validation_clean'] if role=='validation' else r['test'][panel]
                        maximum_metric=max(maximum_metric,compare_metrics(met,expected,stem+'/'+role+'/'+panel))
                        if not args.no_replay:
                            replay,n=independent_inference(model,z,frame,indices);buffers+=n
                            require(replay.source_record.tolist()==sub.source_record.tolist(),'Replay row misalignment')
                            delta=float(np.max(abs(replay[['p_H','p_I','p_O']].to_numpy()-pr)))
                            maximum_probability=max(maximum_probability,delta)
                            require(delta<1e-6,'Selected-weight prediction mismatch')
                        if role=='test':
                            for _,a in sub.iterrows():rows.append({'excluded':excluded,'fold':fold,'seed':seed,'arm':arm,'panel':panel,
                                'source_record':a.source_record,'label':int(a.label),'p_H':a.p_H,'p_I':a.p_I,'p_O':a.p_O})
                    model_hashes[str(rp.relative_to(ROOT))]=sha(rp)
                require(paired[0]==paired[1],'ERM/DRO did not receive identical training views')
                for step,idx in enumerate(batches,1):
                    regenerated=independent_mixed_views(x[idx],excluded,fold,seed,step)
                    require(regenerated==paired[0][step-1],'Independent training view mismatch')
                    regenerated_steps+=1
                paired_steps+=480
            print(f'AUDIT {excluded} fold{fold}: {count}/120 weights verified',flush=True)
    require(count==120,'Missing models')
    require(paired_steps==regenerated_steps==28800,'Missing paired or independently regenerated training steps')
    predictions=pd.DataFrame(rows);predictions.to_csv(OUT/'record_predictions.csv',index=False)
    pooled=[]
    for (excluded,arm,seed,panel),sub in predictions.groupby(['excluded','arm','seed','panel'],sort=False):
        require(len(sub)==21 and sub.source_record.nunique()==21,'OOF files duplicated or missing')
        met=scores(sub.label.to_numpy(int),sub[['p_H','p_I','p_O']].to_numpy(float))
        pooled.append({'excluded':excluded,'arm':arm,'seed':int(seed),'panel':panel,
            'is_excluded_panel':panel==PRIMARY[excluded],**{k:v for k,v in met.items() if k!='confusion_matrix'}})
    pf=pd.DataFrame(pooled);pf.to_csv(OUT/'pooled_summary.csv',index=False)
    descriptive=[]
    for (excluded,arm,panel),sub in pf.groupby(['excluded','arm','panel'],sort=False):
        row={'excluded':excluded,'arm':arm,'panel':panel,'is_excluded_panel':panel==PRIMARY[excluded]}
        for key in ['macro_f1','nll','multiclass_brier','recall_H','recall_I','recall_O']:
            row.update({key+'_mean':float(sub[key].mean()),key+'_min':float(sub[key].min()),key+'_max':float(sub[key].max())})
        descriptive.append(row)
    pd.DataFrame(descriptive).to_csv(OUT/'descriptive_summary.csv',index=False)
    contrasts=[]
    for (excluded,seed,panel),sub in pf.groupby(['excluded','seed','panel'],sort=False):
        a=sub.set_index('arm');row={'excluded':excluded,'seed':int(seed),'panel':panel,'is_excluded_panel':panel==PRIMARY[excluded]}
        for key in ['macro_f1','nll','multiclass_brier','recall_H','recall_I','recall_O']:
            row['dro_minus_erm_'+key]=float(a.loc['mixed_dro',key]-a.loc['mixed_erm',key])
        contrasts.append(row)
    pd.DataFrame(contrasts).to_csv(OUT/'contrasts.csv',index=False)
    report={'passed':not args.no_replay,'status':'full selected-weight replay complete' if not args.no_replay else 'tables only, full verification not complete',
        'finished_utc':datetime.now(timezone.utc).isoformat(),'models':count,'paired_view_steps':paired_steps,
        'independently_regenerated_training_view_steps':regenerated_steps,'excluded_family_absent_in_all_regenerated_training_assignments':True,
        'replayed_panels':0 if args.no_replay else 120*7,'unchanged_BN_buffer_checks':buffers,
        'max_probability_difference':maximum_probability,'max_metric_difference':maximum_metric,
        'pooled_rows':len(pf),'prediction_rows':len(predictions),'design_sha256':sha(RUN/'design.json'),
        'analyzer_sha256':sha(Path(__file__)),'result_hashes':model_hashes,'artifact_hashes':artifact_hashes,
        'output_sha256':{p.name:sha(p) for p in OUT.glob('*.csv')}}
    write(OUT/'audit.json',report);print(json.dumps({k:v for k,v in report.items() if k not in ['result_hashes','output_sha256']},indent=2),flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--no-replay',action='store_true')
    main(ap.parse_args())
