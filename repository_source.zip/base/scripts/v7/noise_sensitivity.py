"""Three new fixed-noise realizations, selected neural checkpoints only."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,time
import numpy as np
import pandas as pd
import torch
from scripts.v5.classbd_models import ClassBDWDCNN
from scripts.v5.prepare_neural_patches import zscore_patch
from scripts.v6.consistency import add_noise
from scripts.v7.robust_training import FAMILIES,synthetic_noise
from scripts.v7.run_matched_classical import aggregate_records,record_metrics,independent_metrics_check
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'results/v7/noise_sensitivity'
DRAW_SEEDS=[7201,7202,7203];CONDITIONS=['20Hz','30Hz','40Hz','60Hz','VS_0_40_0Hz'];PROBS=['p_H','p_I','p_O']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def array_sha(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')
def make_panel(x,family,draw):
 if family not in FAMILIES or draw not in DRAW_SEEDS:raise ValueError('Unregistered noise family or seed')
 rng=np.random.default_rng(np.random.SeedSequence([draw,list(FAMILIES).index(family)]))
 z=synthetic_noise(x.shape,family,rng)
 return add_noise(x,z,-4).astype(np.float32)
def model_inventory():
 inventory=[]
 for study,directory,count in [('v6',ROOT/'results/v6/robustness',60),('v7',ROOT/'results/v7/lofo',120)]:
  paths=sorted(directory.glob('*.pt'));assert len(paths)==count
  for path in paths:
   meta=path.with_suffix('.json');d=json.loads(meta.read_text(encoding='utf-8'))
   assert d['model_sha256']==sha(path)
   inventory.append({'study':study,'arm':d['arm'],'fold':d['fold'],'seed':d['seed'],
    'excluded':d.get('excluded','none'),'selected_update':d['selected_update'],
    'weight_path':str(path.relative_to(ROOT)),'weight_sha256':sha(path),
    'metadata_path':str(meta.relative_to(ROOT)),'metadata_sha256':sha(meta)})
 return inventory
def evaluate(model,x,indices):
 model.eval();parts=[]
 with torch.no_grad():
  for start in range(0,len(indices),48):
   batch=torch.from_numpy(zscore_patch(x[indices[start:start+48]])[:,None,:])
   parts.append(torch.softmax(model(batch)['logits'],dim=-1).numpy().astype(np.float64))
 return np.concatenate(parts)
def main(args):
 torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
 OUT.mkdir(parents=True,exist_ok=True);started=time.perf_counter()
 xp=ROOT/'data/processed/v5/hust_neural_patches.npz';lp=ROOT/'data/processed/v5/hust_neural_patch_lineage.csv'
 frame=pd.read_csv(lp);archive=np.load(xp,allow_pickle=False);x=archive['x']
 assert x.shape==(672,2048) and np.array_equal(archive['patch_id'],frame.patch_id.to_numpy(str))
 inventory=model_inventory();assert len(inventory)==180
 paths=[Path(__file__),ROOT/'docs/v7/noise_sensitivity_design.md',ROOT/'tests/evaluation/test_v7_noise_sensitivity.py',xp,lp,
  ROOT/'scripts/v7/robust_training.py',ROOT/'scripts/v6/consistency.py',ROOT/'scripts/v5/classbd_models.py',
  ROOT/'scripts/v5/prepare_neural_patches.py',ROOT/'scripts/v7/run_matched_classical.py',
  ROOT/'results/v6/robustness/design.json',ROOT/'results/v7/lofo/design.json']
 design={'frozen_utc':datetime.now(timezone.utc).isoformat(),'status':'retrospective fixed-checkpoint sensitivity, no new fit/selection',
  'draw_seed_labels':DRAW_SEEDS,'families':list(FAMILIES),'snr_db':-4,
  'rng_rule':'default_rng(SeedSequence([draw_seed,family_index])); full672patcharray before slicing; familyorder awgn,color,impulse,tone',
  'models':inventory,'planned_model_panel_cells':2160,'planned_record_predictions':9072,'planned_pooled_cells':432,
  'physical_n':'same21sourcefiles, unknown physical-bearing IDs; 3draws and3algorithmseeds are not physicalreplicates',
  'historical_panels':'not pooled; v7 empty-impulse guard differs from historicalv6 sparse-noise recipe',
  'sha256':{str(p.relative_to(ROOT)):sha(p) for p in paths},
  'software':{'torch':torch.__version__,'numpy':np.__version__,'pandas':pd.__version__,'threads':2}}
 dp=OUT/'design.json'
 if dp.exists():
  old=json.loads(dp.read_text(encoding='utf-8'));design['frozen_utc']=old['frozen_utc'];assert old==design,'Frozen noise sensitivity changed'
 else:save(dp,design)
 print('Noise sensitivity frozen before actual-data noise generation:180models,12newpanels',flush=True)
 if args.freeze_only:return
 if (OUT/'audit.json').exists():raise RuntimeError('Completed/noise audit exists; do not overwrite results')
 save(OUT/'status.json',{'passed':False,'status':'running'})
 panels={(draw,family):make_panel(x,family,draw) for draw in DRAW_SEEDS for family in FAMILIES}
 noise_rows=[]
 for (draw,family),values in panels.items():
  noise=values.astype(float)-x;noise-=noise.mean(1,keepdims=True);signal=x.astype(float)-x.mean(1,keepdims=True)
  measured=10*np.log10(np.mean(signal**2,1)/np.mean(noise**2,1))
  assert np.max(np.abs(measured+4))<1e-5
  guard_count=0
  if family=='impulse':
   guard_rng=np.random.default_rng(np.random.SeedSequence([draw,list(FAMILIES).index(family)]))
   raw=guard_rng.normal(size=x.shape)*(guard_rng.random(size=x.shape)<.005)
   guard_count=int(np.sum(np.sum(raw*raw,axis=1)==0))
  noise_rows.append({'draw':draw,'family':family,'array_sha256':array_sha(values),'min_measured_snr_db':float(measured.min()),'max_measured_snr_db':float(measured.max()),'constant_output_patches':int(np.sum(np.std(values,axis=1)==0)),'empty_impulse_guard_activations':guard_count})
 save(OUT/'noise_arrays.json',noise_rows)
 allrecords=[];foldrows=[];bnchecks=[];errors=[]
 for number,item in enumerate(inventory,1):
  checkpoint=torch.load(ROOT/item['weight_path'],map_location='cpu',weights_only=True)
  assert checkpoint['fold']==item['fold'] and checkpoint['seed']==item['seed'] and checkpoint['arm']==item['arm']
  model=ClassBDWDCNN(variant='baseline');model.load_state_dict(checkpoint['model_state']);model.eval()
  before={name:value.detach().clone() for name,value in model.named_buffers()}
  indices=np.flatnonzero(frame.condition.eq(CONDITIONS[item['fold']]).to_numpy())
  contexts={key:item[key] for key in ['study','arm','fold','seed','excluded','selected_update']}
  for (draw,family),values in panels.items():
   probabilities=evaluate(model,values,indices);records=aggregate_records(probabilities,frame.iloc[indices])
   met=record_metrics(records);check=independent_metrics_check(records,met);errors.append(check['max_abs_metric_difference'])
   context={**contexts,'draw':draw,'family':family,'omitted_family_endpoint':item['study']=='v7' and item['excluded']==family}
   allrecords.append(records.assign(**context));foldrows.append({**context,**met})
  unchanged=all(torch.equal(before[name],value) for name,value in model.named_buffers())
  assert unchanged,'Inference changed BatchNorm buffer';bnchecks.append({'weight_path':item['weight_path'],'buffer_count':len(before),'unchanged':True})
  if number%15==0:print(f'{number}/180 models; test only, no updates',flush=True)
 records=pd.concat(allrecords,ignore_index=True);records.to_csv(OUT/'record_predictions.csv',index=False)
 pd.DataFrame(foldrows).to_csv(OUT/'fold_summary.csv',index=False)
 pooled=[];group=['study','arm','seed','excluded','draw','family','omitted_family_endpoint']
 for keys,part in records.groupby(group,sort=False):
  assert len(part)==21 and part.source_record.nunique()==21
  met=record_metrics(part);check=independent_metrics_check(part,met);errors.append(check['max_abs_metric_difference'])
  pooled.append({**dict(zip(group,keys)),**met})
 pooled=pd.DataFrame(pooled);pooled.to_csv(OUT/'pooled_summary.csv',index=False)
 metrics=['macro_f1','nll','multiclass_brier','recall_H','recall_I','recall_O'];keys=['study','arm','seed','excluded','family','omitted_family_endpoint']
 summary=pooled.groupby(keys,sort=False)[metrics].agg(['mean','min','max']);summary.columns=['_'.join(c) for c in summary.columns];summary.reset_index().to_csv(OUT/'draw_sensitivity_by_algorithm_seed.csv',index=False)
 save(OUT/'batchnorm_audit.json',bnchecks)
 assert len(foldrows)==2160 and len(records)==9072 and len(pooled)==432
 for relative,expected in design['sha256'].items():assert sha(ROOT/relative)==expected
 for item in inventory:assert sha(ROOT/item['weight_path'])==item['weight_sha256'] and sha(ROOT/item['metadata_path'])==item['metadata_sha256']
 artifacts=[p for p in OUT.iterdir() if p.is_file() and p.name not in ['audit.json','status.json']]
 save(OUT/'audit.json',{'passed':True,'finished_utc':datetime.now(timezone.utc).isoformat(),'model_count':180,'new_array_count':12,
  'model_panel_cells':2160,'record_predictions':9072,'pooled_cells':432,'batchnorm_unchanged_models':180,
  'max_abs_independent_metric_difference':max(errors),'elapsed_seconds':time.perf_counter()-started,
  'sha256':{str(p.relative_to(ROOT)):sha(p) for p in artifacts}})
 save(OUT/'status.json',{'passed':True,'status':'complete'});print('PASS:180fixedmodels,12newarrays,9072source-recordpredictions',flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--freeze-only',action='store_true');main(p.parse_args())
