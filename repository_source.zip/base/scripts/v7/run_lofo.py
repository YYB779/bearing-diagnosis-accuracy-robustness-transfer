"""Frozen 120-fit leave-one-corruption-family-out source-condition DRO study."""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import copy
import hashlib
import json
import time
import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F
from scripts.v5.classbd_models import ClassBDWDCNN
from scripts.v5.run_classbd_extension import balanced_batch_indices
from scripts.v6.run_robustness import evaluate, CONDITIONS, array_sha
from scripts.v6.consistency import test_panels
from scripts.v7.robust_training import FAMILIES, mixed_views, group_mean_losses, update_adversarial_weights

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'results/v7/lofo'
SEEDS = [11, 22, 33]
STEPS = 480
ARMS = ['mixed_erm', 'mixed_dro']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main(args):
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    OUT.mkdir(parents=True, exist_ok=True)
    xp = ROOT / 'data/processed/v5/hust_neural_patches.npz'
    lp = ROOT / 'data/processed/v5/hust_neural_patch_lineage.csv'
    frame = pd.read_csv(lp)
    archive = np.load(xp, allow_pickle=False)
    x = archive['x']
    assert x.shape == (672, 2048)
    assert np.array_equal(archive['patch_id'], frame.patch_id.to_numpy(str))
    frame['domain_id'] = frame.condition.map(dict(zip(CONDITIONS, range(5))))
    paths = [xp, lp, Path(__file__), ROOT/'docs/v7/design.md', ROOT/'scripts/v7/robust_training.py',
             ROOT/'scripts/v6/run_robustness.py', ROOT/'scripts/v6/consistency.py',
             ROOT/'scripts/v5/classbd_models.py', ROOT/'scripts/v5/run_classbd_extension.py',
             ROOT/'scripts/v5/prepare_neural_patches.py', ROOT/'scripts/v4_external_common.py']
    registration = {'created_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'retrospective exploratory; V6 corruption outcomes known; frozen before V7 measured-data fits',
        'arms': ARMS, 'excluded_families': list(FAMILIES), 'seeds': SEEDS, 'updates': STEPS,
        'groups': 'three source fitting conditions; every group has six source patches, 18 view examples, six per class',
        'q_update': 'logsoftmax(logq+0.01*detached group mean CE); DRO loss dot(q,group CE); initial uniform q',
        'selection': 'clean source-validation record F1; lower NLL; earlier update; checkpoints120/240/360/480',
        'optimizer': 'AdamW lr0.001 wd0.0001 cosine480 clip10', 'source_patches':18, 'views':3,
        'augmentation': 'one clean and two views; perpatch iid uniform among3 nonexcluded families; SNR U[-4,12]',
        'planned_models':120, 'test_panels':list(test_panels(x)),
        'test_panel_sha256':{k:array_sha(v) for k,v in test_panels(x).items()},
        'sha256':{str(p.relative_to(ROOT)):sha(p) for p in paths},
        'software':{'torch':torch.__version__, 'numpy':np.__version__, 'pandas':pd.__version__, 'threads':2}}
    dp = OUT/'design.json'
    if dp.exists():
        old = json.loads(dp.read_text(encoding='utf-8'))
        registration['created_utc'] = old['created_utc']
        assert old == registration, 'Frozen V7 design changed'
    else:
        dp.write_text(json.dumps(registration, indent=2), encoding='utf-8')
    print('V7 design frozen: 120 planned fits; no excluded-family validation', flush=True)
    if args.freeze_only:
        return
    panels = test_panels(x)
    for excluded in args.excluded or FAMILIES:
        for fold in args.fold if args.fold is not None else range(5):
            test = frame.domain_id.eq(fold).to_numpy()
            val = frame.domain_id.eq((fold+1)%5).to_numpy()
            train = ~(test|val)
            tri, vi, ti = [np.flatnonzero(z) for z in [train,val,test]]
            domains = sorted(frame.loc[train,'domain_id'].unique().tolist())
            for a,b in [(train,val),(train,test),(val,test)]:
                assert not set(frame.loc[a,'source_record']) & set(frame.loc[b,'source_record'])
            for seed in SEEDS:
                brng = np.random.default_rng(seed+1000*fold)
                batches = [balanced_batch_indices(frame,tri,domains,brng) for _ in range(STEPS)]
                sp = OUT/f'fold{fold}_s{seed}_split.json'
                split = {'fold':fold,'seed':seed,'train_records':sorted(frame.loc[train,'source_record'].unique().tolist()),
                    'validation_records':sorted(frame.loc[val,'source_record'].unique().tolist()),
                    'test_records':sorted(frame.loc[test,'source_record'].unique().tolist()),
                    'train_domains':domains,'batch_indices':np.stack(batches).tolist()}
                if sp.exists(): assert json.loads(sp.read_text()) == split
                else: sp.write_text(json.dumps(split,indent=2),encoding='utf-8')
                for arm in ARMS:
                    stem = f'{excluded}_fold{fold}_{arm}_s{seed}'
                    rp = OUT/(stem+'.json')
                    if rp.exists():
                        old=json.loads(rp.read_text())
                        assert old['design_sha256']==sha(dp)
                        for key,suffix in [('model_sha256','.pt'),('predictions_sha256','_predictions.csv'),('views_sha256','_views.json')]:
                            assert old[key]==sha(OUT/(stem+suffix))
                        continue
                    started=time.perf_counter()
                    torch.manual_seed(seed)
                    model=ClassBDWDCNN(variant='baseline')
                    opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
                    sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=STEPS)
                    logq=torch.full((3,),-np.log(3.))
                    history=[];trajectory=[];view_hashes=[];best=(-1.,-np.inf)
                    for step,idx in enumerate(batches,1):
                        model.train();opt.zero_grad(set_to_none=True)
                        rng=np.random.default_rng(700000+seed*1000+fold*10000+step)
                        views,assignments=mixed_views(x[idx],rng,excluded)
                        assert excluded not in set(assignments.ravel())
                        view_hashes.append({'views':array_sha(views),'families':array_sha(assignments.astype('U8'))})
                        batch=torch.from_numpy(views.reshape(-1,2048)[:,None,:])
                        target=torch.from_numpy(frame.iloc[idx].class_id.to_numpy(np.int64)).repeat(3)
                        source_domain=frame.iloc[idx].domain_id.map(dict(zip(domains,range(3)))).to_numpy(np.int64)
                        gids=torch.from_numpy(source_domain).repeat(3)
                        for group in range(3):
                            assert torch.bincount(target[gids==group],minlength=3).tolist()==[6,6,6]
                        logits=model(batch)['logits']
                        gl=group_mean_losses(F.cross_entropy(logits,target,reduction='none'),gids)
                        if arm=='mixed_dro':logq=update_adversarial_weights(logq,gl)
                        q=logq.exp()
                        loss=(q*gl).sum() if arm=='mixed_dro' else gl.mean()
                        assert torch.isfinite(loss) and torch.isfinite(q).all() and abs(q.sum().item()-1)<1e-5
                        loss.backward()
                        gn=torch.nn.utils.clip_grad_norm_(model.parameters(),10.)
                        assert torch.isfinite(gn)
                        opt.step();sched.step()
                        trajectory.append({'update':step,'group_ce':gl.detach().tolist(),'q':q.tolist(),
                            'loss':float(loss.detach()),'gradient_norm':float(gn)})
                        if step%120==0:
                            vm,_,_,_=evaluate(model,x,frame,vi)
                            history.append({'update':step,'validation_clean':vm})
                            key=(vm['macro_f1'],-vm['nll'])
                            if key>best:
                                best=key;state=copy.deepcopy(model.state_dict());chosen=step;selected_vm=vm
                    model.load_state_dict(state)
                    rows=[];tm={}
                    for role,panel,signals,indices in [('validation','clean',x,vi)]+[
                        ('test',p,z,ti) for p,z in panels.items()]:
                        met,names,labels,probs=evaluate(model,signals,frame,indices)
                        if role=='test':tm[panel]=met
                        for name,label,p in zip(names,labels,probs):
                            rows.append({'role':role,'panel':panel,'source_record':name,'label':int(label),
                                'p_H':p[0],'p_I':p[1],'p_O':p[2]})
                    pp=OUT/(stem+'_predictions.csv');pd.DataFrame(rows).to_csv(pp,index=False)
                    mp=OUT/(stem+'.pt');torch.save({'model_state':state,'arm':arm,'seed':seed,'fold':fold,
                        'excluded':excluded,'selected_update':chosen,'design_sha256':sha(dp)},mp)
                    vp=OUT/(stem+'_views.json');vp.write_text(json.dumps(view_hashes),encoding='utf-8')
                    result={'excluded':excluded,'fold':fold,'seed':seed,'arm':arm,'selected_update':chosen,
                        'validation_clean':selected_vm,'test':tm,'history':history,'trajectory':trajectory,
                        'seconds':time.perf_counter()-started,'model_parameters':sum(p.numel() for p in model.parameters()),
                        'design_sha256':sha(dp),'split_sha256':sha(sp),'model_sha256':sha(mp),
                        'predictions_sha256':sha(pp),'views_sha256':sha(vp)}
                    rp.write_text(json.dumps(result,indent=2),encoding='utf-8')
                    heldout={'awgn':'AWGN-4dB','colored':'colored-4dB','impulse':'impulse-4dB','tone':'tone-4dB'}[excluded]
                    print(f'DONE {stem}: clean={tm["clean"]["macro_f1"]:.3f} excluded={tm[heldout]["macro_f1"]:.3f} seconds={result["seconds"]:.1f}',flush=True)


if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--freeze-only',action='store_true')
    ap.add_argument('--excluded',action='append',choices=FAMILIES)
    ap.add_argument('--fold',action='append',type=int,choices=range(5))
    main(ap.parse_args())
