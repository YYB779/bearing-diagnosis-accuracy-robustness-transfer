from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
from scipy.signal import resample_poly
ROOT=Path(__file__).resolve().parents[2]
RAW=ROOT/'data/raw/v7_paderborn/derived_by_specimen'
OUT=ROOT/'data/processed/v7'; OUT.mkdir(parents=True,exist_ok=True)
IDS=['K004','K005','K006','KA15','KA16','KA30','KI16','KI18','KI21']
LABELS={'K004':0,'K005':0,'K006':0,'KA15':2,'KA16':2,'KA30':2,'KI16':1,'KI18':1,'KI21':1}
# Metadata-only gate: first four runs for each condition, >=256000 finite samples and monotonic timestamps.
gate=pd.read_csv(ROOT/'docs/v7/data/fresh_first_four_metadata_gate.csv')
rows=[]; nominal=[]; timed=[]; patch_ids=[]
for bid in IDS:
    d=RAW/bid; rec=pd.read_csv(d/'records.csv'); vib=np.load(d/'vibration.npy',mmap_mode='r')
    with np.load(d/'vibration_timestamps.npz',allow_pickle=False) as ts:
        for cond,g in rec.groupby('condition',sort=True):
            first=g.sort_values('run').head(4)
            passrows=gate[(gate.bearing_id==bid)&(gate.condition==cond)].iloc[0]
            passing=set(str(passrows.passing_runs).split(','))
            for _,r in first.iterrows():
                if str(int(r.run)) not in passing: continue
                n=int(r.sample_count); x=np.asarray(vib[int(r.packed_array_start):int(r.packed_array_start)+n],dtype=np.float32)
                key=str(r.timestamp_array_key); raw=ts[key]; t=raw.T.copy().view('<f8').reshape(-1)
                if n<256000 or len(t)!=n or not np.isfinite(x).all() or not np.isfinite(t).all() or np.any(np.diff(t)<=0): continue
                # Nominal documented 64 kHz input. Keep a separate timestamp interpolation sensitivity.
                x0=x[:256000].astype(np.float64)
                xn=resample_poly(x0,2,5).astype(np.float32)
                rel=t[:256000]-t[0]
                target=np.arange(256000,dtype=np.float64)/64000.
                xt=np.interp(target,rel,x0).astype(np.float64)
                xt=resample_poly(xt,2,5).astype(np.float32)
                for sec in range(4):
                    for j,off in enumerate([0,7850,15701,23552]):
                        o=sec*25600+off
                        if o+2048>len(xn) or o+2048>len(xt): raise RuntimeError('patch boundary')
                        idx=len(rows); nominal.append(xn[o:o+2048]);timed.append(xt[o:o+2048])
                        pid=f'{bid}|{cond}|run{int(r.run)}|s{sec}|p{j}'
                        patch_ids.append(pid);rows.append({'patch_id':pid,'bearing_id':bid,'condition':cond,'file_id':r.file_id,'run':int(r.run),'class_id':LABELS[bid],'label':['H','I','O'][LABELS[bid]],'patch_index':j+4*sec,'second':sec,'offset_25k':o,'timing_gate':'passed'})
np.savez_compressed(OUT/'paderborn_test_patches.npz',nominal=np.asarray(nominal,dtype=np.float32),timestamp_sensitive=np.asarray(timed,dtype=np.float32),patch_id=np.asarray(patch_ids,dtype='U64'))
frame=pd.DataFrame(rows);frame.to_csv(OUT/'paderborn_test_patch_lineage.csv',index=False)
report={'status':'PASS','specimens':len(IDS),'records_used':int(frame.file_id.nunique()),'patches':len(frame),'patches_per_file':frame.groupby('file_id').size().value_counts().to_dict(),'class_counts':frame.groupby('bearing_id').class_id.first().value_counts().to_dict(),'nominal_fs_hz':64000,'resample':'scipy.signal.resample_poly(up=2,down=5)','timestamp_sensitivity':'linear interpolation on exact HostService timestamps relative to first sample, then same resampling; not treated as calibrated ADC clock','inputs':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'docs/v7/data/fresh_first_four_metadata_gate.csv']},'outputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'paderborn_test_patches.npz',OUT/'paderborn_test_patch_lineage.csv']}}
(OUT/'paderborn_patch_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))
