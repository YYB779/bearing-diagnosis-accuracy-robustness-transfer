"""Same measured input figure, with training and validation differences exposed."""
from pathlib import Path
import hashlib,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd
import fitz
from PIL import Image
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'figures/v7'
PANELS=['clean','AWGN0dB','AWGN-4dB','colored-4dB','impulse-4dB','tone-4dB']
LABELS=['Clean','Gaussian 0 dB','Gaussian −4 dB','Colored −4 dB','Impulse −4 dB','Tone −4 dB']
METHODS=[('native25','extra_trees','ET native25','#0072B2'),('native25','logistic_regression','LR native25','#E69F00'),
 ('shape25','extra_trees','ET shape25','#009E73'),('shape25','logistic_regression','LR shape25','#CC79A7'),
 ('v6','clean_ce','WDCNN clean†','#666666'),('v6','awgn_ce','WDCNN AWGN†','#D55E00')]
SEEDS=[11,22,33]
WIDTH_INCHES=6.692913385826772
HEIGHT_INCHES=7.086614173228347
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def main():
 OUT.mkdir(exist_ok=True,parents=True);cp=ROOT/'results/v7/classical/pooled_summary.csv';vp=ROOT/'results/v6/analysis/pooled_summary.csv';ca=ROOT/'docs/v7/classical_independent_audit.json'
 assert json.loads(ca.read_text())['passed'] is True
 classical=pd.read_csv(cp);v6=pd.read_csv(vp);rows=[]
 for representation,family,label,color in METHODS:
  for panel in PANELS:
   frame=(v6[(v6.arm==family)&(v6.panel==panel)] if representation=='v6' else classical[(classical.representation==representation)&(classical.family==family)&(classical.panel==panel)])
   assert sorted(frame.seed.tolist())==SEEDS and frame.n_records.eq(21).all()
   for row in frame.to_dict(orient='records'):
    for metric in ['macro_f1','recall_H']:
     rows.append({'method':label,'representation':representation,'family':family,'study':'v6 prior neural context' if representation=='v6' else 'v7 same-patch conventional control',
      'training':'clean+two Gaussian views' if family=='awgn_ce' else 'clean','validation':'clean and +6dB Gaussian' if representation=='v6' else 'clean-only',
      'panel':panel,'seed':row['seed'],'metric':metric,'value':row[metric],'n_unique_source_files':21,'n_healthy_source_files':5})
 source=pd.DataFrame(rows);assert len(source)==216;stem=OUT/'fig_same_patch_controls';source.to_csv(stem.with_suffix('.source.csv'),index=False)
 plt.rcParams.update({'font.family':'Arial','font.size':7.2,'axes.titlesize':7.6,'axes.labelsize':7.5,'xtick.labelsize':7.,'ytick.labelsize':7.,'axes.linewidth':.6,'svg.fonttype':'none','pdf.fonttype':42,'savefig.facecolor':'white','legend.frameon':False,'axes.spines.top':False,'axes.spines.right':False})
 fig,axes=plt.subplots(6,2,figsize=(WIDTH_INCHES,HEIGHT_INCHES));fig.subplots_adjust(left=.245,right=.976,bottom=.055,top=.855,wspace=.22,hspace=.72)
 fig.text(.03,.984,'Same measured input: 32 patches per source file (2.56 s)',fontsize=8.2,va='top')
 fig.text(.03,.955,'Clean-trained conventional controls; neural rows are prior context†',fontsize=7.3,va='top')
 handles=[Line2D([],[],linestyle='none',marker=mark,color='#333333',markerfacecolor='white',markeredgewidth=.65,markersize=3.,label=f'Seed {seed}') for seed,mark in zip(SEEDS,['o','s','^'])]
 fig.legend(handles=handles,loc='upper left',bbox_to_anchor=(.02,.936),ncol=3,fontsize=7.2,handletextpad=.45,columnspacing=1.5,borderaxespad=0.)
 fig.text(.427,.892,'Record macro-F1',ha='center',fontsize=8.);fig.text(.827,.892,'Healthy recall',ha='center',fontsize=8.)
 for pi,(panel,title) in enumerate(zip(PANELS,LABELS)):
  for column,metric in enumerate(['macro_f1','recall_H']):
   ax=axes[pi,column]
   for mi,(_,_,label,color) in enumerate(METHODS):
    values=source[(source.method==label)&(source.panel==panel)&(source.metric==metric)].sort_values('seed').value.to_numpy();y=5-mi
    ax.plot([values.min(),values.max()],[y,y],color=color,lw=.65,zorder=2)
    for value,offset,marker in zip(values,[-.21,0.,.21],['o','s','^']):ax.plot(value,y+offset,marker=marker,markersize=2.7,markeredgewidth=.6,color=color,markerfacecolor='white',linestyle='none',zorder=4)
   ax.set_xlim(-.04,1.04);ax.set_xticks([0,.5,1.]);ax.set_ylim(-.6,5.6);ax.set_yticks(np.arange(6)[::-1]);ax.set_yticklabels([m[2] for m in METHODS] if column==0 else [])
   ax.tick_params(axis='y',length=0,pad=4.);ax.tick_params(axis='x',length=2.,pad=2.);ax.grid(axis='x',color='#E6E6E6',lw=.5,zorder=0);ax.axhline(1.5,color='#B0B0B0',lw=.55,ls=(0,(2,2)));ax.spines['left'].set_visible(False)
   ax.set_title(f'{chr(97+2*pi+column)}  {title}',loc='left',fontsize=7.6,pad=5.,fontweight='bold')
 fig.text(.03,.014,'† Neural context has different training augmentation and validation; see caption.',fontsize=7.,va='bottom');fig.canvas.draw();renderer=fig.canvas.get_renderer();overlap=[]
 for i,ax in enumerate(axes.flat):
  boxes=[t.get_window_extent(renderer) for t in ax.get_yticklabels() if t.get_text()]
  for j in range(len(boxes)-1):
   if boxes[j].overlaps(boxes[j+1]):overlap.append([i,j,j+1])
 assert not overlap,overlap
 fig.savefig(stem.with_suffix('.pdf'),facecolor='white',bbox_inches=None)
 fig.savefig(stem.with_suffix('.svg'),facecolor='white',bbox_inches=None)
 fig.savefig(stem.with_suffix('.png'),dpi=300,facecolor='white',bbox_inches=None)
 plt.close(fig)
 caption=('Fig. 4 | Conventional controls on exactly the neural vibration patches. Panels a,c,e,g,i,k show source-record macro-F1 and b,d,f,h,j,l show healthy recall under the six frozen test panels. Each classical model uses the same 672 measured 2048-point patches at 25.6 kHz, 32 nonoverlapping patches (2.56 s) per file. Native25 retains amplitude; shape25 applies within-patch normalization before the same 25 formulas. ET, Extra Trees (400 trees); LR, weighted standardized logistic regression. All markers are retained for seeds 11,22,33; thin horizontal segments span their minimum and maximum, with small vertical offsets solely to distinguish coincident markers. LR repeats are deterministic. Each pooled point covers the same 21 out-of-fold source recordings, including five healthy recordings; seed ranges are algorithm variation, not physical-population confidence intervals. The four classical rows fit only clean source features and use clean-only validation. The two dagger-marked WDCNN rows are prior v6 context: the clean arm repeats three clean views; the AWGN arm uses clean and two Gaussian-noise views. Both neural context arms select using clean and fixed +6-dB Gaussian validation, which differs from the classical clean-only rule. Thus common measured input does not isolate architecture or augmentation effects. The dashed row divider separates these access regimes. All corruption realizations are synthetic and fixed; measured physical bearing identities remain undocumented. Native25 ET improves clean classification but every perturbed panel loses all five healthy diagnoses. Source Data contain every displayed model/seed/panel endpoint; no test-based winner selection or extra training was performed for this figure.')
 stem.with_suffix('.caption.txt').write_text(caption+'\n',encoding='utf-8')
 stem.with_suffix('.alt.txt').write_text('Twelve dot plots compare six models and all three algorithm seeds across six fixed signal panels. Left columns show record macro-F1 and right columns healthy recall. Native-amplitude Extra Trees performs strongly on clean files, but all perturbed panels lose healthy diagnoses. Historical Gaussian-trained WDCNN performs well on Gaussian noise and worse on other families. Conventional and neural training and validation differ; displayed ranges are not population confidence intervals.\n',encoding='utf-8')
 with fitz.open(stem.with_suffix('.pdf')) as pdf:
  page=pdf[0];width=page.rect.width*25.4/72;height=page.rect.height*25.4/72;spans=[s for b in page.get_text('dict')['blocks'] if b.get('type')==0 for l in b['lines'] for s in l['spans']]
  clipped=[s['text'] for s in spans if s['bbox'][0]<-.1 or s['bbox'][1]<-.1 or s['bbox'][2]>page.rect.width+.1 or s['bbox'][3]>page.rect.height+.1];minimum=min(s['size'] for s in spans);fonts=sorted(set(s['font'] for s in spans))
  assert abs(width-170)<.01 and abs(height-180)<.01 and minimum>=6.99 and not clipped
 with Image.open(stem.with_suffix('.png')) as png:
  png_info={'pixels':list(png.size),'dpi':list(png.info.get('dpi',[])),'mode':png.mode}
  if png.mode=='RGBA':assert png.getextrema()[-1]==(255,255)
 outputs=[p for p in OUT.glob(stem.name+'.*') if p.suffix!='json']
 report={'passed':True,'scientific_role':'same measured input control with training exposure differences explicit','archetype':'quantitative grid','backend':'Python matplotlib','target_journal':'not selected; general manuscript figure','width_mm':width,'height_mm':height,'pdf_min_font_pt':minimum,'pdf_fonts':fonts,'out_of_page_text':clipped,'adjacent_y_label_overlaps':overlap,'png':png_info,'source_rows':len(source),'models':6,'seeds':SEEDS,'test_panels':PANELS,'metric_panels':12,'spread':'min-max over algorithm seeds; deterministic LR repeats; no population CI','omissions':'Only requested v6 clean/AWGN context arms; full response/JSD results remain in their separate figure.','inputs_sha256':{str(p.relative_to(ROOT)):sha(p) for p in [cp,vp,ca,Path(__file__)]},'outputs_sha256':{p.name:sha(p) for p in outputs},'visual_review':'pending rendered-image inspection'}
 stem.with_suffix('.qa.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in report.items() if 'sha256' not in k},indent=2))
if __name__=='__main__':main()
