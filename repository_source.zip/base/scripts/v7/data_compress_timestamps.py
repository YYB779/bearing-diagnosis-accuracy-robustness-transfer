"""Losslessly byte-shuffle source timestamps to bound retained raw-cache storage."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from scripts.v7.data_download_paderborn import RAW, ROOT
from scripts.v7.data_extract_paderborn import load_timestamps


def convert(bearing):
    folder = RAW / "derived_by_specimen" / bearing
    source = folder / "vibration_timestamps.npz"
    report = json.loads((folder / "extraction_audit.json").read_text(encoding="utf-8"))
    with np.load(source, allow_pickle=False) as old:
        if old[old.files[0]].dtype == np.uint8:
            return
        values = {key: old[key] for key in old.files}
    encoded = {key: np.ascontiguousarray(value, dtype="<f8").view(np.uint8).reshape(-1, 8).T.copy() for key, value in values.items()}
    pending = source.with_name("vibration_timestamps_compact.npz")
    np.savez_compressed(pending, **encoded)
    for key, original in values.items():
        reconstructed = load_timestamps(pending, key)
        if reconstructed.dtype != original.dtype or reconstructed.tobytes() != original.tobytes():
            raise RuntimeError("Lossless reconstruction check failed")
    before = source.stat().st_size
    pending.replace(source)
    sha = hashlib.sha256(source.read_bytes()).hexdigest()
    for output in report["outputs"]:
        if output["path"] == source.relative_to(ROOT).as_posix():
            output.update(sha256=sha, bytes=source.stat().st_size)
    report["timestamp_encoding"] = "lossless little-endian float64 byteplanes: uint8[8,N]; transpose-copy then view <f8"
    report["lossless_timestamp_encoding_verified_all_records"] = True
    (folder / "extraction_audit.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"bearing": bearing, "before_bytes": before, "after_bytes": source.stat().st_size, "records_losslessly_verified": len(values)}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("ids", nargs="+")
    args = parser.parse_args()
    for identifier in args.ids:
        convert(identifier)
