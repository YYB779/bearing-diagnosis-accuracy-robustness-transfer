from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd,torch
from datetime import datetime,timezone
from scripts.v5.classbd_models import ClassBDWDCNN
from scripts.v6.analyze_results import normalized_patch,scores,require,sha
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'results/v7/zero_shot'
V6=['clean_ce','awgn_ce','response_ce','response_jsd'];V7=['mixed_erm','mixed_dro'];SEEDS=[11,22,33];FAMS=['awgn','colored','impulse','tone']
def specs(cohort):
 s=[]
 if cohort=='v6':
  for arm in V6:
   for seed in SEEDS:
    for fold in range(5):s.append((arm,seed,fold,'none',ROOT/f'results/v6/robustness/fold{fold}_{arm}_s{seed}.pt'))
 else:
  for fam in FAMS:
   for arm in V7:
    for seed in SEEDS:
     for fold in range(5):s.append((arm,seed,fold,fam,ROOT/f'results/v7/lofo/{fam}_fold{fold}_{arm}_s{seed}.pt'))
 return s
def main(cohort):
 OUT.mkdir(parents=True,exist_ok=True);folder=OUT/cohort;folder.mkdir(exist_ok=True)
 xp=ROOT/'data/processed/v7/paderborn_specimen_test_patches.npz';lp=ROOT/'data/processed/v7/paderborn_specimen_test_patch_lineage.csv';ar=np.load(xp,allow_pickle=False);fr=pd.read_csv(lp)
 require(np.array_equal(ar['patch_id'],fr.patch_id.to_numpy(str)),'patch lineage mismatch');require(fr.bearing_id.nunique()==9,'specimens');require(fr.groupby('file_id').size().eq(16).all(),'patch counts')
 specs0=specs(cohort);dp=folder/'design.json';design={'protocol_status':'exploratory correction; failed preliminary float32 summaries and superseded truncated timestamp interpolation existed before this canonical evaluation', 'created_utc':datetime.now(timezone.utc).isoformat(),'cohort':cohort,'models':len(specs0),'input_modes':['nominal','timestamp_sensitive'],'external_fitting':False,'external_selection':False,'sha256':{str(p.relative_to(ROOT)):sha(p) for p in [xp,lp,Path(__file__),ROOT/'docs/v7/zero_shot_design.md']+[x[4] for x in specs0]}}
 if dp.exists():old=json.loads(dp.read_text());design['created_utc']=old['created_utc'];require(old==design,'design changed')
 else:dp.write_text(json.dumps(design,indent=2),encoding='utf-8')
 # record-level probabilities per frozen fold model
 rec=fr[['file_id','bearing_id','condition','class_id']].drop_duplicates().sort_values('file_id'); recs=rec.file_id.tolist();out=[];bn=0
 for ii,(arm,seed,fold,fam,mp) in enumerate(specs0,1):
  model=ClassBDWDCNN(variant='baseline');ck=torch.load(mp,map_location='cpu',weights_only=False);model.load_state_dict(ck['model_state']);model.eval();before={k:v.clone() for k,v in model.state_dict().items() if 'running_' in k or 'num_batches_tracked' in k}
  for mode in ['nominal','timestamp_sensitive']:
   x=ar[mode];pr=[]
   with torch.no_grad():
    for j in range(0,len(x),48):pr.append(torch.softmax(model(torch.from_numpy(normalized_patch(x[j:j+48])[:,None,:]))['logits'],1).numpy().astype(np.float64))
   pr=np.concatenate(pr)
   for name in recs:
    ids=np.flatnonzero(fr.file_id.to_numpy()==name);ri=rec[rec.file_id==name].iloc[0];p=pr[ids].mean(0);p=p/p.sum();out.append({'cohort':cohort,'excluded':fam,'arm':arm,'seed':seed,'fold':fold,'timing':mode,'file_id':name,'bearing_id':ri.bearing_id,'condition':ri.condition,'label':int(ri.class_id),'p_H':p[0],'p_I':p[1],'p_O':p[2]})
   require(all(torch.equal(v,model.state_dict()[k]) for k,v in before.items()),'BN changed');bn+=len(before)
  if ii%10==0:print(cohort,ii,'/',len(specs0),flush=True)
 fold=pd.DataFrame(out);fold.to_csv(folder/'fold_record_predictions.csv',index=False)
 keys=['cohort','excluded','arm','seed','timing','file_id','bearing_id','condition','label'];ens=fold.groupby(keys,as_index=False)[['p_H','p_I','p_O']].mean();ens.to_csv(folder/'ensemble_record_predictions.csv',index=False)
 cond=ens.groupby(['cohort','excluded','arm','seed','timing','bearing_id','condition','label'],as_index=False)[['p_H','p_I','p_O']].mean();cond.to_csv(folder/'bearing_condition_predictions.csv',index=False)
 bearing=cond.groupby(['cohort','excluded','arm','seed','timing','bearing_id','label'],as_index=False)[['p_H','p_I','p_O']].mean(); pp=bearing[['p_H','p_I','p_O']].to_numpy(dtype=np.float64); pp=pp/pp.sum(axis=1,keepdims=True); bearing[['p_H','p_I','p_O']]=pp; bearing.to_csv(folder/'bearing_predictions.csv',index=False)
 rows=[]
 for (fam,arm,seed,mode),g in bearing.groupby(['excluded','arm','seed','timing']):
  require(len(g)==9,'nine bearings'); pp=g[['p_H','p_I','p_O']].to_numpy(dtype=np.float64); pp=pp/pp.sum(axis=1,keepdims=True); m=scores(g.label.to_numpy(int),pp);rows.append({'cohort':cohort,'excluded':fam,'arm':arm,'seed':int(seed),'timing':mode,**{k:v for k,v in m.items() if k!='confusion_matrix'}})
 summ=pd.DataFrame(rows);summ.to_csv(folder/'seed_summary.csv',index=False)
 desc=[]
 for (fam,arm,mode),g in summ.groupby(['excluded','arm','timing']):
  r={'cohort':cohort,'excluded':fam,'arm':arm,'timing':mode}
  for k in ['macro_f1','nll','multiclass_brier','recall_H','recall_I','recall_O']:
   r[k+'_mean']=float(g[k].mean());r[k+'_min']=float(g[k].min());r[k+'_max']=float(g[k].max())
  desc.append(r)
 pd.DataFrame(desc).to_csv(folder/'descriptive_summary.csv',index=False)
 report={'passed':True,'cohort':cohort,'models':len(specs0),'fold_rows':len(fold),'bearing_rows':len(bearing),'specimens':9,'records':len(recs),'patches':len(fr),'BN_buffer_checks':bn,'external_fitting':False,'external_selection':False,'design_sha256':sha(dp),'output_sha256':{p.name:sha(p) for p in folder.glob('*.csv')},'limitation':'fresh healthy manufacturer and damaged manufacturer are confounded; timing sensitivity uses HostService timestamps not a proven ADC clock'}
 (folder/'audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))
if __name__=='__main__':
 import sys
 if len(sys.argv)!=2 or sys.argv[1] not in ['v6','v7']:raise SystemExit('usage: zero_shot_paderborn.py v6|v7')
 torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
 main(sys.argv[1])
