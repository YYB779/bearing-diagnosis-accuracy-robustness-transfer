"""Measured STFT power as a 3D surface and its unobscured 2D companion.

No synthesized waveform, model outcome selection or image generation.
"""
from pathlib import Path
import hashlib,json,time
import numpy as np
import pandas as pd
import scipy
from scipy.signal import spectrogram
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
import fitz
from PIL import Image
from scripts.v5.prepare_hust_native_features import read_time_and_x

ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'figures/v7'
FS=25600;N=8*FS;WINDOW=1024;OVERLAP=512;FLOOR_DB=-80.

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def array_sha(a):return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()

def main():
 started=time.perf_counter();OUT.mkdir(parents=True,exist_ok=True);stem=OUT/'fig_measured_timefrequency_3d'
 manifests=[ROOT/'data/raw/v3_external/hust_subset_download_manifest.json',ROOT/'data/raw/v4_external/download_manifest.json']
 records=[]
 for path in manifests:records+=json.loads(path.read_text(encoding='utf-8'))['downloads']
 healthy=sorted([r for r in records if r['name'].startswith('H_')],key=lambda r:r['name'])
 chosen=healthy[0];assert chosen['name']=='H_20Hz.xls'
 source=Path(chosen['local_path']);assert sha(source)==chosen['sha256']
 source_time,raw=read_time_and_x(source)
 assert len(raw)==262144 and np.isfinite(raw).all()
 measured_fs=(len(source_time)-1)/(source_time[-1]-source_time[0]);assert abs(measured_fs-FS)<.01
 # Same documented float32 round-trip precision as existing HUST analyses.
 x=raw[:N].astype(np.float32).astype(np.float64)
 frequencies,centres,power=spectrogram(x,fs=FS,window='hann',nperseg=WINDOW,noverlap=OVERLAP,
  nfft=WINDOW,detrend='constant',return_onesided=True,scaling='density',mode='psd')
 assert power.shape==(513,399) and np.isfinite(power).all() and (power>=0).all()
 assert np.allclose(np.diff(frequencies),25.) and np.allclose(np.diff(centres),.02)
 reference=float(power.max());assert reference>0
 relative=10*np.log10(np.maximum(power/reference,10**(FLOOR_DB/10)))
 assert relative.max()==0. and relative.min()>=FLOOR_DB
 np.savez_compressed(stem.with_suffix('.source.npz'),frequency_hz=frequencies,time_center_s=centres,
  psd_source_x_unit_squared_per_hz=power,relative_psd_db=relative,reference_psd=np.array(reference),
  fs_hz=np.array(FS),window_samples=np.array(WINDOW),overlap_samples=np.array(OVERLAP),display_floor_db=np.array(FLOOR_DB))
 tt,ff=np.meshgrid(centres,frequencies)
 pd.DataFrame({'frequency_hz':ff.ravel(),'time_center_s':tt.ravel(),'psd_source_x_unit_squared_per_hz':power.ravel(),
  'relative_psd_db':relative.ravel()}).to_csv(stem.with_suffix('.source.csv'),index=False)
 plt.rcParams.update({'font.family':'Arial','font.size':7.5,'axes.labelsize':7.5,'xtick.labelsize':7.,'ytick.labelsize':7.,
  'axes.linewidth':.65,'svg.fonttype':'none','pdf.fonttype':42,'savefig.facecolor':'white'})
 fig=plt.figure(figsize=(6.692913385826772,5.708661417322835));norm=Normalize(FLOOR_DB,0.);cmap=plt.get_cmap('cividis')
 fig.text(.045,.983,'Measured vibration: time–frequency structure',fontsize=9.,va='top')
 fig.text(.045,.951,'Fixed healthy source · 20 Hz filename condition · first 8.00 s · 25.6 kHz',fontsize=7.5,va='top')
 ax=fig.add_axes([.065,.395,.745,.535],projection='3d',proj_type='ortho')
 # Surface display uses explicit strides; full-resolution 2D/Source Data remain.
 surface=ax.plot_surface(tt,ff/1000,relative,cmap=cmap,norm=norm,rstride=2,cstride=4,
  linewidth=0,antialiased=False,shade=False,rasterized=True)
 ax.view_init(elev=25,azim=-125);ax.set_box_aspect((1.7,1.,.62));ax.set_xlim(0,8);ax.set_ylim(0,12.8);ax.set_zlim(FLOOR_DB,0)
 ax.set_xticks([0,2,4,6,8]);ax.set_yticks([0,4,8,12.8]);ax.set_zticks([-80,-40,0])
 ax.set_xlabel('Time (s)',labelpad=5.);ax.set_ylabel('Frequency (kHz)',labelpad=7.);ax.set_zlabel('Relative PSD (dB)',labelpad=5.)
 ax.tick_params(axis='both',labelsize=7.,pad=1.);ax.tick_params(axis='z',labelsize=7.,pad=2.)
 for axis in [ax.xaxis,ax.yaxis,ax.zaxis]:
  axis.pane.fill=False;axis.pane.set_edgecolor('#FFFFFF');axis._axinfo['grid']['color']=(.85,.85,.85,1);axis._axinfo['grid']['linewidth']=.4
 ax.text2D(-.01,.97,'a  STFT power surface',transform=ax.transAxes,fontsize=8.,weight='bold')
 heat=fig.add_axes([.12,.135,.675,.225])
 heat.pcolormesh(centres,frequencies/1000,relative,cmap=cmap,norm=norm,shading='nearest',rasterized=True)
 heat.set_xlim(0,8);heat.set_ylim(0,12.8);heat.set_xticks([0,2,4,6,8]);heat.set_yticks([0,4,8,12.8]);heat.set_xlabel('Time (s)');heat.set_ylabel('Frequency (kHz)')
 heat.tick_params(length=2.5,pad=3.);heat.spines[['top','right']].set_visible(False)
 heat.set_title('b  Same STFT, full-resolution planar view',loc='left',fontsize=8.,weight='bold',pad=6.)
 cbax=fig.add_axes([.865,.135,.022,.73]);bar=fig.colorbar(ScalarMappable(norm=norm,cmap=cmap),cax=cbax,ticks=[-80,-60,-40,-20,0]);bar.set_label('Relative PSD (dB re record maximum)',fontsize=7.5,labelpad=6.);bar.ax.tick_params(labelsize=7.,length=2.)
 fig.text(.045,.028,'Hann 1024 points · 50% overlap · 25 Hz bins · 20 ms hop · common color scale',fontsize=7.,va='bottom')
 fig.savefig(stem.with_suffix('.pdf'),dpi=600,facecolor='white',bbox_inches=None)
 fig.savefig(stem.with_suffix('.svg'),dpi=600,facecolor='white',bbox_inches=None)
 fig.savefig(stem.with_suffix('.png'),dpi=300,facecolor='white',bbox_inches=None)
 plt.close(fig)
 caption=('Fig. 2 | A measured time–frequency view with a planar companion. The X-axis vibration from the first eight seconds of Zhao et al.’s HUSTbearing record H_20Hz is shown as (a) an orthographic three-dimensional STFT power surface and (b) the same STFT matrix in a full-resolution heat map. The recording was fixed by choosing the lexicographically first healthy source filename from the documented downloaded subset, independently of classification outcomes. Filename condition is20Hz; the source speed column is not used. The measured signal contains204800 samples at25.6kHz; the original source contains262144 samples. A periodic Hann window of1024 samples (40ms),512-sample hop (20ms), constant segment detrending and a1024-point one-sided density periodogram produce513 frequency bins (25Hz spacing,0–12.8kHz) and399 complete time frames centred from0.02 to7.98s. No zero-padding, waveform filtering or synthetic perturbation is applied. Both panels use10log10 of PSD divided by its maximum over this fixed record, with a common cividis scale and display floor of−80dB. The reference is a within-record normalization, not an absolute calibrated power unit. The surface is displayed with a two-frequency-bin/four-time-frame stride solely for rendering; the planar view and Source Data retain every STFT value. Surface height and color encode the same relative power; the planar companion removes surface occlusion. The perspective supplies a view of the measured spectral landscape, not an additional experiment, classifier input or demonstration of a defect mechanism. Source Data retain unnormalized PSD and the normalization reference; the original waveform is not redistributed in this derived-data figure bundle.')
 for a,b in [('is20Hz','is 20 Hz'),('contains204800','contains 204800'),('at25.6kHz','at 25.6 kHz'),('contains262144','contains 262144'),('of1024','of 1024'),('(40ms)','(40 ms)'),(',512-sample',', 512-sample'),('(20ms)','(20 ms)'),('a1024-point','a 1024-point'),('produce513','produce 513'),('(25Hz spacing,0–12.8kHz)','(25 Hz spacing, 0–12.8 kHz)'),('and399','and 399'),('from0.02 to7.98s','from 0.02 to 7.98 s'),('use10log10','use 10 log10'),('of−80dB','of −80 dB')]:caption=caption.replace(a,b)
 stem.with_suffix('.caption.txt').write_text(caption+'\n',encoding='utf-8')
 stem.with_suffix('.alt.txt').write_text('A measured healthy vibration record is represented twice. The upper panel uses a three-dimensional surface whose horizontal axes are time from 0 to 8 seconds and frequency from 0 to 12.8 kHz; height and cividis color both show spectral power relative to the maximum within that same record, from -80 to 0 dB. The lower panel shows the identical complete STFT as a flat heat map to avoid three-dimensional occlusion. No synthesized signal or classifier output is displayed.\n',encoding='utf-8')
 with fitz.open(stem.with_suffix('.pdf')) as doc:
  page=doc[0];spans=[s for b in page.get_text('dict')['blocks'] if b.get('type')==0 for line in b['lines'] for s in line['spans']]
  clips=[s['text'] for s in spans if s['bbox'][0]<-.1 or s['bbox'][1]<-.1 or s['bbox'][2]>page.rect.width+.1 or s['bbox'][3]>page.rect.height+.1]
  minimum=min(s['size'] for s in spans);width=page.rect.width*25.4/72;height=page.rect.height*25.4/72
  assert abs(width-170)<.01 and abs(height-145)<.01 and not clips and minimum>=6.99
 with Image.open(stem.with_suffix('.png')) as im:
  png={'pixels':list(im.size),'dpi':list(im.info.get('dpi',[]))};assert im.mode!='RGBA' or im.getextrema()[-1]==(255,255)
 result={'passed':True,'figure_contract':{'claim':'One fixed measured vibration record has a reproducible STFT landscape;3D+2D are alternative encodings of the same matrix.','archetype':'asymmetric measured surface and planar companion','backend':'Python matplotlib','journal':'not selected; general manuscript figure','model_outcome_selection':False},
  'source_name':chosen['name'],'source_sha256':chosen['sha256'],'source_author_repository':'https://github.com/CHAOZHAO-1/HUSTbearing-dataset',
  'selection_rule':'lexicographically firsthealthyfilename among documented downloadedsubset','source_shape_samples':262144,'used_samples':N,'used_duration_seconds':8.,'original_source_x_dtype':'text parsed float64 thenfloat32 roundtrip as existinganalysis',
  'measured_endpoint_fs':measured_fs,'analysis_fs':FS,'waveform_sha256':array_sha(x),'window':'periodic Hann','nperseg':WINDOW,'noverlap':OVERLAP,'nfft':WINDOW,'mode':'one-sided density PSD','detrend':'constant eachsegment','zero_padding':False,
  'frequency_bins':len(frequencies),'time_frames':len(centres),'full_stft_values':int(power.size),'reference_psd_source_x_unit_squared_per_hz':reference,'relative_display_floor_db':FLOOR_DB,
  'surface_display_strides':{'frequency':2,'time':4},'planar_full_resolution':True,'common_color_norm':True,'colormap':'cividis','view':{'projection':'orthographic','elevation':25,'azimuth':-125},
  'width_mm':width,'height_mm':height,'minimum_pdf_font_pt':minimum,'text_outside_pdf':clips,'png':png,'visual_review':'pending renderedinspection','elapsed_seconds':time.perf_counter()-started,
  'software':{'numpy':np.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__},
  'input_sha256':{str(p.relative_to(ROOT)):sha(p) for p in manifests+[Path(__file__),ROOT/'scripts/v5/prepare_hust_native_features.py']},
  'output_sha256':{p.name:sha(p) for p in OUT.glob(stem.name+'.*') if p.suffix!='json'}}
 stem.with_suffix('.qa.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:v for k,v in result.items() if 'sha256' not in k},indent=2))
if __name__=='__main__':main()
