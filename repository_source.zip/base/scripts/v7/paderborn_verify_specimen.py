"""Independent arithmetic and saved-pipeline replay for specimen-separated tests."""
from pathlib import Path
import json,hashlib,time
import joblib,numpy as np,pandas as pd
from threadpoolctl import threadpool_limits
from scripts.v7.paderborn_prepare import sha,write_json
from scripts.v7.paderborn_specimen import DEV_IDS,TEST_IDS,CONDITIONS,PROBS

ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'results/v7/paderborn_specimen';DOC=ROOT/'docs/v7'


def metric_arithmetic(frame):
    p=frame[PROBS].to_numpy(np.float64);y=frame.class_id.to_numpy(int);prediction=p.argmax(1)
    cm=np.zeros((3,3),dtype=int)
    for a,b in zip(y,prediction):cm[a,b]+=1
    f1=[];recall=[]
    for k in range(3):
        denom=cm[k].sum()+cm[:,k].sum();f1.append(2*cm[k,k]/denom if denom else 0.)
        recall.append(cm[k,k]/cm[k].sum())
    return {'macro_f1':float(np.mean(f1)),'balanced_accuracy':float(np.mean(recall)),
        'nll':float(-np.log(np.clip(p[np.arange(len(y)),y],np.finfo(np.float64).eps,1)).mean()),
        'multiclass_brier':float(np.mean(np.sum((p-np.eye(3)[y])**2,axis=1))),
        **dict(zip(['recall_H','recall_I','recall_O'],map(float,recall))),
        'n_records':len(y),'confusion_matrix':cm.tolist()}


def independently_aggregate(probabilities,lineage):
    table=lineage[['file_id','bearing_id','class_id','condition','run']].reset_index(drop=True).copy()
    for k,name in enumerate(PROBS):table[name]=probabilities[:,k]
    records=table.groupby(['file_id','bearing_id','class_id','condition','run'],sort=True)[PROBS].mean().reset_index()
    conditions=records.groupby(['bearing_id','class_id','condition'],sort=True)[PROBS].mean().reset_index()
    bearings=conditions.groupby(['bearing_id','class_id'],sort=True)[PROBS].mean().reset_index()
    for data in [records,conditions,bearings]:
        p=data[PROBS].to_numpy(float);data[PROBS]=p/p.sum(1,keepdims=True)
    return records,conditions,bearings


def main():
    started=time.perf_counter();path=OUT/'audit.json'
    write_json(path,{'passed':False,'status':'running; not a passed final audit'})
    design=json.loads((OUT/'design.json').read_text());selection=json.loads((OUT/'selection_manifest.json').read_text());ev=json.loads((OUT/'evaluation_manifest.json').read_text())
    for collection in [design['sha256'],selection['input_sha256'],ev['outputs']]:
        for relative,value in collection.items():assert sha(ROOT/relative)==value,relative
    assert sha(OUT/'selection_manifest.json')==ev['selection_manifest_sha256']
    for role in ['development','test']:
        preparation=json.loads((DOC/f'paderborn_specimen_{role}_preparation.json').read_text())
        for collection in [preparation['input_sha256'],preparation['outputs']]:
            for relative,value in collection.items():assert sha(ROOT/relative)==value,relative
    dev=pd.read_csv(ROOT/'data/processed/v7/paderborn_specimen_development_patch_lineage.csv')
    test=pd.read_csv(ROOT/'data/processed/v7/paderborn_specimen_test_patch_lineage.csv')
    assert set(dev.bearing_id)==set(DEV_IDS) and set(test.bearing_id)==set(TEST_IDS) and not set(dev.bearing_id)&set(test.bearing_id)
    assert dev.groupby('file_id').size().eq(16).all() and test.groupby('file_id').size().eq(16).all()
    for split in json.loads((OUT/'development_splits.json').read_text()):
        a=set(split['train_specimens']);b=set(split['validation_specimens']);assert len(a)==6 and len(b)==3 and not a&b and a|b==set(DEV_IDS)
        assert set(dev.iloc[split['train_patch_indices']].bearing_id)==a and set(dev.iloc[split['validation_patch_indices']].bearing_id)==b
    candidates=json.loads((OUT/'cv_candidates.json').read_text());oof=pd.read_csv(OUT/'development_oof_bearing_predictions.csv');maxmetric=0.
    for row in candidates:
        part=oof[(oof.representation==row['representation'])&(oof.family==row['family'])&(oof.seed==row['seed'])&(oof.config_index==row['config_index'])]
        assert len(part)==9 and not part.bearing_id.duplicated().any();manual=metric_arithmetic(part)
        for k in ['macro_f1','nll','multiclass_brier','recall_H','recall_I','recall_O']:maxmetric=max(maxmetric,abs(manual[k]-row[k]))
    stored_bearings=pd.read_csv(OUT/'bearing_predictions.csv');stored_conditions=pd.read_csv(OUT/'condition_bearing_predictions.csv');summary=pd.read_csv(OUT/'seed_summary.csv')
    maxprob=0.;replays=0
    with threadpool_limits(limits=1):
        for selected in selection['selected_models']:
            matching=[row for row in candidates if (row['representation'],row['family'],row['seed'])==(selected['representation'],selected['family'],selected['seed'])]
            chosen=sorted(matching,key=lambda r:(-r['macro_f1'],r['nll'],r['config_index']))[0]
            assert chosen['config_index']==selected['config_index']
            assert sha(ROOT/selected['model_path'])==selected['model_sha256'];model=joblib.load(ROOT/selected['model_path'])
            for timing in ['nominal','timestamp_sensitive']:
                table=pd.read_csv(OUT/f'test_{selected["representation"]}_{timing}_features.csv');assert table.patch_id.tolist()==test.patch_id.tolist()
                p=model.predict_proba(table[selection['feature_names']].to_numpy(np.float64));_,conditions,bearings=independently_aggregate(p,test)
                query=(stored_bearings.representation==selected['representation'])&(stored_bearings.family==selected['family'])&(stored_bearings.seed==selected['seed'])&(stored_bearings.timing==timing)
                recorded=stored_bearings[query].sort_values('bearing_id');bearings=bearings.sort_values('bearing_id')
                assert recorded.bearing_id.tolist()==bearings.bearing_id.tolist()
                maxprob=max(maxprob,float(abs(recorded[PROBS].to_numpy()-bearings[PROBS].to_numpy()).max()))
                for condition,frame in [('pooled',bearings)]+[(c,conditions[conditions.condition==c])for c in CONDITIONS]:
                    q=summary[(summary.representation==selected['representation'])&(summary.family==selected['family'])&(summary.seed==selected['seed'])&(summary.timing==timing)&(summary.condition==condition)]
                    assert len(q)==1;reported=q.iloc[0];manual=metric_arithmetic(frame)
                    for k in ['macro_f1','nll','multiclass_brier','recall_H','recall_I','recall_O']:maxmetric=max(maxmetric,abs(manual[k]-reported[k]))
                replays+=1
    assert maxprob<1e-12 and maxmetric<1e-12,(maxprob,maxmetric)
    artifacts=[OUT/'design.json',OUT/'selection_manifest.json',OUT/'evaluation_manifest.json',OUT/'descriptive_summary.csv',OUT/'bearing_predictions.csv',OUT/'seed_summary.csv']
    write_json(path,{'passed':True,'status':'complete independent arithmetic and saved-pipeline replay',
        'selected_models':12,'candidate_cv_fits':162,'replayed_model_timing_cells':replays,'newtest_specimens':9,'development_specimens':9,
        'test_measurements':test.file_id.nunique(),'test_patches':len(test),'development_measurements':dev.file_id.nunique(),
        'max_abs_bearing_probability_difference':maxprob,'max_abs_metric_difference':maxmetric,
        'all_frozen_source_and_input_hashes_match':True,'whole_bearing_cv_and_newtest_disjoint':True,
        'selection_independently_recomputed':True,'all_test_labels_excluded_from_fit_and_selection_by_code_review':True,
        'manufacturer_confound':'freshhealthyIBU;freshfaultyFAG/MTK; no causal defect identification',
        'limitations':['source metadata and original labels may encode manufacturer/damage provenance','timestamp proxy not validated vibration clock','nine test bearing units, no seed-based population CI','no measured field-noise validation'],
        'seconds':time.perf_counter()-started,'artifact_sha256':{str(p.relative_to(ROOT)):sha(p)for p in artifacts},'verifier_sha256':sha(Path(__file__))})
    print(json.dumps(json.loads(path.read_text()),indent=2),flush=True)


if __name__=='__main__':main()
