"""Frozen, duration- and patch-matched conventional HUSTbearing controls.

No test-based tuning, no probability calibration, no additional raw samples.
"""
from __future__ import annotations
import os
for _name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ.setdefault(_name,'1')
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import time
import warnings
import joblib
import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import confusion_matrix, f1_score, log_loss, balanced_accuracy_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from scripts.v3.prepare_novic_physical_features import feature_block, EPS
from scripts.v5.prepare_neural_patches import zscore_patch
from scripts.v6.consistency import test_panels

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/v7/classical'
CONDITIONS=['20Hz','30Hz','40Hz','60Hz','VS_0_40_0Hz']
SEEDS=[11,22,33]
REPRESENTATIONS=['native25','shape25']
BINS=[(0.,500.),(500.,2000.),(2000.,5000.),(5000.,12800.)]
CONFIGS={'extra_trees':[{'min_samples_leaf':leaf,'max_features':mf}
    for leaf in [1,2,4] for mf in ['sqrt',1.0]],
    'logistic_regression':[{'C':c} for c in [.1,1.,10.]]}
PROBS=['p_H','p_I','p_O']


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def array_sha(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()


def save_json(path,value):
    Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False)+'\n',encoding='utf-8')


def extract_features(x,representation):
    x=np.asarray(x)
    if x.ndim!=2 or x.shape[1]!=2048 or not np.isfinite(x).all():
        raise ValueError('Require finite [n,2048] vibration patches')
    if representation not in REPRESENTATIONS:raise ValueError('Unknown representation')
    normalized=zscore_patch(x) if representation=='shape25' else x
    rows=[];names=None
    for original,signal in zip(x,normalized):
        values,_=feature_block(signal,25600.,'Hz','source_X_unit' if representation=='native25' else '1',BINS)
        if representation=='shape25':
            active=float(np.std(original.astype(np.float32),ddof=0))>1e-8
            values['mean']=0.;values['std']=values['rms']=1. if active else 0.
        current=list(values)
        if names is None:names=current
        if names!=current or len(values)!=25:raise ValueError('Feature schema changed')
        rows.append(list(values.values()))
    a=np.asarray(rows,dtype=np.float64)
    if not np.isfinite(a).all():raise ValueError('Nonfinite conventional features')
    return a,names


def partition(frame,fold):
    if fold not in range(5):raise ValueError('Invalid condition fold')
    test=frame.condition.eq(CONDITIONS[fold]).to_numpy()
    val=frame.condition.eq(CONDITIONS[(fold+1)%5]).to_numpy()
    train=~(test|val)
    sets=[set(frame.loc[mask,'source_record']) for mask in [train,val,test]]
    if any(sets[i]&sets[j] for i,j in [(0,1),(0,2),(1,2)]):
        raise ValueError('Source recording crosses train/validation/test')
    if not all(sets):raise ValueError('Empty source partition')
    return tuple(np.flatnonzero(mask) for mask in [train,val,test])


def training_weights(frame):
    size=frame.groupby(['condition','class_id'])['source_record'].transform('size').to_numpy(float)
    counts=frame.groupby('source_record').size()
    if not counts.eq(32).all():raise ValueError('Every fitted source requires exactly 32 patches')
    if not frame.groupby('condition').class_id.nunique().eq(3).all():raise ValueError('All source groups require H/I/O')
    weights=1./size
    return weights/weights.mean()


def build_model(family,config,seed):
    if family=='extra_trees':
        return Pipeline([('classifier',ExtraTreesClassifier(n_estimators=400,n_jobs=1,
            random_state=seed,class_weight=None,**config))])
    if family=='logistic_regression':
        return Pipeline([('scale',StandardScaler()),('classifier',LogisticRegression(
            solver='lbfgs',max_iter=5000,random_state=seed,class_weight=None,**config))])
    raise ValueError('Unknown classifier family')


def fit_model(model,x,y,weights):
    params={'classifier__sample_weight':weights}
    if 'scale' in model.named_steps:params['scale__sample_weight']=weights
    return model.fit(x,y,**params)


def aggregate_records(p,frame,expected_patches=32):
    p=np.asarray(p,dtype=np.float64)
    if p.shape!=(len(frame),3) or not np.isfinite(p).all() or (p<0).any() or not np.allclose(p.sum(1),1):
        raise ValueError('Invalid patch probabilities')
    rows=[]
    for source,indices in frame.groupby('source_record',sort=True).indices.items():
        sub=frame.iloc[indices]
        if len(sub)!=expected_patches or sub.class_id.nunique()!=1:
            raise ValueError('Record must have exact patch count and one true label')
        probabilities=p[indices].mean(0);probabilities/=probabilities.sum()
        row={'source_record':source,'class_id':int(sub.class_id.iloc[0]),'patch_count':len(sub)}
        if 'condition' in sub:row['condition']=str(sub.condition.iloc[0])
        row.update(dict(zip(PROBS,map(float,probabilities))))
        rows.append(row)
    return pd.DataFrame(rows)


def record_metrics(records):
    y=records.class_id.to_numpy(int);p=records[PROBS].to_numpy(float);pred=p.argmax(1)
    cm=confusion_matrix(y,pred,labels=[0,1,2]);recall=np.diag(cm)/cm.sum(1)
    return {'macro_f1':float(f1_score(y,pred,labels=[0,1,2],average='macro',zero_division=0)),
        'balanced_accuracy':float(balanced_accuracy_score(y,pred)),
        'nll':float(log_loss(y,p,labels=[0,1,2])),
        'multiclass_brier':float(np.mean(np.sum((p-np.eye(3)[y])**2,axis=1))),
        **{f'recall_{c}':float(v) for c,v in zip('HIO',recall)},
        'confusion_matrix':cm.tolist(),'n_records':len(y)}


def independent_metrics_check(records,reported):
    """Direct confusion and score arithmetic, independent of sklearn metrics."""
    y=records.class_id.to_numpy(int);p=records[PROBS].to_numpy(float);pred=p.argmax(1)
    cm=np.zeros((3,3),dtype=int)
    for a,b in zip(y,pred):cm[a,b]+=1
    values=[];recalls=[]
    for k in range(3):
        denom=int(cm[k,:].sum()+cm[:,k].sum())
        values.append(2*cm[k,k]/denom if denom else 0.)
        recalls.append(cm[k,k]/cm[k].sum())
    manual={'macro_f1':float(np.mean(values)),'balanced_accuracy':float(np.mean(recalls)),
        'nll':float(-np.mean(np.log(np.clip(p[np.arange(len(y)),y],np.finfo(np.float64).eps,1.)))),
        'multiclass_brier':float(np.mean((p*p).sum(1)-2*p[np.arange(len(y)),y]+1)),
        **dict(zip(['recall_H','recall_I','recall_O'],map(float,recalls)))}
    error=max(abs(manual[k]-reported[k]) for k in manual)
    if error>1e-12 or reported['confusion_matrix']!=cm.tolist() or reported['n_records']!=len(y):
        raise AssertionError(f'Independent metrics differ: {error}')
    return {'passed':True,'max_abs_metric_difference':error}


def select_candidate(rows):return min(rows,key=lambda r:(-r['macro_f1'],r['nll'],r['config_index']))


def predict_frame(model,features,frame,indices):
    p=model.predict_proba(features[indices])
    classes=model.named_steps['classifier'].classes_.tolist()
    if classes!=[0,1,2]:raise ValueError('Classifier class order changed')
    return p,aggregate_records(p,frame.iloc[indices])


def main(args):
    started=time.perf_counter();OUT.mkdir(parents=True,exist_ok=True)
    xp=ROOT/'data/processed/v5/hust_neural_patches.npz'
    lp=ROOT/'data/processed/v5/hust_neural_patch_lineage.csv'
    frame=pd.read_csv(lp);archive=np.load(xp,allow_pickle=False);x=archive['x']
    assert x.shape==(672,2048) and x.dtype==np.float32
    assert np.array_equal(archive['patch_id'],frame.patch_id.to_numpy(str))
    assert frame.source_record.nunique()==21 and frame.groupby('source_record').size().eq(32).all()
    panels=test_panels(x)
    panel_hashes={k:array_sha(v) for k,v in panels.items()}
    v6=json.loads((ROOT/'results/v6/robustness/design.json').read_text(encoding='utf-8'))
    assert panel_hashes==v6['test_noise_array_sha256'],'Fixed v6 noise panels changed'
    paths=[Path(__file__),ROOT/'docs/v7/classical_design.md',ROOT/'tests/evaluation/test_v7_matched_classical.py',
        xp,lp,ROOT/'scripts/v3/prepare_novic_physical_features.py',ROOT/'scripts/v5/prepare_neural_patches.py',
        ROOT/'scripts/v6/consistency.py',ROOT/'results/v6/robustness/design.json']
    design={'frozen_utc':datetime.now(timezone.utc).isoformat(),'status':'retrospective v6-informed equal-input controls',
        'input_shape':list(x.shape),'input_dtype':str(x.dtype),'source_records':21,'patches_per_record':32,
        'seconds_per_record':2.56,'representations':REPRESENTATIONS,'feature_count':25,'bins_hz':BINS,
        'shape_normalization':'neural float32 within-patch zscore; canonical exact mean0,std/rms1 for nondegenerate patches',
        'conditions':CONDITIONS,'seeds':SEEDS,'configs':CONFIGS,'tree_count':400,'lr_max_iter':5000,
        'training_weights':'equal total source-condition/class weight; equal source files within cell; mean sample weight1; no additional class_weight',
        'selection':'clean-only validation file macroF1,lowerfileNLL,smallerconfigindex; no calibration or test selection',
        'aggregation':'mean native predict_proba over exact32patches per file; row roundoff-only normalization',
        'planned_candidate_fits':270,'planned_selected_models':60,'planned_fold_panel_cells':360,'planned_pooled_cells':72,
        'panel_array_sha256':panel_hashes,'sha256':{str(p.relative_to(ROOT)):sha(p) for p in paths},
        'software':{'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'joblib':joblib.__version__},
        'threads':1,'limitations':['unknown measured physical bearing IDs','synthetic stress,not industrial-noise validation',
            'native25 has amplitude access absent from neural normalization','full-batch ML vs stochastic neural compute not matched',
            'deterministic LR repeats are not independent stochastic seeds','clean-only selection differs from v6']}
    dp=OUT/'design.json'
    if dp.exists():
        old=json.loads(dp.read_text(encoding='utf-8'));design['frozen_utc']=old['frozen_utc']
        assert old==json.loads(json.dumps(design)), 'Frozen conventional design changed'
    else:save_json(dp,design)
    print('Matched conventional design frozen before fitting; 270 candidates',flush=True)
    if args.freeze_only:return
    features={};feature_names={};feature_hashes={}
    for representation in REPRESENTATIONS:
        for panel,values in panels.items():
            features[(representation,panel)],names=extract_features(values,representation)
            feature_names[representation]=names
            feature_hashes[f'{representation}/{panel}']=array_sha(features[(representation,panel)])
    save_json(OUT/'feature_audit.json',{'columns':feature_names,'array_sha256':feature_hashes,
        'shape_per_array':[672,25],'metadata_columns_in_features':[],'fitting_in_feature_extraction':False})
    candidate_rows=[];all_records=[];fold_rows=[];selected_rows=[];replay_rows=[];metric_errors=[]
    runroot=OUT/'runs';runroot.mkdir(exist_ok=True)
    with threadpool_limits(limits=1):
        for representation in REPRESENTATIONS:
            for family,configs in CONFIGS.items():
                for fold in range(5):
                    ti,vi,ei=partition(frame,fold);weights=training_weights(frame.iloc[ti])
                    y=frame.class_id.to_numpy(int);clean=features[(representation,'clean')]
                    for seed in SEEDS:
                        rid=f'{representation}__{family}__fold{fold}__seed{seed}'
                        run=runroot/rid;run.mkdir(exist_ok=True)
                        if (run/'metadata.json').exists():
                            raise RuntimeError(f'Existing completed run; use frozen results rather than overwrite: {rid}')
                        fitted=[];local=[];run_start=time.perf_counter()
                        for index,config in enumerate(configs):
                            model=build_model(family,config,seed);start=time.perf_counter()
                            with warnings.catch_warnings(record=True) as captured:
                                warnings.simplefilter('always');fit_model(model,clean[ti],y[ti],weights)
                            p,record=predict_frame(model,clean,frame,vi);met=record_metrics(record)
                            check=independent_metrics_check(record,met);metric_errors.append(check['max_abs_metric_difference'])
                            row={'representation':representation,'family':family,'fold':fold,'seed':seed,
                                'config_index':index,**met,'fit_seconds':time.perf_counter()-start,
                                'parameters':config,'warnings':[str(w.message) for w in captured],
                                'validation_predictions':record.to_dict(orient='records')}
                            candidate_rows.append(row);local.append(row);fitted.append(model)
                        chosen=select_candidate(local);index=chosen['config_index'];model=fitted[index]
                        modelpath=run/'selected_model.joblib';joblib.dump(model,modelpath,compress=3)
                        reopened=joblib.load(modelpath);patch_rows=[];record_rows=[];test_cells=[]
                        for panel in panels:
                            p,records=predict_frame(model,features[(representation,panel)],frame,ei)
                            replay=reopened.predict_proba(features[(representation,panel)][ei])
                            error=float(np.max(np.abs(p-replay)))
                            if error!=0.:raise AssertionError('Selected estimator replay changed probabilities')
                            met=record_metrics(records);check=independent_metrics_check(records,met)
                            metric_errors.append(check['max_abs_metric_difference'])
                            context={'representation':representation,'family':family,'fold':fold,'seed':seed,'panel':panel}
                            fold_rows.append({**context,**met});test_cells.append({**context,**met})
                            records=records.assign(**context);record_rows.append(records);all_records.append(records)
                            patch=frame.iloc[ei].copy().reset_index(drop=True)
                            for j,col in enumerate(PROBS):patch[col]=p[:,j]
                            patch_rows.append(patch.assign(**context))
                            replay_rows.append({**context,'max_abs_probability_difference':error})
                        pd.concat(record_rows,ignore_index=True).to_csv(run/'record_test_predictions.csv',index=False)
                        pd.concat(patch_rows,ignore_index=True).to_csv(run/'patch_test_predictions.csv',index=False)
                        _,vrec=predict_frame(model,clean,frame,vi);vrec.to_csv(run/'record_validation_predictions.csv',index=False)
                        save_json(run/'candidate_validation.json',local)
                        artifacts=[p for p in run.iterdir() if p.is_file()]
                        metadata={'run_id':rid,'representation':representation,'family':family,'fold':fold,'seed':seed,
                            'selected_config_index':index,'selected_parameters':configs[index],
                            'validation':{k:v for k,v in chosen.items() if k!='validation_predictions'},
                            'test':test_cells,'estimator_parameters':{k:str(v) for k,v in model.get_params().items()},
                            'train_source_records':sorted(frame.iloc[ti].source_record.unique().tolist()),
                            'validation_source_records':sorted(frame.iloc[vi].source_record.unique().tolist()),
                            'test_source_records':sorted(frame.iloc[ei].source_record.unique().tolist()),
                            'train_patch_count':len(ti),'train_weight_sha256':array_sha(weights),
                            'train_weight_group_sums':frame.iloc[ti].assign(weight=weights).groupby(['condition','class_id']).weight.sum().reset_index().to_dict(orient='records'),
                            'elapsed_seconds':time.perf_counter()-run_start,'design_sha256':sha(dp),
                            'sha256':{p.name:sha(p) for p in artifacts}}
                        save_json(run/'metadata.json',metadata)
                        selected_rows.append({'representation':representation,'family':family,'fold':fold,'seed':seed,
                            'config_index':index,'parameters':configs[index],'model_sha256':sha(modelpath),
                            'elapsed_seconds':metadata['elapsed_seconds']})
                        save_json(OUT/'candidate_validation.json',candidate_rows)
                        print(f'{len(selected_rows):02d}/60 {rid}: selected config {index}',flush=True)
    records=pd.concat(all_records,ignore_index=True)
    records.to_csv(OUT/'record_predictions.csv',index=False)
    pd.DataFrame(fold_rows).to_csv(OUT/'fold_summary.csv',index=False)
    pooled=[]
    for keys,sub in records.groupby(['representation','family','seed','panel'],sort=False):
        if len(sub)!=21 or sub.source_record.nunique()!=21:raise AssertionError('OOF support not exactly21 files')
        met=record_metrics(sub);check=independent_metrics_check(sub,met);metric_errors.append(check['max_abs_metric_difference'])
        pooled.append({**dict(zip(['representation','family','seed','panel'],keys)),**met})
    pooled=pd.DataFrame(pooled);pooled.to_csv(OUT/'pooled_summary.csv',index=False)
    keys=['representation','family','panel'];metrics=['macro_f1','nll','multiclass_brier','recall_H','recall_I','recall_O']
    summary=pooled.groupby(keys,sort=False)[metrics].agg(['mean','min','max'])
    summary.columns=['_'.join(col) for col in summary.columns];summary.reset_index().to_csv(OUT/'descriptive_summary.csv',index=False)
    save_json(OUT/'selected_models.json',selected_rows);save_json(OUT/'model_replay.json',replay_rows)
    assert len(candidate_rows)==270 and len(selected_rows)==60 and len(fold_rows)==360 and len(pooled)==72
    assert len(records)==1512 and len(replay_rows)==360
    assert not any(row['warnings'] for row in candidate_rows),'Convergence or fitting warnings require review'
    for relative,expected in design['sha256'].items():assert sha(ROOT/relative)==expected,'Frozen input changed during fitting'
    artifacts=[p for p in OUT.rglob('*') if p.is_file() and p.name!='audit.json']
    save_json(OUT/'audit.json',{'passed':True,'finished_utc':datetime.now(timezone.utc).isoformat(),
        'candidate_fits':270,'selected_models':60,'fold_panel_cells':360,'pooled_cells':72,'record_predictions':1512,
        'test_patch_predictions':48384,'selected_model_panel_replays':360,'max_abs_probability_replay_difference':0.,
        'max_abs_independent_metric_difference':max(metric_errors),'fit_warnings':0,
        'elapsed_seconds':time.perf_counter()-started,'sha256':{str(p.relative_to(ROOT)):sha(p) for p in artifacts}})
    print('PASS: 270 candidate fits,60 selected models,360 exact model-panel replays',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--freeze-only',action='store_true')
    main(parser.parse_args())
