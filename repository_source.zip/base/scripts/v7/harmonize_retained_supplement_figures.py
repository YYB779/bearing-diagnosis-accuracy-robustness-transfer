"""Rerender five retained scientific figures into v7 only, without refitting."""
from pathlib import Path
import hashlib,json,ast,textwrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.text import Text
import numpy as np
import pandas as pd
import fitz
from PIL import Image
from scripts.v4 import draw_state_figures as state
from scripts.v5 import plot_extension as extension
from scripts.v6 import plot_robustness as robustness
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'figures/v7/si'
REPORT=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save_figure(fig,stem,tables,caption,alt='',inputs=None):
 OUT.mkdir(parents=True,exist_ok=True);width=fig.get_figwidth()*25.4;fig.set_figwidth(170/25.4)
 for item in fig.findobj(Text):
  item.set_fontfamily('Arial');item.set_fontsize(max(7.,item.get_fontsize()*min(1.,170/width)))
 # Retain marker/data semantics; only typography and physical page width change.
 fig.canvas.draw()
 for suffix in ['pdf','svg','png']:fig.savefig(OUT/f'{stem}.{suffix}',dpi=300,facecolor='white',transparent=False,bbox_inches=None)
 plt.close(fig);sources=[]
 for name,table in tables.items():
  p=OUT/f'{stem}_{name}.csv';table.to_csv(p,index=False);sources.append({'name':p.name,'rows':len(table),'sha256':sha(p)})
 cp=OUT/f'{stem}_caption.md';cp.write_text(caption+'\n\nAlt text: '+alt+'\n',encoding='utf-8')
 with fitz.open(OUT/f'{stem}.pdf') as doc:
  page=doc[0];spans=[s for b in page.get_text('dict')['blocks'] if b.get('type')==0 for line in b['lines'] for s in line['spans']]
  clipped=[s['text'] for s in spans if s['bbox'][0]<-.1 or s['bbox'][1]<-.1 or s['bbox'][2]>page.rect.width+.1 or s['bbox'][3]>page.rect.height+.1];minimum=min(s['size'] for s in spans);fonts=sorted(set(s['font'] for s in spans));height=page.rect.height*25.4/72
  assert not clipped,(stem,clipped)
  assert minimum>=6.99,(stem,minimum)
 with Image.open(OUT/f'{stem}.png') as im:
  png={'size':list(im.size),'dpi':list(im.info.get('dpi',[]))};assert im.mode!='RGBA' or im.getextrema()[-1]==(255,255)
 report={'stem':stem,'passed':True,'width_mm':170,'height_mm':height,'minimum_font_pt':minimum,'fonts':fonts,'out_of_page_text':clipped,'source_tables':sources,'caption_sha256':sha(cp),'png':png,'input_sha256':{str(p.relative_to(ROOT)):sha(p) for p in inputs or []},'output_sha256':{f'{stem}.{e}':sha(OUT/f'{stem}.{e}') for e in ['pdf','svg','png']},'visual_review':'pending rendered inspection'}
 REPORT.append(report);(OUT/f'{stem}_qa.json').write_text(json.dumps(report,indent=2)+'\n');print(stem,'saved',flush=True);return report
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 plt.rcParams.update({'font.family':'Arial','font.size':7.5,'axes.labelsize':7.5,'axes.titlesize':8.,'xtick.labelsize':7.,'ytick.labelsize':7.,'legend.fontsize':7.,'pdf.fonttype':42,'svg.fonttype':'none','axes.linewidth':.65})
 paths=[ROOT/'scripts/v4/draw_state_figures.py',ROOT/'scripts/v5/plot_extension.py',ROOT/'scripts/v6/plot_robustness.py',ROOT/'scripts/v4_external_draw.py']
 old_hashes={str(p.relative_to(ROOT)):sha(p) for p in paths}
 def state_save(fig,name,caption,tables):return save_figure(fig,'si_same_model',tables,caption,'Same fitted model predicts known-state and unknown-state tests; every frozen rotation retained.',[paths[0],state.A/'fold_metrics.csv'])
 state.save=state_save;state.figure5(pd.read_csv(state.A/'fold_metrics.csv'))
 def feature_save(fig,stem,source,caption,alt,inputs,transformations):return save_figure(fig,'si_native_hust',{'source':source},caption,alt,list(inputs)+[paths[1]])
 extension.save=feature_save;extension.feature_figure(pd.read_csv(extension.ANALYSIS/'pooled_summary.csv'))
 design,predictions,pooled,_,inputs=robustness.load_complete_results()
 def robust_save(fig,stem,source,caption,alt,paths_in,transformations,estimator):
  target='si_consistency_design' if stem=='fig16_sensor_consistency_design' else 'si_incremental_gains'
  return save_figure(fig,target,{'source':source},caption,alt,list(paths_in)+[paths[2]])
 robustness.save=robust_save;robustness.design_figure(design);robustness.gains_figure(pooled,predictions,inputs)
 # The legacy external plotting module executes on import. Execute only its
 # read-only initializer and the last, support-specific plotting block. Its
 # exporter is replaced before the plotting block runs, and OUT is redirected.
 path=paths[3];source=path.read_text(encoding='utf-8');tree=ast.parse(source)
 prefix=[];withnode=None
 for node in tree.body:
  if isinstance(node,ast.With):withnode=node;break
  prefix.append(node)
 code=ast.Module(body=prefix,type_ignores=[])
 namespace={'__file__':str(path),'__name__':'retained_external_support'}
 prefix_source=ast.unparse(code).replace("OUT = ROOT / 'figures/v4_external'","OUT = ROOT / 'figures/v7/si'")
 exec(compile(prefix_source,str(path),'exec'),namespace)
 def external_save(fig,name,data,semantics,alt,caption):return save_figure(fig,'si_hust_support',{'source':pd.DataFrame(data)},caption,alt,namespace['input_paths']+[path])
 namespace['export']=external_save
 body=withnode.body;start=[i for i,n in enumerate(body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='fig' for t in n.targets)][-1]
 plot=ast.Module(body=body[start:],type_ignores=[])
 with plt.rc_context(namespace['STYLE']):exec(compile(plot,str(path),'exec'),namespace)
 assert old_hashes=={str(p.relative_to(ROOT)):sha(p) for p in paths}
 manifest={'passed':True,'count':len(REPORT),'font':'Arial>=7pt','physical_width_mm':170,'old_scientific_source_files_unchanged':True,'no_model_fitting':True,'figures':REPORT,'script_sha256':sha(Path(__file__))}
 (OUT/'retained_supplement_style_audit.json').write_text(json.dumps(manifest,indent=2)+'\n');print('PASS all5retainedfigures rerendered tov7only',flush=True)
if __name__=='__main__':main()
