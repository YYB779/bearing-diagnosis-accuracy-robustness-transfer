"""Evidence-bounded extensions; frozen V6 evidence is never overwritten."""
