"""Frozen whole-bearing CV, development-only refit and separate new-specimen test."""
from __future__ import annotations
import os
for name in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
    os.environ.setdefault(name,'1')
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,hashlib,time,warnings
import joblib,numpy as np,pandas as pd,scipy,sklearn
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits
from scripts.v7.paderborn_specimen import (DEV_IDS,TEST_IDS,LABELS,CONDITIONS,CONFIGS,PROBS,
    development_partition,training_weights,aggregate_hierarchical,extract_features,
    build_model,fit_model,record_metrics,independent_metrics_check,select_candidate)
from scripts.v7.paderborn_prepare import sha,write_json,prepare

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/v7/paderborn_specimen'
DATA=ROOT/'data/processed/v7'
DOC=ROOT/'docs/v7'
SEEDS=[11,22,33]
REPRESENTATIONS=['native25','shape25']
MODELS=['extra_trees','logistic_regression']


def protocol():
    OUT.mkdir(parents=True,exist_ok=True)
    paths=[Path(__file__),ROOT/'scripts/v7/paderborn_specimen.py',ROOT/'scripts/v7/paderborn_prepare.py',
        DOC/'paderborn_specimen_design.md',ROOT/'tests/evaluation/test_v7_paderborn_specimen.py',
        ROOT/'scripts/v7/run_matched_classical.py',ROOT/'scripts/v3/prepare_novic_physical_features.py',
        ROOT/'scripts/v5/prepare_neural_patches.py',ROOT/'scripts/v6/consistency.py']
    record={'frozen_utc':datetime.now(timezone.utc).isoformat(),
        'status':'retrospective computational extension; classical protocol frozen before classical fitting/prediction; external neural inference partially attempted during evolving implementation; historical dev specimens exposed',
        'development_specimens':DEV_IDS,'new_test_specimens':TEST_IDS,'conditions':CONDITIONS,'measurement_runs':[1,2,3,4],
        'strict_gate':'finite same-length1D,count>=256000,strictly increasing relativetimestamps,last>=3.999984375s; no padding/substitution',
        'bearing_gate':'atleast1passingselectedmeasurementpercondition;all4conditions;developmentall9required',
        'primary_input':'documentednominal64k:first256000float32?resample_poly2/5constantpadding?25.6k;16patch2048',
        'timing_sensitivity':'exactrelativehosttimestampinterpontoarange256000/64000,float32thenidenticalresample; notverifiedphysicalclock',
        'training_input':'nominaldevelopmentonly','representations':REPRESENTATIONS,'classifiers':MODELS,
        'seeds':SEEDS,'configs':CONFIGS,'et_trees':400,'lr_max_iter':5000,
        'cv':'3wholebearingfolds,jthdevelopmentbearingperclass;pooled9bearingOOFF1,lowerNLL,smallerconfigindex',
        'weights':'equalbearingandconditiontotalweight,meanpatchweight1',
        'aggregation':'16patchmean?equalpassingmeasurementmeanpercondition?equal4conditionmeanperbearing',
        'planned_cv_fits':162,'planned_selected_models':12,'no_external_calibration':True,
        'manufacturer_confound':'freshhealthyIBU;freshdamagedFAGorMTK;notcausaldefectmechanismidentification',
        'sha256':{str(p.relative_to(ROOT)):sha(p)for p in paths},
        'software':{'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__,'joblib':joblib.__version__},'threads':1}
    path=OUT/'design.json'
    if path.exists():
        old=json.loads(path.read_text(encoding='utf-8'));record['frozen_utc']=old['frozen_utc']
        if record!=old:raise RuntimeError('Frozen specimen protocol/source changed')
    else:write_json(path,record)
    return record


def check_prepared(role):
    report=json.loads((DOC/f'paderborn_specimen_{role}_preparation.json').read_text(encoding='utf-8'))
    for relative,value in report['outputs'].items():
        if sha(ROOT/relative)!=value:raise RuntimeError('Prepared output hash changed: '+relative)
    return report


def load_role(role):
    check_prepared(role)
    frame=pd.read_csv(DATA/f'paderborn_specimen_{role}_patch_lineage.csv')
    z=np.load(DATA/f'paderborn_specimen_{role}_patches.npz',allow_pickle=False)
    if not np.array_equal(z['patch_id'],frame.patch_id.to_numpy(str)):raise RuntimeError('Array-lineage mismatch')
    return z,frame


def features_for(role):
    z,frame=load_role(role);arrays={};names=None
    for timing in ['nominal','timestamp_sensitive']:
        for representation in REPRESENTATIONS:
            x,current=extract_features(z[timing],representation)
            if names is not None and current!=names:raise RuntimeError('Feature dictionary differs')
            names=current;arrays[(representation,timing)]=x
            pd.DataFrame(x,columns=current).assign(patch_id=frame.patch_id.to_numpy()).to_csv(
                OUT/f'{role}_{representation}_{timing}_features.csv',index=False)
    z.close()
    return arrays,frame,names


def predict(model,x,frame):
    if model.named_steps['classifier'].classes_.tolist()!=[0,1,2]:raise RuntimeError('Changed model class order')
    p=model.predict_proba(x);return p,aggregate_hierarchical(p,frame)


def fit_all():
    protocol();check_prepared('development')
    if (OUT/'selection_manifest.json').exists():raise RuntimeError('Selection already frozen; use evaluate or verify')
    arrays,frame,names=features_for('development')
    if set(frame.bearing_id)!=set(DEV_IDS) or set(frame.role)!={'development'}:raise RuntimeError('Development source changed')
    split=[]
    for fold in range(3):
        tr,va=development_partition(frame,fold)
        split.append({'fold':fold,'train_specimens':sorted(frame.iloc[tr].bearing_id.unique()),
            'validation_specimens':sorted(frame.iloc[va].bearing_id.unique()),'train_patch_indices':tr.tolist(),'validation_patch_indices':va.tolist()})
    write_json(OUT/'development_splits.json',split)
    candidates=[];oof=[];models=[]
    with threadpool_limits(limits=1):
        for representation in REPRESENTATIONS:
            x=arrays[(representation,'nominal')]
            for family in MODELS:
                for seed in SEEDS:
                    available=[]
                    for index,config in enumerate(CONFIGS[family]):
                        cv_bearings=[];fold_details=[]
                        for fold in range(3):
                            tr,va=development_partition(frame,fold)
                            model=build_model(family,config,seed)
                            with warnings.catch_warnings():
                                warnings.simplefilter('error',ConvergenceWarning)
                                fit_model(model,x[tr],frame.iloc[tr].class_id.to_numpy(int),training_weights(frame.iloc[tr]))
                            _,(_,_,bearings)=predict(model,x[va],frame.iloc[va])
                            cv_bearings.append(bearings)
                            fold_details.append({'fold':fold,'n_training_patches':len(tr),'n_validation_patches':len(va),'metrics':record_metrics(bearings)})
                        pooled=pd.concat(cv_bearings,ignore_index=True)
                        if len(pooled)!=9 or pooled.bearing_id.duplicated().any():raise RuntimeError('CV is not nine unique held-out bearings')
                        metrics=record_metrics(pooled);independent_metrics_check(pooled,metrics)
                        row={'representation':representation,'family':family,'seed':seed,'config_index':index,'config':config,**metrics,'folds':fold_details}
                        available.append(row);candidates.append(row)
                        for record in pooled.to_dict('records'):oof.append({'representation':representation,'family':family,'seed':seed,'config_index':index,**record})
                    selected=select_candidate(available)
                    model=build_model(family,selected['config'],seed);started=time.perf_counter()
                    with warnings.catch_warnings():
                        warnings.simplefilter('error',ConvergenceWarning)
                        fit_model(model,x,frame.class_id.to_numpy(int),training_weights(frame))
                    stem=f'{representation}_{family}_s{seed}';mp=OUT/(stem+'.joblib');joblib.dump(model,mp,compress=3)
                    models.append({'representation':representation,'family':family,'seed':seed,'config_index':selected['config_index'],
                        'config':selected['config'],'development_cv':{k:selected[k]for k in ['macro_f1','nll','recall_H','recall_I','recall_O']},
                        'model_path':str(mp.relative_to(ROOT)),'model_sha256':sha(mp),'fit_seconds':time.perf_counter()-started})
                    print(f'FIT {stem}: devCV={selected["macro_f1"]:.3f}',flush=True)
    write_json(OUT/'cv_candidates.json',candidates);pd.DataFrame(oof).to_csv(OUT/'development_oof_bearing_predictions.csv',index=False)
    inputs=[OUT/'design.json',DOC/'paderborn_specimen_development_preparation.json',DATA/'paderborn_specimen_development_patches.npz',
        DATA/'paderborn_specimen_development_patch_lineage.csv',OUT/'development_splits.json',OUT/'cv_candidates.json',OUT/'development_oof_bearing_predictions.csv']
    inputs += [OUT/f'development_{r}_{t}_features.csv'for r in REPRESENTATIONS for t in ['nominal','timestamp_sensitive']]
    selection={'frozen_before_test_prediction_utc':datetime.now(timezone.utc).isoformat(),'selected_models':models,
        'candidate_cv_fits':162,'final_models':12,'feature_names':names,'input_sha256':{str(p.relative_to(ROOT)):sha(p)for p in inputs},
        'selection':'nine-development-bearingOOFF1,lowerNLL,fixedindex; nominalonly; no newtest model prediction before this manifest'}
    write_json(OUT/'selection_manifest.json',selection)
    print('Selection manifest frozen:12models, no newtest predictions',flush=True)


def check_selection():
    protocol();path=OUT/'selection_manifest.json';selected=json.loads(path.read_text(encoding='utf-8'))
    if len(selected['selected_models'])!=12:raise RuntimeError('Twelve final models required')
    for relative,value in selected['input_sha256'].items():
        if sha(ROOT/relative)!=value:raise RuntimeError('Frozen fitting input changed: '+relative)
    for m in selected['selected_models']:
        if sha(ROOT/m['model_path'])!=m['model_sha256']:raise RuntimeError('Frozen final model changed')
    return selected


def evaluate_all():
    selected=check_selection();test_report=check_prepared('test');arrays,frame,names=features_for('test')
    if set(frame.bearing_id)&set(DEV_IDS) or set(frame.role)!={'test'}:raise RuntimeError('Test specimen leaked into development')
    if names!=selected['feature_names']:raise RuntimeError('Test feature order changed')
    measurements=[];conditions=[];bearings=[];summaries=[]
    with threadpool_limits(limits=1):
        for m in selected['selected_models']:
            model=joblib.load(ROOT/m['model_path']);r=m['representation'];family=m['family'];seed=m['seed']
            for timing in ['nominal','timestamp_sensitive']:
                _,(me,co,be)=predict(model,arrays[(r,timing)],frame)
                fields={'representation':r,'model':'logistic'if family=='logistic_regression'else family,'family':family,'seed':seed,'timing':timing}
                for target,data in [(measurements,me),(conditions,co),(bearings,be)]:
                    target.extend([{**fields,**row}for row in data.to_dict('records')])
                for condition,records in [('pooled',be)]+[(c,co[co.condition==c])for c in CONDITIONS]:
                    met=record_metrics(records);independent_metrics_check(records,met)
                    summaries.append({**fields,'condition':condition,**{k:v for k,v in met.items()if k!='confusion_matrix'}})
    pd.DataFrame(measurements).to_csv(OUT/'measurement_predictions.csv',index=False)
    pd.DataFrame(conditions).to_csv(OUT/'condition_bearing_predictions.csv',index=False)
    pd.DataFrame(bearings).to_csv(OUT/'bearing_predictions.csv',index=False)
    seed=pd.DataFrame(summaries);seed.to_csv(OUT/'seed_summary.csv',index=False)
    rows=[]
    for (r,m,t),q in seed[seed.condition=='pooled'].groupby(['representation','model','timing'],sort=True):
        row={'representation':r,'model':m,'timing':t,'condition':'pooled','seeds':len(q),'test_specimens':int(q.n_records.iloc[0])}
        for name in ['macro_f1','nll','multiclass_brier','recall_H','recall_I','recall_O']:
            row[name+'_mean']=float(q[name].mean());row[name+'_min']=float(q[name].min());row[name+'_max']=float(q[name].max())
        rows.append(row)
    pd.DataFrame(rows).to_csv(OUT/'descriptive_summary.csv',index=False)
    outputs=[OUT/p for p in ['measurement_predictions.csv','condition_bearing_predictions.csv','bearing_predictions.csv','seed_summary.csv','descriptive_summary.csv']]
    write_json(OUT/'evaluation_manifest.json',{'selection_manifest_sha256':sha(OUT/'selection_manifest.json'),
        'test_preparation_sha256':sha(DOC/'paderborn_specimen_test_preparation.json'),'test_specimens':len(test_report['eligible_specimens']),
        'test_measurements':test_report['passing_measurements'],'test_patches':len(frame),
        'outputs':{str(p.relative_to(ROOT)):sha(p)for p in outputs},
        'limitations':['class-manufacturer confounding:allnewhealthyIBU,faultyFAG/MTK','timingproxyisnotverifiedphysicalclock','threealgorithmseedsarenotnewbearings','noindustrialnoisetest']})
    print('New-specimen prediction complete; independent verification still required',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['freeze','prepare','fit','evaluate','all'],default='all');a=p.parse_args()
    protocol()
    if a.mode in ['prepare','all']:
        prepare('development');prepare('test')
    if a.mode in ['fit','all']:fit_all()
    if a.mode in ['evaluate','all']:evaluate_all()
