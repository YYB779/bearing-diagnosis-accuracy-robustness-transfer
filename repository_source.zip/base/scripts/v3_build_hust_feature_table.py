"""Fixed non-overlapping, full-bandwidth HUST vibration features, without fitting.

Primary axis is X (declared here). Y/Z are exported for a labelled sensitivity
analysis, not for choosing the most favorable test axis. Scaling belongs inside
the training split. No auxiliary speed column or nominal target condition is
included as a predictive feature.
"""
from pathlib import Path
import csv, datetime, hashlib, json
import numpy as np
from scipy.signal import periodogram
from scipy.stats import skew, kurtosis

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'data/raw/v3_external/hust_subset_structure_audit.json'
OUT=ROOT/'data/processed/v3_external'
OUT.mkdir(parents=True,exist_ok=True)
audit=json.loads(SRC.read_text(encoding='utf8'))
archive=Path(audit['numeric_archive'])
assert hashlib.sha256(archive.read_bytes()).hexdigest()==audit['numeric_archive_sha256']
data=np.load(archive,allow_pickle=False)
FS=25600.; WINDOW=4096; EPS=1e-20
BANDS=np.geomspace(10,FS/2,13)

def features(x):
    x=np.asarray(x,dtype=np.float64)
    absolute=np.abs(x); rms=np.sqrt(np.mean(x*x)); absmean=np.mean(absolute); peak=np.max(absolute)
    f,p=periodogram(x,fs=FS,window='hann',detrend='constant',scaling='spectrum')
    p=np.maximum(p,0); mass=p.sum()+EPS; prob=p/mass
    centroid=float(np.sum(f*prob)); spread=float(np.sqrt(np.sum((f-centroid)**2*prob)))
    values={
      'mean':x.mean(),'std':x.std(),'rms':rms,'absolute_mean':absmean,
      'peak_to_peak':np.ptp(x),'crest_factor':peak/(rms+EPS),'impulse_factor':peak/(absmean+EPS),
      'shape_factor':rms/(absmean+EPS),'clearance_factor':peak/(np.mean(np.sqrt(absolute))**2+EPS),
      'skewness':skew(x,bias=True),'kurtosis_pearson':kurtosis(x,fisher=False,bias=True),
      'zero_crossing_fraction':np.mean(np.signbit(x[1:])!=np.signbit(x[:-1])),
      'mean_absolute_difference':np.mean(np.abs(np.diff(x))),'mean_squared_difference':np.mean(np.diff(x)**2),
      'spectral_centroid_hz':centroid,'spectral_spread_hz':spread,
      'spectral_entropy_normalized':-np.sum(prob*np.log(prob+EPS))/np.log(len(prob)),
      'spectral_flatness':np.exp(np.mean(np.log(p+EPS)))/(np.mean(p)+EPS),
      'dominant_frequency_hz':f[np.argmax(p)],
      'spectral_rolloff95_hz':f[min(int(np.searchsorted(np.cumsum(prob),.95)),len(f)-1)],
      'spectral_fraction_above_2000hz':np.sum(prob[f>=2000]),
    }
    for i,(lo,hi) in enumerate(zip(BANDS[:-1],BANDS[1:])):
        mask=(f>=lo)&(f<hi if i<11 else f<=hi)
        values[f'band_fraction_{i+1:02d}']=np.sum(prob[mask])
    assert len(values)==33
    assert np.isfinite(list(values.values())).all()
    return values

rows=[]
for record,x in enumerate(data['vibration_xyz']):
    name=str(data['record_name'][record]); cls=str(data['class_name'][record]); condition=str(data['condition'][record])
    for index,start in enumerate(range(0,len(x)-WINDOW+1,WINDOW)):
        stop=start+WINDOW
        row={'source_record_id':Path(name).stem,'raw_file_name':name,'class_name':cls,'class_id':{'H':0,'I':1,'O':2}[cls],
          'nominal_condition':condition,'window_index':index,'start_sample':start,'stop_sample_exclusive':stop,
          'start_time_s':start/FS,'duration_s':WINDOW/FS,'sample_rate_hz':int(FS)}
        for channel,axis in enumerate(['X','Y','Z']):
            row.update({f'f_{axis}__{key}':float(value) for key,value in features(x[start:stop,channel]).items()})
        rows.append(row)

assert len(rows)==576
path=OUT/'hust_hio_20_40_vs_features_4096.csv'
with path.open('w',newline='',encoding='utf8') as f:
    writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
metadata={
  'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'archive':str(archive),'archive_sha256':audit['numeric_archive_sha256'],
  'csv':str(path),'csv_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
  'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
  'rows':len(rows),'record_count':9,'window_samples':WINDOW,'window_duration_s':WINDOW/FS,'windows_per_record':64,
  'window_overlap_samples':0,'spectrum':'Hann periodogram, detrend constant, original fs=25600Hz; no pre-feature downsampling',
  'bands_hz':BANDS.tolist(),'primary_predictors_prefix':'f_X__','sensitivity_predictors_prefixes':['f_Y__','f_Z__'],
  'feature_count_per_axis':33,'class_mapping':{'H':0,'I':1,'O':2},
  'excluded_predictors':['source_record_id','raw_file_name','class_name','class_id','nominal_condition','window_index','start_sample','stop_sample_exclusive','start_time_s','duration_s','sample_rate_hz'],
  'training_note':'No fitting or scaling has occurred. Fit any scaler, feature selection, and hyperparameters only on training and validation data. Never feed filenames, window times, or target conditions as features.',
  'limitations':audit['limitations'],
}
(OUT/'hust_hio_20_40_vs_features_4096.metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf8')
print(json.dumps({k:metadata[k] for k in ['rows','record_count','csv','csv_sha256','feature_count_per_axis','primary_predictors_prefix']},indent=2))
