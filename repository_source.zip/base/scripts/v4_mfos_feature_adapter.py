"""Extract the matching-title MFoS2E repository features on v3 physical intervals.

The public numerical implementation is imported unchanged from hustviz.py at the
recorded commit. Only native-data loading, exact-endpoint interval sampling and
output bookkeeping are adapted. No classifier or fold selection runs here.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys
import time

import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits


ROOT = Path(__file__).resolve().parents[1]
VENDOR = ROOT / "scripts/vendor_v4_mfos2e"
OUTPUT = ROOT / "data/processed/v4"
RESONANCES_HZ = [3000.0, 4000.0, 7500.0]
RATIO = 7.9 / 38.5
PRINCIPAL_ORDERS = (4.5*(1+RATIO), 4.5*(1-RATIO),
                    (1-RATIO**2)/(2*RATIO), 0.5*(1-RATIO))
RIDGE_LAMBDA = 0.005  # First value of the repository's declared ridge grid; no fitted selection.


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as source:
        for part in iter(lambda: source.read(1024*1024), b""):
            h.update(part)
    return h.hexdigest()


def load_repository_module(vendor: Path = VENDOR):
    """Load the supplied Py3.10-compatible module after verifying source hashes."""
    manifest = json.loads((vendor / "download_manifest.json").read_text(encoding="utf-8"))
    for item in manifest["files"]:
        if sha256(vendor / item["name"]) != item["sha256"]:
            raise ValueError(f"Repository source hash changed: {item['name']}")
    os.environ.setdefault("MPLBACKEND", "Agg")
    for module_name, filename in [("hust_loader", "hust_loader.py"),
                                   ("_v4_mfos_repository_core", "hustviz.py")]:
        if module_name in sys.modules:
            existing = Path(sys.modules[module_name].__file__).resolve()
            if existing != (vendor / filename).resolve():
                raise RuntimeError(f"Conflicting imported module: {module_name}")
            continue
        spec = importlib.util.spec_from_file_location(module_name, vendor / filename)
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
    return sys.modules["_v4_mfos_repository_core"]


def native_interval(x, rpm, source_fs, start_s, stop_s):
    """Keep both declared endpoints on an approximately native-rate regular grid.

    Fractional boundaries cannot both lie on the original sample grid. The
    nearest native sample count and its exact effective rate avoid either early
    carrier compression or pretending unequal edge time steps are uniform.
    """
    x = np.asarray(x, dtype=float)
    rpm = np.asarray(rpm, dtype=float)
    if x.ndim != 1 or rpm.shape != x.shape or x.size < 64:
        raise ValueError("Vibration and RPM must have matching one-dimensional support")
    if not np.isfinite(x).all() or not np.isfinite(rpm).all() or np.any(rpm <= 0):
        raise ValueError("Measured vibration must be finite and measured RPM finite and positive")
    if not np.isfinite(source_fs) or source_fs <= 0:
        raise ValueError("Native sample rate must be positive")
    if not (0 <= start_s < stop_s <= (x.size-1)/source_fs + 1e-12):
        raise ValueError("Physical interval is outside the measured native source")
    n = int(round((stop_s-start_s)*source_fs)) + 1
    if n < 64:
        raise ValueError("Physical interval has insufficient native support")
    coordinate = np.linspace(start_s*source_fs, stop_s*source_fs, n)
    native_coordinate = np.arange(x.size, dtype=float)
    interval_x = np.interp(coordinate, native_coordinate, x)
    interval_fr = np.interp(coordinate, native_coordinate, rpm) / 60.0
    effective_fs = (n-1)/(stop_s-start_s)
    audit = {"native_count": n, "physical_start_s": float(start_s),
             "physical_stop_s": float(stop_s), "effective_fs_hz": float(effective_fs),
             "source_fs_hz": float(source_fs),
             "fs_relative_difference": float(effective_fs/source_fs-1),
             "maximum_interpolation_distance_samples": float(np.max(np.abs(coordinate-np.rint(coordinate))))}
    return interval_x, interval_fr, effective_fs, audit


def extract_feature_vector(core, x, f_rot, fs, *, label=0, file_id="unlabelled"):
    """Use the repository numerical path with fixed parameters, one sample at a time."""
    sample = core.MatSample(label=int(label), file_id=str(file_id),
                            x=np.asarray(x), f_rot=np.asarray(f_rot), fs=float(fs))
    cache = core.cache_samples_from_mat(
        [sample], fs_global=None, res_freqs=RESONANCES_HZ,
        principal_orders=PRINCIPAL_ORDERS, delta_order=0.4, M=2, L=128,
        search_bw=1600.0, lp_cut=600.0, stft_nperseg=1024,
        stft_noverlap=768, median_kernel_power=401)
    cfg = core.DenoiseCConfig()
    X, _, _, metrics = core.build_features_from_cache_mat(
        cache, cfg, ridge_lambda=RIDGE_LAMBDA, compute_metrics=True)
    if X.shape[0] != 1 or not np.isfinite(X).all():
        raise ValueError("Repository returned invalid feature rows")
    debug = cache["samples"][0]["dbgA"]
    spans = [float(debug["cycles"][e-1]-debug["cycles"][s])
             for s, e in zip(debug["starts"], debug["ends"])]
    audit = {"repository_revolution_bins": len(spans),
             "minimum_revolution_phase_span": min(spans),
             "maximum_revolution_phase_span": max(spans),
             "rcs_error": float(metrics["rcs"][0]),
             "cbai_mean": float(metrics["cbai_mean"][0]),
             "feature_count": int(X.shape[1]),
             "stageB_cfg": vars(cfg)}
    return X[0].copy(), audit


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT)
    args = parser.parse_args()
    start_clock = time.perf_counter()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    preprocessing_path = ROOT / "data/processed/v3/preprocessing_audit.json"
    preprocessing = json.loads(preprocessing_path.read_text(encoding="utf-8"))
    schema = json.loads((ROOT / "data/raw/novic_variable_speed/official_schema_and_pairing.json").read_text(encoding="utf-8"))
    raw_path = ROOT / schema["data_path"]
    expected_raw_hash = preprocessing["inputs"][0]["sha256"]
    if sha256(raw_path) != expected_raw_hash:
        raise ValueError("Native NOVIC source checksum no longer matches the v3 audit")
    lineage_path = ROOT / "data/processed/v3/novic_physical_lineage.csv"
    reference_path = ROOT / "data/processed/v3/novic_physical_features.csv"
    lineage = pd.read_csv(lineage_path)
    reference_ids = pd.read_csv(reference_path, usecols=["sample_id"])["sample_id"].tolist()
    if len(lineage) != 404 or lineage["sample_id"].tolist() != reference_ids:
        raise ValueError("Expected the ordered 404-sample v3 lineage")
    raw = np.load(raw_path, mmap_mode="r")
    if tuple(raw.shape) != (101, 102400, 9):
        raise ValueError(f"Unexpected raw source shape {raw.shape}")
    core = load_repository_module()
    vectors, sample_audits = [], []
    with threadpool_limits(limits=1):
        for i, row in enumerate(lineage.itertuples(index=False)):
            source_row = np.asarray(raw[int(row.array_row)])
            x, fr, fs, interval_audit = native_interval(
                source_row[:, 0], source_row[:, 8], 25600.0,
                float(row.physical_start_s), float(row.physical_stop_s))
            # Constant sentinel label: true labels, nuisance codes, subset and IDs
            # cannot enter the signal feature calculation.
            vector, feature_audit = extract_feature_vector(core, x, fr, fs, label=0,
                                                           file_id=str(row.sample_id))
            vectors.append(vector)
            sample_audits.append({"sample_id": row.sample_id,
                                  "array_row": int(row.array_row),
                                  **interval_audit,
                                  **{k: v for k, v in feature_audit.items() if k != "stageB_cfg"}})
            if (i+1) % 20 == 0 or i == 0:
                print(f"MFoS repository features {i+1}/{len(lineage)} elapsed={time.perf_counter()-start_clock:.1f}s", flush=True)
    X = np.stack(vectors)
    feature_columns = [f"mfos_repository__f{i:04d}" for i in range(X.shape[1])]
    frame = pd.DataFrame(X, columns=feature_columns)
    frame.insert(0, "sample_id", reference_ids)
    feature_path = args.output_dir / "mfos_repository_features.csv"
    frame.to_csv(feature_path, index=False)
    sample_audit_path = args.output_dir / "mfos_repository_sample_audit.csv"
    sample_frame = pd.DataFrame(sample_audits)
    sample_frame.to_csv(sample_audit_path, index=False)
    # A real numerical label-isolation check on the first source interval.
    first = lineage.iloc[0]
    source_row = np.asarray(raw[int(first.array_row)])
    x, fr, fs, _ = native_interval(source_row[:, 0], source_row[:, 8], 25600.0,
                                  float(first.physical_start_s), float(first.physical_stop_s))
    with threadpool_limits(limits=1):
        relabelled, _ = extract_feature_vector(core, x, fr, fs, label=999, file_id="label-invariance-check")
    if not np.array_equal(X[0], relabelled):
        raise AssertionError("Repository features changed after relabelling")
    manifest_path = VENDOR / "download_manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    audit = {
        "status": "complete: features only; no classifier fitted",
        "method_label": "exploratory matching-title MFoS2E repository-code baseline",
        "paper_doi": "10.1016/j.ymssp.2026.114844",
        "repository": manifest["repository"], "commit": manifest["commit"],
        "module": "hustviz.py", "module_sha256": sha256(VENDOR / "hustviz.py"),
        "core_source_modifications": [],
        "module_choice_reason": "version20.py contains a Py3.10-incompatible plotting f-string; supplied hustviz.py has equivalent numerical feature path and parses unchanged",
        "author_repository_identity_link_verified": False,
        "repository_license": None,
        "redistribute_vendor_in_public_package": False,
        "rows": len(frame), "feature_count": X.shape[1],
        "sample_ids_match_v3_order": frame["sample_id"].tolist() == reference_ids,
        "feature_columns": feature_columns,
        "true_labels_provided_to_core": False,
        "sentinel_label": 0,
        "relabelled_first_sample_bitwise_identical": True,
        "cross_sample_fit_or_scaling": False,
        "per_sample_operations": "STFT ridge/demodulation, median-floor/log1p/z-score feature envelope, revolution projection, fixed proximal denoising, fixed dictionary ridge projection; repository nan_to_num retained",
        "classifier_scaling_requirement": "Any subsequent classifier StandardScaler/PCA/selection must fit within each training fold only",
        "parameters": {"res_freqs_hz": RESONANCES_HZ, "principal_orders": PRINCIPAL_ORDERS,
                       "principal_order_names": ["BPFI", "BPFO", "BSF", "FTF"],
                       "geometry": preprocessing["geometry"],
                       "delta_order": 0.4, "M": 2, "L": 128,
                       "search_bw_hz": 1600.0, "lp_cut_hz": 600.0,
                       "stft_nperseg": 1024, "stft_noverlap": 768,
                       "median_kernel_power": 401,
                       "stageB_cfg": vars(core.DenoiseCConfig()),
                       "ridge_lambda": RIDGE_LAMBDA,
                       "ridge_choice": "first value in published repository main search grid, fixed without validation/test selection"},
        "input_interval": "Both v3 float endpoints; nearest native sample count on regular equal-time grid, linear interpolation and exact effective sampling rate; no compact carrier compression",
        "processing_context": "Repository processes each approx-native eight-turn interval directly; full-four-second context is not substituted for the original sample-wise path",
        "effective_fs_range_hz": [float(sample_frame.effective_fs_hz.min()), float(sample_frame.effective_fs_hz.max())],
        "native_count_range": [int(sample_frame.native_count.min()), int(sample_frame.native_count.max())],
        "revolution_bins_range": [int(sample_frame.repository_revolution_bins.min()), int(sample_frame.repository_revolution_bins.max())],
        "minimum_revolution_phase_span": float(sample_frame.minimum_revolution_phase_span.min()),
        "all_features_finite": bool(np.isfinite(X).all()),
        "elapsed_seconds": time.perf_counter()-start_clock,
        "inputs": [{"path": str(raw_path), "sha256": expected_raw_hash},
                   {"path": str(lineage_path), "sha256": sha256(lineage_path)},
                   {"path": str(preprocessing_path), "sha256": sha256(preprocessing_path)},
                   {"path": str(Path(__file__).resolve()), "sha256": sha256(Path(__file__))}],
        "outputs": [{"path": str(feature_path), "sha256": sha256(feature_path)},
                    {"path": str(sample_audit_path), "sha256": sha256(sample_audit_path)}],
        "software": {"python": platform.python_version(), **{p: importlib.metadata.version(p) for p in ["numpy", "scipy", "scikit-learn", "matplotlib", "pandas"]}},
        "limitations": ["Not a full-paper reproduction; paper full text unavailable and repository authorship linkage unverified",
                        "Parameters fixed, not claimed optimally tuned for NOVIC",
                        "Repository normalizes every accepted revolution bin, including boundary partial bins, to a local unit phase",
                        "Native-grid interpolation is an explicit input adaptation and changes sampling rate slightly",
                        "Approx-native counts differ across intervals; no matched-point-budget claim against compact v3 inputs",
                        "Per-interval filtering uses offline future samples and has its own boundary behavior",
                        "State and physical-bearing independence are properties of subsequent evaluation splits, not this feature extraction"]}
    (args.output_dir / "mfos_repository_feature_audit.json").write_text(
        json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"rows": len(frame), "features": X.shape[1],
                      "seconds": audit["elapsed_seconds"], "output": str(feature_path)}, ensure_ascii=True), flush=True)


if __name__ == "__main__":
    main()
