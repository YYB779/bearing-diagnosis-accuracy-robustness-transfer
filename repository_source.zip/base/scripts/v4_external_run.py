"""Frozen source-record/condition-blocked HUST comparisons; no target tuning."""
from pathlib import Path
import datetime,json,platform,time
import joblib,numpy as np,scipy,sklearn
from scipy.signal import butter,sosfiltfilt,resample_poly,hilbert
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.svm import SVC
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from v4_external_common import CLASSES,generic,sha,csv_write,metrics,aggregate,RecordSigmoid

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results/v4_external'; OUT.mkdir(parents=True,exist_ok=True)
PROV=ROOT/'data/raw/v4_external'
CONDITIONS=['20Hz','30Hz','40Hz','60Hz','VS_0_40_0Hz']
REPS=['raw_lowpass_33','single_carrier_2_5khz_33','three_carrier_99']
SEEDS=[11,22,33]; FS=25600; SECONDS=8; LOW_FS=400
OLD_MANIFEST=ROOT/'data/raw/v3_external/hust_subset_download_manifest.json'
NEW_MANIFEST=PROV/'download_manifest.json'
old=json.loads(OLD_MANIFEST.read_text(encoding='utf8'))['downloads']
new=json.loads(NEW_MANIFEST.read_text(encoding='utf8'))['downloads'] if NEW_MANIFEST.exists() else []
acquisition_ok=len(new)==12 and all('error' not in row for row in new)
downloads=old+new if acquisition_ok else old
assert len(downloads)==(21 if acquisition_ok else 9)
assert len({r['sha256'] for r in downloads})==len(downloads)
registration={
 'registered_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'frozen_before_model_fit':True,'design_file':str(ROOT/'docs/v4/external_frozen_design.md'),
 'design_sha256':sha(ROOT/'docs/v4/external_frozen_design.md'),
 'script_sha256':sha(__file__),'common_sha256':sha(ROOT/'scripts/v4_external_common.py'),
 'download_manifest_sha256':sha(NEW_MANIFEST) if NEW_MANIFEST.exists() else None,
 'old_manifest_sha256':sha(OLD_MANIFEST),'expanded_acquisition_complete':acquisition_ok,
 'raw_source_records':len(downloads),'representations':dict(zip(REPS,[33,33,99])),
 'outer_conditions':CONDITIONS if acquisition_ok else [],
 'outer_validation_rule':'next condition in fixed cyclic order; remaining three train',
 'ET':{'n_estimators':200,'min_samples_leaf':[1,3],'seeds':SEEDS,'max_features':1.0,'bootstrap':False,'n_jobs':2},
 'SVM':{'kernel':'rbf','C':[.1,1,10],'gamma':'scale','scaler':'train-fit StandardScaler inside pipeline',
        'calibration':'three training-condition OOF folds, aggregate to source-record decision scores, record-only smoothed OVR Platt sigmoid; final base refit on all training windows'},
 'selection':'validation record macro-F1 descending, NLL ascending, lower leaf/C',
 'ET_calibration':'supplementary, selected ET only, same training-record OOF sigmoid; no recalibration with validation/test',
 'source_scope':'within-HUST held-condition acquisitions; the same bearing recurs within a health or damage state',
 'new_data_scope':'12 new source files, not new independent physical bearings or cohorts',
 'auxiliary_speed_used':False,'test_frequency_or_temperature_tuning':False,
 'versions':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'sklearn':sklearn.__version__},
}
regpath=OUT/'registration.json'
if regpath.exists():
    existing=json.loads(regpath.read_text(encoding='utf8'))
    for key in ['design_sha256','script_sha256','common_sha256','download_manifest_sha256','old_manifest_sha256']:
        assert existing[key]==registration[key], 'Frozen definition changed: '+key
else:
    regpath.write_text(json.dumps(registration,indent=2),encoding='utf8')

lineage=[]; features={rep:[] for rep in REPS}; structure=[]
lowfilter=butter(6,180,fs=FS,btype='lowpass',output='sos')
for row in sorted(downloads,key=lambda r:r['name']):
    path=ROOT/row['local_path']; assert sha(path)==row['sha256']
    with path.open(encoding='utf8') as stream:
        header=[]
        for line in stream:
            header.append(line.rstrip('\n'))
            if line.strip()=='Data':break
        arr=np.loadtxt(stream,delimiter='\t',dtype=np.float64)
    assert arr.shape==(262144,5) and np.isfinite(arr).all()
    assert (np.diff(arr[:,0])>0).all()
    endpoint_fs=(len(arr)-1)/(arr[-1,0]-arr[0,0]);assert abs(endpoint_fs-FS)<.01
    stem=path.stem; medium=stem.startswith('0.5X_')
    health,condition=(stem[5:] if medium else stem).split('_',1)
    label=CLASSES.index(health)
    severity='healthy' if health=='H' else ('medium' if medium else 'severe')
    # Match v3 numeric-archive quantization for the retained nine raw records.
    raw=arr[:SECONDS*FS,2].astype(np.float32).astype(np.float64)
    low=resample_poly(sosfiltfilt(lowfilter,raw),1,64)
    envs=[]
    for lo,hi in [(500,2000),(2000,5000),(5000,10000)]:
        envelope=np.abs(hilbert(sosfiltfilt(butter(4,[lo,hi],fs=FS,btype='bandpass',output='sos'),raw)))
        envs.append(resample_poly(sosfiltfilt(lowfilter,envelope),1,64))
    for window in range(8):
        seg=slice(window*LOW_FS,(window+1)*LOW_FS)
        lineage.append({'source_record':path.name,'condition':condition,'class_id':label,'class_name':health,
                        'severity':severity,'window_index':window,'start_sample':window*FS,
                        'stop_sample_exclusive':(window+1)*FS,'new_v4_file':path.name not in {r['name'] for r in old}})
        features[REPS[0]].append(generic(low[seg]))
        features[REPS[1]].append(generic(envs[1][seg]))
        features[REPS[2]].append({f'carrier{b+1}_{k}':v for b,env in enumerate(envs) for k,v in generic(env[seg]).items()})
    structure.append({'name':path.name,'sha256':row['sha256'],'shape':list(arr.shape),'endpoint_fs':float(endpoint_fs),
                      'condition':condition,'class_name':health,'severity':severity,'physical_bearing_id':None,
                      'new_v4_file':path.name not in {r['name'] for r in old},'auxiliary_speed_used':False})
    print('Extracted',path.name,flush=True)

(PROV/'structure_audit.json').write_text(json.dumps({'records':structure,'n_raw_records':len(structure),
    'unique_sha256':len(set(r['sha256'] for r in structure)),'frozen_experiment_registration_sha256':sha(regpath),
    'independent_bearing_id_available':False,'unverified_speed_column_used':False},indent=2),encoding='utf8')
csv_write(OUT/'window_lineage.csv',lineage)
for rep in REPS:
    csv_write(OUT/f'{rep}_features.csv',[{**meta,**value} for meta,value in zip(lineage,features[rep])])
y=np.array([r['class_id'] for r in lineage]); groups=np.array([r['source_record'] for r in lineage]); conditions=np.array([r['condition'] for r in lineage])
feature_arrays={rep:np.array([list(d.values()) for d in features[rep]],dtype=float) for rep in REPS}
assert all(np.isfinite(a).all() for a in feature_arrays.values())
metadata={r['source_record']:r for r in lineage}
candidate_rows=[]; result_rows=[]; predictions=[]; calibration_audits=[]; split_audits=[]

def et(seed,leaf):
    return ExtraTreesClassifier(n_estimators=200,min_samples_leaf=leaf,max_features=1.0,bootstrap=False,class_weight=None,random_state=seed,n_jobs=2)

def svm(c):
    return make_pipeline(StandardScaler(),SVC(kernel='rbf',C=c,gamma='scale',decision_function_shape='ovr',probability=False))

def scores(model,X,family):
    if family=='ET':
        return np.log(np.clip(model.predict_proba(X),1e-12,1))
    return model.decision_function(X)

def fit_record_calibrator(X,train,constructor,family,fold_id,rep,seed,hyper):
    levels=sorted(set(conditions[train])); assert len(levels)==3
    names=[]; labels=[]; values=[]; folds=[]
    for hold in levels:
        fit=train&(conditions!=hold); held=train&(conditions==hold)
        assert set(y[fit])==set(y[held])=={0,1,2}
        assert not(set(groups[fit])&set(groups[held]))
        model=constructor();model.fit(X[fit],y[fit])
        gn,gy,gs=aggregate(scores(model,X[held],family),y[held],groups[held])
        names.extend(gn);labels.extend(gy);values.extend(gs)
        folds.append({'held_training_condition':hold,'fit_source_records':sorted(set(groups[fit])),
                      'held_source_records':gn,'fit_classes':sorted(set(int(v) for v in y[fit])),
                      'held_classes':sorted(set(int(v) for v in y[held]))})
    assert len(names)==len(set(names))==len(set(groups[train]))
    calibrator=RecordSigmoid().fit(np.asarray(values),np.asarray(labels))
    calibration_audits.append({'fold':fold_id,'representation':rep,'family':family,'seed':seed,'hyperparameter':hyper,
                               'calibration_source_records':names,'n_effective_calibration_records':len(names),
                               'calibration_folds':folds,'sigmoid_fit':calibrator.audit,
                               'calibration_uses_validation':False,'calibration_uses_test':False})
    return calibrator

def record_prob(model,X,idx,family,cal=None):
    if cal is None:
        return aggregate(model.predict_proba(X[idx]),y[idx],groups[idx])
    names,labels,values=aggregate(scores(model,X[idx],family),y[idx],groups[idx])
    return names,labels,cal.predict_proba(values)

def add_result(study,fold,rep,family,seed,hyper,model,X,test,valmetric,cal=None):
    names,labels,prob=record_prob(model,X,test,family,cal)
    met=metrics(labels,prob)
    row={'study':study,'fold':fold,'representation':rep,'n_features':X.shape[1],
         'model':family+('_record_sigmoid' if cal is not None else '_uncalibrated'),
         'seed':seed,'selected_hyperparameter':hyper,'validation_record_metrics':valmetric,'test_record_metrics':met}
    result_rows.append(row)
    for name,label,p in zip(names,labels,prob):
        meta=metadata[name]
        predictions.append({'study':study,'fold':fold,'representation':rep,'model':row['model'],'seed':seed,
            'source_record':name,'condition':meta['condition'],'severity':meta['severity'],'new_v4_file':meta['new_v4_file'],
            'true_class':int(label),'predicted_class':int(np.argmax(p)),**{f'prob_{c}':float(p[k]) for k,c in enumerate(CLASSES)}})
    print(study,fold,rep,row['model'],seed,'F1',met['macro_f1'],'NLL',met['nll'],flush=True)

studies=[]
if acquisition_ok:
    for i,test_condition in enumerate(CONDITIONS):
        val_condition=CONDITIONS[(i+1)%5]
        studies.append(('expanded_condition_holdout',test_condition,conditions!=test_condition,conditions==val_condition,conditions==test_condition,True))
# The already-observed v3 subset remains an explicit fixed split.
oldnames={r['name'] for r in old}
legacy=np.array([g in oldnames for g in groups])
studies.append(('original_nine_file_split','VS_0_40_0Hz',legacy&(conditions=='20Hz'),legacy&(conditions=='40Hz'),legacy&(conditions=='VS_0_40_0Hz'),False))

for study,fold,train,val,test,can_calibrate in studies:
    train=train&~val&~test
    for a,b in [(train,val),(train,test),(val,test)]:assert not(set(groups[a])&set(groups[b]))
    assert set(y[train])==set(y[val])==set(y[test])=={0,1,2}
    split_audits.append({'study':study,'fold':fold,'train_records':sorted(set(groups[train])),
                        'validation_records':sorted(set(groups[val])),'test_records':sorted(set(groups[test])),
                        'train_conditions':sorted(set(conditions[train])),'validation_conditions':sorted(set(conditions[val])),
                        'test_conditions':sorted(set(conditions[test])),'record_calibration_feasible':can_calibrate,
                        'infeasible_reason':None if can_calibrate else 'Only three training files, one/class. Holding any source record out removes its class from base-model training; no valid three-fold record sigmoid calibration.'})
    for rep in REPS:
        X=feature_arrays[rep]
        for seed in SEEDS:
            options=[]
            for leaf in [1,3]:
                model=et(seed,leaf);model.fit(X[train],y[train])
                vn,vy,vp=record_prob(model,X,val,'ET');vm=metrics(vy,vp)
                candidate_rows.append({'study':study,'fold':fold,'representation':rep,'model':'ET_uncalibrated',
                                       'seed':seed,'hyperparameter':leaf,'validation_record_metrics':vm})
                options.append((vm,leaf,model))
            vm,leaf,model=min(options,key=lambda r:(-r[0]['macro_f1'],r[0]['nll'],r[1]))
            add_result(study,fold,rep,'ET',seed,leaf,model,X,test,vm)
            artifact={'base_model':model,'record_calibrator':None,'registration_sha256':sha(regpath)}
            if can_calibrate:
                cal=fit_record_calibrator(X,train,lambda:et(seed,leaf),'ET',fold,rep,seed,leaf)
                vn,vy,vp=record_prob(model,X,val,'ET',cal)
                add_result(study,fold,rep,'ET',seed,leaf,model,X,test,metrics(vy,vp),cal)
                artifact['record_calibrator']=cal
            joblib.dump(artifact,OUT/f'{study}_{fold}_{rep}_ET_seed{seed}.joblib',compress=3)
        if can_calibrate:
            options=[]
            for c in [.1,1,10]:
                cal=fit_record_calibrator(X,train,lambda:svm(c),'SVM',fold,rep,'deterministic',c)
                model=svm(c);model.fit(X[train],y[train])
                vn,vy,vp=record_prob(model,X,val,'SVM',cal);vm=metrics(vy,vp)
                candidate_rows.append({'study':study,'fold':fold,'representation':rep,'model':'SVM_record_sigmoid',
                                       'seed':'deterministic','hyperparameter':c,'validation_record_metrics':vm})
                options.append((vm,c,model,cal))
            vm,c,model,cal=min(options,key=lambda r:(-r[0]['macro_f1'],r[0]['nll'],r[1]))
            add_result(study,fold,rep,'SVM','deterministic',c,model,X,test,vm,cal)
            joblib.dump({'base_model':model,'record_calibrator':cal,'registration_sha256':sha(regpath)},
                        OUT/f'{study}_{fold}_{rep}_SVM.joblib',compress=3)
    # Persist completed-fold outputs so a failed later fit cannot hide earlier failures.
    (OUT/'candidate_validation.json').write_text(json.dumps(candidate_rows,indent=2),encoding='utf8')
    (OUT/'selected_results.json').write_text(json.dumps(result_rows,indent=2),encoding='utf8')
    (OUT/'calibration_audit.json').write_text(json.dumps(calibration_audits,indent=2),encoding='utf8')
    (OUT/'split_audit.json').write_text(json.dumps(split_audits,indent=2),encoding='utf8')
    csv_write(OUT/'heldout_record_predictions.csv',predictions)

pooled=[]
if acquisition_ok:
    combos=sorted({(p['representation'],p['model'],str(p['seed'])) for p in predictions if p['study']=='expanded_condition_holdout'})
    for rep,model,seed in combos:
        subset=[p for p in predictions if p['study']=='expanded_condition_holdout' and p['representation']==rep and p['model']==model and str(p['seed'])==seed]
        assert len(subset)==len({p['source_record'] for p in subset})==21
        for severity_scope in ['all_records','healthy_plus_severe','healthy_plus_medium']:
            chosen=[p for p in subset if severity_scope=='all_records' or p['severity']=='healthy' or p['severity']==severity_scope.removeprefix('healthy_plus_')]
            labels=np.array([p['true_class'] for p in chosen]);prob=np.array([[p[f'prob_{c}'] for c in CLASSES] for p in chosen])
            pooled.append({'representation':rep,'model':model,'seed':seed,'severity_scope':severity_scope,**metrics(labels,prob)})
csv_write(OUT/'selected_metrics.csv',[{'study':r['study'],'fold':r['fold'],'representation':r['representation'],'model':r['model'],
    'seed':r['seed'],'selected_hyperparameter':r['selected_hyperparameter'],**{k:v for k,v in r['test_record_metrics'].items() if k!='confusion_matrix'}} for r in result_rows])
if pooled:csv_write(OUT/'pooled_metrics.csv',[{k:v for k,v in r.items() if k!='confusion_matrix'} for r in pooled])
summary={'registration_sha256':sha(regpath),'expanded_acquisition_complete':acquisition_ok,
         'raw_recordings':len(downloads),'windows':len(lineage),'features':dict(zip(REPS,[33,33,99])),
         'selected_runs':len(result_rows),'validation_candidates':len(candidate_rows),
         'pooled_out_of_fold_records':pooled,'results':result_rows,
         'limitations':['The provider links acquisitions within a state across speeds to the same bearing; cross-state serial numbers are unavailable.',
          'Five condition folds reuse training domains and are not independent cohorts.',
          'Medium severity covers only 20/40/VS; class-severity coverage is not balanced across conditions.',
          'Previously observed original nine-file result remains included; extension is not a pristine confirmatory benchmark.',
          'Eight windows per file are repeated measurements; record count is the effective prediction-unit count.',
          'No calibrated Speed used; VS is a filename command profile, not measured instantaneous RPM.',
          'Calibration uses only nine to thirteen training source records; probability estimates remain fragile.',
          'Within-HUST fitting is not zero-shot cross-source transfer or a reproduction of the complete published benchmark.']}
(OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
(OUT/'artifact_hashes.json').write_text(json.dumps({p.name:sha(p) for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='artifact_hashes.json'},indent=2),encoding='utf8')
print('COMPLETED',len(result_rows),'selected runs',flush=True)
