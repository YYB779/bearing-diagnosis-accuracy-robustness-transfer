"""First-party vibration adaptation of three-view predictive consistency.

JSD mechanism: Hendrycks et al., AugMix, ICLR 2020, arXiv:1912.02781.
Not the original image-mixing augmentation or clean-only supervised recipe.
All perturbations are synthetic and label-blind. No fitting or loader here.
"""
import numpy as np
import torch
from scripts.v5.prepare_neural_patches import zscore_patch


def three_view_jsd(logits):
    if logits.ndim!=3 or logits.shape[0]!=3:
        raise ValueError('Expected [three views,batch,classes] logits')
    logp=torch.log_softmax(logits,dim=-1)
    logm=torch.logsumexp(logp,dim=0)-np.log(3.)
    return (logp.exp()*(logp-logm)).sum(-1).mean()


def apply_response(x,log_gains):
    """Positive zero-phase frequency response on finite periodic FFT blocks.

    This noncausal, circular amplitude transformation is a perturbation proxy,
    not an identified/measured mechanical transfer function.
    """
    x=np.asarray(x,float);g=np.asarray(log_gains,float)
    if x.ndim!=2 or g.shape!=(len(x),5) or not np.isfinite(g).all():
        raise ValueError('One set of five finite anchor gains per patch required')
    if np.max(np.abs(g))>.70000001:raise ValueError('Response gains exceed frozen bound')
    anchors=np.array([0,2000,4000,8000,12800])/12800
    freq=np.linspace(0,1,x.shape[-1]//2+1)
    multiplier=np.exp(np.stack([np.interp(freq,anchors,row) for row in g]))
    return np.fft.irfft(np.fft.rfft(x,axis=-1)*multiplier,n=x.shape[-1],axis=-1)


def add_noise(x,z,snr_db):
    x=np.asarray(x,float);z=np.asarray(z,float)
    centered=x-x.mean(-1,keepdims=True);noise=z-z.mean(-1,keepdims=True)
    power=np.mean(noise**2,-1,keepdims=True)
    factor=np.sqrt(np.mean(centered**2,-1,keepdims=True)/np.maximum(power,1e-30))
    snr=np.asarray(snr_db,float)
    if snr.ndim==1:snr=snr[:,None]
    return x+noise*factor*10**(-snr/20)


def training_views(x,rng,mode):
    if mode not in ['clean','awgn','response']:raise ValueError('Unknown training augmentation')
    clean=zscore_patch(x)
    if mode=='clean':return np.stack([clean,clean,clean])
    views=[clean]
    for _ in range(2):
        # Draw order is identical for the AWGN and response arms. The runner
        # uses a separate per-step NumPy RNG, independent of training sampling.
        gains=np.clip(rng.normal(0,.35,size=(len(x),5)),-.7,.7)
        z=rng.normal(size=x.shape);snr=rng.uniform(-4,12,size=len(x))
        signal=apply_response(x,gains) if mode=='response' else x
        views.append(zscore_patch(add_noise(signal,z,snr).astype(np.float32)))
    return np.stack(views)


def test_panels(x):
    """Six frozen panels, generated once in original complete patch order."""
    x=np.asarray(x,np.float32);length=x.shape[-1]
    panels={'clean':x}
    for snr in [0,-4]:
        z=np.random.default_rng(5102026+abs(snr)).normal(size=x.shape)
        panels[f'AWGN{snr}dB']=add_noise(x,z,snr).astype(np.float32)
    # Colored Gaussian: positive spectral amplitude proportional to f^-1/2,
    # with the first nonzero bin as floor and DC subsequently centered out.
    rng=np.random.default_rng(6601)
    z=rng.normal(size=x.shape);freq=np.fft.rfftfreq(length,1/25600)
    weights=1/np.sqrt(np.maximum(freq,25600/length))
    z=np.fft.irfft(np.fft.rfft(z,axis=-1)*weights,n=length,axis=-1)
    panels['colored-4dB']=add_noise(x,z,-4).astype(np.float32)
    rng=np.random.default_rng(6602)
    z=rng.normal(size=x.shape)*(rng.random(size=x.shape)<.005)
    panels['impulse-4dB']=add_noise(x,z,-4).astype(np.float32)
    rng=np.random.default_rng(6603)
    frequencies=rng.uniform(300,10000,size=(len(x),1));phases=rng.uniform(0,2*np.pi,size=(len(x),1))
    z=np.sin(2*np.pi*frequencies*np.arange(length)[None,:]/25600+phases)
    panels['tone-4dB']=add_noise(x,z,-4).astype(np.float32)
    return panels
