"""Complete, fixed-threshold selective prediction audit without fitting."""
from pathlib import Path
from datetime import datetime,timezone
import json
import pandas as pd
from scripts.v4_external_common import sha

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/v6/analysis'


def main():
    audit=json.loads((OUT/'audit.json').read_text(encoding='utf-8'))
    assert audit.get('passed') is True or audit.get('status') in ['PASS','passed']
    paths=[p for p in (ROOT/'results/v6/robustness').glob('fold*_predictions.csv')]
    assert len(paths)==60
    frames=[]
    for path in paths:
        result=json.loads(path.with_name(path.name.replace('_predictions.csv','.json')).read_text(encoding='utf-8'))
        assert result['predictions_sha256']==sha(path)
        frame=pd.read_csv(path,float_precision='round_trip');frame=frame[frame.role=='test'].copy()
        for name in ['arm','seed','fold']:frame[name]=result[name]
        frames.append(frame)
    allpred=pd.concat(frames,ignore_index=True);rows=[]
    for (arm,seed,panel),f in allpred.groupby(['arm','seed','panel']):
        assert len(f)==f.source_record.nunique()==21
        p=f[['p_H','p_I','p_O']].to_numpy();pred=p.argmax(1);confidence=p.max(1)
        wrong=pred!=f.label.to_numpy();healthy=f.label.to_numpy()==0
        assert healthy.sum()==5
        for threshold in [.5,.7,.9,.95]:
            accepted=confidence>=threshold;count=int(accepted.sum())
            rows.append({'arm':arm,'seed':seed,'panel':panel,'threshold':threshold,'accepted':count,'total':21,
                'coverage':count/21,'accepted_errors':int((accepted&wrong).sum()),'rejected_errors':int((~accepted&wrong).sum()),
                'total_errors':int(wrong.sum()),'selective_accuracy':float((~wrong)[accepted].mean()) if count else None,
                'healthy_accepted':int((healthy&accepted).sum()),'healthy_accepted_errors':int((healthy&accepted&wrong).sum()),
                'unconditional_accepted_healthy_recall':float((healthy&accepted&~wrong).sum()/5)})
    data=pd.DataFrame(rows);assert len(data)==288
    data.to_csv(OUT/'selective_thresholds.csv',index=False)
    report={'status':'PASS','created_utc':datetime.now(timezone.utc).isoformat(),'rows':len(data),'thresholds':[.5,.7,.9,.95],
        'script_sha256':sha(Path(__file__)),'design_sha256':sha(ROOT/'docs/v6/selective_analysis_design.md'),
        'source_analysis_audit_sha256':sha(OUT/'audit.json'),'output_sha256':sha(OUT/'selective_thresholds.csv'),
        'test_fitted_parameters':0,'no_coverage_or_risk_guarantee':True}
    (OUT/'selective_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report),flush=True)


if __name__=='__main__':main()
