"""Frozen source-only four-arm, three-seed vibration consistency experiment."""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import copy
import hashlib
import json
import time
import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F
from scripts.v5.classbd_models import ClassBDWDCNN
from scripts.v5.run_classbd_extension import balanced_batch_indices
from scripts.v5.prepare_neural_patches import zscore_patch
from scripts.v4_external_common import aggregate,metrics,sha
from scripts.v6.consistency import three_view_jsd,training_views,test_panels,add_noise

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'results/v6/robustness'
CONDITIONS=['20Hz','30Hz','40Hz','60Hz','VS_0_40_0Hz']
ARMS={'clean_ce':('clean',0.),'awgn_ce':('awgn',0.),'response_ce':('response',0.),'response_jsd':('response',12.)}
SEEDS=[11,22,33]
STEPS=480


def array_sha(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()


def evaluate(model,x,frame,indices):
    model.eval();probs=[]
    with torch.no_grad():
        for start in range(0,len(indices),48):
            batch=torch.from_numpy(zscore_patch(x[indices[start:start+48]])[:,None,:])
            probs.append(torch.softmax(model(batch)['logits'],dim=1).numpy().astype(np.float64))
    p=np.concatenate(probs);sf=frame.iloc[indices]
    names,y,pr=aggregate(p,sf.class_id.to_numpy(int),sf.source_record.to_numpy())
    # Explicit roundoff-only normalization, fixed before fitting. No estimated
    # temperature, label-dependent adjustment or held-out calibration.
    pr/=pr.sum(1,keepdims=True)
    return metrics(y,pr),names,y,pr


def main(args):
    torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    OUT.mkdir(parents=True,exist_ok=True)
    xp=ROOT/'data/processed/v5/hust_neural_patches.npz';lp=ROOT/'data/processed/v5/hust_neural_patch_lineage.csv'
    frame=pd.read_csv(lp);archive=np.load(xp,allow_pickle=False);x=archive['x']
    assert x.shape==(672,2048) and np.array_equal(archive['patch_id'],frame.patch_id.to_numpy(str))
    frame['domain_id']=frame.condition.map(dict(zip(CONDITIONS,range(5))))
    panels=test_panels(x)
    rng=np.random.default_rng(6606);validation_noise=add_noise(x,rng.normal(size=x.shape),6).astype(np.float32)
    paths=[xp,lp,Path(__file__),ROOT/'scripts/v6/consistency.py',ROOT/'docs/v6/design.md',
        ROOT/'scripts/v5/classbd_models.py',ROOT/'scripts/v5/run_classbd_extension.py',
        ROOT/'scripts/v5/prepare_neural_patches.py',ROOT/'scripts/v4_external_common.py']
    registration={'frozen_utc':datetime.now(timezone.utc).isoformat(),
        'status':'retrospective exploratory extension; v5 test outcomes known; no v6 measured-data fitting before this design',
        'question':'can bounded acquisition perturbations and predictive consistency repair corruption failures beyond a properly budgeted clean backend?',
        'method':'first-party vibration augmentation/JSD adaptation inspired by AugMix ICLR2020 arXiv1912.02781, not original image AugMix or new foundation algorithm',
        'arms':{k:{'augmentation':v[0],'jsd_lambda':v[1]} for k,v in ARMS.items()},
        'seeds':SEEDS,'updates':STEPS,'checkpoint_updates':[120,240,360,480],
        'batch':{'source_patches':18,'views':3,'forward_examples':54,'source_conditions':3,'class_domain_patches':2,
                 'sampling':'record uniform within domain/class then patch uniform, with replacement; common frozen batches across arms'},
        'views':'one clean and two independently perturbed, concatenated in one train forward; clean arm repeats clean three times before independent dropout',
        'supervision':'mean CE over all 3 views; plus fixed lambda*mean_view,batch(sum_class(p_i*(logp_i-logmeanp))) for consistency arm',
        'augmentation_rng':'per step fresh numpy RNG seed 600000+seed*1000+fold*10000+step, independent of batch sampling and arm; responseCE and responseJSD exact input equality',
        'training_perturbations':{'awgn_snr_uniform_db':[-4,12],'log_gain_sd':.35,'log_gain_clip':[-.7,.7],
            'response_anchors_hz':[0,2000,4000,8000,12800],
            'response':'real positive exp(linearly interpolated log gain), phase preserving periodic FFT block proxy; noncausal circular transform, not measured sensor dynamics'},
        'optimizer':{'name':'AdamW','lr':.001,'weight_decay':.0001,'schedule':'cosine480','gradient_clip_norm':10},
        'selection':'mean(clean and fixed+6dBAWGN validation record macroF1),lowermeanNLL,earlierupdate; no model-family or test selection; no refit',
        'validation_panels':['clean','AWGN6dB_seed6606'],
        'test_panels':list(panels),
        'untrained_corruption_families':['colored additive Gaussian -4dB with spectral amplitude f^-1/2, seed6601',
            'independent sparse Gaussian impulses probability0.005, -4dB seed6602',
            'perpatch sine frequency uniform300..10000Hz phaseuniform0..2pi -4dB seed6603'],
        'test_noise_array_sha256':{k:array_sha(v) for k,v in panels.items()},
        'validation_awgn_array_sha256':array_sha(validation_noise),
        'noise_unit':'centered perpatch signal/noise powers; 1 fixed realization per panel; algorithm seeds are not noise-realization replicates',
        'outer_split':'test conditioni,valconditioni+1,other3fit; whole source file disjoint; no measured bearing IDs',
        'primary':'21 unique OOF source-record F1,NLL,Brier,HIO recall, each arm/seed/panel; no physical-population CI',
        'planned_selected_models':60,'planned_checkpoint_options':240,'validation_panel_evaluations':480,
        'limitations':['previously inspected21files; not independent confirmation','synthetic corruptions are not measured industrial noise',
            'bounded response label preservation is an assumption','480updates3views=12x v5 patch presentations; use newcleanarm as concurrent comparator',
            'no convergence proof','no conformal/domain-shift guarantee','newdata and original novelty require separate evidence'],
        'sha256':{str(p.relative_to(ROOT)):sha(p) for p in paths},
        'software':{'torch':torch.__version__,'numpy':np.__version__,'pandas':pd.__version__,'threads':2}}
    dp=OUT/'design.json'
    if dp.exists():
        old=json.loads(dp.read_text(encoding='utf-8'));registration['frozen_utc']=old['frozen_utc'];assert old==registration,'frozen v6 design changed'
    else:dp.write_text(json.dumps(registration,indent=2),encoding='utf-8')
    print('V6 design frozen; no test-based parameter search',flush=True)
    if args.freeze_only:return
    for fold in (args.fold if args.fold else range(5)):
        test=frame.domain_id.eq(fold).to_numpy();val=frame.domain_id.eq((fold+1)%5).to_numpy();train=~(test|val)
        train_indices=np.flatnonzero(train);vi=np.flatnonzero(val);ti=np.flatnonzero(test)
        domains=sorted(frame.loc[train,'domain_id'].unique().tolist())
        for a,b in [(train,val),(train,test),(val,test)]:assert not set(frame.loc[a,'source_record'])&set(frame.loc[b,'source_record'])
        for seed in SEEDS:
            batch_rng=np.random.default_rng(seed+1000*fold)
            batches=[balanced_batch_indices(frame,train_indices,domains,batch_rng) for _ in range(STEPS)]
            split={'fold':fold,'seed':seed,'train_records':sorted(frame.loc[train,'source_record'].unique().tolist()),
                'validation_records':sorted(frame.loc[val,'source_record'].unique().tolist()),'test_records':sorted(frame.loc[test,'source_record'].unique().tolist()),
                'train_domains':domains,'batch_indices':np.stack(batches).tolist()}
            sp=OUT/f'fold{fold}_s{seed}_split.json';sp.write_text(json.dumps(split,indent=2),encoding='utf-8')
            for arm,(augmentation,coefficient) in ARMS.items():
                stem=f'fold{fold}_{arm}_s{seed}';rp=OUT/(stem+'.json')
                if rp.exists():continue
                started=time.perf_counter();torch.manual_seed(seed)
                model=ClassBDWDCNN(variant='baseline')
                optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
                scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer,T_max=STEPS)
                best=(-1.,-np.inf);history=[];view_hashes=[]
                for step,idx in enumerate(batches,1):
                    model.train();optimizer.zero_grad(set_to_none=True)
                    view_rng=np.random.default_rng(600000+seed*1000+fold*10000+step)
                    views=training_views(x[idx],view_rng,augmentation)
                    view_hashes.append(array_sha(views))
                    batch=torch.from_numpy(views.reshape(-1,2048)[:,None,:])
                    target=torch.from_numpy(frame.iloc[idx].class_id.to_numpy(np.int64))
                    logits=model(batch)['logits'].reshape(3,len(idx),3)
                    ce=F.cross_entropy(logits.reshape(-1,3),target.repeat(3));jsd=three_view_jsd(logits)
                    loss=ce+coefficient*jsd
                    if not torch.isfinite(loss):raise RuntimeError(f'nonfinite loss {stem} step{step}')
                    loss.backward();gn=torch.nn.utils.clip_grad_norm_(model.parameters(),10.)
                    if not torch.isfinite(gn):raise RuntimeError('nonfinite gradient')
                    optimizer.step();scheduler.step()
                    if step%120==0:
                        validation={}
                        for panel,signals in [('clean',x),('AWGN6dB',validation_noise)]:
                            met,_,_,_=evaluate(model,signals,frame,vi);validation[panel]=met
                        selection={'macro_f1':float(np.mean([v['macro_f1'] for v in validation.values()])),
                                   'nll':float(np.mean([v['nll'] for v in validation.values()]))}
                        row={'update':step,'train_loss':float(loss.detach()),'train_ce':float(ce.detach()),'train_jsd':float(jsd.detach()),
                            'gradient_norm_before_clip':float(gn),'validation':validation,'selection':selection}
                        history.append(row);key=(selection['macro_f1'],-selection['nll'])
                        if key>best:
                            best=key;selected_state=copy.deepcopy(model.state_dict());chosen_update=step;selected_vm=copy.deepcopy(validation);selected_selection=selection
                        print(f'{stem} update{step}/{STEPS} robustValF1={selection["macro_f1"]:.3f}',flush=True)
                model.load_state_dict(selected_state)
                test_metrics={};rows=[]
                for role,panel,signals,indices in [('validation','clean',x,vi),('validation','AWGN6dB',validation_noise,vi)]+[
                        ('test',panel,signals,ti) for panel,signals in panels.items()]:
                    met,names,labels,p=evaluate(model,signals,frame,indices)
                    if role=='test':test_metrics[panel]=met
                    for name,label,proba in zip(names,labels,p):
                        rows.append({'role':role,'panel':panel,'source_record':name,'label':int(label),
                            'p_H':float(proba[0]),'p_I':float(proba[1]),'p_O':float(proba[2])})
                pp=OUT/(stem+'_predictions.csv');pd.DataFrame(rows).to_csv(pp,index=False)
                mp=OUT/(stem+'.pt');torch.save({'model_state':selected_state,'arm':arm,'seed':seed,'fold':fold,
                    'selected_update':chosen_update,'design_sha256':sha(dp)},mp)
                vh=OUT/(stem+'_view_hashes.json');vh.write_text(json.dumps(view_hashes),encoding='utf-8')
                result={'fold':fold,'seed':seed,'arm':arm,'augmentation':augmentation,'jsd_lambda':coefficient,
                    'selected_update':chosen_update,'validation':selected_vm,'selection':selected_selection,
                    'test':test_metrics,'history':history,'model_parameters':sum(p.numel() for p in model.parameters()),
                    'source_patches_per_update':18,'views_per_update':54,'total_forward_patch_presentations':STEPS*54,
                    'seconds':time.perf_counter()-started,'design_sha256':sha(dp),'split_sha256':sha(sp),
                    'model_sha256':sha(mp),'predictions_sha256':sha(pp),'view_hashes_sha256':sha(vh)}
                rp.write_text(json.dumps(result,indent=2),encoding='utf-8')
                print(f'DONE {stem} cleanF1={test_metrics["clean"]["macro_f1"]:.3f} AWGN-4F1={test_metrics["AWGN-4dB"]["macro_f1"]:.3f}',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fold',type=int,choices=range(5),action='append');parser.add_argument('--freeze-only',action='store_true')
    main(parser.parse_args())
