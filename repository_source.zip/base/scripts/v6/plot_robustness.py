"""Truthful 170-mm v6 figures; requires the completed independent analysis audit.

All 60 fitted models, all six frozen panels and every training seed are kept.
No fitting, data-dependent method selection or confidence interval occurs here.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch
import numpy as np
import pandas as pd
from PIL import Image

from scripts.v4_external_common import metrics, sha
from scripts.v6.consistency import training_views


ROOT = Path(__file__).resolve().parents[2]
RUNS = ROOT / "results/v6/robustness"
AUDIT = ROOT / "results/v6/analysis/audit.json"
OUT = ROOT / "figures/v6"
ARMS = ["clean_ce", "awgn_ce", "response_ce", "response_jsd"]
ARM_LABELS = ["A  Clean CE", "B  AWGN CE", "C  Response + AWGN CE", "D  Same views + JSD"]
SEEDS = [11, 22, 33]
PANELS = ["clean", "AWGN0dB", "AWGN-4dB", "colored-4dB", "impulse-4dB", "tone-4dB"]
PANEL_LABELS = ["Clean", "AWGN 0 dB", "AWGN −4 dB", "Colored −4 dB", "Impulse −4 dB", "Tone −4 dB"]
CONDITIONS = ["20 Hz", "30 Hz", "40 Hz", "60 Hz", "Variable"]
COLORS = ["#0072B2", "#C45A00", "#007A5C", "#805687"]
MARKERS = ["o", "s", "^"]
WIDTH = 170 / 25.4


def array_sha(x):
    return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()


def panel_title(ax, letter, title):
    ax.set_title(f"{letter}  {title}", loc="left", fontsize=8, pad=7, weight="normal")


def clean_axis(ax, axis="x"):
    ax.spines[["top", "right"]].set_visible(False)
    ax.tick_params(length=2.2, width=.65, pad=2.3)
    ax.grid(axis=axis, color="#E4E4E4", linewidth=.5, zorder=0)
    ax.set_axisbelow(True)


def unit_axis(ax, axis="x"):
    getattr(ax, f"set_{axis}lim")(-.025, 1.025)
    getattr(ax, f"set_{axis}ticks")([0, .5, 1])


def load_complete_results():
    """Fail closed on incomplete, altered, duplicated or unaudited evidence."""
    if not AUDIT.exists():
        raise RuntimeError("Complete independent results/v6/analysis/audit.json before plotting")
    audit = json.loads(AUDIT.read_text(encoding="utf-8"))
    if not (audit.get("passed") is True or str(audit.get("status", "")).lower() in {"pass", "passed", "complete"}):
        raise RuntimeError("Analysis audit does not explicitly pass")
    design_path = RUNS / "design.json"
    design = json.loads(design_path.read_text(encoding="utf-8"))
    assert design["planned_selected_models"] == 60
    assert design["test_panels"] == PANELS and design["seeds"] == SEEDS
    assert set(design["arms"]) == set(ARMS)
    for relative, expected in design["sha256"].items():
        assert sha(ROOT / relative) == expected, f"Frozen input changed: {relative}"
    inputs = [AUDIT, design_path]
    records, summaries = [], []
    for fold in range(5):
        for seed in SEEDS:
            response_hashes = []
            for arm in ARMS:
                stem = f"fold{fold}_{arm}_s{seed}"
                rp = RUNS / f"{stem}.json"
                result = json.loads(rp.read_text(encoding="utf-8"))
                assert (result["fold"], result["seed"], result["arm"]) == (fold, seed, arm)
                assert result["design_sha256"] == sha(design_path)
                assert result["total_forward_patch_presentations"] == 25920
                assert [r["update"] for r in result["history"]] == [120, 240, 360, 480]
                best = max(result["history"], key=lambda r: (r["selection"]["macro_f1"], -r["selection"]["nll"], -r["update"]))
                assert result["selected_update"] == best["update"]
                for row in result["history"]:
                    expected_f1 = np.mean([row["validation"][p]["macro_f1"] for p in ["clean", "AWGN6dB"]])
                    expected_nll = np.mean([row["validation"][p]["nll"] for p in ["clean", "AWGN6dB"]])
                    assert abs(expected_f1 - row["selection"]["macro_f1"]) < 1e-12
                    assert abs(expected_nll - row["selection"]["nll"]) < 1e-12
                pp = RUNS / f"{stem}_predictions.csv"
                mp = RUNS / f"{stem}.pt"
                vp = RUNS / f"{stem}_view_hashes.json"
                sp = RUNS / f"fold{fold}_s{seed}_split.json"
                for path, key in [(pp, "predictions_sha256"), (mp, "model_sha256"), (vp, "view_hashes_sha256"), (sp, "split_sha256")]:
                    assert sha(path) == result[key], f"Result asset changed: {path}"
                hashes = json.loads(vp.read_text(encoding="utf-8"))
                assert len(hashes) == 480
                if arm in ["response_ce", "response_jsd"]:
                    response_hashes.append(hashes)
                pred = pd.read_csv(pp)
                subset = pred[pred.role.eq("test")].copy()
                assert set(subset.panel) == set(PANELS)
                assert not subset.duplicated(["panel", "source_record"]).any()
                for challenge, group in subset.groupby("panel"):
                    p = group[["p_H", "p_I", "p_O"]].to_numpy(float)
                    assert np.isfinite(p).all() and (p >= 0).all() and (p <= 1).all()
                    np.testing.assert_allclose(p.sum(1), 1, atol=1e-12, rtol=0)
                    met = metrics(group.label.to_numpy(int), p)
                    for key in ["macro_f1", "nll", "multiclass_brier", "recall_H", "recall_I", "recall_O"]:
                        assert abs(met[key] - result["test"][challenge][key]) < 1e-10
                    summaries.append({"fold": fold, "seed": seed, "arm": arm, "panel": challenge, **met})
                subset["fold"] = fold
                subset["seed"] = seed
                subset["arm"] = arm
                records.append(subset)
                inputs.extend([rp, pp, vp, sp])
            assert response_hashes[0] == response_hashes[1], f"Response inputs differ: fold{fold}, seed{seed}"
    predictions = pd.concat(records, ignore_index=True)
    assert len(predictions) == 21 * 6 * 4 * 3
    assert not predictions.duplicated(["arm", "seed", "panel", "source_record"]).any()
    pooled = []
    for (arm, seed, challenge), group in predictions.groupby(["arm", "seed", "panel"]):
        assert len(group) == 21 and group.source_record.nunique() == 21
        p = group[["p_H", "p_I", "p_O"]].to_numpy(float)
        pooled.append({"arm": arm, "seed": seed, "panel": challenge, **metrics(group.label.to_numpy(int), p)})
    assert len(pooled) == 72
    return design, predictions, pd.DataFrame(pooled), pd.DataFrame(summaries), sorted(set(inputs))


def save(fig, stem, source, caption, alt, inputs, transformations, estimator):
    OUT.mkdir(parents=True, exist_ok=True)
    data_dir = OUT / "source_data"
    data_dir.mkdir(exist_ok=True)
    source_path = data_dir / f"{stem}.csv"
    source.to_csv(source_path, index=False)
    caption_path = OUT / f"{stem}_caption.md"
    caption_path.write_text(caption.strip() + "\n\nAlt text: " + alt + "\n", encoding="utf-8")
    files = []
    for extension in ["pdf", "svg", "png"]:
        path = OUT / f"{stem}.{extension}"
        fig.savefig(path, dpi=300, facecolor="white", transparent=False, bbox_inches=None)
        files.append(path)
    with Image.open(OUT / f"{stem}.png") as im:
        raster = {"pixels": list(im.size), "mode": im.mode, "dpi": list(im.info.get("dpi", ()))}
        assert abs(im.width - WIDTH * 300) <= 1
        assert im.info.get("dpi", (0,))[0] >= 299
    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "script_sha256": sha(Path(__file__)), "intended_width_mm": 170,
        "intended_height_mm": float(fig.get_size_inches()[1] * 25.4),
        "destination": "Provisional general manuscript artwork; specific journal rules require final verification",
        "estimator": estimator,
        "unit": "Source recording proxy; physical-bearing identities unknown. Patch traces are illustrative repeated measurements.",
        "uncertainty": "All three algorithm seeds shown. No confidence intervals, population inference or noise-realization replication.",
        "completeness": "All 60 models, six panels, four arms and three seeds validated before any plotting",
        "transformations": transformations,
        "inputs": {str(p.relative_to(ROOT)): sha(p) for p in sorted(set(inputs))},
        "source_data": {"path": str(source_path.relative_to(ROOT)), "sha256": sha(source_path), "rows": len(source)},
        "caption": {"path": str(caption_path.relative_to(ROOT)), "sha256": sha(caption_path)},
        "alt_text": alt,
        "outputs": {str(p.relative_to(ROOT)): {"sha256": sha(p), "bytes": p.stat().st_size} for p in files},
        "raster_metadata": raster,
        "software": {"matplotlib": matplotlib.__version__, "numpy": np.__version__, "pandas": pd.__version__},
        "fonts": "Arial, PDF Type42; SVG editable text requires installed font",
    }
    (OUT / f"{stem}_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    plt.close(fig)
    return manifest


def design_figure(design):
    frame_path = ROOT / "data/processed/v5/hust_neural_patch_lineage.csv"
    signal_path = ROOT / "data/processed/v5/hust_neural_patches.npz"
    frame = pd.read_csv(frame_path)
    x = np.load(signal_path, allow_pickle=False)["x"]
    assert x.shape == (672, 2048)
    # Fold0 holds20Hz test,30Hz validation. Choose by source ID/sample boundary,
    # not a waveform/result visual preference; the example is never a test row.
    eligible = frame[~frame.condition.isin(["20Hz", "30Hz"])].copy()
    example = eligible.sort_values(["source_record", "start_sample", "patch_id"]).iloc[0]
    index = int(example.name)
    views = training_views(x[index:index+1], np.random.default_rng(66017), "response")[:, 0]
    gains = np.clip(np.random.default_rng(66016).normal(0, .35, size=(10, 5)), -.7, .7)
    freq = np.fft.rfftfreq(2048, 1 / 25600)
    anchors = np.array([0, 2000, 4000, 8000, 12800])
    response = np.exp(np.stack([np.interp(freq, anchors, row) for row in gains]))
    fig = plt.figure(figsize=(WIDTH, 154 / 25.4))
    ax = fig.add_axes([.055, .60, .91, .345])
    ax.set_axis_off()
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    panel_title(ax, "a", "Controlled three-view study")
    box = FancyBboxPatch((.015, .30), .21, .40, boxstyle="round,pad=0.012,rounding_size=0.015", fc="#F1F1F1", ec="#777777", lw=.7)
    ax.add_patch(box)
    ax.text(.12, .50, "Same source patches\n18 per update\nNative 2048 points\nNo target fitting", ha="center", va="center", fontsize=7.2, linespacing=1.5)
    descriptions = ["3 × clean; mean CE", "Clean + 2 × AWGN; mean CE", "Clean + 2 × response/AWGN; mean CE", "Identical C views; mean CE + 12 JSD"]
    source = []
    for ai, (label, detail, color) in enumerate(zip(ARM_LABELS, descriptions, COLORS)):
        y = .89 - ai * .245
        ax.add_patch(FancyBboxPatch((.305, y - .085), .68, .17, boxstyle="round,pad=0.007,rounding_size=0.012", fc="white", ec=color, lw=.95))
        ax.text(.325, y + .027, label, fontsize=7.4, weight="bold", color=color, va="center")
        ax.text(.325, y - .035, detail, fontsize=7, va="center")
        ax.add_patch(FancyArrowPatch((.235, .50), (.30, y), arrowstyle="-|>", mutation_scale=6, lw=.65, color="#777777"))
        source.append({"kind": "arm_design", "arm": ARMS[ai], "description": detail, "source_patch": example.patch_id, "source_record": example.source_record})
    ax.text(.5, -.12, "Same 66,083-parameter backend · 480 updates · 3 seeds · 5 whole-condition rotations", ha="center", fontsize=7)
    response_ax = fig.add_axes([.10, .14, .36, .335])
    for i, curve in enumerate(response):
        response_ax.plot(freq / 1000, curve, color=COLORS[i % 4], linestyle=["-", "--", "-.", ":"][i % 4], linewidth=.75, alpha=.85)
        for hz, value in zip(freq, curve):
            source.append({"kind": "response_example", "curve": i, "frequency_hz": hz, "multiplier": value, "example_rng_seed": 66016})
        for anchor, gain in zip(anchors, gains[i]):
            source.append({"kind": "response_anchor", "curve": i, "frequency_hz": anchor, "log_gain": gain, "example_rng_seed": 66016})
    response_ax.axhline(1, color="#333333", linewidth=.7)
    response_ax.axhline(np.exp(-.7), color="#777777", linewidth=.6, linestyle=":")
    response_ax.axhline(np.exp(.7), color="#777777", linewidth=.6, linestyle=":")
    response_ax.set(xlim=(0, 12.8), ylim=(0, 2.15), xlabel="Frequency (kHz)", ylabel="Amplitude multiplier")
    response_ax.set_xticks([0, 2, 4, 8, 12.8])
    panel_title(response_ax, "b", "Ten fixed response draws")
    clean_axis(response_ax, "y")
    limit = max(3, float(np.ceil(np.abs(views).max())))
    wave_axes = []
    t = np.arange(2048) / 25600 * 1000
    for vi, label in enumerate(["Clean", "View 1", "View 2"]):
        wave_ax = fig.add_axes([.62, .36 - vi * .11, .34, .09])
        wave_ax.plot(t, views[vi], color=COLORS[vi], linewidth=.45)
        wave_ax.set(xlim=(0, 80), ylim=(-limit, limit), ylabel=label)
        wave_ax.set_yticks([-limit, 0, limit])
        if vi < 2:
            wave_ax.set_xticklabels([])
        else:
            wave_ax.set_xlabel("Time (ms)")
        clean_axis(wave_ax, "y")
        wave_axes.append(wave_ax)
        for ms, value in zip(t, views[vi]):
            source.append({"kind": "waveform_example", "view": label, "time_ms": ms, "zscored_value": value,
                           "source_patch": example.patch_id, "source_record": example.source_record,
                           "source_condition": example.condition, "patch_index": index, "example_rng_seed": 66017})
    panel_title(wave_axes[0], "c", "One source patch, three views")
    fig.text(.5, .077, "Trace amplitude: individual-patch z-score units; all three traces share the same vertical limits.", ha="center", fontsize=6.5)
    fig.text(.5, .048, "Response curves and augmented traces are synthetic proxies, not measured transfer functions.", ha="center", fontsize=6.8)
    fig.text(.5, .024, "Example selected by source ID and sample order from fold-0 training data; no test-based waveform choice.", ha="center", fontsize=6.4)
    caption = ("Figure 16. A controlled source-only sensor-perturbation consistency study. (a) All four arms use the same architecture, initialization per seed, record/class/condition-balanced training batches, three-view joint forward count and 480-update budget. A repeats each clean patch three times; B adds two independently generated AWGN views; C adds bounded smooth positive amplitude-response variation before AWGN; D receives exactly C's views and adds Jensen–Shannon divergence (JSD), with fixed multiplier 12, to the mean supervised cross-entropy (CE) over all three views. This is an engineering adaptation, not original image AugMix. (b) Ten deterministically seeded example response curves use five fixed frequency anchors, normal log-gains with SD 0.35 clipped to [−0.7,0.7], linear interpolation in log-gain and exponentiation. Horizontal dotted lines mark allowed multiplier bounds; the full axis includes zero. The finite-block FFT transform retains phase but is circular and noncausal, so the curves are synthetic acquisition proxies rather than identified mechanical transfer functions. (c) One native source-training patch and its two augmented, individually z-scored views; all traces have identical vertical limits in z-score units. The patch is the lexicographically first source record and earliest sample among fold-0 training conditions, chosen without inspecting outcomes. Illustrative draws use seeds 66016/66017 and are not selected optimizer batches. Four patches per second yield 32 repeated patch measurements per file; no extra independent specimens are created.")
    alt = "Four matched training arms distinguish clean supervision, Gaussian augmentation, smooth-response augmentation and additional predictive consistency. Ten bounded synthetic response curves and the clean plus two perturbed versions of a deterministically chosen training patch illustrate the input mechanism without using test records."
    return save(fig, "fig16_sensor_consistency_design", pd.DataFrame(source), caption, alt,
                [AUDIT, RUNS / "design.json", frame_path, signal_path, ROOT / "scripts/v6/consistency.py"],
                ["Four-arm schematic mirrors frozen design", "Ten response curves are seeded examples, not fitted estimates",
                 "One source-only patch chosen by source identifier then start_sample", "Per-patch z-score; no filtering/resampling; identical trace limits"],
                "Method diagram and deterministic synthetic illustrations; no effect-size estimator")


def corruption_figure(pooled, inputs):
    metrics_to_plot = [("macro_f1", "Macro-F1"), ("recall_H", "Healthy recall"), ("nll", "NLL (nats)")]
    fig, axes = plt.subplots(6, 3, figsize=(WIDTH, 205 / 25.4))
    fig.subplots_adjust(left=.225, right=.975, top=.91, bottom=.095, hspace=.85, wspace=.38)
    source = []
    nll_upper = max(1, float(np.ceil(pooled.nll.max() * 1.08 * 2) / 2))
    for pi, challenge in enumerate(PANELS):
        for mi, (metric, title) in enumerate(metrics_to_plot):
            ax = axes[pi, mi]
            if pi >= 3:
                ax.set_facecolor("#F7F7F7")
            for ai, arm in enumerate(ARMS):
                data = pooled[pooled.arm.eq(arm) & pooled.panel.eq(challenge)].sort_values("seed")
                assert data.seed.tolist() == SEEDS
                for si, row in enumerate(data.itertuples(index=False)):
                    value = float(getattr(row, metric))
                    offset = [-.16, 0, .16][si]
                    ax.plot(value, ai + offset, color=COLORS[ai], marker=MARKERS[si], linestyle="none", markersize=3.6,
                            markerfacecolor="white", markeredgewidth=.8, zorder=3)
                    source.append({"kind": "pooled_seed_metric", "figure_panel": chr(97 + pi * 3 + mi), "metric": metric,
                                   "challenge": challenge, "arm": arm, "seed": int(row.seed), "value": value,
                                   "display_y_offset": offset, "n_records": 21, "n_healthy_records": 5})
            ax.set_ylim(3.5, -.5)
            ax.set_yticks(range(4), ["A", "B", "C", "D"] if mi == 0 else [""] * 4)
            ax.tick_params(axis="y", length=0)
            if metric != "nll":
                unit_axis(ax)
            else:
                ax.set_xlim(0, nll_upper)
                ax.set_xticks(np.linspace(0, nll_upper, 3))
            label = f"{PANEL_LABELS[pi]} · {title}" if mi == 0 else title
            panel_title(ax, chr(97 + pi * 3 + mi), label)
            clean_axis(ax)
    handles = [Line2D([], [], color=c, linewidth=1.3, label=label) for c, label in zip(COLORS, ARM_LABELS)]
    fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(.52, .992), frameon=False, ncol=2, fontsize=7.1,
               columnspacing=1.2, handlelength=1.6)
    handles = [Line2D([], [], color="#333333", marker=m, markerfacecolor="white", linestyle="none", markersize=4,
                      label=f"Seed {s}") for m, s in zip(MARKERS, SEEDS)]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5, .047), frameon=False, ncol=3, fontsize=7,
               columnspacing=1.8, handletextpad=.4)
    fig.text(.5, .030, "Gray rows: corruption families excluded from training and validation. All seed points retained; no CIs.", ha="center", fontsize=6.5)
    fig.text(.5, .012, "21 held-out source records per point · healthy recall uses five records · one fixed noise realization per panel", ha="center", fontsize=6.5)
    caption = ("Figure 17. Complete recording-level corruption evaluation. Rows show clean input, the two historical AWGN challenges and three corruption families excluded from training and validation (colored Gaussian noise, sparse impulses and a sinusoidal tone, each at −4 dB; gray backgrounds). Columns show pooled out-of-fold macro-F1, healthy recall and negative log likelihood (NLL, nats) for all four frozen training arms. Each circle, square and triangle denotes a separate algorithm seed (11, 22 or 33); small vertical offsets only prevent overplotting. All points pool the same 21 source recordings, each held out once in five condition rotations, after averaging patch probabilities per recording. F1 and recall use a common full [0,1] scale, and every NLL panel uses the same zero-based scale. There are no confidence intervals: three seeds do not increase the number of independent recordings, and physical-bearing IDs are unknown. Healthy recall uses five source files, one per condition. Each corruption has one label-blind fixed realization shared across all models, not a measured industrial-noise collection. Higher F1/recall and lower NLL are preferable. All arms and failures are retained; no best seed or test-selected method is emphasized.")
    alt = "Eighteen aligned point plots retain all four training arms and all three seeds on F1, healthy recall and negative log likelihood under all six frozen test panels. The colored, impulse and tone rows are marked as excluded corruption families. Full metric scales and all negative outcomes are retained."
    return save(fig, "fig17_corruption_robustness", pd.DataFrame(source), caption, alt, inputs,
                ["Recompute metrics from all saved test record probabilities", "Pool exactly21 unique OOF records per arm/seed/panel",
                 "Show all seeds with fixed offsets; no intervals or favourable selection", "NLL uses common zero-based range over all rows"],
                "Pooled source-record macro-F1, healthy recall and mean negative log likelihood; each arm/seed/panel separately")


def matrix(ax, table, labels, title, letter, value_name):
    values = table[value_name]
    image = ax.imshow(values, vmin=0, vmax=1, cmap="cividis", interpolation="nearest", aspect="auto")
    ax.set_xticks(range(5), CONDITIONS, fontsize=6.7)
    ax.set_yticks(range(12), labels, fontsize=6.7)
    ax.tick_params(length=0, pad=4)
    for (row, col), value in np.ndenumerate(values):
        numerator = int(table["numerator"][row, col])
        denominator = int(table["denominator"][row, col])
        ax.text(col, row, f"{numerator}/{denominator}", ha="center", va="center", fontsize=6.6,
                color="white" if value < .48 else "#111111")
    for boundary in [2.5, 5.5, 8.5]:
        ax.axhline(boundary, color="white", linewidth=1.8)
    panel_title(ax, letter, title)
    return image


def gains_figure(pooled, predictions, inputs):
    pairs = [("awgn_ce", "clean_ce", "B − A: AWGN"),
             ("response_ce", "awgn_ce", "C − B: response"),
             ("response_jsd", "response_ce", "D − C: JSD")]
    fig = plt.figure(figsize=(WIDTH, 202 / 25.4))
    grid = fig.add_gridspec(1, 3, left=.21, right=.975, top=.91, bottom=.62, wspace=.45)
    source = []
    for ci, (candidate, reference, title) in enumerate(pairs):
        ax = fig.add_subplot(grid[0, ci])
        ax.axvline(0, color="#555555", linewidth=.8)
        for pi, challenge in enumerate(PANELS):
            for si, seed in enumerate(SEEDS):
                a = pooled[pooled.arm.eq(candidate) & pooled.seed.eq(seed) & pooled.panel.eq(challenge)].iloc[0]
                b = pooled[pooled.arm.eq(reference) & pooled.seed.eq(seed) & pooled.panel.eq(challenge)].iloc[0]
                delta = float(a.macro_f1 - b.macro_f1)
                ax.plot(delta, pi + [-.15, 0, .15][si], color=COLORS[ci + 1], marker=MARKERS[si], markersize=3.8,
                        markerfacecolor="white", markeredgewidth=.8, linestyle="none", zorder=3)
                for metric in ["macro_f1", "recall_H", "recall_I", "recall_O", "nll", "multiclass_brier"]:
                    source.append({"kind": "paired_seed_difference", "figure_panel": chr(97 + ci),
                                   "candidate": candidate, "reference": reference, "seed": seed, "challenge": challenge,
                                   "metric": metric, "candidate_value": float(a[metric]), "reference_value": float(b[metric]),
                                   "value": float(a[metric] - b[metric]), "n_records_per_arm": 21,
                                   "plotted": metric == "macro_f1"})
        ax.set(xlim=(-1.05, 1.05), ylim=(5.5, -.5), xlabel="Paired Δ macro-F1")
        ax.set_xticks([-1, 0, 1])
        ax.set_yticks(range(6), PANEL_LABELS if ci == 0 else [""] * 6)
        ax.tick_params(axis="y", length=0)
        panel_title(ax, chr(97 + ci), title)
        clean_axis(ax)
    labels = [f"{chr(65 + ai)} / {seed}" for ai in range(4) for seed in SEEDS]
    tables = []
    for challenge, label_id, metric_name in [("clean", 1, "Clean inner-fault recall"), ("AWGN-4dB", 0, "AWGN −4 dB healthy recall")]:
        values, numerators, denominators = [], [], []
        for arm in ARMS:
            for seed in SEEDS:
                row_values, row_num, row_den = [], [], []
                for fold in range(5):
                    group = predictions[predictions.arm.eq(arm) & predictions.seed.eq(seed) & predictions.panel.eq(challenge)
                                        & predictions.fold.eq(fold) & predictions.label.eq(label_id)]
                    assert len(group) in [1, 2]
                    predicted = group[["p_H", "p_I", "p_O"]].to_numpy(float).argmax(1)
                    correct = int((predicted == label_id).sum())
                    n = len(group)
                    row_values.append(correct / n)
                    row_num.append(correct)
                    row_den.append(n)
                    source.append({"kind": "condition_class_recall", "figure_panel": "d" if label_id == 1 else "e", "arm": arm,
                                   "seed": seed, "challenge": challenge, "fold": fold, "condition": CONDITIONS[fold],
                                   "metric": "recall_I" if label_id == 1 else "recall_H", "value": correct / n,
                                   "numerator_correct": correct, "denominator_records": n, "plotted": True})
                    for record, yhat in zip(group.source_record, predicted):
                        source.append({"kind": "condition_class_prediction", "arm": arm, "seed": seed, "challenge": challenge,
                                       "fold": fold, "source_record": record, "true_class": label_id,
                                       "predicted_class": int(yhat), "plotted": False})
                values.append(row_values)
                numerators.append(row_num)
                denominators.append(row_den)
        tables.append({"value": np.asarray(values), "numerator": np.asarray(numerators), "denominator": np.asarray(denominators)})
    left_ax = fig.add_axes([.12, .16, .345, .35])
    right_ax = fig.add_axes([.59, .16, .345, .35])
    matrix(left_ax, tables[0], labels, "Clean inner-fault recall", "d", "value")
    image = matrix(right_ax, tables[1], labels, "AWGN −4 dB healthy recall", "e", "value")
    cbax = fig.add_axes([.95, .16, .015, .35])
    colorbar = fig.colorbar(image, cax=cbax, ticks=[0, .5, 1])
    colorbar.ax.set_title("Recall", fontsize=6.5, pad=7)
    colorbar.ax.tick_params(labelsize=6.5, length=2)
    fig.text(.5, .545, "Matrices retain every arm / seed; entries are correct / available source recordings.", ha="center", fontsize=6.7)
    handles = [Line2D([], [], color="#333333", marker=m, markerfacecolor="white", markersize=4, linestyle="none",
                      label=f"Seed {s}") for m, s in zip(MARKERS, SEEDS)]
    fig.legend(handles=handles, frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(.5, .985), fontsize=7,
               columnspacing=1.7, handletextpad=.4)
    fig.text(.5, .09, "A clean CE · B AWGN CE · C response + AWGN CE · D same views + JSD", ha="center", fontsize=6.9)
    fig.text(.5, .055, "ΔF1 > 0 favors the added component. Seeds are paired algorithm runs; no population CIs.", ha="center", fontsize=6.7)
    fig.text(.5, .023, "Each condition has one healthy file; physical-bearing identities are unknown. All failures remain visible.", ha="center", fontsize=6.5)
    caption = ("Figure 18. Incremental benefit and retained class–condition failures. (a–c) Pooled macro-F1 differences are evaluated only for the three declared component comparisons: ordinary AWGN augmentation versus matched clean training (B−A), adding smooth amplitude-response variation (C−B), and adding JSD on exactly the same views (D−C). All six test panels and all three paired algorithm seeds are retained on a common [−1,1] difference scale; the source-data CSV also records paired NLL, multiclass Brier and all class-recall differences. Symbols are offset only for visibility and no statistical interval is implied. (d) Clean inner-fault recall and (e) −4-dB AWGN healthy recall are shown by all five held-out conditions. Every arm and each seed has its own row, avoiding averaging over isolated class failures. Cells report correct source recordings divided by available class recordings; each condition has one healthy record and one or two inner-fault records. Thus 0/1 and 1/1 are individual-file outcomes, not precise population estimates. The 60-Hz inner-fault column remains visible regardless of whether the error persists or changes. All files were already observed in v5; new computational models do not establish independent physical-bearing replication or state-of-the-art superiority.")
    alt = "Three paired-difference dot plots show each planned component's F1 change for all six panels and every seed. Two full arm-by-seed matrices expose clean inner-fault recall, including 60 Hz, and severe Gaussian-noise healthy recall across all five conditions, with exact correct/available recording counts in every cell."
    return save(fig, "fig18_incremental_gains", pd.DataFrame(source), caption, alt, inputs,
                ["Only three predeclared contrasts; match each seed and panel", "Paired differences retain negative outcomes",
                 "Class-condition recall recomputed directly from all record probabilities", "No seed averaging in matrices; annotate exact class support"],
                "Paired pooled record macro-F1 differences and per-condition correct/available class-record proportions")


def main():
    plt.rcParams.update({"font.family": "Arial", "font.size": 7.1, "axes.labelsize": 7.1,
                         "xtick.labelsize": 6.7, "ytick.labelsize": 6.7,
                         "axes.linewidth": .65, "pdf.fonttype": 42, "ps.fonttype": 42,
                         "svg.fonttype": "none", "savefig.facecolor": "white"})
    design, predictions, pooled, _, inputs = load_complete_results()
    manifests = [design_figure(design), corruption_figure(pooled, inputs), gains_figure(pooled, predictions, inputs)]
    print(json.dumps({"figures": len(manifests), "models": 60, "pooled_arm_seed_panels": len(pooled),
                      "source_rows": {Path(m["source_data"]["path"]).stem: m["source_data"]["rows"] for m in manifests}}, indent=2))


if __name__ == "__main__":
    main()
