"""Fail-closed V6 result audit and independent selected-weight inference replay.

This module does not import the frozen experiment runner, corruption functions,
normalizer, aggregator or metric helper. The frozen architecture is imported only
to load the selected weights. It never fits models, selects a family using test
outcomes, or treats patches as independent physical replicates.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import time

import numpy as np
import pandas as pd
import torch

from scripts.v5.classbd_models import ClassBDWDCNN


ROOT = Path(__file__).resolve().parents[2]
RUN = ROOT / 'results/v6/robustness'
OUT = ROOT / 'results/v6/analysis'
CONDITIONS = ['20Hz', '30Hz', '40Hz', '60Hz', 'VS_0_40_0Hz']
ARMS = ['clean_ce', 'awgn_ce', 'response_ce', 'response_jsd']
SEEDS = [11, 22, 33]
PANELS = ['clean', 'AWGN0dB', 'AWGN-4dB', 'colored-4dB', 'impulse-4dB', 'tone-4dB']
METRIC_KEYS = ['macro_f1', 'balanced_accuracy', 'nll', 'multiclass_brier',
               'recall_H', 'recall_I', 'recall_O', 'n_records']
TOLERANCE = 1e-6


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def array_sha(array):
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write_json(path, content):
    Path(path).write_text(json.dumps(content, indent=2, allow_nan=False), encoding='utf-8')


def normalized_patch(x):
    # Float32 arithmetic is part of the frozen input specification. This is an
    # independent implementation of within-patch population-standardization.
    values = np.asarray(x, dtype=np.float32)
    deviation = values - values.mean(axis=1, keepdims=True)
    population_sd = np.sqrt((deviation * deviation).mean(axis=1, keepdims=True))
    return deviation / np.maximum(population_sd, np.float32(1e-8))


def noise_scaled_to_snr(x, noise, snr):
    values = np.asarray(x, dtype=np.float64)
    disturbance = np.asarray(noise, dtype=np.float64)
    centered_signal = values - values.mean(axis=1, keepdims=True)
    centered_noise = disturbance - disturbance.mean(axis=1, keepdims=True)
    noise_power = (centered_noise ** 2).mean(axis=1, keepdims=True)
    ratio = np.sqrt((centered_signal ** 2).mean(axis=1, keepdims=True)
                    / np.maximum(noise_power, 1e-30))
    target_snr = np.asarray(snr, dtype=np.float64)
    if target_snr.ndim == 1:
        target_snr = target_snr[:, None]
    return values + centered_noise * ratio * 10 ** (-target_snr / 20)


def independent_panels(x):
    """Generate complete-order fixed realizations without importing training code."""
    x = np.asarray(x, dtype=np.float32)
    width = x.shape[1]
    panels = {'clean': x}
    for snr in (0, -4):
        rng = np.random.default_rng(5102026 + abs(snr))
        panels[f'AWGN{snr}dB'] = noise_scaled_to_snr(x, rng.normal(size=x.shape), snr).astype(np.float32)
    rng = np.random.default_rng(6601)
    white = rng.normal(size=x.shape)
    frequencies = np.fft.rfftfreq(width, 1 / 25600)
    weights = 1 / np.sqrt(np.maximum(frequencies, 25600 / width))
    colored = np.fft.irfft(np.fft.rfft(white, axis=-1) * weights, n=width, axis=-1)
    panels['colored-4dB'] = noise_scaled_to_snr(x, colored, -4).astype(np.float32)
    rng = np.random.default_rng(6602)
    impulses = rng.normal(size=x.shape) * (rng.random(size=x.shape) < .005)
    panels['impulse-4dB'] = noise_scaled_to_snr(x, impulses, -4).astype(np.float32)
    rng = np.random.default_rng(6603)
    frequencies = rng.uniform(300, 10000, size=(len(x), 1))
    phases = rng.uniform(0, 2 * np.pi, size=(len(x), 1))
    tone = np.sin(2 * np.pi * frequencies * np.arange(width)[None, :] / 25600 + phases)
    panels['tone-4dB'] = noise_scaled_to_snr(x, tone, -4).astype(np.float32)
    rng = np.random.default_rng(6606)
    validation = noise_scaled_to_snr(x, rng.normal(size=x.shape), 6).astype(np.float32)
    return panels, validation


def response_view(x, gains):
    """Independent positive zero-phase finite-block response implementation."""
    knots = np.asarray([0, 2000, 4000, 8000, 12800], dtype=float) / 12800
    grid = np.linspace(0, 1, x.shape[1] // 2 + 1)
    amplitude = np.exp(np.stack([np.interp(grid, knots, row) for row in gains]))
    return np.fft.irfft(np.fft.rfft(np.asarray(x, float), axis=-1) * amplitude,
                        n=x.shape[1], axis=-1)


def independent_views(x, fold, seed, step, mode):
    clean = normalized_patch(x)
    if mode == 'clean':
        return np.stack([clean, clean, clean])
    rng = np.random.default_rng(600000 + seed * 1000 + fold * 10000 + step)
    views = [clean]
    for _ in range(2):
        gains = np.clip(rng.normal(0, .35, size=(len(x), 5)), -.7, .7)
        white = rng.normal(size=x.shape)
        snr = rng.uniform(-4, 12, size=len(x))
        values = response_view(x, gains) if mode == 'response' else x
        noisy = noise_scaled_to_snr(values, white, snr).astype(np.float32)
        views.append(normalized_patch(noisy))
    return np.stack(views)


def scores(labels, probability):
    """Independent confusion-matrix F1, proper scoring rules and class recall."""
    labels = np.asarray(labels, dtype=int)
    probability = np.asarray(probability, dtype=np.float64)
    require(probability.shape == (len(labels), 3), 'invalid probability matrix')
    require(np.isfinite(probability).all() and (probability >= 0).all()
            and (probability <= 1).all(), 'nonfinite or out-of-range probabilities')
    require(np.max(np.abs(probability.sum(axis=1) - 1)) < 1e-10, 'rows are not normalized')
    predictions = probability.argmax(axis=1)
    matrix = np.zeros((3, 3), dtype=int)
    np.add.at(matrix, (labels, predictions), 1)
    actual = matrix.sum(axis=1)
    predicted = matrix.sum(axis=0)
    denominator = actual + predicted
    f1 = np.divide(2 * np.diag(matrix), denominator, out=np.zeros(3), where=denominator > 0)
    recall = np.divide(np.diag(matrix), actual, out=np.full(3, np.nan), where=actual > 0)
    clipped = np.clip(probability, np.finfo(np.float64).eps, 1 - np.finfo(np.float64).eps)
    # sklearn's float64 log-loss normalizes clipped rows before scoring.
    clipped = clipped / clipped.sum(axis=1, keepdims=True)
    result = {'macro_f1': float(f1.mean()), 'balanced_accuracy': float(np.nanmean(recall)),
              'nll': float(-np.log(clipped[np.arange(len(labels)), labels]).mean()),
              'multiclass_brier': float(np.square(probability - np.eye(3)[labels]).sum(axis=1).mean()),
              'confusion_matrix': matrix.tolist(), 'n_records': len(labels)}
    for k, label in enumerate('HIO'):
        result[f'recall_{label}'] = float(recall[k]) if actual[k] else None
    return result


def compare_metrics(actual, stored, description):
    require(actual['confusion_matrix'] == stored['confusion_matrix'], f'confusion mismatch: {description}')
    maximum = 0.
    for key in METRIC_KEYS:
        a, b = actual[key], stored[key]
        if a is None or b is None:
            require(a is b, f'missing metric mismatch: {description}/{key}')
        else:
            delta = abs(float(a) - float(b))
            require(delta <= TOLERANCE, f'metric mismatch {description}/{key}: {delta}')
            maximum = max(maximum, delta)
    return maximum


def history_confusion_check(entry, expected_n, name):
    cm = np.asarray(entry['confusion_matrix'], dtype=int)
    require(cm.shape == (3, 3) and (cm >= 0).all() and cm.sum() == expected_n,
            f'history confusion/count invalid {name}')
    require(entry['n_records'] == expected_n, f'history record count {name}')
    actual, predicted = cm.sum(1), cm.sum(0)
    f1 = np.divide(2 * cm.diagonal(), actual + predicted, out=np.zeros(3), where=actual + predicted > 0)
    require(abs(f1.mean() - entry['macro_f1']) < TOLERANCE, f'history F1 mismatch {name}')
    recall = np.divide(cm.diagonal(), actual, out=np.zeros(3), where=actual > 0)
    require(abs(recall[actual > 0].mean() - entry['balanced_accuracy']) < TOLERANCE,
            f'history balanced accuracy mismatch {name}')
    for i, label in enumerate('HIO'):
        require(abs(recall[i] - entry[f'recall_{label}']) < TOLERANCE, f'history recall mismatch {name}')
    require(np.isfinite(entry['nll']) and entry['nll'] >= 0, f'history NLL invalid {name}')
    require(np.isfinite(entry['multiclass_brier']) and 0 <= entry['multiclass_brier'] <= 2,
            f'history Brier invalid {name}')


def expected_batches(frame, train_indices, domains, fold, seed):
    rng = np.random.default_rng(seed + 1000 * fold)
    # Cache record membership before sampling. This changes no RNG draw order.
    cells = {}
    train_frame = frame.iloc[train_indices]
    for domain in domains:
        for label in range(3):
            cell = train_frame[(train_frame.domain_id == domain) & (train_frame.class_id == label)]
            records = sorted(cell.source_record.unique())
            require(len(records) > 0, 'missing source condition/class cell')
            cells[domain, label] = (records, {r: cell.index[cell.source_record.eq(r)].to_numpy() for r in records})
    for _ in range(480):
        indices = []
        for domain in domains:
            for label in range(3):
                records, members = cells[domain, label]
                for _ in range(2):
                    record = rng.choice(records)
                    indices.append(int(rng.choice(members[record])))
        yield np.asarray(indices)[rng.permutation(len(indices))]


def load_complete_inputs():
    expected = {f'fold{fold}_{arm}_s{seed}' for fold in range(5) for arm in ARMS for seed in SEEDS}
    available = {p.stem for p in RUN.glob('fold*_s*.json')
                 if not p.name.endswith('_split.json') and not p.name.endswith('_view_hashes.json')}
    require(available == expected, f'V6 incomplete/unexpected result set; missing={sorted(expected-available)}, extra={sorted(available-expected)}')
    design_path = RUN / 'design.json'
    design = read_json(design_path)
    require(design['planned_selected_models'] == 60 and design['planned_checkpoint_options'] == 240,
            'frozen design model/checkpoint counts changed')
    require(design['seeds'] == SEEDS and list(design['arms']) == ARMS and design['test_panels'] == PANELS,
            'frozen design arms/seeds/panels differ')
    for relative, digest in design['sha256'].items():
        require(sha(ROOT / relative) == digest, f'frozen source/input SHA mismatch: {relative}')
    archive = np.load(ROOT / 'data/processed/v5/hust_neural_patches.npz', allow_pickle=False)
    x = archive['x']
    frame = pd.read_csv(ROOT / 'data/processed/v5/hust_neural_patch_lineage.csv')
    require(x.shape == (672, 2048) and x.dtype == np.float32 and np.isfinite(x).all(), 'invalid patch array')
    require(np.array_equal(archive['patch_id'], frame.patch_id.to_numpy(str)), 'patch ID ordering differs')
    require(int(archive['fs']) == 25600, 'sampling rate changed')
    require(frame.source_record.nunique() == 21 and len(frame) == 672, 'lineage record/patch counts differ')
    require(frame.groupby('source_record').size().eq(32).all(), 'each source file must have 32 patches')
    require(frame.groupby('window_row').size().eq(4).all(), 'each second must have four patches')
    require(frame.groupby('source_record').class_id.nunique().eq(1).all(), 'record labels inconsistent')
    frame['domain_id'] = frame.condition.map(dict(zip(CONDITIONS, range(5))))
    require(frame.domain_id.notna().all(), 'unknown condition in lineage')
    panels, validation = independent_panels(x)
    for panel, values in panels.items():
        require(array_sha(values) == design['test_noise_array_sha256'][panel], f'independent panel SHA mismatch: {panel}')
    require(array_sha(validation) == design['validation_awgn_array_sha256'], 'independent validation noise SHA mismatch')
    results = {stem: read_json(RUN / (stem + '.json')) for stem in sorted(expected)}
    return design, sha(design_path), x, frame, panels, validation, results


def validate_splits_and_views(x, frame, results):
    splits, steps, regenerated_hashes = {}, 0, 0
    for fold in range(5):
        domains = [d for d in range(5) if d not in (fold, (fold + 1) % 5)]
        role_masks = {'train': frame.domain_id.isin(domains).to_numpy(),
                      'validation': frame.domain_id.eq((fold + 1) % 5).to_numpy(),
                      'test': frame.domain_id.eq(fold).to_numpy()}
        memberships = {role: sorted(frame.loc[mask, 'source_record'].unique()) for role, mask in role_masks.items()}
        require(not set(memberships['train']) & set(memberships['test']), 'training/test record overlap')
        require(not set(memberships['train']) & set(memberships['validation']), 'training/validation record overlap')
        require(not set(memberships['test']) & set(memberships['validation']), 'validation/test record overlap')
        for seed in SEEDS:
            sp = RUN / f'fold{fold}_s{seed}_split.json'
            split = read_json(sp)
            require(split['fold'] == fold and split['seed'] == seed and split['train_domains'] == domains,
                    'split identifiers/domains differ')
            for role in memberships:
                require(split[f'{role}_records'] == memberships[role], f'{role} memberships differ')
            batches = np.asarray(split['batch_indices'], dtype=int)
            require(batches.shape == (480, 18), 'expected 480 source-only batches of 18')
            require(batches.min() >= 0 and batches.max() < len(frame), 'out-of-range patch index')
            train_indices = np.flatnonzero(role_masks['train'])
            for stored, generated in zip(batches, expected_batches(frame, train_indices, domains, fold, seed)):
                require(np.array_equal(stored, generated), 'independent record-uniform batch reconstruction differs')
                cell_counts = frame.iloc[stored].groupby(['domain_id', 'class_id']).size()
                require(len(cell_counts) == 9 and cell_counts.eq(2).all(), 'source class/domain balance differs')
                require(set(frame.iloc[stored].domain_id) == set(domains), 'validation/test patch entered training')
            hash_lists = {}
            for arm in ARMS:
                stem = f'fold{fold}_{arm}_s{seed}'
                rp = results[stem]
                require(rp['split_sha256'] == sha(sp), f'split SHA mismatch {stem}')
                hp = RUN / (stem + '_view_hashes.json')
                require(rp['view_hashes_sha256'] == sha(hp), f'view hash file SHA mismatch {stem}')
                values = read_json(hp)
                require(len(values) == 480 and all(isinstance(v, str) and len(v) == 64 for v in values),
                        '480 valid step view hashes required')
                hash_lists[arm] = values
            require(hash_lists['response_ce'] == hash_lists['response_jsd'], 'paired response CE/JSD views differ')
            for step, batch in enumerate(batches, 1):
                for arm, mode in [('clean_ce', 'clean'), ('awgn_ce', 'awgn'), ('response_ce', 'response')]:
                    digest = array_sha(independent_views(x[batch], fold, seed, step, mode))
                    require(digest == hash_lists[arm][step - 1], f'independent training-view SHA mismatch fold{fold}/s{seed}/{arm}/step{step}')
                    regenerated_hashes += 1
                steps += 1
            splits[fold, seed] = (split, role_masks)
            print(f'AUDIT split fold{fold} seed{seed}: 480 balanced source batches; paired views exact', flush=True)
    require(steps == 7200 and regenerated_hashes == 21600, 'view/batch audit counts incomplete')
    return splits, regenerated_hashes


def result_tables(design, design_hash, frame, results, splits):
    records, validation_records, folds, costs, max_metric_delta = [], [], [], [], 0.
    labels_by_record = frame.groupby('source_record').class_id.first().to_dict()
    metadata = frame.groupby('source_record')[['condition', 'severity', 'class_name']].first().to_dict('index')
    max_row_residual = 0.
    for stem, result in results.items():
        fold, arm, seed = int(result['fold']), result['arm'], int(result['seed'])
        require(stem == f'fold{fold}_{arm}_s{seed}', 'result filename/identifier mismatch')
        require(result['design_sha256'] == design_hash, f'design SHA mismatch {stem}')
        require(result['augmentation'] == design['arms'][arm]['augmentation']
                and result['jsd_lambda'] == design['arms'][arm]['jsd_lambda'], 'arm configuration mismatch')
        for suffix, key in [('.pt', 'model_sha256'), ('_predictions.csv', 'predictions_sha256')]:
            require(sha(RUN / (stem + suffix)) == result[key], f'artifact SHA mismatch {stem}/{key}')
        split, masks = splits[fold, seed]
        expected_val_n = len(split['validation_records'])
        history = result['history']
        require([h['update'] for h in history] == [120, 240, 360, 480], 'checkpoint options incomplete')
        for checkpoint in history:
            require(set(checkpoint['validation']) == {'clean', 'AWGN6dB'}, 'checkpoint validation panels differ')
            for panel, entry in checkpoint['validation'].items():
                history_confusion_check(entry, expected_val_n, f'{stem}/u{checkpoint["update"]}/{panel}')
            means = {key: float(np.mean([m[key] for m in checkpoint['validation'].values()])) for key in ('macro_f1', 'nll')}
            for key in means:
                require(abs(means[key] - checkpoint['selection'][key]) < TOLERANCE, 'checkpoint selection average mismatch')
            for key in ('train_loss', 'train_ce', 'train_jsd', 'gradient_norm_before_clip'):
                require(np.isfinite(checkpoint[key]), f'nonfinite checkpoint diagnostic {key}')
        selected = max(history, key=lambda h: (h['selection']['macro_f1'], -h['selection']['nll'], -h['update']))
        require(result['selected_update'] == selected['update'], 'selected update violates two-panel validation rule')
        require(result['validation'] == selected['validation'] and result['selection'] == selected['selection'],
                'selected checkpoint metadata differs')
        predictions = pd.read_csv(RUN / (stem + '_predictions.csv'), float_precision='round_trip')
        require(set(predictions.role) == {'validation', 'test'}, 'prediction roles differ')
        expected_rows = 2 * len(split['validation_records']) + 6 * len(split['test_records'])
        require(len(predictions) == expected_rows, 'prediction record row count differs')
        require(not predictions.duplicated(['role', 'panel', 'source_record']).any(), 'duplicate saved record prediction')
        require(all(labels_by_record.get(row.source_record) == row.label for row in predictions.itertuples()), 'prediction label does not match lineage')
        for role, panels in [('validation', ['clean', 'AWGN6dB']), ('test', PANELS)]:
            subset = predictions[predictions.role.eq(role)]
            require(set(subset.panel) == set(panels), f'saved {role} panels incomplete')
            for panel in panels:
                part = subset[subset.panel.eq(panel)].sort_values('source_record')
                require(part.source_record.tolist() == split[f'{role}_records'], f'wrong {role} source membership {stem}/{panel}')
                probability = part[['p_H', 'p_I', 'p_O']].to_numpy(float)
                max_row_residual = max(max_row_residual, float(np.max(np.abs(probability.sum(1) - 1))))
                actual = scores(part.label.to_numpy(int), probability)
                stored = result['validation'][panel] if role == 'validation' else result['test'][panel]
                max_metric_delta = max(max_metric_delta, compare_metrics(actual, stored, f'{stem}/{role}/{panel}'))
                if role == 'test':
                    folds.append({'fold': fold, 'test_condition': CONDITIONS[fold], 'arm': arm, 'seed': seed,
                                  'panel': panel, **{k: actual[k] for k in METRIC_KEYS},
                                  'confusion_matrix': json.dumps(actual['confusion_matrix'])})
                for row in part.itertuples(index=False):
                    item = {'fold': fold, 'arm': arm, 'seed': seed, 'role': role, 'panel': panel,
                            'source_record': row.source_record, 'label': int(row.label),
                            'p_H': row.p_H, 'p_I': row.p_I, 'p_O': row.p_O,
                            'predicted_label': int(np.argmax([row.p_H, row.p_I, row.p_O])), **metadata[row.source_record]}
                    (records if role == 'test' else validation_records).append(item)
        require(result['model_parameters'] == 66083 and result['total_forward_patch_presentations'] == 480 * 54,
                'parameter/input budget differs')
        require(result['source_patches_per_update'] == 18 and result['views_per_update'] == 54, 'training example budget differs')
        require(np.isfinite(result['seconds']) and result['seconds'] > 0, 'invalid training cost')
        costs.append({'fold': fold, 'arm': arm, 'seed': seed, 'selected_update': result['selected_update'],
                      'parameters': result['model_parameters'], 'seconds': result['seconds'],
                      'updates': 480, 'forward_patch_presentations': 480 * 54,
                      'validation_mean_macro_f1': result['selection']['macro_f1'],
                      'validation_mean_nll': result['selection']['nll'],
                      'checkpoint_options': 4, 'validation_panel_evaluations': 8})
    records = pd.DataFrame(records).sort_values(['arm', 'seed', 'panel', 'source_record']).reset_index(drop=True)
    validation_records = pd.DataFrame(validation_records).sort_values(['arm', 'seed', 'fold', 'panel', 'source_record']).reset_index(drop=True)
    require(len(records) == 1512 and len(validation_records) == 504, 'complete test/validation records not recovered')
    pooled = []
    for (arm, seed, panel), part in records.groupby(['arm', 'seed', 'panel'], sort=False):
        require(len(part) == 21 and part.source_record.nunique() == 21, 'incomplete or duplicated OOF source records')
        require(set(part.source_record) == set(labels_by_record), 'OOF memberships differ')
        actual = scores(part.label.to_numpy(int), part[['p_H', 'p_I', 'p_O']].to_numpy(float))
        pooled.append({'arm': arm, 'seed': int(seed), 'panel': panel, **{k: actual[k] for k in METRIC_KEYS},
                       'confusion_matrix': json.dumps(actual['confusion_matrix'])})
    pooled = pd.DataFrame(pooled)
    require(len(pooled) == 72, 'expected 72 pooled cells')
    descriptive = []
    continuous = [k for k in METRIC_KEYS if k != 'n_records']
    for (arm, panel), part in pooled.groupby(['arm', 'panel'], sort=False):
        require(sorted(part.seed) == SEEDS, 'seed summary incomplete')
        row = {'arm': arm, 'panel': panel, 'n_algorithm_seeds': 3, 'n_source_records_per_seed': 21,
               'uncertainty_interpretation': 'descriptive algorithm-seed variation; not physical-population inference'}
        for key in continuous:
            for statistic, value in [('mean', part[key].mean()), ('min', part[key].min()), ('max', part[key].max()), ('sd', part[key].std(ddof=1))]:
                row[f'{key}_{statistic}'] = float(value)
        descriptive.append(row)
    contrasts = []
    indexed = pooled.set_index(['arm', 'seed', 'panel'])
    for intervention, control in [('awgn_ce', 'clean_ce'), ('response_ce', 'awgn_ce'), ('response_jsd', 'response_ce')]:
        for seed in SEEDS:
            for panel in PANELS:
                a, b = indexed.loc[(intervention, seed, panel)], indexed.loc[(control, seed, panel)]
                row = {'intervention': intervention, 'control': control, 'seed': seed, 'panel': panel,
                       'contrast_definition': 'intervention minus control; positive F1/recall and negative NLL/Brier favor intervention'}
                for key in continuous:
                    row[f'delta_{key}'] = float(a[key] - b[key])
                contrasts.append(row)
    tables = {'record_predictions.csv': records, 'validation_record_predictions.csv': validation_records,
              'pooled_summary.csv': pooled, 'descriptive_summary.csv': pd.DataFrame(descriptive),
              'fold_summary.csv': pd.DataFrame(folds), 'cost_summary.csv': pd.DataFrame(costs),
              'contrasts.csv': pd.DataFrame(contrasts)}
    for name, table in tables.items():
        table.to_csv(OUT / name, index=False)
    require(len(folds) == 360 and len(costs) == 60 and len(descriptive) == 24 and len(contrasts) == 54,
            'output table count mismatch')
    return {'tables': {name: {'rows': len(value), 'sha256': sha(OUT / name)} for name, value in tables.items()},
            'max_saved_metric_absolute_difference': max_metric_delta,
            'max_saved_probability_rowsum_residual': max_row_residual}


def independent_inference(model, signals, frame, indices):
    predictions = []
    model.eval()
    require(all(not layer.training for layer in model.modules()), 'eval mode not propagated')
    with torch.no_grad():
        for offset in range(0, len(indices), 48):
            patch = normalized_patch(signals[indices[offset:offset + 48]])
            logits = model(torch.from_numpy(patch[:, None, :]))['logits']
            require(torch.isfinite(logits).all().item(), 'replay produced nonfinite logits')
            predictions.append(torch.softmax(logits, dim=1).numpy().astype(np.float64))
    patch_probability = np.concatenate(predictions)
    sf = frame.iloc[indices]
    record_names = sorted(sf.source_record.unique())
    means, labels = [], []
    for record in record_names:
        mask = sf.source_record.eq(record).to_numpy()
        require(mask.sum() == 32, 'replay record patch count not 32')
        labels.append(int(sf.loc[mask, 'class_id'].iloc[0]))
        means.append(patch_probability[mask].mean(axis=0))
    means = np.stack(means)
    means = means / means.sum(axis=1, keepdims=True)
    return record_names, np.asarray(labels), means


def replay_all_weights(design_hash, frame, panels, validation, results, splits):
    started = time.perf_counter()
    write_json(OUT / 'replay_audit.json', {'status': 'running', 'success': False,
               'design_sha256': design_hash, 'analyzer_sha256': sha(__file__)})
    replayed, largest_probability_difference, largest_metric_difference = [], 0., 0.
    total_cells, total_rows, buffers_verified = 0, 0, 0
    for stem, result in results.items():
        mp = RUN / (stem + '.pt')
        require(sha(mp) == result['model_sha256'], 'model hash changed before replay')
        checkpoint = torch.load(mp, map_location='cpu', weights_only=True)
        for key in ('fold', 'arm', 'seed', 'selected_update'):
            require(checkpoint[key] == result[key], f'checkpoint/result identity mismatch: {stem}/{key}')
        require(checkpoint['design_sha256'] == design_hash, 'checkpoint design hash differs')
        model = ClassBDWDCNN(variant='baseline')
        model.load_state_dict(checkpoint['model_state'], strict=True)
        require(sum(p.numel() for p in model.parameters()) == 66083, 'replay parameter count differs')
        require(all(torch.isfinite(value).all().item() for value in model.state_dict().values()), 'nonfinite saved weights')
        before = {name: value.detach().clone() for name, value in model.named_buffers()}
        require(len(before) > 0, 'missing BatchNorm state for leakage check')
        _, masks = splits[result['fold'], result['seed']]
        saved = pd.read_csv(RUN / (stem + '_predictions.csv'), float_precision='round_trip')
        model_max = 0.
        roles = [('test', panel, signals, masks['test']) for panel, signals in panels.items()]
        roles += [('validation', 'clean', panels['clean'], masks['validation']),
                  ('validation', 'AWGN6dB', validation, masks['validation'])]
        for role, panel, signals, mask in roles:
            indices = np.flatnonzero(mask)
            names, labels, probability = independent_inference(model, signals, frame, indices)
            selected = saved[saved.role.eq(role) & saved.panel.eq(panel)].sort_values('source_record')
            require(names == selected.source_record.tolist() and np.array_equal(labels, selected.label.to_numpy(int)),
                    f'independent replay record order/labels differ {stem}/{role}/{panel}')
            difference = float(np.max(np.abs(probability - selected[['p_H', 'p_I', 'p_O']].to_numpy(float))))
            require(difference <= TOLERANCE, f'weight replay posterior mismatch {stem}/{role}/{panel}: {difference}')
            model_max = max(model_max, difference)
            actual = scores(labels, probability)
            stored = result['test'][panel] if role == 'test' else result['validation'][panel]
            largest_metric_difference = max(largest_metric_difference, compare_metrics(actual, stored, f'replay/{stem}/{role}/{panel}'))
            total_cells += 1
            total_rows += len(labels)
        after = dict(model.named_buffers())
        require(set(before) == set(after) and all(torch.equal(before[k], after[k]) for k in before),
                f'BatchNorm/buffer mutation during held-out replay: {stem}')
        buffers_verified += len(before)
        largest_probability_difference = max(largest_probability_difference, model_max)
        replayed.append({'model': stem, 'model_sha256': sha(mp), 'panels_replayed': 8,
                         'max_probability_absolute_difference': model_max, 'all_buffers_unchanged': True,
                         'buffer_tensor_count': len(before)})
        print(f'REPLAY {len(replayed)}/60 {stem}: all 8 panels match, BN unchanged', flush=True)
    require(len(replayed) == 60 and total_cells == 480 and total_rows == 2016, 'incomplete selected-weight replay')
    audit = {'status': 'passed', 'success': True, 'created_utc': datetime.now(timezone.utc).isoformat(), 'design_sha256': design_hash,
             'analyzer_sha256': sha(__file__), 'models': 60, 'test_cells': 360, 'validation_cells': 120,
             'total_record_predictions': total_rows, 'total_buffer_tensors_unchanged': buffers_verified,
             'max_probability_absolute_difference': largest_probability_difference,
             'max_metric_absolute_difference': largest_metric_difference, 'tolerance': TOLERANCE,
             'cpu_threads': torch.get_num_threads(), 'seconds': time.perf_counter() - started,
             'independent_reimplemented_components': ['six fixed test-noise panels', 'validation AWGN realization',
                'within-patch float32 normalization', 'float64 mean of patch posteriors within source record',
                'roundoff-only record normalization', 'confusion/F1/recall/Brier/NLL'],
             'shared_frozen_component': 'ClassBDWDCNN baseline architecture only; no experiment helper imports',
             'scope': 'selected checkpoint weights; nonselected checkpoint weights were not saved and cannot be independently replayed',
             'selected_result_json_sha256': {stem: sha(RUN / (stem + '.json')) for stem in results},
             'details': replayed}
    write_json(OUT / 'replay_audit.json', audit)
    return audit


def self_check():
    rng = np.random.default_rng(123)
    signals = rng.normal(size=(7, 2048)).astype(np.float32)
    normalized = normalized_patch(signals)
    require(np.max(abs(normalized.mean(1))) < 1e-6, 'normalization mean self-check')
    require(np.max(abs(np.square(normalized).mean(1) - 1)) < 1e-6, 'normalization variance self-check')
    noise = noise_scaled_to_snr(signals, rng.normal(size=signals.shape), -4) - signals
    snr = 10 * np.log10(np.var(signals.astype(float), axis=1) / np.var(noise, axis=1))
    require(np.max(abs(snr + 4)) < 1e-6, 'SNR self-check')
    actual = scores(np.array([0, 1, 2]), np.array([[.8, .1, .1], [.1, .8, .1], [.1, .1, .8]]))
    require(actual['macro_f1'] == 1 and abs(actual['nll'] + np.log(.8)) < 1e-12, 'metric self-check')
    require(np.max(abs(response_view(signals, np.zeros((7, 5))) - signals)) < 1e-10, 'identity response self-check')
    print('Synthetic analyzer self-checks passed; no experimental audit issued.', flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=['all', 'tables', 'replay'], default='all',
                        help='tables reports replay pending; all is required for a full pass')
    parser.add_argument('--self-check', action='store_true', help='synthetic checks only; never writes audit pass')
    args = parser.parse_args()
    torch.set_num_threads(2)
    torch.set_num_interop_threads(1)
    torch.use_deterministic_algorithms(True)
    if args.self_check:
        self_check()
        return
    started = time.perf_counter()
    # Require all selected results before creating audit output. Incomplete runs
    # cannot accidentally produce an apparently passing report.
    design, design_hash, x, frame, panels, validation, results = load_complete_inputs()
    OUT.mkdir(parents=True, exist_ok=True)
    write_json(OUT / 'audit.json', {'status': 'running', 'passed': False,
               'design_sha256': design_hash, 'analyzer_sha256': sha(__file__)})
    print('All 60 selected results present; frozen inputs and independent panel hashes match.', flush=True)
    splits, generated_hashes = validate_splits_and_views(x, frame, results)
    tables = result_tables(design, design_hash, frame, results, splits)
    replay = None
    if args.mode in ['all', 'replay']:
        replay = replay_all_weights(design_hash, frame, panels, validation, results, splits)
    else:
        previous = OUT / 'replay_audit.json'
        if previous.exists():
            candidate = read_json(previous)
            if (candidate.get('status') == 'passed' and candidate.get('design_sha256') == design_hash
                    and candidate.get('analyzer_sha256') == sha(__file__)
                    and candidate.get('selected_result_json_sha256') ==
                    {stem: sha(RUN / (stem + '.json')) for stem in results}):
                replay = candidate
    audit = {'status': 'passed' if replay is not None else 'tables_passed_replay_pending',
             'passed': replay is not None,
             'created_utc': datetime.now(timezone.utc).isoformat(), 'design_sha256': design_hash,
             'analyzer_sha256': sha(__file__), 'selected_models': 60, 'checkpoint_options': 240,
             'historical_validation_panel_evaluations': 480, 'test_cells': 360,
             'split_maps': 15, 'source_only_balanced_batches': 7200,
             'response_ce_jsd_matched_view_steps': 7200, 'independently_regenerated_unique_view_hashes': generated_hashes,
             'sha_verified_per_model': ['design', 'split', 'model', 'predictions', 'training_view_hashes'],
             'metric_tolerance': TOLERANCE, 'cpu_threads': 2, 'seconds': time.perf_counter() - started,
             'selected_weights_independently_replayed': replay is not None,
             'replay_audit_sha256': sha(OUT / 'replay_audit.json') if replay is not None else None,
             'limitations': ['21 source files are not proven to be 21 independent bearings',
                '3 algorithm seeds are not physical or corruption-realization replicates',
                'one fixed synthetic realization per corruption family',
                'historical nonselected validation probabilities/weights were not retained; history confusion and selection rules were checked, not raw-logit replayed',
                'new V6 development follows prior V5 test inspection; no untouched confirmation or SOTA inference'],
             **tables}
    write_json(OUT / 'audit.json', audit)
    print(json.dumps({'status': audit['status'], 'models': 60, 'OOF_rows': 1512,
                      'replay': replay is not None, 'seconds': audit['seconds']}), flush=True)


if __name__ == '__main__':
    main()
