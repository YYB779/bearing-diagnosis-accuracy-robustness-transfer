"""Inspect the selected HUST raw text recordings; no model fitting or split."""
from pathlib import Path
import datetime,hashlib,json
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
PROVENANCE=ROOT/'data/raw/v3_external'
manifest=json.loads((PROVENANCE/'hust_subset_download_manifest.json').read_text(encoding='utf8'))
rows=[];signals=[];aux=[];labels=[];conditions=[];names=[]
for entry in manifest['downloads']:
    assert 'error' not in entry
    path=Path(entry['local_path'])
    with path.open(encoding='utf8') as f:
        header=[]
        for line in f:
            header.append(line.rstrip('\n'))
            if line.strip()=='Data':break
        arr=np.loadtxt(f,delimiter='\t',dtype=np.float64)
    assert arr.shape==(262144,5), (path,arr.shape)
    assert np.isfinite(arr).all()
    dt=np.diff(arr[:,0]); assert (dt>0).all()
    fs_endpoints=(len(arr)-1)/(arr[-1,0]-arr[0,0])
    assert abs(fs_endpoints-25600)<.01
    row={'name':path.name,'sha256':entry['sha256'],'shape':list(arr.shape),'columns':['time_seconds','speed_auxiliary_NOT_calibrated_rpm','X_vibration','Y_vibration','Z_vibration'],
         'sample_rate_hz_author':25600,'sample_rate_hz_endpoints':float(fs_endpoints),'time_range_s':[float(arr[0,0]),float(arr[-1,0])],
         'aux_min_median_max':np.quantile(arr[:,1],[0,.5,1]).tolist(),'aux_std':float(np.std(arr[:,1])),
         'axis_std_XYZ':np.std(arr[:,2:5],axis=0).tolist(),'header':header,
         'class_from_filename':path.name.split('_')[0],
         'condition_from_filename':path.stem.split('_',1)[1]}
    rows.append(row);signals.append(arr[:,2:5].astype(np.float32));aux.append(arr[:,1].astype(np.float32));labels.append(row['class_from_filename']);conditions.append(row['condition_from_filename']);names.append(path.name)

out=Path(manifest['registration']['data_root'])/'hust_hio_20_40_vs_raw_float32.npz'
np.savez_compressed(out,vibration_xyz=np.stack(signals),auxiliary_column=np.stack(aux),class_name=np.asarray(labels),condition=np.asarray(conditions),record_name=np.asarray(names),sample_rate_hz=25600)
audit={
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_recordings':len(rows),'records':rows,
    'numeric_archive':str(out),'numeric_archive_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
    'permission':manifest['registration']['permission'],
    'limitations':[
        'Independent physical bearing identities are not supplied; H/I/O are health states, not bearing replicate IDs.',
        'Only one source recording per selected class/condition. Random window splitting is not independent recording validation.',
        'Second numeric column has no calibrated unit in the raw header. Author warns it is meaningless for constant-speed records; no rpm conversion or order tracking is authorized by these files alone.',
        'Filename VS_0_40_0Hz documents the commanded condition but does not establish samplewise measured shaft speed.',
        'X/Y/Z values are treated as recorded vibration amplitudes; physical acceleration units are not established by this audit.',
        'This 9-record subset is not the complete 99-file author release and does not reproduce the authors published benchmark.',
    ],
    'candidate_use':'Additional test-rig health discrimination with raw vibrations under filename-defined operating conditions; no physical-speed claim without calibration.'
}
(PROVENANCE/'hust_subset_structure_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf8')
print(json.dumps({'record_count':len(rows),'numeric_archive':str(out),'numeric_archive_bytes':out.stat().st_size,'summaries':[{k:r[k] for k in ['name','shape','sample_rate_hz_endpoints','aux_min_median_max','axis_std_XYZ']} for r in rows]},indent=2))
