"""Exploratory follow-up with identical feature count and per-branch point budget.

The first v3 record-holdout results had been inspected before this follow-up.
The middle carrier band is fixed at 2--5 kHz; it is not chosen by test accuracy.
No test prediction changes any model, band, threshold or representation choice.
"""
from __future__ import annotations
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from scipy.signal import resample_poly

from scripts.v3.prepare_novic_physical_features import feature_block
from scripts.v3.run_controlled_benchmark import (ROOT, TASKS, PROTOCOLS, digest,
    fit_candidate, group_probabilities, make_protocol, scores, write_json)

REPRESENTATIONS = ('lowband_256', 'time_middle_256', 'order_middle_256',
                   'time_middle_2048', 'order_middle_2048')


def extract_features():
    base = ROOT/'data/processed/v3'
    frame = pd.read_csv(base/'novic_physical_lineage.csv')
    original = pd.read_csv(base/'novic_physical_features.csv')
    views = np.load(base/'novic_physical_views.npz', allow_pickle=False)
    assert np.array_equal(frame.sample_id, views['sample_id'])
    meta = [c for c in original if c.startswith('meta__')]
    blocks = {}
    rows = []
    for i in range(len(frame)):
        row = {'sample_id': frame.iloc[i].sample_id}
        for c in meta:
            row[c] = float(original.iloc[i][c])
        for rep in REPRESENTATIONS:
            if rep == 'lowband_256':
                values = views['time_lowband'][i].astype(float)
            else:
                view = 'order_envelope' if rep.startswith('order') else 'time_envelope'
                values = views[view][i, 1].astype(float)
                if rep.endswith('_256'):
                    values = resample_poly(values, 255, 2047, padtype='line')
            # Mean-speed time is expressed in equivalent revolutions over the
            # same known eight-turn interval. Both coordinate choices then
            # have identical spectral bins and feature dimension.
            values_dict, _ = feature_block(values, (len(values)-1)/8., 'order', 'g',
                                           [(0., 4.), (4., 8.), (8., 12.), (12., 16.)])
            columns = []
            for key, value in values_dict.items():
                c = f'{rep}__{key}'
                row[c] = value; columns.append(c)
            if rep not in blocks:
                blocks[rep] = meta+columns
        rows.append(row)
    features = pd.DataFrame(rows)
    assert len({len(v) for v in blocks.values()}) == 1
    assert np.isfinite(features.drop(columns='sample_id').to_numpy()).all()
    return frame, features, blocks


def main():
    out = ROOT/'results/v3/matched_budget'
    out.mkdir(parents=True, exist_ok=True)
    frame, features, blocks = extract_features()
    features_path = out/'features.csv'; features.to_csv(features_path, index=False)
    registration = {
        'frozen_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'exploratory follow-up after first v3 record-holdout results were inspected',
        'question': 'Does a retained-envelope contrast survive equal one-channel, equal-point, equal-feature controls?',
        'carrier_band_hz': [2000, 5000], 'band_selection': 'fixed engineering control; not chosen by test performance',
        'interval': 'identical complete eight measured turns, same endpoints',
        'feature_dimension': len(next(iter(blocks.values()))),
        'features': '12 amplitude statistics + five spectral descriptors + four equal 0--16 order bins (energy and fraction) + same eight metadata',
        'coordinate': 'time uses equivalent mean-speed phase 8*(t-t0)/(t1-t0); order uses integrated measured phase',
        'limitations': ['lowband versus envelope changes physical information and units of amplitude, not just operation order',
                       '256-point angular Nyquist is 15.9375 orders; not all third BPFI harmonics are retained',
                       '2048 versus 256 changes both retained spectral support and sampling resolution',
                       'No independent bearing identity, fresh rig or preregistered confirmatory interpretation'],
        'protocols': list(PROTOCOLS), 'tasks': list(TASKS), 'representations': list(REPRESENTATIONS),
        'models': {'extra_trees': {'seeds': [11,22,33], 'min_samples_leaf': [1,3]},
                   'group_calibrated_svm': {'seeds': [11], 'C': [.1,1.,10.]}},
        'planned_selected_models': 160,
        'selection': 'validation equal-record macro F1 then lower NLL; fit on train only; no refit or test selection',
        'blocks': blocks,
        'sha256': {str(p.relative_to(ROOT)):digest(p) for p in [Path(__file__), features_path,
                     ROOT/'data/processed/v3/novic_physical_lineage.csv',
                     ROOT/'data/processed/v3/novic_physical_views.npz',
                     ROOT/'scripts/v3/prepare_novic_physical_features.py',
                     ROOT/'scripts/v3/run_controlled_benchmark.py']}}
    design_path = out/'design.json'
    if design_path.exists():
        previous = json.loads(design_path.read_text(encoding='utf-8'))
        registration['frozen_utc'] = previous['frozen_utc']
        if registration != previous:
            raise RuntimeError('Matched-budget frozen design changed')
    else:
        write_json(design_path, registration)
    for protocol in PROTOCOLS:
        assigned, masks = make_protocol(frame, protocol)
        for task in TASKS:
            y = frame[task].to_numpy(int)
            for rep in REPRESENTATIONS:
                x = features[blocks[rep]].to_numpy(float)
                for name, seeds, grid in [
                    ('extra_trees', [11,22,33], [{'min_samples_leaf':1},{'min_samples_leaf':3}]),
                    ('group_calibrated_svm', [11], [{'C':.1},{'C':1.},{'C':10.}])]:
                    for seed in seeds:
                        stem = f'{protocol}_{task}_{rep}_{name}_s{seed}'
                        result_path = out/(stem+'.json')
                        if result_path.exists():
                            continue
                        tic = time.perf_counter(); selected=None; best=(-1.,-float('inf')); candidates=[]
                        for config in grid:
                            model=fit_candidate(name,x[masks['train']],y[masks['train']],
                                frame.loc[masks['train']].reset_index(drop=True),seed,config)
                            vp=model.predict_proba(x[masks['validation']])[:,1]
                            vg=group_probabilities(frame.loc[masks['validation']],y[masks['validation']],vp)
                            metrics=scores(vg.y.to_numpy(),vg.p.to_numpy())
                            key=(metrics['macro_f1'],-metrics['nll'])
                            candidates.append({'config':config,'validation_record':metrics})
                            if key>best:
                                best=key; selected=model; chosen=config; selected_vp=vp
                        tp=selected.predict_proba(x[masks['test']])[:,1]
                        results={}; prediction_rows=[]
                        for split,p in [('validation',selected_vp),('test',tp)]:
                            sf=frame.loc[masks[split]].reset_index(drop=True); sy=y[masks[split]]
                            sg=group_probabilities(sf,sy,p)
                            results[split]={'record':scores(sg.y.to_numpy(),sg.p.to_numpy()),'window':scores(sy,p)}
                            prediction_rows.extend([{'sample_id':sf.iloc[i].sample_id,
                                'group':sf.iloc[i].inferred_source_group,'subset':sf.iloc[i].subset,
                                'split':split,'label':int(sy[i]),'p1':float(p[i])} for i in range(len(sf))])
                        pp=out/(stem+'_predictions.csv'); pd.DataFrame(prediction_rows).to_csv(pp,index=False)
                        mp=out/(stem+'.joblib'); joblib.dump(selected,mp,compress=3)
                        write_json(result_path,{'protocol':protocol,'task':task,'representation':rep,'model':name,'seed':seed,
                            'n_features':len(blocks[rep]),'feature_columns':blocks[rep],'selected_config':chosen,
                            'candidates':candidates,**results,'seconds':time.perf_counter()-tic,
                            'test_predict_calls':1,'design_sha256':digest(design_path),
                            'predictions':pp.name,'predictions_sha256':digest(pp),'model_sha256':digest(mp)})
                        print(f'DONE matched {stem}: record F1 {results["test"]["record"]["macro_f1"]:.3f}',flush=True)


if __name__ == '__main__':
    main()
