"""Independent, label-blind physical preprocessing of the measured NOVIC+ subset.

The frozen v2 inputs and all v2 results are untouched. Source recording groups
and labels are reused exactly; no new physical-bearing independence is implied.
The only extraction limit is the first 32 measured turns, in up to four complete
nonoverlapping eight-turn intervals. Demodulation precedes all downsampling.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import scipy
from scipy.signal import butter, hilbert, periodogram, resample_poly, sosfiltfilt, sosfreqz

ROOT = Path(__file__).resolve().parents[2]
FS = 25600.
SAMPLES = 2048
TURNS = 8.
BANDS = {"b500_2000": (500., 2000.), "b2000_5000": (2000., 5000.), "b5000_10000": (5000., 10000.)}
EPS = np.finfo(float).eps


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for piece in iter(lambda: f.read(1024 * 1024), b""):
            h.update(piece)
    return h.hexdigest()


def measured_phase(rpm: np.ndarray, fs: float) -> np.ndarray:
    rpm = np.asarray(rpm, dtype=float)
    if rpm.ndim != 1 or rpm.size < 2 or not np.isfinite(rpm).all() or np.any(rpm <= 0):
        raise ValueError("Measured bearing-shaft RPM must be finite, positive, and one dimensional")
    if not np.isfinite(fs) or fs <= 0:
        raise ValueError("Sample rate must be positive and finite")
    return np.r_[0., np.cumsum((rpm[:-1] + rpm[1:]) / (120. * fs))]


def fixed_turn_intervals(phase: np.ndarray, turns: float = TURNS, max_intervals: int = 4) -> list[tuple[float, float]]:
    phase = np.asarray(phase, dtype=float)
    if phase.ndim != 1 or phase.size < 2 or not np.isfinite(phase).all() or np.any(np.diff(phase) <= 0):
        raise ValueError("Phase must be finite and strictly increasing")
    if turns <= 0 or max_intervals < 1:
        raise ValueError("Interval extent and limit must be positive")
    available = int(np.floor((phase[-1] - phase[0]) / turns + 1e-12))
    return [(phase[0] + k*turns, phase[0] + (k+1)*turns) for k in range(min(available, max_intervals))]


def paired_coordinates(phase: np.ndarray, fs: float, start_turn: float, stop_turn: float, n: int = SAMPLES) -> dict:
    if n < 3 or stop_turn <= start_turn or start_turn < phase[0] or stop_turn > phase[-1] + 1e-12:
        raise ValueError("Requested interval has insufficient measured angular coverage")
    source_t = np.arange(len(phase), dtype=float) / fs
    phase_grid = np.linspace(start_turn, stop_turn, n)
    angle_t = np.interp(phase_grid, phase, source_t)
    time_t = np.linspace(angle_t[0], angle_t[-1], n)
    # Constructing both grids from the same phase boundaries makes this invariant exact.
    if time_t[0] != angle_t[0] or time_t[-1] != angle_t[-1]:
        raise AssertionError("Physical view endpoints differ")
    return {"time_s": time_t, "angle_time_s": angle_t, "phase_turns": phase_grid,
            "duration_s": float(time_t[-1] - time_t[0]),
            "time_sample_rate_hz": float((n-1)/(time_t[-1] - time_t[0])),
            "angular_sample_rate_per_turn": float((n-1)/(stop_turn - start_turn))}


def lowpass(x: np.ndarray, fs: float, cutoff: float, order: int = 6) -> np.ndarray:
    if not (0 < cutoff < fs / 2):
        raise ValueError("Lowpass cutoff must lie inside the source Nyquist limit")
    return sosfiltfilt(butter(order, cutoff, btype="lowpass", fs=fs, output="sos"), x)


def demodulate_bands(x: np.ndarray, fs: float = FS) -> dict[str, np.ndarray]:
    """Full-source-rate offline bandpass, Hilbert magnitude, then 1-kHz LPF.

    All samples of a single four-second source segment provide filter context.
    This is zero-phase offline processing, not a causal streaming implementation.
    """
    x = np.asarray(x, dtype=float)
    if not np.isfinite(x).all():
        raise ValueError("Nonfinite vibration is not imputed")
    answer = {}
    for name, limits in BANDS.items():
        carrier = sosfiltfilt(butter(4, limits, btype="bandpass", fs=fs, output="sos"), x)
        envelope = np.abs(hilbert(carrier))
        answer[name] = lowpass(envelope, fs, 1000., order=6)
    return answer


def characteristic_orders(geometry: dict | None = None) -> dict[str, float]:
    geometry = geometry or {"n_balls": 9, "ball_diameter_mm": 7.9, "pitch_diameter_mm": 38.5, "contact_angle_degrees": 0.}
    n = geometry["n_balls"]
    ratio = geometry["ball_diameter_mm"] / geometry["pitch_diameter_mm"]
    contact = np.deg2rad(geometry["contact_angle_degrees"])
    r = ratio * np.cos(contact)
    return {"bpfo": float(n/2 * (1-r)), "bpfi": float(n/2 * (1+r)), "bsf": float((1-r*r)/(2*ratio))}


def spectrum(x: np.ndarray, sampling_rate: float) -> tuple[np.ndarray, np.ndarray]:
    return periodogram(np.asarray(x, dtype=float), fs=sampling_rate, window="hann", detrend="constant", scaling="density")


def integrated_energy(frequency: np.ndarray, density: np.ndarray, lower: float, upper: float) -> float:
    """Sum periodogram density times the native Fourier-bin width; upper-exclusive."""
    mask = (frequency >= lower) & (frequency < upper)
    return float(np.sum(density[mask]) * (frequency[1]-frequency[0]))


def feature_block(x: np.ndarray, sampling_rate: float, coordinate: str, amplitude_unit: str,
                  bins: list[tuple[float, float]]) -> tuple[dict, dict]:
    x = np.asarray(x, dtype=float)
    if x.ndim != 1 or len(x) < 3 or not np.isfinite(x).all():
        raise ValueError("Feature input must be finite and one dimensional")
    centered = x-x.mean()
    sd = float(np.sqrt(np.mean(centered**2)))
    rms = float(np.sqrt(np.mean(x*x)))
    ma = float(np.mean(np.abs(x)))
    peak = float(np.max(np.abs(x)))
    nonzero_sd = max(sd, EPS)
    f = {"mean": float(x.mean()), "std": sd, "rms": rms, "peak_abs": peak,
         "peak_to_peak": float(np.ptp(x)), "mean_abs": ma,
         "skewness": float(np.mean(centered**3)/nonzero_sd**3),
         "kurtosis_nonexcess": float(np.mean(centered**4)/nonzero_sd**4),
         "crest_factor": peak/max(rms, EPS), "shape_factor": rms/max(ma, EPS),
         "impulse_factor": peak/max(ma, EPS),
         "clearance_factor": peak/max(float(np.mean(np.sqrt(np.abs(x))))**2, EPS)}
    formulas = {"mean": "mean(x)", "std": "sqrt(mean((x-mean(x))^2)); population SD",
        "rms": "sqrt(mean(x^2))", "peak_abs": "max(abs(x))", "peak_to_peak": "max(x)-min(x)",
        "mean_abs": "mean(abs(x))", "skewness": "mean((x-mean(x))^3)/max(std,eps)^3",
        "kurtosis_nonexcess": "mean((x-mean(x))^4)/max(std,eps)^4; Gaussian=3",
        "crest_factor": "max(abs(x))/max(rms,eps)", "shape_factor": "rms/max(mean_abs,eps)",
        "impulse_factor": "max(abs(x))/max(mean_abs,eps)",
        "clearance_factor": "max(abs(x))/max(mean(sqrt(abs(x)))^2,eps)"}
    dimless = {"skewness", "kurtosis_nonexcess", "crest_factor", "shape_factor", "impulse_factor", "clearance_factor"}
    d = {key: {"unit": "1" if key in dimless else amplitude_unit, "definition": formulas[key]} for key in f}
    q, p = spectrum(x, sampling_rate)
    widths = q[1]-q[0]
    weights = p * widths
    total = float(weights.sum())
    proportions = weights/max(total, EPS)
    centroid = float(np.sum(q*proportions))
    spec = {"spectral_energy": total, "spectral_centroid": centroid,
        "spectral_spread": float(np.sqrt(np.sum((q-centroid)**2*proportions))),
        "spectral_entropy": float(-np.sum(proportions[proportions > 0]*np.log(proportions[proportions > 0]))/np.log(len(q))),
        "spectral_peak": float(q[np.argmax(p[1:])+1]) if total > EPS else 0.}
    units = {"spectral_energy": amplitude_unit+"^2", "spectral_centroid": coordinate,
        "spectral_spread": coordinate, "spectral_entropy": "1", "spectral_peak": coordinate}
    definitions = {"spectral_energy": "sum(Hann, constant-detrended one-sided periodogram density * native bin width)",
        "spectral_centroid": "sum(coordinate*normalized bin energy)",
        "spectral_spread": "sqrt(sum((coordinate-centroid)^2*normalized bin energy))",
        "spectral_entropy": "-sum(p*ln(p))/ln(number of one-sided bins); zero energy -> 0",
        "spectral_peak": "coordinate of maximal non-DC periodogram bin; zero energy -> 0"}
    f.update(spec)
    d.update({key: {"unit": units[key], "definition": definitions[key]} for key in spec})
    for lower, upper in bins:
        tag = f"bin_{lower:g}_{upper:g}".replace(".", "p")
        energy = integrated_energy(q, p, lower, upper)
        f[tag+"_energy"] = energy
        f[tag+"_fraction"] = energy/max(total, EPS)
        d[tag+"_energy"] = {"unit": amplitude_unit+"^2", "definition": f"sum(PSD*dq) for {lower} <= {coordinate} < {upper}"}
        d[tag+"_fraction"] = {"unit": "1", "definition": f"{tag}_energy/max(spectral_energy,eps)"}
    return f, d


def harmonic_features(x: np.ndarray, order_rate: float, orders: dict[str, float]) -> tuple[dict, dict]:
    q, p = spectrum(x, order_rate)
    total = float(p.sum()*(q[1]-q[0]))
    values, definitions = {}, {}
    for fault, order in orders.items():
        for harmonic in [1, 2, 3]:
            center = harmonic*order
            half_width = max(.25, .03*center)
            energy = integrated_energy(q, p, center-half_width, center+half_width)
            tag = f"{fault}_h{harmonic}"
            values[tag+"_energy"] = energy
            values[tag+"_fraction"] = energy/max(total, EPS)
            # Fixed local background, excluding the target and any choice based on labels.
            background = integrated_energy(q, p, center-1., center-half_width) + integrated_energy(q, p, center+half_width, center+1.)
            signal_width = 2*half_width
            background_width = 2-2*half_width
            ratio = (energy/max(signal_width, EPS))/max(background/max(background_width, EPS), EPS)
            values[tag+"_local_density_ratio"] = float(ratio)
            scope = f"ideal {fault.upper()}={order:.12g} orders, harmonic {harmonic}, center={center:.12g}, half-width=max(0.25,0.03*center)={half_width:.12g} orders"
            definitions[tag+"_energy"] = {"unit": "g^2", "definition": "sum(PSD*dq) inside target; "+scope}
            definitions[tag+"_fraction"] = {"unit": "1", "definition": "target energy/max(total Hann non-DC spectral energy,eps); "+scope}
            definitions[tag+"_local_density_ratio"] = {"unit": "1", "definition": "target mean spectral energy density / mean local background energy density; background=center +/-1 order excluding target; "+scope}
    return values, definitions


def filter_gain_audit(fs: float = FS) -> list[dict]:
    """Analytical zero-phase gains and independently injected steady sinusoids."""
    result = []
    t = np.arange(int(2*fs))/fs
    for name, (lower, upper) in BANDS.items():
        sos = butter(4, [lower, upper], btype="bandpass", fs=fs, output="sos")
        center = np.sqrt(lower*upper)
        q, response = sosfreqz(sos, worN=np.array([lower, center, upper]), fs=fs)
        zero_phase_gain = np.abs(response)**2
        pure = np.sin(2*np.pi*center*t)
        filtered = sosfiltfilt(sos, pure)
        interior = slice(int(.5*fs), int(1.5*fs))
        result.append({"band": name, "lower_hz": lower, "upper_hz": upper, "center_hz": float(center),
            "zero_phase_lower_edge_amplitude_gain": float(zero_phase_gain[0]),
            "zero_phase_center_amplitude_gain": float(zero_phase_gain[1]),
            "zero_phase_upper_edge_amplitude_gain": float(zero_phase_gain[2]),
            "empirical_center_rms_ratio": float(np.sqrt(np.mean(filtered[interior]**2)/np.mean(pure[interior]**2))),
            "meaning": "sosfiltfilt amplitude transfer is |single-pass H(f)|^2; band edges are -6.02 dB in amplitude after two passes"})
    return result


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--schema", type=Path, default=ROOT/"data/raw/novic_variable_speed/official_schema_and_pairing.json")
    p.add_argument("--manifest", type=Path, default=ROOT/"data/raw/novic_variable_speed/subsetE_segment_manifest.csv")
    p.add_argument("--v2-pointer", type=Path, default=ROOT/"data/novic_same_interval_preprocessing.json")
    p.add_argument("--output-dir", type=Path, default=ROOT/"data/processed/v3")
    args = p.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    schema = json.loads(args.schema.read_text(encoding="utf-8"))
    raw_path = Path(schema["data_path"])
    raw_meta_path = raw_path.with_suffix(".npy.metadata.json")
    raw_meta = json.loads(raw_meta_path.read_text(encoding="utf-8"))
    if not raw_meta.get("checksum_verified"):
        raise RuntimeError("Only a checksum-verified complete official source may be processed")
    actual_sha = digest(raw_path)
    if actual_sha != raw_meta["sha256"]:
        raise RuntimeError("Raw-data SHA256 differs from the audited official download")
    raw = np.load(raw_path, mmap_mode="r", allow_pickle=False)
    manifest = pd.read_csv(args.manifest, dtype={"misalignment_code": str, "unbalance_code": str})
    if tuple(raw.shape) != (len(manifest), 102400, 9) or schema["sample_rate_hz"] != FS:
        raise ValueError("Unexpected source shape or sample rate")
    old_pointer = json.loads(args.v2_pointer.read_text(encoding="utf-8"))
    frozen_lineage_path = Path(old_pointer["data_path"]).with_name("novic_subsetE_same_interval_v1_lineage.csv")
    old = pd.read_csv(frozen_lineage_path)
    frozen_groups = old[["inferred_source_group", "split", "inner_presence", "outer_presence"]].drop_duplicates()
    if len(frozen_groups) != 79 or frozen_groups.groupby("inferred_source_group").size().max() != 1:
        raise AssertionError("Frozen grouping/labels/splits are inconsistent")
    groups = frozen_groups.set_index("inferred_source_group")
    split_path = args.output_dir/"novic_source_group_manifest.csv"
    frozen_groups.sort_values("inferred_source_group").to_csv(split_path, index=False)
    if set(manifest.inferred_source_group) != set(groups.index):
        raise AssertionError("Source-group population changed")
    geometry = schema["geometry_from_primary_paper"]
    orders = characteristic_orders(geometry)
    block_columns = {name: [] for name in ["metadata_only", "time_lowband", "angle_raw", "time_envelope", "order_envelope"]}
    definitions, records, lineage, exclusions = {}, [], [], []
    views = {key: [] for key in ["time_lowband", "angle_raw", "time_envelope", "order_envelope", "measured_rpm"]}
    filter_checks = filter_gain_audit(FS)
    for rec in manifest.to_dict("records"):
        array_row = int(rec["array_row"])
        group = rec["inferred_source_group"]
        assignment = groups.loc[group]
        if int(assignment.inner_presence) != int(rec["inner_presence"]) or int(assignment.outer_presence) != int(rec["outer_presence"]):
            raise AssertionError("Labels differ from frozen lineage")
        segment = np.asarray(raw[array_row])
        vibration = np.asarray(segment[:, 0], dtype=float)
        rpm = np.asarray(segment[:, 8], dtype=float)
        phase = measured_phase(rpm, FS)
        if not np.isfinite(vibration).all():
            raise ValueError(f"Segment {array_row}: invalid vibration; refusing implicit imputation")
        source_t = np.arange(len(vibration), dtype=float)/FS
        intervals = fixed_turn_intervals(phase)
        if not intervals:
            exclusions.append({"array_row": array_row, "reason": "less than one complete eight-turn measured interval", "available_turns": float(phase[-1])})
            continue
        # Entire-segment filter context never crosses a source recording group.
        envelope = demodulate_bands(vibration, FS)
        lowband = lowpass(vibration, FS, 180., order=6)
        angular_nyquist = (SAMPLES-1)/(2*TURNS)
        # Conservative native-time LPF prevents high-frequency raw vibration from
        # folding into the compressed angular grid at the slowest measured RPM.
        angular_raw_cutoff = .8*angular_nyquist*float(rpm.min())/60.
        angular_safe = lowpass(vibration, FS, angular_raw_cutoff, order=6)
        if float(rpm.min())/60.*angular_nyquist < 1000.:
            raise ValueError("The declared 1-kHz envelope cutoff exceeds conservative angular support")
        for k, (start_turn, stop_turn) in enumerate(intervals):
            coordinates = paired_coordinates(phase, FS, start_turn, stop_turn)
            tgrid = coordinates["time_s"]
            angle_tgrid = coordinates["angle_time_s"]
            speed = np.interp(tgrid, source_t, rpm)
            time_high = np.interp(tgrid, source_t, lowband)
            # Endpoint-retaining rational ratio: output k maps to input k*2047/255.
            time_small = resample_poly(time_high, 255, 2047, padtype="line")
            if len(time_small) != 256:
                raise AssertionError("Expected exactly 256 endpoint-retaining control samples")
            angular = np.interp(angle_tgrid, source_t, angular_safe)
            time_env = np.asarray([np.interp(tgrid, source_t, envelope[band]) for band in BANDS])
            order_env = np.asarray([np.interp(angle_tgrid, source_t, envelope[band]) for band in BANDS])
            sample_id = f"novic_E_{array_row:03d}_turn{k*8:02d}_{(k+1)*8:02d}_physical_v3"
            sample_features = {"sample_id": sample_id}
            def add(block, prefix, values, specs):
                for key, value in values.items():
                    name = prefix+key
                    sample_features[name] = float(value)
                    if name not in definitions:
                        block_columns[block].append(name)
                        definitions[name] = {"block": block, **specs[key]}
            meta = {"rpm_mean": float(speed.mean()), "rpm_std": float(speed.std()), "rpm_min": float(speed.min()),
                "rpm_max": float(speed.max()), "rpm_range": float(np.ptp(speed)), "duration_s": coordinates["duration_s"],
                "actual_turns": stop_turn-start_turn, "rpm_linear_slope": float(np.polyfit(tgrid-tgrid[0], speed, 1)[0])}
            meta_def = {key: {"unit": "s" if key == "duration_s" else "turn" if key == "actual_turns" else "rpm/s" if key == "rpm_linear_slope" else "rpm",
                              "definition": "Descriptive measured bearing-after-gearbox RPM on the 2048-point matched time grid; "+key} for key in meta}
            meta_def["duration_s"]["definition"] = "time of stop-turn boundary minus time of start-turn boundary"
            meta_def["actual_turns"]["definition"] = "stop-turn minus start-turn; fixed at eight, never padded"
            meta_def["rpm_linear_slope"]["definition"] = "OLS slope RPM ~ intercept + elapsed seconds within matched interval"
            add("metadata_only", "meta__", meta, meta_def)
            time_rate = 255/coordinates["duration_s"]
            f, d = feature_block(time_small, time_rate, "Hz", "g", [(i, i+15.) for i in np.arange(0, 180, 15.)])
            add("time_lowband", "time_lowband__", f, d)
            angle_rate = coordinates["angular_sample_rate_per_turn"]
            f, d = feature_block(angular, angle_rate, "order", "g", [(i, i+4.) for i in np.arange(0, 32, 4.)])
            add("angle_raw", "angle_raw__", f, d)
            for j, band in enumerate(BANDS):
                f, d = feature_block(time_env[j], coordinates["time_sample_rate_hz"], "Hz", "g", [(i, i+100.) for i in np.arange(0, 1000, 100.)])
                add("time_envelope", f"time_envelope__{band}__", f, d)
                f, d = feature_block(order_env[j], angle_rate, "order", "g", [(i, i+4.) for i in np.arange(0, 32, 4.)])
                extra, extra_defs = harmonic_features(order_env[j], angle_rate, orders)
                f.update(extra); d.update(extra_defs)
                add("order_envelope", f"order_envelope__{band}__", f, d)
            if not np.isfinite([v for key, v in sample_features.items() if key != "sample_id"]).all():
                raise AssertionError("Nonfinite features must not reach model fitting")
            records.append(sample_features)
            start_s, stop_s = float(tgrid[0]), float(tgrid[-1])
            lineage.append({"sample_id": sample_id, "array_row": array_row, "upstream_name": rec["upstream_name"],
                "inferred_source_group": group, "group_status": "filename-derived recording proxy; physical-bearing independence unknown",
                "split": assignment.split, "subset": rec["subset"], "inner_presence": int(rec["inner_presence"]),
                "outer_presence": int(rec["outer_presence"]), "misalignment_code": rec["misalignment_code"], "unbalance_code": rec["unbalance_code"],
                "window_index": k, "start_turn": start_turn, "stop_turn": stop_turn, "actual_turns": stop_turn-start_turn,
                "physical_start_s": start_s, "physical_stop_s": stop_s, "duration_s": coordinates["duration_s"],
                "start_source_sample_float": start_s*FS, "stop_source_sample_float": stop_s*FS,
                "source_start_floor": int(np.floor(start_s*FS)), "source_stop_ceil": int(np.ceil(stop_s*FS)),
                "time_lowband_samples": 256, "angle_samples": SAMPLES, "time_envelope_samples": SAMPLES,
                "time_lowband_rate_hz": time_rate, "time_lowband_nyquist_hz": time_rate/2,
                "time_lowband_prior_cutoff_hz": 180., "angle_rate_per_turn": angle_rate, "angular_nyquist_order": angular_nyquist,
                "angular_raw_native_lowpass_hz": angular_raw_cutoff, "envelope_native_lowpass_hz": 1000.,
                "conservative_minrpm_angular_nyquist_hz": float(rpm.min())/60.*angular_nyquist,
                "bpfi_fundamental_resolved": bool(orders["bpfi"] < angular_nyquist),
                "bpfi_third_harmonic_resolved": bool(3*orders["bpfi"] < angular_nyquist),
                "endpoint_max_difference_s": max(abs(tgrid[0]-angle_tgrid[0]), abs(tgrid[-1]-angle_tgrid[-1])),
                "source_filter_context": "same full four-second segment; zero-phase offline processing",
                "touches_source_start": bool(start_s == 0.), "source_sha256": actual_sha,
                "frozen_lineage_sha256": digest(frozen_lineage_path) if not lineage else lineage[0]["frozen_lineage_sha256"]})
            for key, values in [("time_lowband", time_small), ("angle_raw", angular), ("time_envelope", time_env), ("order_envelope", order_env), ("measured_rpm", speed)]:
                views[key].append(np.asarray(values, dtype=np.float32))
        if array_row % 10 == 0:
            print(f"Prepared source segment {array_row+1}/{len(manifest)}; complete intervals={len(records)}", flush=True)
    feature_table = pd.DataFrame(records)
    lineage_table = pd.DataFrame(lineage)
    if lineage_table.groupby("inferred_source_group").split.nunique().max() != 1:
        raise AssertionError("A source recording group crosses a split")
    for _, subset in lineage_table.groupby("array_row"):
        ordered = subset.sort_values("window_index")
        if np.any(ordered.physical_start_s.to_numpy()[1:] < ordered.physical_stop_s.to_numpy()[:-1] - 1e-12):
            raise AssertionError("Physical interval interiors overlap")
    feature_path = args.output_dir/"novic_physical_features.csv"
    lineage_path = args.output_dir/"novic_physical_lineage.csv"
    views_path = args.output_dir/"novic_physical_views.npz"
    feature_table.to_csv(feature_path, index=False)
    lineage_table.to_csv(lineage_path, index=False)
    np.savez_compressed(views_path, sample_id=lineage_table.sample_id.to_numpy(dtype=str),
        **{key: np.asarray(values) for key, values in views.items()}, band_names=np.array(list(BANDS)),
        labels=lineage_table[["inner_presence", "outer_presence"]].to_numpy(dtype=np.int64))
    blocks_path = args.output_dir/"novic_physical_feature_blocks.json"
    blocks_path.write_text(json.dumps({"schema_version": "physical-v3.1", "sample_id_column": "sample_id", "blocks": block_columns,
        "feature_definitions": definitions, "definitions_count": len(definitions), "missing_value_rule": "fail on nonfinite; no imputation",
        "normalization": "No data-dependent scaling here; model pipeline must fit all scalers on training groups only",
        "coordinate_units": {"time_spectrum": "Hz", "angle_spectrum": "order = cycles/shaft revolution", "vibration": "source g (source paper defines g as 9.8 m/s^2)"}}, indent=2), encoding="utf-8")
    exclusion_path = args.output_dir/"novic_physical_exclusions.json"
    exclusion_path.write_text(json.dumps(exclusions, indent=2), encoding="utf-8")
    source_paths = [raw_path, raw_meta_path, args.schema, args.manifest, args.v2_pointer, frozen_lineage_path, Path(__file__).resolve()]
    outputs = [feature_path, lineage_path, views_path, blocks_path, split_path, exclusion_path]
    audit = {"status": "new physical preprocessing complete; no model fitting or test-result consultation",
        "schema_version": "physical-v3.1", "created_utc": datetime.now(timezone.utc).isoformat(),
        "source_doi": schema["dataset_doi"], "source_segments": len(manifest), "source_groups": len(groups),
        "physical_bearing_count": None, "source_channels": {"vibration": 0, "bearing_shaft_rpm": 8},
        "source_sample_rate_hz": FS, "input_shape": list(raw.shape), "derived_intervals": len(lineage),
        "derived_intervals_per_segment": lineage_table.groupby("array_row").size().value_counts().sort_index().to_dict(),
        "window_counts_by_split": lineage_table.split.value_counts().to_dict(),
        "window_counts_by_subset": lineage_table.subset.value_counts().to_dict(),
        "feature_blocks": {key: len(value) for key, value in block_columns.items()}, "total_features": len(definitions),
        "phase_definition": "phase[0]=0; phase[k]=sum_{i=1..k}(rpm[i-1]+rpm[i])/(120*25600), in measured turns",
        "interval_selection": "first min(4,floor(measured_turns/8)) complete intervals; fixed eight turns each; adjacent intervals share only a zero-measure boundary; no padding",
        "offline_context": "SOS zero-phase filtering and Hilbert on each original four-second segment before crop; full-segment future context retained; not a causal streaming pipeline",
        "lowband_control": "native 180-Hz Butterworth LP order6, same interval mapped to 2048 equal-time points then endpoint-retaining resample_poly(255,2047,padtype=line) ->256",
        "angular_raw_antialias": "native LP order6 at 0.8*angular_Nyquist_order*segment_min_RPM/60 before phase mapping; cutoff depends only on measured RPM, not labels",
        "envelope_extraction": "native25.6kHz fixed Butterworth bandpass order4, sosfiltfilt, abs(Hilbert), native1kHz LP order6; no carrier downsampling before demodulation",
        "filter_gain_checks": filter_checks,
        "geometry": {**geometry, "source_url": "https://arxiv.org/pdf/2505.24001", "source_doi": "10.1016/j.ymssp.2025.113786",
            "primary_locator": "Section5.1, PDF page11 (index10), lines361-370 in verified text", "verified_on": "2026-10-20",
            "assumptions": "ideal characteristic orders, no slip, documented zero contact angle, no load-dependent correction"},
        "characteristic_orders": orders, "harmonics": [1,2,3],
        "target_band_half_width_orders": "max(0.25,0.03*harmonic*ideal_fault_order); fixed before model fitting",
        "angular_grid_samples": SAMPLES, "angular_extent_turns": TURNS, "angular_nyquist_order": (SAMPLES-1)/(2*TURNS),
        "angular_fourier_bin_width_order": (SAMPLES-1)/(TURNS*SAMPLES),
        "all_bpfi_third_harmonics_below_grid_nyquist": bool(lineage_table.bpfi_third_harmonic_resolved.all()),
        "duration_range_s": [float(lineage_table.duration_s.min()), float(lineage_table.duration_s.max())],
        "maximum_physical_endpoint_difference_s": float(lineage_table.endpoint_max_difference_s.max()),
        "no_interval_interior_overlap": True, "no_source_group_crosses_frozen_split": True,
        "all_features_finite": bool(np.isfinite(feature_table.drop(columns="sample_id").to_numpy()).all()),
        "raw_path_unchanged": True, "frozen_v2_artifacts_unchanged": True,
        "inputs": [{"path": str(path.resolve()), "sha256": actual_sha if path == raw_path else digest(path)} for path in source_paths],
        "outputs": [{"path": str(path.resolve()), "sha256": digest(path), "bytes": path.stat().st_size} for path in outputs],
        "software": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__, "pandas": pd.__version__},
        "limitations": ["The same79 inferred recording proxies do not establish independent physical bearings or an independent rig.",
            "First interval begins at upstream segment boundary; finite-segment Hilbert and zero-phase filter boundary effects remain possible and are disclosed.",
            "The fixed prior bands are not claimed to be measured rig resonances, optimized bands, or a new signal-processing invention.",
            "Four-second source segments can be temporally distant or adjacent within an inferred source recording; source-group isolation is retained.",
            "Ideal frequency support is not empirical proof of fault observability, classification accuracy, or physical validation.",
            "Filtering and phase interpolation are deterministic; train/test label inspection is not used to choose them."]}
    audit_path = args.output_dir/"preprocessing_audit.json"
    audit_path.write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(json.dumps({"audit": str(audit_path), "intervals": len(lineage), "groups": len(groups),
        "features": len(definitions), "blocks": audit["feature_blocks"], "output_bytes": sum(path.stat().st_size for path in outputs)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
