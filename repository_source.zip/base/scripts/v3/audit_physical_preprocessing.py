"""Read-only-to-input v3 coordinate, provenance and injected-signal audit.

This program never opens a classification score or fitted model. Its generated
artifacts are physical QA data, not additional measured validation samples.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.signal import butter, sosfreqz

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location("physical_v3", ROOT/"scripts/v3/prepare_novic_physical_features.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    folder = ROOT/"data/processed/v3"
    audit = json.loads((folder/"preprocessing_audit.json").read_text(encoding="utf-8"))
    blocks = json.loads((folder/"novic_physical_feature_blocks.json").read_text(encoding="utf-8"))
    feature = pd.read_csv(folder/"novic_physical_features.csv")
    lineage = pd.read_csv(folder/"novic_physical_lineage.csv")
    arrays = np.load(folder/"novic_physical_views.npz", allow_pickle=False)
    source = np.load(audit["inputs"][0]["path"], mmap_mode="r", allow_pickle=False)
    assert (feature.sample_id == lineage.sample_id).all()
    assert np.array_equal(arrays["sample_id"], lineage.sample_id.to_numpy())
    assert np.array_equal(arrays["labels"], lineage[["inner_presence", "outer_presence"]].to_numpy())
    expected_columns = [name for value in blocks["blocks"].values() for name in value]
    assert len(expected_columns) == len(set(expected_columns)) == 373
    assert set(expected_columns) == set(feature.columns)-{"sample_id"}
    assert set(expected_columns) == set(blocks["feature_definitions"])
    assert np.isfinite(feature[expected_columns]).all().all()
    assert lineage.inferred_source_group.nunique() == 79
    assert lineage.groupby("inferred_source_group").split.nunique().max() == 1
    max_duration_error, max_phase_error, max_float32_rms_error = 0., 0., 0.
    for row_index, segment_rows in lineage.groupby("array_row", sort=True):
        rpm = np.asarray(source[int(row_index), :, 8], dtype=float)
        # Independent explicit trapezoid re-expression rather than reusing the extractor API.
        dt = 1/25600.
        turns = np.zeros(len(rpm))
        turns[1:] = np.cumsum(.5*(rpm[:-1]/60.+rpm[1:]/60.)*dt)
        t = np.arange(len(rpm))*dt
        for row in segment_rows.itertuples():
            start_s = np.interp(row.start_turn, turns, t)
            stop_s = np.interp(row.stop_turn, turns, t)
            error = max(abs(start_s-row.physical_start_s), abs(stop_s-row.physical_stop_s))
            max_duration_error = max(max_duration_error, error)
            phase_error = abs(np.interp(stop_s,t,turns)-np.interp(start_s,t,turns)-8.)
            max_phase_error = max(max_phase_error, phase_error)
        ordered = segment_rows.sort_values("window_index")
        assert np.allclose(ordered.physical_start_s.to_numpy()[1:], ordered.physical_stop_s.to_numpy()[:-1], atol=1e-13)
    for i in range(len(lineage)):
        rms = float(np.sqrt(np.mean(arrays["time_lowband"][i].astype(float)**2)))
        max_float32_rms_error = max(max_float32_rms_error, abs(rms-feature.iloc[i]["time_lowband__rms"]))
    assert max_duration_error < 1e-11
    assert max_phase_error < 1e-10
    assert max_float32_rms_error < 1e-7
    for item in audit["outputs"]:
        assert digest(item["path"]) == item["sha256"], item["path"]
    for item in audit["inputs"]:
        assert digest(item["path"]) == item["sha256"], item["path"]
    # Explicit finite antialias rolloff: these filters attenuate rather than
    # mathematically erase all energy above the compressed grid's Nyquist.
    minimum_nyquist = float(lineage.conservative_minrpm_angular_nyquist_hz.min())
    attenuation = []
    for kind, cutoff in [("raw_angular_worst_support", .8*minimum_nyquist), ("envelope_fixed_1kHz", 1000.)]:
        sos = butter(6, cutoff, btype="lowpass", fs=25600., output="sos")
        _, response = sosfreqz(sos, worN=np.array([minimum_nyquist]), fs=25600.)
        amplitude = float(abs(response[0])**2)
        attenuation.append({"path": kind, "native_cutoff_hz": cutoff, "minimum_grid_nyquist_hz": minimum_nyquist,
            "zero_phase_amplitude_gain_at_grid_nyquist": amplitude, "amplitude_db_at_grid_nyquist": float(20*np.log10(amplitude)),
            "interpretation": "finite antialias attenuation, not zero alias energy or measured noise rejection"})
    fs = 25600.
    t = np.arange(int(4*fs))/fs
    metrics, spectra, traces = [], [], []
    for speed_profile in ["constant_1800rpm", "sinusoidal_1800plus600rpm"]:
        rpm = np.full(len(t),1800.) if speed_profile.startswith("constant") else 1800.+600.*np.sin(2*np.pi*.23*t)
        phase = np.r_[0., np.cumsum((rpm[:-1]+rpm[1:])/(120.*fs))]
        coordinates = m.paired_coordinates(phase, fs, 32., 40.)
        for band, carrier_hz in {"b500_2000": 1200., "b2000_5000": 3300., "b5000_10000": 7500.}.items():
            for fault, order in m.characteristic_orders().items():
                injection = (1+.6*np.cos(2*np.pi*order*phase))*np.cos(2*np.pi*carrier_hz*t)
                env = m.demodulate_bands(injection, fs)[band]
                angular = np.interp(coordinates["angle_time_s"],t,env)
                q, power = m.spectrum(angular, (2048-1)/8.)
                peak = q[np.argmax(power[1:])+1]
                target = m.integrated_energy(q,power,order-.25,order+.25)
                background = m.integrated_energy(q,power,order+.75,order+1.25)
                ratio = target/max(background,1e-15)
                assert abs(peak-order) < .14
                assert ratio > 40
                metrics.append({"speed_profile": speed_profile, "band": band, "carrier_hz": carrier_hz, "injected_fault_order": fault,
                    "ideal_order": order, "observed_peak_order": float(peak), "absolute_peak_error_order": abs(float(peak)-order),
                    "target_order_energy_g2": target, "fixed_control_order_energy_g2": background,
                    "target_to_control_energy_ratio": ratio, "scope": "noise-free known-order injection; not a measured fault or model performance"})
                if fault == "bpfi" and speed_profile.startswith("sinusoidal"):
                    for frequency, density in zip(q[q<32], power[q<32]):
                        spectra.append({"band": band, "carrier_hz": carrier_hz, "order": frequency, "envelope_psd_g2_per_order": density, "ideal_bpfi_order": order})
                    if band == "b2000_5000":
                        for k in range(0,len(t),64):
                            traces.append({"time_s": t[k], "measured_profile_rpm": rpm[k], "analytic_phase_turns": phase[k],
                                "injected_carrier_g": injection[k], "full_resolution_envelope_g": env[k],
                                "known_modulating_envelope_g": 1+.6*np.cos(2*np.pi*order*phase[k])})
    metrics_path = folder/"physical_injection_calibration.csv"
    spectra_path = folder/"physical_injection_spectrum_source.csv"
    trace_path = folder/"physical_injection_trace_source.csv"
    pd.DataFrame(metrics).to_csv(metrics_path,index=False)
    pd.DataFrame(spectra).to_csv(spectra_path,index=False)
    pd.DataFrame(traces).to_csv(trace_path,index=False)
    report = {"status": "PASS", "checked_intervals": len(lineage), "checked_features": len(expected_columns), "source_groups":79,
        "maximum_independent_endpoint_error_s": max_duration_error, "maximum_turn_extent_error": max_phase_error,
        "maximum_stored_float32_rms_discrepancy": max_float32_rms_error,
        "all_registered_input_and_output_hashes_match": True, "all_sample_ids_labels_and_group_partitions_match":True,
        "all_373_definitions_match_feature_columns": True, "all_feature_values_finite":True,
        "known_order_injection_cases": len(metrics), "all_known_order_peak_errors_below_0p14":True,
        "all_known_order_target_to_control_energy_ratios_above_40":True,
        "worst_known_order_peak_error": max(row["absolute_peak_error_order"] for row in metrics),
        "minimum_known_order_target_to_control_energy_ratio": min(row["target_to_control_energy_ratio"] for row in metrics),
        "antialias_rolloff": attenuation,
        "source_paper_verification": {"url":"https://arxiv.org/pdf/2505.24001", "doi":"10.1016/j.ymssp.2025.113786",
            "locator":"Section5.1, PDF page11", "verified_fields":["NSK6205","9 balls","ball diameter7.90mm","pitch diameter38.5mm","contact angle0deg","sample rate25.6kHz","g=9.8m/s^2"],
            "verification_date":"2026-10-20"},
        "artifacts":[{"path":str(path.resolve()),"sha256":digest(path)} for path in [metrics_path,spectra_path,trace_path]],
        "limitations":["Injected signals check numerical and physical consistency, not empirical robustness or new physical specimens.",
            "The raw angular lowpass has finite attenuation at Nyquist; aliases are attenuated, not mathematically excluded.",
            "1kHz envelope lowpass has finite rolloff; all claims remain bounded by grid support and filtering.",
            "Filter/Hilbert boundary effects, fixed prior bands, shared-rig data and inferred recording proxies remain limitations."]}
    path = ROOT/"results/v3_physical_preprocessing_integrity.json"
    path.write_text(json.dumps(report,indent=2),encoding="utf-8")
    print(json.dumps(report,indent=2))


if __name__ == "__main__":
    main()
