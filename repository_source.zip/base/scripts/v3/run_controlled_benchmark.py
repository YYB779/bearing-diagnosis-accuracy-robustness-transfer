"""Frozen, group-aware physical-representation controls for the v3 revision.

This is a retrospective computational extension on previously inspected public
data, not a preregistered independent validation or new physical experiment.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import (average_precision_score, balanced_accuracy_score,
                            brier_score_loss, confusion_matrix, f1_score,
                            log_loss, roc_auc_score)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

ROOT = Path(__file__).resolve().parents[2]
TASKS = ("inner_presence", "outer_presence")
PROTOCOLS = ("record_holdout", "unseen_A", "unseen_B", "unseen_C")
REPRESENTATIONS = ("metadata_only", "time_lowband", "angle_raw", "time_envelope",
                   "order_envelope_generic", "order_envelope")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+"\n", encoding="utf-8")


def group_probabilities(frame, y, p):
    table = pd.DataFrame({"group": frame.inferred_source_group.to_numpy(), "y": y, "p": p})
    if table.groupby("group").y.nunique().max() != 1:
        raise ValueError("one source group has conflicting labels")
    return table.groupby("group", sort=True).agg(y=("y", "first"), p=("p", "mean"))


def scores(y, p):
    y, p = np.asarray(y, dtype=int), np.asarray(p, dtype=float)
    assert np.isfinite(p).all() and np.all((p >= 0) & (p <= 1))
    pred = (p >= 0.5).astype(int)
    nclass = len(np.unique(y))
    bins = np.minimum((p * 10).astype(int), 9)
    # Binary calibration error, signed event frequency against p(Y=1).
    ece = sum(np.mean(bins == b)*abs(p[bins == b].mean()-y[bins == b].mean())
              for b in range(10) if np.any(bins == b))
    return {"n": len(y), "positive": int(y.sum()),
            "macro_f1": float(f1_score(y, pred, labels=[0, 1], average="macro", zero_division=0)),
            "balanced_accuracy": float(balanced_accuracy_score(y, pred)) if nclass == 2 else None,
            "auroc": float(roc_auc_score(y, p)) if nclass == 2 else None,
            "average_precision": float(average_precision_score(y, p)) if y.sum() else None,
            "nll": float(log_loss(y, np.column_stack((1-p, p)), labels=[0, 1])),
            "brier_binary": float(brier_score_loss(y, p)), "ece10_binary": float(ece),
            "confusion_matrix": confusion_matrix(y, pred, labels=[0, 1]).tolist()}


def make_protocol(frame, protocol):
    groups = frame.drop_duplicates("inferred_source_group").copy().reset_index(drop=True)
    if groups.groupby("inferred_source_group").size().max() != 1:
        raise ValueError("duplicate groups")
    if protocol == "record_holdout":
        result = frame["split"].copy()
    else:
        held = protocol.removeprefix("unseen_")
        subset = groups["subset"].astype(str).str.replace("subset", "", regex=False)
        test = subset.eq(held)
        pool = groups.loc[~test].reset_index(drop=True)
        strata = pool.inner_presence.astype(int) + 2*pool.outer_presence.astype(int)
        cv = StratifiedGroupKFold(n_splits=4, shuffle=True, random_state=20261020)
        # A fixed fold, independent of every model's validation/test performance.
        tr, va = next(cv.split(np.zeros((len(pool), 1)), strata, pool.inferred_source_group))
        assignment = {name:"test" for name in groups.loc[test, "inferred_source_group"]}
        assignment.update({name:"train" for name in pool.iloc[tr].inferred_source_group})
        assignment.update({name:"validation" for name in pool.iloc[va].inferred_source_group})
        result = frame.inferred_source_group.map(assignment)
    assert result.notna().all()
    audit = pd.DataFrame({"group":frame.inferred_source_group,"split":result})
    assert audit.groupby("group").split.nunique().max() == 1
    masks = {split:result.eq(split).to_numpy() for split in ("train", "validation", "test")}
    for task in TASKS:
        for name, mask in masks.items():
            if set(frame.loc[mask,task].astype(int)) != {0,1}:
                raise ValueError(f"{protocol}/{task}/{name} has one class; preserve as infeasible")
    return result, masks


def block_columns(blocks, representation):
    metadata = list(blocks["metadata_only"])
    if representation == "metadata_only":
        return metadata
    if representation == "order_envelope_generic":
        values = [c for c in blocks["order_envelope"]
                  if not any(token in c.lower() for token in ("bpfi", "bpfo", "bsf", "ftf", "harmonic"))]
    else:
        values = list(blocks[representation])
    return list(dict.fromkeys(metadata+values))


def fit_candidate(name, x, y, frame, seed, config):
    if name == "extra_trees":
        model = ExtraTreesClassifier(n_estimators=200, min_samples_leaf=config["min_samples_leaf"],
                                     max_features=1.0, class_weight="balanced", random_state=seed, n_jobs=2)
    else:
        folds = list(StratifiedGroupKFold(n_splits=3, shuffle=True, random_state=seed).split(
            x, y, frame.inferred_source_group.to_numpy()))
        for fit, cal in folds:
            assert not set(frame.iloc[fit].inferred_source_group) & set(frame.iloc[cal].inferred_source_group)
            if len(np.unique(y[fit])) != 2 or len(np.unique(y[cal])) != 2:
                raise ValueError("one-class calibration fold")
        base = make_pipeline(StandardScaler(), SVC(C=config["C"], kernel="rbf", gamma="scale", class_weight="balanced"))
        model = CalibratedClassifierCV(base, method="sigmoid", cv=folds, n_jobs=1)
    model.fit(x, y)
    return model


def run(args):
    features_path = ROOT / "data/processed/v3/novic_physical_features.csv"
    lineage_path = ROOT / "data/processed/v3/novic_physical_lineage.csv"
    blocks_path = ROOT / "data/processed/v3/novic_physical_feature_blocks.json"
    feature_table = pd.read_csv(features_path)
    frame = pd.read_csv(lineage_path)
    raw_blocks = json.loads(blocks_path.read_text(encoding="utf-8"))
    blocks = raw_blocks.get("blocks", raw_blocks)
    if isinstance(blocks, list):
        raise ValueError("feature blocks must map names to column lists")
    blocks = {k:(v["columns"] if isinstance(v, dict) else v) for k,v in blocks.items()}
    if "sample_id" in feature_table:
        assert np.array_equal(feature_table.sample_id, frame.sample_id)
    assert len(frame) == len(feature_table)
    out = ROOT / "results/v3/controlled_benchmark"
    out.mkdir(parents=True, exist_ok=True)
    scenarios = {}
    assignments = []
    for protocol in PROTOCOLS:
        assigned, masks = make_protocol(frame, protocol)
        scenarios[protocol] = masks
        assignment = frame[["sample_id", "inferred_source_group", "subset", *TASKS]].copy()
        assignment["protocol"] = protocol; assignment["assigned_split"] = assigned
        assignments.append(assignment)
    assignment_path = out / "split_assignments.csv"
    pd.concat(assignments).to_csv(assignment_path, index=False)
    registration = {
        "design_frozen_utc": datetime.now(timezone.utc).isoformat(),
        "status": "retrospective public-data revision; frozen before v3 model fitting; v2 test results were known",
        "hypotheses": ["retaining resonance envelopes changes diagnosis beyond metadata-only and low-band input",
                       "order-coordinate features differ from time-envelope features on exactly the same intervals",
                       "gains persist or fail under withheld A/B/C speed subsets and source-record aggregation"],
        "primary_endpoint":"equal-record Macro-F1 at fixed probability 0.5; window Macro-F1 secondary",
        "independent_unit":"inferred acquisition recording; physical bearing identity remains unknown",
        "protocols":list(PROTOCOLS), "tasks":list(TASKS), "representations":list(REPRESENTATIONS),
        "models":{"extra_trees":{"seeds":[11,22,33],"grid":{"min_samples_leaf":[1,3]}},
                  "group_calibrated_svm":{"seeds":[11],"grid":{"C":[0.1,1.,10.]}}},
        "planned_selected_models":len(PROTOCOLS)*len(TASKS)*len(REPRESENTATIONS)*4,
        "tuning":"maximum validation equal-record Macro-F1, then lower NLL, then first grid item; no test selection",
        "metadata_budget":"same metadata columns appended to every representation; metadata-only is negative control",
        "uncertainty":"record bootstrap conditional on selected models and one fixed split; withheld subsets are 3 correlated domain tests, not population replication",
        "sha256":{str(p.relative_to(ROOT)):digest(p) for p in (features_path,lineage_path,blocks_path,Path(__file__),assignment_path)},
        "software":{"numpy":np.__version__,"pandas":pd.__version__},
    }
    registration_path = out / "design.json"
    if registration_path.exists():
        old = json.loads(registration_path.read_text(encoding="utf-8"))
        registration["design_frozen_utc"] = old["design_frozen_utc"]
        if registration != old:
            raise ValueError("frozen design changed; do not resume in existing directory")
    else:
        write_json(registration_path, registration)
    for protocol, masks in scenarios.items():
        for task in TASKS:
            y = frame[task].to_numpy(int)
            for representation in REPRESENTATIONS:
                cols = block_columns(blocks, representation)
                x = feature_table[cols].to_numpy(float)
                assert np.isfinite(x).all()
                for name, seeds, grid in [
                    ("extra_trees", [11,22,33], [{"min_samples_leaf":1},{"min_samples_leaf":3}]),
                    ("group_calibrated_svm", [11], [{"C":.1},{"C":1.},{"C":10.}]),
                ]:
                    for seed in seeds:
                        stem = f"{protocol}_{task}_{representation}_{name}_s{seed}"
                        path = out / (stem+".json")
                        if path.exists():
                            continue
                        start = time.perf_counter(); selected = None; best = (-1., -float("inf")); candidates=[]
                        for config in grid:
                            model = fit_candidate(name, x[masks["train"]], y[masks["train"]], frame.loc[masks["train"]].reset_index(drop=True), seed, config)
                            vp = model.predict_proba(x[masks["validation"]])[:,1]
                            vg = group_probabilities(frame.loc[masks["validation"]],y[masks["validation"]],vp)
                            vm = scores(vg.y.to_numpy(),vg.p.to_numpy())
                            key = (vm["macro_f1"], -vm["nll"])
                            candidates.append({"config":config,"validation_record":vm})
                            if key > best:
                                best=key; selected=model; chosen=config; selected_vp=vp
                        tp = selected.predict_proba(x[masks["test"]])[:,1]
                        rows=[]; metrics={}
                        for split,p in (("validation",selected_vp),("test",tp)):
                            sf = frame.loc[masks[split]].reset_index(drop=True)
                            sy = y[masks[split]]
                            sg = group_probabilities(sf,sy,p)
                            metrics[split]={"window":scores(sy,p),"record":scores(sg.y.to_numpy(),sg.p.to_numpy())}
                            for i in range(len(sf)):
                                rows.append({"sample_id":sf.iloc[i].sample_id,"group":sf.iloc[i].inferred_source_group,
                                             "subset":sf.iloc[i].subset,"split":split,"label":int(sy[i]),"p1":float(p[i])})
                        prediction_path=out/(stem+"_predictions.csv")
                        pd.DataFrame(rows).to_csv(prediction_path,index=False)
                        model_path=out/(stem+".joblib")
                        joblib.dump(selected,model_path,compress=3)
                        result={"protocol":protocol,"task":task,"representation":representation,"model":name,"seed":seed,
                                "feature_columns":cols,"n_features":len(cols),"selected_config":chosen,"candidates":candidates,
                                **metrics,"seconds":time.perf_counter()-start,"test_predict_calls":1,
                                "design_sha256":digest(registration_path),"predictions":prediction_path.name,
                                "predictions_sha256":digest(prediction_path),"model_sha256":digest(model_path)}
                        write_json(path,result)
                        print(f"DONE {stem}: record F1 {metrics['test']['record']['macro_f1']:.3f}, window {metrics['test']['window']['macro_f1']:.3f}",flush=True)
    print("Completed frozen v3 selected-model matrix",flush=True)


if __name__ == "__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    run(parser.parse_args())
