"""Audit saved probabilities, summarize all v3 runs, and draw measured-data figures.

No training, tuning or new test inference is performed here. Bootstrap intervals
are exploratory, conditional on one fixed fitted seed and inferred source groups.
"""
from __future__ import annotations
import hashlib
import json
import string
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import pandas as pd
from scipy.signal import butter, periodogram, sosfreqz
from sklearn.metrics import roc_curve, precision_recall_curve

from scripts.v3.run_controlled_benchmark import ROOT, PROTOCOLS, TASKS, REPRESENTATIONS, digest, write_json

FIG = ROOT/'figures/v3'
SRC = FIG/'source_data'
OUT = ROOT/'results/v3/analysis'
COLORS = {'metadata_only':'#009E73','time_lowband':'#6B7280','angle_raw':'#CC79A7',
          'time_envelope':'#D55E00','order_envelope_generic':'#56B4E9','order_envelope':'#0072B2',
          'lowband_256':'#6B7280','time_middle_256':'#E69F00','order_middle_256':'#56B4E9',
          'time_middle_2048':'#D55E00','order_middle_2048':'#0072B2'}
LABELS = {'metadata_only':'Metadata','time_lowband':'Low-band raw','angle_raw':'Angular raw',
          'time_envelope':'Time envelope','order_envelope_generic':'Order envelope','order_envelope':'Order + geometry',
          'lowband_256':'Raw 256','time_middle_256':'Time 256','order_middle_256':'Order 256',
          'time_middle_2048':'Time 2048','order_middle_2048':'Order 2048'}
P_LABEL = {'record_holdout':'Record holdout','unseen_A':'Hold out A','unseen_B':'Hold out B','unseen_C':'Hold out C'}
M_LABEL = {'extra_trees':'Extra Trees','group_calibrated_svm':'Calibrated SVM'}
manifest = []


def style():
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,
        'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
        'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6,
        'lines.linewidth':1.,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
        'savefig.dpi':300,'figure.facecolor':'white','axes.facecolor':'white'})


def panel(ax, letter, title):
    ax.set_title(title,loc='left',pad=8)
    ax.text(-.13,1.08,letter,transform=ax.transAxes,fontweight='bold',fontsize=11,va='bottom')
    ax.tick_params(width=.6,length=3)


def save(fig, stem, caption, sources, alt):
    fig.set_size_inches(180/25.4,fig.get_size_inches()[1])
    for ext in ('pdf','png','svg'):
        fig.savefig(FIG/f'{stem}.{ext}',bbox_inches='tight',pad_inches=.08)
    plt.close(fig)
    (FIG/f'{stem}_caption.md').write_text(caption+'\n\nAlt text: '+alt+'\n',encoding='utf-8')
    manifest.append({'figure':stem,'caption':caption,'alt_text':alt,'script':str(Path(__file__).relative_to(ROOT)),
                     'script_sha256':digest(Path(__file__)),
                     'source_data':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p)} for p in sources],
                     'exports':[{ 'path':str((FIG/f'{stem}.{e}').relative_to(ROOT)),
                                  'sha256':digest(FIG/f'{stem}.{e}')} for e in ('pdf','png','svg')]})


def csv(frame,name):
    p=SRC/(name+'.csv'); frame.to_csv(p,index=False); return p


def manual_binary(y,p):
    y=np.asarray(y,int); p=np.asarray(p,float); z=p>=.5
    tn=np.sum((y==0)&~z); fp=np.sum((y==0)&z); fn=np.sum((y==1)&~z); tp=np.sum((y==1)&z)
    f1=.5*((2*tn/(2*tn+fp+fn)) if 2*tn+fp+fn else 0)+.5*((2*tp/(2*tp+fp+fn)) if 2*tp+fp+fn else 0)
    eps=np.finfo(float).eps
    clipped=np.clip(p,eps,1-eps)
    return {'macro_f1':float(f1),'nll':float(-np.mean(y*np.log(clipped)+(1-y)*np.log(1-clipped))),
            'brier_binary':float(np.mean((p-y)**2))}


def record_predictions(path):
    rows=pd.read_csv(path); rows=rows[rows.split.eq('test')]
    assert rows.groupby('group').label.nunique().max()==1
    return rows.groupby('group',sort=True).agg(label=('label','first'),p1=('p1','mean'),subset=('subset','first'))


def load_matrix(folder,expected):
    entries=[]; audit=[]
    design=folder/'design.json'
    for p in sorted(folder.glob('*.json')):
        if p.name=='design.json': continue
        value=json.loads(p.read_text(encoding='utf-8'))
        if 'representation' not in value or 'test' not in value: continue
        assert digest(design)==value['design_sha256']
        pp=folder/value['predictions']
        assert digest(pp)==value['predictions_sha256']
        assert digest(p.with_suffix('.joblib'))==value['model_sha256']
        raw=pd.read_csv(pp); test=raw[raw.split.eq('test')]; grouped=record_predictions(pp)
        for level,ys,ps in [('window',test.label,test.p1),('record',grouped.label,grouped.p1)]:
            diffs={k:abs(v-value['test'][level][k]) for k,v in manual_binary(ys,ps).items()}
            assert max(diffs.values())<1e-9,(p,level,diffs)
            audit.append({'run':p.stem,'level':level,'maximum_metric_difference':max(diffs.values()),'hashes_match':True})
        row={k:value[k] for k in ('protocol','task','representation','model','seed','n_features','seconds')}
        row['path']=str(p.relative_to(ROOT)); row['predictions_path']=str(pp.relative_to(ROOT))
        row['record_n']=value['test']['record']['n']
        for level in ('record','window'):
            row.update({f'{level}_{k}':v for k,v in value['test'][level].items() if isinstance(v,(float,int))})
        entries.append(row)
    assert len(entries)==expected,(folder,len(entries),expected)
    return pd.DataFrame(entries),pd.DataFrame(audit)


def prediction(matrix,protocol,task,rep,model='extra_trees',seed=11):
    row=matrix[(matrix.protocol==protocol)&(matrix.task==task)&(matrix.representation==rep)&(matrix.model==model)&(matrix.seed==seed)].iloc[0]
    return record_predictions(ROOT/row.predictions_path)


def bootstrap_f1(y,p,index):
    yy=y[index]; zz=p[index]>=.5
    tn=((yy==0)&~zz).sum(1); fp=((yy==0)&zz).sum(1); fn=((yy==1)&~zz).sum(1); tp=((yy==1)&zz).sum(1)
    return .5*np.divide(2*tn,2*tn+fp+fn,out=np.zeros(len(index)),where=(2*tn+fp+fn)>0)+.5*np.divide(2*tp,2*tp+fp+fn,out=np.zeros(len(index)),where=(2*tp+fp+fn)>0)


def paired_contrasts(matrix):
    rows=[]
    contrasts=[('time_envelope','time_lowband','Envelope - low-band'),
               ('order_envelope_generic','time_envelope','Order - time'),
               ('order_envelope','order_envelope_generic','Geometry augmentation')]
    rng=np.random.default_rng(20261020)
    for protocol in PROTOCOLS:
        for task in TASKS:
            for model in M_LABEL:
                for target,control,name in contrasts:
                    a=prediction(matrix,protocol,task,target,model); b=prediction(matrix,protocol,task,control,model)
                    assert a.index.equals(b.index) and np.array_equal(a.label,b.label)
                    y=a.label.to_numpy(); pa=a.p1.to_numpy(); pb=b.p1.to_numpy()
                    neg=np.where(y==0)[0]; pos=np.where(y==1)[0]
                    idx=np.c_[rng.choice(neg,(2000,len(neg)),replace=True),rng.choice(pos,(2000,len(pos)),replace=True)]
                    effects=bootstrap_f1(y,pa,idx)-bootstrap_f1(y,pb,idx)
                    rows.append({'protocol':protocol,'task':task,'model':model,'seed':11,'contrast':name,
                                 'target':target,'control':control,'record_n':len(y),
                                 'effect':manual_binary(y,pa)['macro_f1']-manual_binary(y,pb)['macro_f1'],
                                 'ci_low':float(np.quantile(effects,.025)),'ci_high':float(np.quantile(effects,.975))})
    return pd.DataFrame(rows)


def schematic():
    fig,axes=plt.subplots(2,2,figsize=(7.09,4.9),layout='constrained')
    for ax in axes.flat: ax.axis('off')
    def box(ax,x,y,w,h,text,color='black'):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.012,rounding_size=0.025',
                     transform=ax.transAxes,facecolor='white',edgecolor=color,linewidth=.9))
        ax.text(x+w/2,y+h/2,text,ha='center',va='center',transform=ax.transAxes,fontsize=8,color=color)
    def arrow(ax,a,b):
        ax.add_patch(FancyArrowPatch(a,b,transform=ax.transAxes,arrowstyle='-|>',mutation_scale=9,color='#4B5563',linewidth=.8))
    panel(axes[0,0],'a','Measured mechanical information')
    ax=axes[0,0]
    box(ax,.02,.58,.42,.24,'Bearing impacts\n+ structural response')
    box(ax,.58,.58,.38,.24,'25.6 kHz vibration\n+ shaft RPM')
    arrow(ax,(.45,.70),(.57,.70))
    ax.text(.03,.34,r'$x(t)\approx a(\theta(t))\,c(t)+\epsilon(t)$',transform=ax.transAxes,fontsize=10)
    ax.text(.03,.16,r'$\theta(t)=\int_0^t \mathrm{RPM}(u)/60\,du$ (turns)',transform=ax.transAxes,fontsize=9)
    panel(axes[0,1],'b','Different front ends retain different information')
    ax=axes[0,1]
    box(ax,.03,.62,.38,.21,'180 Hz low-pass\nraw → 256 points',COLORS['time_lowband'])
    box(ax,.55,.62,.40,.21,'Band-pass → Hilbert\n1 kHz envelope LP',COLORS['time_envelope'])
    box(ax,.55,.22,.40,.21,'Time / measured angle\n2048 points × 3 bands',COLORS['order_envelope'])
    arrow(ax,(.75,.61),(.75,.44))
    ax.text(.02,.22,'Shared interval:\n8 measured turns\nIdentical endpoints',transform=ax.transAxes,fontsize=8)
    panel(axes[1,0],'c','Controlled model and evaluation matrix')
    ax=axes[1,0]
    ax.text(.02,.83,'6 representations × 2 binary tasks',transform=ax.transAxes,fontsize=9)
    ax.text(.02,.61,'Extra Trees: 3 seeds; SVM: 1 fixed seed',transform=ax.transAxes,fontsize=8)
    ax.text(.02,.39,'Record holdout + held-out A / B / C',transform=ax.transAxes,fontsize=8)
    ax.text(.02,.17,'192 selected models; record mean probability',transform=ax.transAxes,fontsize=8)
    panel(axes[1,1],'d','Follow-up separates input budgets')
    ax=axes[1,1]
    ax.text(.02,.83,'Fixed 2–5 kHz carrier; one envelope channel',transform=ax.transAxes,fontsize=8)
    ax.text(.02,.61,'256 / 2048 points; time / measured-angle grid',transform=ax.transAxes,fontsize=8)
    ax.text(.02,.39,'33 features for every representation',transform=ax.transAxes,fontsize=8)
    ax.text(.02,.17,'160 additional models; exploratory extension',transform=ax.transAxes,fontsize=8)
    p=csv(pd.DataFrame({'factor':['source_segments','inferred_groups','intervals','core_models','matched_models'],
                       'count':[101,79,404,192,160]}),'fig01_design_counts')
    save(fig,'fig01_physical_design','Figure 1. Physical information flow and the computational design. The two main front ends have different input budgets. The single-band follow-up matches feature count and compares point budgets explicitly. Envelopes and order tracking are established operations. Diagrams describe processing rather than an invented experimental rig.',[p],
         'Four panels connect measured bearing vibration and RPM to front ends, grouped evaluation, and a matched-budget follow-up.')


def data_support(lineage,assignments):
    fig,axes=plt.subplots(2,2,figsize=(7.09,5.3),layout='constrained')
    schema=json.loads((ROOT/'data/raw/novic_variable_speed/official_schema_and_pairing.json').read_text(encoding='utf-8'))
    raw=np.load(schema['data_path'],mmap_mode='r',allow_pickle=False)
    speed_rows=[]
    ax=axes[0,0]; panel(ax,'a','Measured bearing-shaft speed')
    colors=['#3B4252','#8F9BA8','#B8C0CA']
    for k,subset in enumerate(['subsetA','subsetB','subsetC']):
        ids=sorted(lineage[lineage.subset.eq(subset)].array_row.unique())
        for j,i in enumerate(ids):
            t=np.arange(0,102400,256)/25600
            ax.plot(t,raw[i,::256,8],color=colors[k],alpha=.20,linewidth=.45)
            speed_rows.extend([{'subset':subset,'array_row':i,'time_s':tt,'rpm':rp} for tt,rp in zip(t,raw[i,::256,8])])
        i=ids[0]; ax.plot(t,raw[i,::256,8],color=colors[k],linewidth=1.2,label=f'{subset[-1]} (n={len(ids)})')
    ax.set(xlabel='Time within source segment (s)',ylabel='RPM'); ax.legend(frameon=False,ncol=3,loc='upper center',fontsize=6)
    groups=lineage.drop_duplicates('inferred_source_group').copy()
    groups['state']=groups.inner_presence.astype(str)+groups.outer_presence.astype(str)
    support=pd.crosstab(groups.state,groups.subset).reindex(['00','10','01','11']).fillna(0).astype(int)
    ax=axes[0,1]; panel(ax,'b','Source-record label support')
    im=ax.imshow(support.to_numpy(),cmap='Blues',vmin=0,vmax=support.to_numpy().max(),aspect='auto')
    for i in range(4):
        for j in range(3): ax.text(j,i,str(support.iloc[i,j]),ha='center',va='center',color='white' if support.iloc[i,j]>support.to_numpy().max()*.55 else 'black')
    ax.set(xticks=range(3),xticklabels=['A','B','C'],yticks=range(4),yticklabels=['Neither','Inner only','Outer only','Both'],xlabel='Acquisition regime',ylabel='Bearing-fault presence')
    ax=axes[1,0]; panel(ax,'c','Every source group stays in one partition')
    pivot=assignments.drop_duplicates(['protocol','inferred_source_group']).pivot(index='inferred_source_group',columns='protocol',values='assigned_split').reindex(columns=PROTOCOLS)
    matrix=pivot.replace({'train':0,'validation':1,'test':2}).to_numpy(dtype=float)
    from matplotlib.colors import ListedColormap
    ax.imshow(matrix,aspect='auto',interpolation='nearest',cmap=ListedColormap(['#E6E9ED','#A8B2BE','#43576B']),vmin=0,vmax=2)
    ax.set(xticks=range(4),xticklabels=['Record','A','B','C'],yticks=[0,39,78],yticklabels=['1','40','79'],xlabel='Holdout protocol',ylabel='Inferred source group (index)')
    ax.text(.02,-.32,'Light: train   Mid: validation   Dark: test',transform=ax.transAxes,fontsize=7)
    ax=axes[1,1]; panel(ax,'d','Recording groups and dependent intervals')
    counts=[]
    for subset in ['subsetA','subsetB','subsetC']:
        g=groups[groups.subset.eq(subset)]; w=lineage[lineage.subset.eq(subset)]
        counts.append({'subset':subset,'groups':len(g),'windows':len(w)})
    cc=pd.DataFrame(counts)
    x=np.arange(3); ax.bar(x-.17,cc.groups,.32,color='#43576B',label='Source groups')
    ax.bar(x+.17,cc.windows,.32,color='#B8C0CA',label='8-turn intervals')
    for j,r in cc.iterrows():
        ax.text(j-.17,r.groups+2,str(r.groups),ha='center',fontsize=7); ax.text(j+.17,r.windows+2,str(r.windows),ha='center',fontsize=7)
    ax.set(xticks=x,xticklabels=['A','B','C'],ylabel='Count',ylim=(0,200));ax.legend(frameon=False,loc='upper left')
    paths=[csv(pd.DataFrame(speed_rows),'fig02_speed_trajectories'),csv(support.reset_index(),'fig02_label_support'),csv(pivot.reset_index(),'fig02_group_partitions'),csv(cc,'fig02_counts')]
    save(fig,'fig02_data_support','Figure 2. Measured speed, label support and partitions. All 101 four-second segments are shown as thin lines, with the first array row of each regime emphasized. Label counts refer to 79 filename-derived source groups. Four intervals per segment are dependent observations, and physical-bearing identities are unknown. Regime C has approximately constant speed within each source segment. Neither-bearing-fault records may contain misalignment or unbalance.',paths,'Speed trajectories, label-count matrix, disjoint source-group partition matrix and record-versus-window counts.')


def mechanism(lineage):
    views=np.load(ROOT/'data/processed/v3/novic_physical_views.npz',allow_pickle=False)
    schema=json.loads((ROOT/'data/raw/novic_variable_speed/official_schema_and_pairing.json').read_text(encoding='utf-8'))
    raw=np.load(schema['data_path'],mmap_mode='r',allow_pickle=False)
    idx=int(lineage[lineage.inner_presence.eq(1)].sort_values('sample_id').index[0]); row=lineage.iloc[idx]
    fs=25600.; x=raw[int(row.array_row),:,0]
    f,p=periodogram(x,fs=fs,window='hann',detrend='constant')
    fig,axes=plt.subplots(2,2,figsize=(7.09,5.2),layout='constrained')
    ax=axes[0,0];panel(ax,'a','Carrier information before compression')
    ax.semilogy(f,np.maximum(p,1e-14),color='#374151',linewidth=.5)
    for lo,hi in [(500,2000),(2000,5000),(5000,10000)]:ax.axvspan(lo,hi,color=COLORS['time_envelope'],alpha=.1)
    ax.axvline(180,color=COLORS['time_lowband'],linestyle='--');ax.set(xlim=(0,11000),xlabel='Frequency (Hz)',ylabel=r'PSD ($g^2$/Hz)')
    ax=axes[0,1]; panel(ax,'b','Declared zero-phase filter responses')
    freq=np.linspace(1,12000,5000)
    response_rows=[]
    for name,sos,color in [('Raw LP 180 Hz',butter(6,180,fs=fs,output='sos'),COLORS['time_lowband']),('Carrier 2–5 kHz',butter(4,[2000,5000],btype='bandpass',fs=fs,output='sos'),COLORS['time_envelope']),('Envelope LP 1 kHz',butter(6,1000,fs=fs,output='sos'),COLORS['order_envelope'])]:
        _,h=sosfreqz(sos,worN=freq,fs=fs);db=20*np.log10(np.maximum(np.abs(h)**2,1e-10))
        ax.plot(freq,db,label=name,color=color)
        response_rows.extend([{'filter':name,'frequency_hz':ff,'zero_phase_amplitude_db':dd} for ff,dd in zip(freq,db)])
    ax.set(xscale='log',xlim=(20,12000),ylim=(-100,3),xlabel='Frequency (Hz)',ylabel='Amplitude gain (dB)');ax.legend(frameon=False,fontsize=6)
    ax=axes[1,0]; panel(ax,'c','Same eight-turn envelope, two coordinates')
    sr=(2048-1)/8.; spectrum_rows=[]
    for view,color,label in [('time_envelope',COLORS['time_envelope'],'Mean-speed equivalent order'),('order_envelope',COLORS['order_envelope'],'Integrated measured order')]:
        q,d=periodogram(views[view][idx,1],fs=sr,window='hann',detrend='constant');norm=d/max(d.sum(),1e-20)
        ax.plot(q,norm,color=color,label=label)
        spectrum_rows.extend([{'representation':view,'order':qq,'normalized_bin_energy':dd} for qq,dd in zip(q,norm)])
    audit=json.loads((ROOT/'data/processed/v3/preprocessing_audit.json').read_text(encoding='utf-8'))
    for name,order in audit['characteristic_orders'].items():
        if name not in ['bpfi','bpfo']:continue
        for h in range(1,4): ax.axvline(order*h,color='black',linestyle=':',linewidth=.5,alpha=.6)
    ax.set(xlim=(0,20),xlabel='Cycles per shaft revolution',ylabel='Fraction of spectral energy');ax.legend(frameon=False,fontsize=6)
    ax=axes[1,1];panel(ax,'d','Measured support of the retained inputs')
    feature=pd.read_csv(ROOT/'data/processed/v3/novic_physical_features.csv')
    rmscols=[c for c in feature if c.startswith('time_envelope__') and c.endswith('__rms')]
    source=[]
    for j,col in enumerate(rmscols):
        group=pd.DataFrame({'group':lineage.inferred_source_group,'rms':feature[col]}).groupby('group').rms.mean()
        y=group.to_numpy();jitter=np.linspace(-.10,.10,len(y))
        ax.scatter(np.full(len(y),j)+jitter,y,s=8,alpha=.4,color=COLORS['time_envelope'],linewidths=0)
        ax.plot([j-.17,j+.17],[np.median(y)]*2,color='black')
        source.extend([{'band':col,'group':g,'mean_envelope_rms_g':v} for g,v in group.items()])
    ax.set(xticks=range(3),xticklabels=['0.5–2','2–5','5–10'],yscale='log',xlabel='Carrier band (kHz)',ylabel='Mean envelope RMS per source (g)')
    paths=[csv(pd.DataFrame({'frequency_hz':f,'psd_g2_per_hz':p}),'fig03_raw_psd'),csv(pd.DataFrame(response_rows),'fig03_filter_responses'),csv(pd.DataFrame(spectrum_rows),'fig03_envelope_spectra'),csv(pd.DataFrame(source),'fig03_group_envelope_rms')]
    save(fig,'fig03_bandwidth_mechanism',f'Figure 3. Retaining carrier information before forming a compact input. The signal example is the lexicographically first inner-positive interval, {row.sample_id}, selected without its prediction. Panel a uses its full four-second source for PSD; panel c uses the identical eight-turn physical interval in both coordinates and the fixed 2–5 kHz carrier. Black dotted lines are ideal BPFO/BPFI harmonics, not identified measured fault peaks. Panel d includes all 79 source groups. Zero-phase amplitude gain is the square of the single-pass magnitude. The low-band input has 256 points and envelopes have 2048; this figure does not imply equal input capacity.',paths,'Raw carrier PSD, actual filter responses, same-interval envelope spectra, and all-source envelope amplitudes.')


def main_results(matrix):
    fig,axes=plt.subplots(1,2,figsize=(7.09,3.25),layout='constrained')
    subset=matrix[matrix.protocol.eq('record_holdout')]
    for t,ax in zip(TASKS,axes):
        panel(ax,'a' if t==TASKS[0] else 'b',t.split('_')[0].title()+'-race presence')
        for j,rep in enumerate(REPRESENTATIONS):
            for k,model in enumerate(M_LABEL):
                vals=subset[(subset.task==t)&(subset.representation==rep)&(subset.model==model)].record_macro_f1.to_numpy()
                offset=-.11 if k==0 else .11
                ax.scatter(j+offset+np.linspace(-.025,.025,len(vals)),vals,color=COLORS[rep],marker='s' if k==0 else '^',s=27,linewidths=.4,edgecolors='white')
        ax.set(xticks=range(6),xticklabels=[LABELS[r] for r in REPRESENTATIONS],ylim=(0,1.05),ylabel='Record Macro-F1')
        ax.tick_params(axis='x',rotation=55)
        ax.grid(axis='y',alpha=.16)
    axes[1].scatter([],[],marker='s',c='black',s=22,label='Extra Trees, 3 seeds')
    axes[1].scatter([],[],marker='^',c='black',s=22,label='SVM, 1 fixed seed')
    axes[1].legend(frameon=False,loc='lower right',fontsize=6)
    p=csv(subset,'fig04_all_record_holdout_runs')
    save(fig,'fig04_record_holdout','Figure 4. Record-holdout performance for every fitted seed. Each point is a selected model evaluated on the same 16 source groups, after averaging probabilities within source group. Symbols distinguish classifiers; three tree seeds characterize fitting variability and do not represent three physical replications. Input point count and feature count differ across the main representations; see the matched-budget follow-up.',[p],'Two panels show inner- and outer-presence record Macro-F1 for six representations and two classifier families, retaining every seed.')


def heatmaps(matrix,matched=False):
    reps=list(REPRESENTATIONS) if not matched else ['lowband_256','time_middle_256','order_middle_256','time_middle_2048','order_middle_2048']
    fig,axes=plt.subplots(2,2,figsize=(7.09,5.0),layout='constrained')
    summary=[]
    for i,task in enumerate(TASKS):
        for j,model in enumerate(M_LABEL):
            ax=axes[i,j]; panel(ax,string.ascii_lowercase[i*2+j],task.split('_')[0].title()+' / '+M_LABEL[model])
            table=matrix[(matrix.task==task)&(matrix.model==model)].pivot_table(index='representation',columns='protocol',values='record_macro_f1',aggfunc='mean').reindex(index=reps,columns=PROTOCOLS)
            im=ax.imshow(table.to_numpy(),vmin=0,vmax=1,cmap='Blues',aspect='auto')
            for a in range(len(reps)):
                for b in range(4):
                    v=table.iloc[a,b];ax.text(b,a,f'{v:.2f}',ha='center',va='center',fontsize=7,color='white' if v>.65 else 'black')
                    summary.append({'task':task,'model':model,'representation':reps[a],'protocol':PROTOCOLS[b],'mean_record_macro_f1':v})
            ax.set(xticks=range(4),xticklabels=['Record','A','B','C'],yticks=range(len(reps)),yticklabels=[LABELS[r] for r in reps],xlabel='Held-out unit or regime')
    fig.colorbar(im,ax=axes.ravel().tolist(),shrink=.6,label='Record Macro-F1',fraction=.025,pad=.025)
    stem='fig09_matched_budget' if matched else 'fig05_regime_generalization'
    p=csv(pd.DataFrame(summary),stem+'_matrix')
    caption=('Figure 9. Exploratory matched-budget controls. Every cell uses exactly 33 features including identical eight metadata and one signal channel; tree results average three fitted seeds and SVM uses one fixed seed. The fixed middle carrier is 2–5 kHz. Time-coordinate spectra use equivalent mean-speed phase, while angular spectra use integrated measured RPM. Both grids cover the same eight turns. The 256-point angular Nyquist is 15.9375 orders. This follow-up was designed after inspecting the first main v3 results; it is not confirmatory preregistration.' if matched else
             'Figure 5. Performance under acquisition-regime holdout. Cells show the mean of three Extra Trees seeds or one fixed calibrated SVM result. A, B and C are held out as complete regimes; validation uses only the remaining regimes. Record holdout is a different, less demanding estimand. The three domain tests are correlated evaluations, not independent population replications. Regime effects can include label composition and acquisition conditions as well as speed.')
    save(fig,stem,caption,[p], 'Four representation-by-protocol heatmaps separated by task and classifier, with fixed zero-to-one scale.')


def contrast_plot(contrasts):
    fig,axes=plt.subplots(2,2,figsize=(7.09,5.0),layout='constrained')
    for i,task in enumerate(TASKS):
        for j,contrast in enumerate(['Envelope - low-band','Order - time']):
            ax=axes[i,j];panel(ax,string.ascii_lowercase[2*i+j],task.split('_')[0].title()+': '+contrast)
            ss=contrasts[(contrasts.task==task)&(contrasts.contrast==contrast)]
            for k,model in enumerate(M_LABEL):
                for z,protocol in enumerate(PROTOCOLS):
                    r=ss[(ss.model==model)&(ss.protocol==protocol)].iloc[0]
                    yy=z+(-.11 if k==0 else .11)
                    ax.plot([r.ci_low,r.ci_high],[yy,yy],color='#43576B' if k==0 else '#A3AAB3',linewidth=1)
                    ax.scatter(r.effect,yy,marker='s' if k==0 else '^',s=23,color='#43576B' if k==0 else '#A3AAB3')
            ax.axvline(0,color='black',linestyle=':',linewidth=.7)
            ax.set(yticks=range(4),yticklabels=[P_LABEL[p] for p in PROTOCOLS],xlabel='Paired change in record Macro-F1',ylim=(3.5,-.5),xlim=(-.45,1.05) if j==0 else (-.4,.4))
            if j==1:ax.set_yticklabels([])
    p=csv(contrasts,'fig06_paired_record_bootstrap')
    save(fig,'fig06_paired_effects','Figure 6. Paired performance contrasts with conditional uncertainty. Squares are Extra Trees seed 11; triangles are calibrated SVM with fixed seed 11. Intervals are percentile 95% ranges from 2,000 label-stratified paired source-record bootstrap draws; the same record indices are used in both members of each contrast. They condition on fitted models, this split and inferred acquisition groups. They exclude training and physical-bearing uncertainty, are not multiplicity-adjusted, and degenerate intervals at perfect prediction do not establish zero population uncertainty. Envelope-minus-low-band changes input budget as well as representation; the equal-budget control is Figure 9.',[p],'Four forest plots contrast envelope versus low-band and order versus time for each held-out regime and classifier.')


def errors_and_nuisance(matrix,lineage):
    fig,axes=plt.subplots(2,2,figsize=(7.09,5.3),layout='constrained')
    a=prediction(matrix,'unseen_A','outer_presence','time_envelope');b=prediction(matrix,'unseen_A','outer_presence','order_envelope')
    ax=axes[0,0];panel(ax,'a','Outer-fault errors under held-out A')
    y=a.label.to_numpy();x=np.arange(len(a))
    ax.scatter(x,a.p1,c=COLORS['time_envelope'],marker='o',s=18,label='Time envelope')
    ax.scatter(x,b.p1,c=COLORS['order_envelope'],marker='s',s=18,label='Order + geometry')
    ax.scatter(x,y,c='black',marker='_',s=45,label='Observed presence')
    ax.axhline(.5,c='black',linestyle=':',linewidth=.7);ax.set(xlabel='Source record index (sorted ID)',ylabel='Outer-presence probability',ylim=(-.06,1.06));ax.legend(frameon=False,fontsize=6,loc='center left')
    ax=axes[0,1];panel(ax,'b','Window and record metrics differ')
    ss=matrix[(matrix.task=='outer_presence')&(matrix.protocol=='unseen_A')&(matrix.seed==11)]
    for _,r in ss.iterrows():
        ax.plot([0,1],[r.window_macro_f1,r.record_macro_f1],color=COLORS[r.representation],marker='s' if r.model=='extra_trees' else '^',alpha=.8)
    ax.set(xticks=[0,1],xticklabels=['Equal windows','Record means'],ylabel='Macro-F1',ylim=(0,1.05),xlim=(-.3,1.3))
    groupmeta=lineage.drop_duplicates('inferred_source_group').set_index('inferred_source_group')
    nuisance_rows=[]
    for ii,code in enumerate(['misalignment_code','unbalance_code']):
        ax=axes[1,ii];panel(ax,'c' if ii==0 else 'd',('Misalignment' if ii==0 else 'Unbalance')+' strata in held-out A')
        for k,rep in enumerate(['time_lowband','time_envelope','order_envelope']):
            g=prediction(matrix,'unseen_A','outer_presence',rep).join(groupmeta[[code]],how='left')
            present=~g[code].astype(str).isin(['0','0.0'])
            for z,mask in enumerate([~present,present]):
                q=g[mask]
                value=manual_binary(q.label,q.p1)['macro_f1'] if len(q) and q.label.nunique()==2 else np.nan
                nuisance_rows.append({'nuisance':code,'present':z,'representation':rep,'n_records':len(q),'positive':int(q.label.sum()),'record_macro_f1':value})
                if np.isfinite(value):ax.scatter(z+(k-1)*.08,value,color=COLORS[rep],s=25,marker=['o','s','^'][k])
                else:ax.text(z+(k-1)*.08,.07,'NA',fontsize=6,color=COLORS[rep],rotation=90,ha='center')
        for z in range(2):
            row=next(r for r in nuisance_rows if r['nuisance']==code and r['present']==z)
            ax.text(z,.97,f"n={row['n_records']}\npos={row['positive']}",ha='center',fontsize=6,va='top')
        ax.set(xticks=[0,1],xticklabels=['Absent','Present'],ylabel='Record Macro-F1',ylim=(0,1.1),xlim=(-.4,1.4))
    paths=[csv(a.reset_index().assign(order_geometry_p1=b.p1.to_numpy()),'fig07_all_test_record_probabilities'),csv(ss,'fig07_window_record_units'),csv(pd.DataFrame(nuisance_rows),'fig07_nuisance_support')]
    save(fig,'fig07_errors_and_nuisance','Figure 7. Every held-out A outer-fault recording and supported nuisance strata. Panels a, c and d use tree seed 11 fixed without test selection. Source groups are sorted by ID; probabilities average all their intervals. Panel b includes both model families and exposes changes between window- and record-weighted metrics. The two nuisance strata display their exact source-record support and positive counts. A stratum lacking either class is shown as NA, rather than assigned a misleading two-class performance value. Observed nuisance labels are used only for posthoc stratification, never classifier inputs.',paths,'Per-record probabilities, changes with aggregation, and support-labelled nuisance-stratum scores including unsupported cells.')


def reliability(matrix):
    fig,axes=plt.subplots(2,2,figsize=(7.09,5.3),layout='constrained')
    reliability_rows=[]
    for j,protocol in enumerate(['record_holdout','unseen_A']):
        ax=axes[0,j];panel(ax,'a' if j==0 else 'b','Outer probability: '+P_LABEL[protocol])
        ax.plot([0,1],[0,1],color='black',linestyle=':',linewidth=.7)
        for rep in ['metadata_only','time_lowband','time_envelope','order_envelope']:
            g=prediction(matrix,protocol,'outer_presence',rep); bins=np.minimum((g.p1.to_numpy()*5).astype(int),4)
            xp=[];yp=[]
            for b in range(5):
                mask=bins==b
                if mask.any():
                    xx=g.p1.to_numpy()[mask].mean(); yy=g.label.to_numpy()[mask].mean()
                    xp.append(xx);yp.append(yy);reliability_rows.append({'protocol':protocol,'representation':rep,'bin':b,'n':int(mask.sum()),'mean_probability':xx,'event_frequency':yy})
            ax.plot(xp,yp,marker='o',color=COLORS[rep],markersize=3,label=LABELS[rep])
        ax.set(xlim=(-.02,1.02),ylim=(-.02,1.02),xlabel='Mean event probability',ylabel='Observed event frequency')
    axes[0,1].legend(frameon=False,fontsize=6,loc='lower right')
    ax=axes[1,0];panel(ax,'c','Outer-fault probability loss across regimes')
    ss=matrix[(matrix.task=='outer_presence')&(matrix.model=='extra_trees')&(matrix.seed==11)]
    for rep in ['metadata_only','time_lowband','time_envelope','order_envelope']:
        vals=ss[ss.representation.eq(rep)].set_index('protocol').reindex(PROTOCOLS)
        ax.plot(range(4),vals.record_nll,marker='o',markersize=3,color=COLORS[rep],label=LABELS[rep])
    ax.set(xticks=range(4),xticklabels=['Record','A','B','C'],ylabel='Record negative log-likelihood',xlabel='Held-out unit or regime')
    ax=axes[1,1];panel(ax,'d','Observed fitting cost and feature budget')
    ss2=matrix[matrix.protocol.eq('record_holdout')]
    for rep in REPRESENTATIONS:
        for model in M_LABEL:
            vals=ss2[(ss2.representation==rep)&(ss2.model==model)]
            ax.scatter(vals.n_features,vals.seconds,s=16,c=COLORS[rep],marker='s' if model=='extra_trees' else '^',alpha=.7)
    ax.set(xlabel='Input feature count',ylabel='Candidate search + saved artifacts (s)',yscale='log')
    paths=[csv(pd.DataFrame(reliability_rows),'fig08_reliability_bins'),csv(ss,'fig08_nll_all_regimes'),csv(ss2,'fig08_observed_fitting_cost')]
    save(fig,'fig08_reliability_and_cost','Figure 8. Classification probabilities and measured computational costs. Five equal-width event-probability bins are used at source-record level; empty bins are omitted and exact bin counts are exported. Panels a–c use Extra Trees seed 11; the SVM calibration results are retained in the full result table. Tree probabilities have not been temperature-scaled on test data. Panel d includes every main record-holdout fit and both tasks; elapsed wall time includes candidate fitting, validation, test prediction and saving, on this shared CPU workload. It is not causal online latency or an isolated preprocessing benchmark.',paths,'Source-record calibration curves, NLL across regimes, and measured search cost versus feature dimension.')


def supplementary(matrix,matched):
    for n,kind in [(1,'roc'),(2,'pr')]:
        fig,axes=plt.subplots(2,4,figsize=(7.09,4.5),layout='constrained');rows=[]
        for i,task in enumerate(TASKS):
            for j,protocol in enumerate(PROTOCOLS):
                ax=axes[i,j];panel(ax,string.ascii_lowercase[4*i+j],task.split('_')[0]+' / '+protocol.replace('unseen_',''))
                for rep in ['metadata_only','time_lowband','angle_raw','time_envelope','order_envelope']:
                    g=prediction(matrix,protocol,task,rep)
                    if kind=='roc':xx,yy,_=roc_curve(g.label,g.p1)
                    else:yy,xx,_=precision_recall_curve(g.label,g.p1)
                    ax.plot(xx,yy,color=COLORS[rep],linewidth=.8)
                    rows.extend([{'task':task,'protocol':protocol,'representation':rep,'x':x,'y':y} for x,y in zip(xx,yy)])
                ax.set(xlim=(0,1),ylim=(0,1.02),xlabel='FPR' if kind=='roc' else 'Recall',ylabel='TPR' if kind=='roc' else 'Precision')
        p=csv(pd.DataFrame(rows),f'figS{n:02d}_{kind}')
        save(fig,f'figS{n:02d}_{kind}',f'Figure S{n}. Complete record-level {kind.upper()} curves for Extra Trees seed 11 in both tasks and all four protocols. No threshold or feature choice is selected from these curves. Colors match the main figures.',[p],f'Eight panels of complete {kind.upper()} curves.')
    metrics=['record_macro_f1','record_auroc','record_nll','record_brier_binary']
    for n,model in [(3,'extra_trees'),(4,'group_calibrated_svm')]:
        fig,axes=plt.subplots(2,2,figsize=(7.09,5.0),layout='constrained')
        ss=matrix[matrix.model.eq(model)]
        for k,(ax,metric) in enumerate(zip(axes.flat,metrics)):
            panel(ax,string.ascii_lowercase[k],metric.replace('record_','').replace('_',' ').title())
            for j,rep in enumerate(REPRESENTATIONS):
                vals=ss[ss.representation.eq(rep)][metric].to_numpy()
                ax.scatter(j+np.linspace(-.16,.16,len(vals)),vals,s=10,c=COLORS[rep],alpha=.6,linewidths=0)
            ax.set(xticks=range(6),xticklabels=[LABELS[r] for r in REPRESENTATIONS]);ax.tick_params(axis='x',rotation=55)
            if metric in ['record_macro_f1','record_auroc']:ax.set_ylim(0,1.05)
        p=csv(ss,f'figS{n:02d}_all_{model}_metrics')
        save(fig,f'figS{n:02d}_{model}_metrics',f'Figure S{n}. Every selected {M_LABEL[model]} main-run result across two tasks and four protocols. Points are fitted models, not physical replication; no domain or seed is excluded. NLL and binary Brier use record-mean probabilities.',[p],'All discrimination and probability metrics for every model fit.')
    fig,axes=plt.subplots(1,2,figsize=(7.09,3.0),layout='constrained')
    for i,task in enumerate(TASKS):
        ax=axes[i];panel(ax,'a' if i==0 else 'b',task.split('_')[0].title()+': same records, different weights')
        ss=matrix[matrix.task.eq(task)]
        for rep in REPRESENTATIONS:
            q=ss[ss.representation.eq(rep)];ax.scatter(q.window_macro_f1,q.record_macro_f1,c=COLORS[rep],s=14,alpha=.7)
        ax.plot([0,1],[0,1],c='black',ls=':',lw=.7);ax.set(xlim=(0,1.02),ylim=(0,1.02),xlabel='Window Macro-F1',ylabel='Record Macro-F1')
    p=csv(matrix,'figS05_window_record_full')
    save(fig,'figS05_window_record','Figure S5. All 192 fitted-model results under equal-window and record-mean evaluation. Repeated seeds and protocols share source material; the cloud is descriptive and is not a sample of 192 independent experiments.',[p],'Scatter plot of window and record scores for both tasks.')
    fig,axes=plt.subplots(1,2,figsize=(7.09,3.0),layout='constrained')
    ngrid=['lowband_256','time_middle_256','order_middle_256','time_middle_2048','order_middle_2048']
    for i,task in enumerate(TASKS):
        ax=axes[i];panel(ax,'a' if i==0 else 'b',task.split('_')[0].title()+': all equal-feature runs')
        for j,rep in enumerate(ngrid):
            ss=matched[(matched.task==task)&(matched.representation==rep)]
            ax.scatter(j+np.linspace(-.15,.15,len(ss)),ss.record_macro_f1,s=12,c=COLORS[rep],alpha=.7)
        ax.set(xticks=range(5),xticklabels=[LABELS[r] for r in ngrid],ylim=(0,1.05),ylabel='Record Macro-F1');ax.tick_params(axis='x',rotation=55)
    p=csv(matched,'figS06_matched_all_runs')
    save(fig,'figS06_matched_all_runs','Figure S6. Every selected exploratory matched-budget model. Every representation has 33 features. Points span both classifiers, all protocols and all planned seeds; the distinction between source-domain sensitivity and seed variability remains in the source CSV.',[p],'Every equal-feature model result without exclusion.')


def supplementary_physics_and_external(matrix,lineage):
    injection_path=ROOT/'data/processed/v3/physical_injection_calibration.csv'
    inj=pd.read_csv(injection_path)
    fig,axes=plt.subplots(1,2,figsize=(7.09,3.0),layout='constrained')
    for i,(ax,field) in enumerate(zip(axes,['absolute_peak_error_order','target_to_control_energy_ratio'])):
        panel(ax,'a' if i==0 else 'b','Known-order recovery' if i==0 else 'Known signal versus control band')
        for j,kind in enumerate(['bpfo','bpfi','bsf']):
            vals=inj[inj.injected_fault_order.eq(kind)][field].to_numpy()
            ax.scatter(j+np.linspace(-.12,.12,len(vals)),vals,s=21,c=COLORS['order_envelope'],marker='o')
        ax.set(xticks=range(3),xticklabels=['BPFO','BPFI','BSF'],ylabel='Absolute error (order)' if i==0 else 'Target/control energy ratio')
        if i==0:
            ax.set_ylim(0,.14)
            ax.axhline(2047/(8*2048),color='black',linestyle=':',linewidth=.7)
            ax.text(.98,.92,'Native Fourier bin width',transform=ax.transAxes,ha='right',fontsize=6)
        if i==1:ax.set_yscale('log')
    save(fig,'figS07_known_order_verification','Figure S7. Numerical verification with 18 noise-free known-order injections: three fault orders, three carrier bands and constant/variable speed. These are software and coordinate checks, not measured defect validation or robustness to physical noise. Every condition is retained.',[injection_path],'Known injected-order errors and energy ratios for every physical software verification case.')
    views=np.load(ROOT/'data/processed/v3/novic_physical_views.npz',allow_pickle=False)
    idx=int(lineage[lineage.inner_presence.eq(1)].sort_values('sample_id').index[0])
    fig,axes=plt.subplots(2,3,figsize=(7.09,4.4),layout='constrained');rows=[]
    for i,key in enumerate(['time_envelope','order_envelope']):
        for j,band in enumerate(['0.5–2','2–5','5–10']):
            ax=axes[i,j];panel(ax,string.ascii_lowercase[3*i+j],('Time ' if i==0 else 'Order ')+band+' kHz')
            q,d=periodogram(views[key][idx,j],fs=2047/8,window='hann',detrend='constant');d=d/max(d.sum(),1e-20)
            ax.plot(q,d,c=COLORS[key],lw=.8);ax.set(xlim=(0,24),xlabel='Equivalent order' if i==0 else 'Measured order',ylabel='Energy fraction')
            rows.extend([{'view':key,'band':band,'order':x,'energy_fraction':y} for x,y in zip(q,d)])
    p=csv(pd.DataFrame(rows),'figS08_all_band_spectra')
    save(fig,'figS08_all_band_spectra','Figure S8. All three carrier-band spectra for the same first inner-positive interval used in Figure 3. The upper row uses mean-speed equivalent phase; the lower row uses integrated measured phase. No band or interval is chosen for a favorable classification result.',[p],'Six full-band comparisons of time- and angle-coordinate envelope spectra.')
    fig,axes=plt.subplots(2,4,figsize=(7.09,5.0),layout='constrained');rows=[]
    reps=['metadata_only','time_lowband','time_envelope','order_envelope']
    for i,task in enumerate(TASKS):
        for j,protocol in enumerate(PROTOCOLS):
            ax=axes[i,j];panel(ax,string.ascii_lowercase[4*i+j],task.split('_')[0]+' / '+protocol.replace('unseen_',''))
            preds=[prediction(matrix,protocol,task,r) for r in reps]
            yy=preds[0].label.to_numpy()
            values=np.array([np.where(yy==1,g.p1.to_numpy(),1-g.p1.to_numpy()) for g in preds]).T
            im=ax.imshow(values,vmin=0,vmax=1,cmap='Blues',aspect='auto',interpolation='nearest')
            ax.set(xticks=range(4),xticklabels=['Meta','Raw','Time','Order'],ylabel='Source record',xlabel='Representation')
            ax.tick_params(axis='x',rotation=65)
            for z,g in enumerate(preds):
                rows.extend([{'task':task,'protocol':protocol,'representation':reps[z],'source_group':name,'label':int(r.label),'p1':float(r.p1)} for name,r in g.iterrows()])
    fig.colorbar(im,ax=axes.ravel().tolist(),shrink=.6,fraction=.025,label='Probability assigned to observed class')
    p=csv(pd.DataFrame(rows),'figS09_every_source_record')
    save(fig,'figS09_every_source_record','Figure S9. Every test source-record probability, sorted by source ID within panel, for fixed Extra Trees seed 11. Color represents probability assigned to the observed class, not correctness averaged over seeds. The same sources can appear in different protocol panels; these are correlated evaluations.',[p],'Eight source-record probability heatmaps showing every included recording.')
    hustle=ROOT/'results/v3_hust_external/selected_metrics.csv'
    hs=pd.read_csv(hustle)
    fig,axes=plt.subplots(1,2,figsize=(7.09,3.0),layout='constrained')
    for k,(ax,field) in enumerate(zip(axes,['record_macro_f1','record_nll'])):
        panel(ax,'a' if k==0 else 'b','HUST discrimination' if k==0 else 'HUST probability loss')
        for j,(rep,color) in enumerate(zip(['duration_only','raw_lowpass_180hz','three_carrier_envelopes'],['#009E73','#6B7280','#D55E00'])):
            ss=hs[hs.representation.eq(rep)]
            ax.scatter(j+np.linspace(-.08,.08,len(ss)),ss[field],s=24,c=color)
        ax.set(xticks=range(3),xticklabels=['Duration','Raw LP','Envelopes'],ylabel='Record Macro-F1' if k==0 else 'Record NLL')
        if k==0:ax.set_ylim(0,1.05)
    save(fig,'figS10_hust_probability_failure','Figure S10. The HUST gain in Macro-F1 accompanies a severe deterioration in negative log-likelihood. Every selected seed is shown. Three test recordings do not support a population confidence interval. Zero probability assigned to the healthy class is clipped only for numerical NLL calculation; no posthoc calibration is fitted on test data.',[hustle],'HUST class-score improvement and worsened probability loss shown together.')


def main():
    for p in (FIG,SRC,OUT):p.mkdir(parents=True,exist_ok=True)
    style()
    matrix,audit=load_matrix(ROOT/'results/v3/controlled_benchmark',192)
    matched,maudit=load_matrix(ROOT/'results/v3/matched_budget',160)
    matrix.to_csv(OUT/'main_all_runs.csv',index=False);matched.to_csv(OUT/'matched_all_runs.csv',index=False)
    pd.concat([audit,maudit]).to_csv(OUT/'independent_probability_checks.csv',index=False)
    grouped=matrix.groupby(['protocol','task','representation','model']).agg(
        record_f1_mean=('record_macro_f1','mean'),record_f1_sd=('record_macro_f1','std'),
        window_f1_mean=('window_macro_f1','mean'),record_nll_mean=('record_nll','mean'),
        record_brier_mean=('record_brier_binary','mean'),seed_count=('seed','size'),test_records=('record_n','first')).reset_index()
    grouped.to_csv(OUT/'main_summary.csv',index=False)
    matched.groupby(['protocol','task','representation','model']).record_macro_f1.agg(['mean','std','count']).reset_index().to_csv(OUT/'matched_summary.csv',index=False)
    contrasts=paired_contrasts(matrix);contrasts.to_csv(OUT/'paired_record_contrasts.csv',index=False)
    lineage=pd.read_csv(ROOT/'data/processed/v3/novic_physical_lineage.csv')
    assignments=pd.read_csv(ROOT/'results/v3/controlled_benchmark/split_assignments.csv')
    schematic();data_support(lineage,assignments);mechanism(lineage);main_results(matrix);heatmaps(matrix)
    contrast_plot(contrasts);errors_and_nuisance(matrix,lineage);reliability(matrix);heatmaps(matched,True);supplementary(matrix,matched)
    supplementary_physics_and_external(matrix,lineage)
    write_json(FIG/'figure_manifest.json',{'nominal_width_mm':180,'format':'PDF and SVG vectors; PNG 300 dpi',
        'palette':COLORS,'conditional_bootstrap_seed':20261020,'figures':manifest})
    write_json(OUT/'integrity_summary.json',{'main_selected_models':len(matrix),'matched_selected_models':len(matched),
        'saved_prediction_checks':len(audit)+len(maudit),'metric_fields_independently_recomputed':['macro_f1','nll','brier_binary'],
        'maximum_absolute_metric_difference':float(pd.concat([audit,maudit]).maximum_metric_difference.max()),
        'model_prediction_and_design_hashes_match':True,'new_test_inferences_in_analysis':0,
        'figures_generated':len(manifest),'status':'all planned NOVIC selected models complete; scientific scope remains bounded by public data'})
    print(json.dumps({'main_models':len(matrix),'matched_models':len(matched),'figures':len(manifest),'max_metric_difference':float(pd.concat([audit,maudit]).maximum_metric_difference.max())}),flush=True)


if __name__=='__main__': main()
