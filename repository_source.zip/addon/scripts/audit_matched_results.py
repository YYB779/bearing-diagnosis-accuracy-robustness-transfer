"""Independent post-fit integrity checks; no selection, fitting or model changes."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import pandas as pd
import argparse
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output-dir',type=Path,required=True)
P=parser.parse_args().output_dir.resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def metrics(y,p):
    cm=np.zeros((3,3),dtype=int)
    for a,b in zip(y,p.argmax(1)):cm[a,b]+=1
    f=np.array([2*cm[k,k]/(cm[k].sum()+cm[:,k].sum()) if cm[k].sum()+cm[:,k].sum() else 0. for k in range(3)])
    return {'macro_f1':float(f.mean()),'nll':float(-np.log(np.maximum(p[np.arange(len(y)),y],np.finfo(float).eps)).mean()),'recall_H':float(cm[0,0]/cm[0].sum()),'recall_I':float(cm[1,1]/cm[1].sum()),'recall_O':float(cm[2,2]/cm[2].sum()),'multiclass_brier':float(((p-np.eye(3)[y])**2).sum(1).mean())}
plan=read(P/'analysis_plan.json');completion=read(P/'completion.json')
assert completion['fits']==30 and completion['checkpoints']==120
assert plan['planned_fits']==30 and sha(P/'analysis_plan.json')==completion['plan_sha256']
rows=[];pairs=[];errors=[]
for fold in range(5):
    for seed in [11,22,33]:
        split=read(P/f'fold{fold}_seed{seed}_split.json')
        assert not(set(split['training_records'])&set(split['validation_records']) or set(split['training_records'])&set(split['test_records']) or set(split['validation_records'])&set(split['test_records']))
        results=[]
        for arm in ['patch_rms','training_rms']:
            r=P/f'fold{fold}_seed{seed}_{arm}';d=read(r/'result.json')
            assert len(list(r.glob('checkpoint_*.pt')))==4
            assert d['plan_sha256']==sha(P/'analysis_plan.json')
            assert d['parameter_count']==66083
            assert [h['update'] for h in d['history']]==[120,240,360,480]
            selected=min(d['history'],key=lambda h:(-h['clean_validation']['macro_f1'],h['clean_validation']['nll'],h['update']))['update']
            assert selected==d['selected_update']
            pred=pd.read_csv(r/'test_predictions.csv');p=pred[['p_H','p_I','p_O']].to_numpy(float);y=pred.class_id.to_numpy(int)
            assert set(pred.source_record)==set(split['test_records']) and pred.source_record.nunique()==len(pred)
            assert np.isfinite(p).all() and (p>=0).all() and np.allclose(p.sum(1),1)
            manual=metrics(y,p);err=max(abs(manual[k]-d['test'][k]) for k in manual);assert err<1e-12
            errors.append(err);rows.append({'fold':fold,'seed':seed,'arm':arm,'selected_update':selected,**manual})
            if arm=='patch_rms':
                audit=read(r/'historical_training_audit.json')
                assert audit['historical_state_exact_equal'] and audit['max_history_absolute_difference']<=1e-10
            results.append(d)
        assert results[0]['initial_state_sha256']==results[1]['initial_state_sha256']
        assert results[0]['batch_sha256']==results[1]['batch_sha256']==split['batch_sha256']
        assert results[0]['training_rms']==results[1]['training_rms']==split['training_rms']
        pairs.append({'fold':fold,'seed':seed,'identical_initial_state':True,'identical_batches':True,'shared_training_scalar':True})
pd.DataFrame(rows).to_csv(P/'fold_summary.csv',index=False)
pred=pd.read_csv(P/'record_predictions.csv');allmetrics=[]
for (seed,arm),q in pred.groupby(['seed','arm']):
    assert len(q)==21 and q.source_record.nunique()==21
    allmetrics.append({'seed':int(seed),'arm':arm,**metrics(q.class_id.to_numpy(int),q[['p_H','p_I','p_O']].to_numpy(float))})
archived=read(P/'pooled_summary.json')
for r in allmetrics:
    ref=next(v for v in archived if v['seed']==r['seed'] and v['arm']==r['arm'])
    assert max(abs(r[k]-ref[k]) for k in ['macro_f1','nll','recall_H','recall_I','recall_O','multiclass_brier'])<1e-12
status={'status':'PASS','fits':30,'checkpoints':120,'pairs':pairs,'manual_fold_metric_max_error':max(errors),'source_file_sets_match':True,'pooled_records_per_arm_seed':21,'source_only_selection_recovered':30,'historical_trajectories_and_states_matched':15,'all_initial_states_batches_and_training_normalizers_paired':True,'scope':'integrity/arithmetic/protocol checks, not an independent-sample statistical validation','input_raw_bridge':read(P/'RAW_INPUT_EQUIVALENCE.json')}
(P/'FINAL_AUDIT.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'status':'PASS','fits':30,'checkpoints':120,'maximum_metric_error':max(errors),'historical_exact_matches':15}))
