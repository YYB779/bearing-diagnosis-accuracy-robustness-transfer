"""Fresh original HUST bytes -> frozen raw patches and full-window features.

This wrapper preserves archived algorithms and never writes into their project.
Each response is hash/size checked before parsing; raw files stay in memory.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, certifi, hashlib, importlib.util, io, json, platform, sys, time
import numpy as np
import pandas as pd
import requests
import scipy

def digest(p):
    h = hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def save(p, x):
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def compare_csv(new, old):
    a,b = pd.read_csv(new),pd.read_csv(old)
    schemas = a.columns.tolist()==b.columns.tolist() and a.shape==b.shape
    if not schemas:
        return {'pass':False,'schema_matches':False,'new_shape':list(a.shape),'old_shape':list(b.shape)}
    ids = a.sample_id.tolist()==b.sample_id.tolist()
    x,y = a.drop(columns='sample_id').to_numpy(float),b.drop(columns='sample_id').to_numpy(float)
    dif=np.abs(x-y);norm=dif/np.maximum(1.0,np.abs(y))
    return {'pass':bool(ids and np.isfinite(x).all() and np.max(norm)<=1e-12),
        'schema_matches':True,'sample_ids_exact':ids,'shape':list(a.shape),
        'byte_identical':digest(new)==digest(old),'numeric_array_exact':bool(np.array_equal(x,y)),
        'max_absolute_difference':float(dif.max()),'max_normalized_difference':float(norm.max()),
        'tolerance_rule':'abs(new-old)/max(1,abs(old)) <= 1e-12','new_sha256':digest(new),'reference_sha256':digest(old)}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--project',type=Path,required=True)
    ap.add_argument('--reference-patches',type=Path,help='Optional independently retained old patch NPZ for array-by-array verification')
    ap.add_argument('--preflight',action='store_true')
    ap.add_argument('--output-dir',type=Path,required=True)
    args=ap.parse_args();root=args.project.resolve();out=args.output_dir.resolve();out.mkdir(parents=True,exist_ok=True)
    assert not out.is_relative_to(root), 'Output must be outside the archived extraction'
    plan_template=Path(__file__).resolve().parents[1]/'evidence/hust_raw_rebuild/PLAN.md'
    if not (out/'PLAN.md').exists():
        (out/'PLAN.md').write_text(plan_template.read_text(encoding='utf-8'),encoding='utf-8')
    expected_patch_sha=json.loads((root/'provenance/revision_reproduction.json').read_text(encoding='utf-8'))['hust']['patch_archive_sha256']
    if args.reference_patches is not None:
        assert digest(args.reference_patches)==expected_patch_sha, 'Optional reference patch digest differs from frozen provenance'
    log=out/'events.jsonl'
    def event(x):
        x={'utc':datetime.now(timezone.utc).isoformat(),**x}
        with log.open('a',encoding='utf-8') as f:f.write(json.dumps(x,ensure_ascii=False)+'\n')
        print(json.dumps(x,ensure_ascii=True),flush=True)
    started=time.time()
    manifest_paths=[root/'data/raw/v3_external/hust_subset_download_manifest.json',root/'data/raw/v4_external/download_manifest.json']
    rows=sum([json.loads(p.read_text(encoding='utf-8'))['downloads'] for p in manifest_paths],[])
    byname={r['name']:r for r in rows}
    assert len(rows)==len(byname)==21
    lp=root/'results/v4_external/window_lineage.csv';lineage=pd.read_csv(lp)
    assert len(lineage)==168 and lineage.source_record.nunique()==21 and set(lineage.source_record)==set(byname)
    implementation=root/'scripts/v5/prepare_hust_native_features.py'
    spec=importlib.util.spec_from_file_location('archived_hust_native',implementation)
    fn=importlib.util.module_from_spec(spec);spec.loader.exec_module(fn)
    tracked=manifest_paths+[lp,implementation,fn.BASE_PATH,root/'scripts/v5/prepare_neural_patches.py',root/'data/processed/v5/hust_native_features.csv',root/'data/processed/v5/hust_native_shape_features.csv',root/'data/processed/v5/hust_neural_patch_lineage.csv',root/'provenance/revision_reproduction.json']
    if args.reference_patches is not None:tracked.append(args.reference_patches)
    before={str(p):digest(p) for p in tracked}
    if args.preflight:
        print(json.dumps({'status':'PREFLIGHT_PASS','original_sources':21,'expected_patch_sha256':expected_patch_sha,'reference_array_comparison':args.reference_patches is not None,'tracked_inputs':len(before)}));return
    report={'status':'running','started_utc':datetime.now(timezone.utc).isoformat(),'plan_sha256':digest(out/'PLAN.md'),
       'script_sha256':digest(__file__),'inputs':before,'sources':[],'models_trained':0,
       'independent_specimens_added':0,'network_tls_verified':True,'raw_spreadsheets_saved':False,
       'versions':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'requests':requests.__version__},
       'protocol':{'fs':25600,'raw_column_zero_based':2,'raw_shape':[262144,5],'first_seconds':8,'patch_samples':2048,'offsets':[0,7850,15701,23552],'cast':'raw float64 -> float32; native feature calculations use float32 -> float64'}}
    save(out/'raw_regeneration_result.json',report)
    signals={};patches=[];patch_rows=[];offsets=np.linspace(0,25600-2048,4,dtype=int)
    session=requests.Session()
    try:
        for index,(name,lf) in enumerate(lineage.groupby('source_record',sort=False),1):
            row=byname[name];payload=None
            for attempt in range(1,4):
                try:
                    event({'type':'request_start','index':index,'name':name,'attempt':attempt,'url':row['source_url']})
                    chunks=[];total=0;h=hashlib.sha256()
                    with session.get(row['source_url'],stream=True,timeout=(20,90),verify=certifi.where()) as response:
                        response.raise_for_status()
                        final_url=response.url
                        for block in response.iter_content(1024*1024):
                            total+=len(block)
                            if total>row['bytes']:raise ValueError('Response exceeds expected source size')
                            h.update(block);chunks.append(block)
                    observed=h.hexdigest()
                    if total!=row['bytes'] or observed!=row['sha256']:
                        raise ValueError(f'Source integrity mismatch: bytes={total}, sha256={observed}')
                    payload=b''.join(chunks);del chunks
                    break
                except Exception as e:
                    event({'type':'request_failed','index':index,'name':name,'attempt':attempt,'error':repr(e)})
                    if attempt==3:raise
            stream=io.StringIO(payload.decode('utf-8'));del payload
            for line in stream:
                if line.strip()=='Data':break
            else:raise ValueError('No Data boundary')
            arr=np.loadtxt(stream,delimiter='\t',dtype=np.float64);stream.close()
            assert arr.shape==(262144,5) and np.isfinite(arr).all() and np.all(np.diff(arr[:,0])>0)
            rate=(len(arr)-1)/(arr[-1,0]-arr[0,0]);assert abs(rate-25600)<.01
            raw=arr[:8*25600,2].astype(np.float32);del arr
            signals[name]=raw.astype(np.float64)
            for wi,record in lf.iterrows():
                start,stop=int(record.start_sample),int(record.stop_sample_exclusive)
                assert stop-start==25600
                for pi,offset in enumerate(offsets):
                    a=start+int(offset);b=a+2048;assert start<=a<b<=stop
                    patches.append(raw[a:b].copy())
                    patch_rows.append({'patch_id':f'hust_native_w{wi:03d}_p{pi}','source_record':name,
                        'window_row':int(wi),'window_index':int(record.window_index),'patch_index':pi,
                        'start_sample':a,'stop_sample_exclusive':b,'condition':record.condition,
                        'class_id':int(record.class_id),'class_name':record.class_name,'severity':record.severity})
            report['sources'].append({'name':name,'requested_url':row['source_url'],'final_url':final_url,
                'bytes':total,'sha256':observed,'bytes_match':True,'sha256_match':True,
                'shape':[262144,5],'endpoint_fs':float(rate),'first_eight_seconds_float32_sha256':hashlib.sha256(raw.tobytes()).hexdigest()})
            event({'type':'source_verified_and_parsed','index':index,'name':name,'bytes':total,'sha256':observed})
            save(out/'raw_regeneration_result.json',report)
        frame=pd.DataFrame(patch_rows);order=np.lexsort((frame.patch_index,frame.window_row))
        frame=frame.iloc[order].reset_index(drop=True);x=np.stack(patches)[order]
        assert x.shape==(672,2048) and x.dtype==np.float32 and np.isfinite(x).all()
        np.savez_compressed(out/'hust_neural_patches.npz',x=x,patch_id=frame.patch_id.to_numpy(str),fs=np.array(25600),offsets=offsets)
        frame.to_csv(out/'hust_neural_patch_lineage.csv',index=False)
        native=fn.features_for_lineage(signals,lineage)
        shape=fn.features_for_lineage(signals,lineage,shape=True)
        assert native.shape==shape.shape==(168,26)
        native.to_csv(out/'hust_native_features.csv',index=False);shape.to_csv(out/'hust_native_shape_features.csv',index=False)
        # Comparisons start only after extraction is complete.
        if args.reference_patches is not None:
            with np.load(args.reference_patches,allow_pickle=False) as old, np.load(out/'hust_neural_patches.npz',allow_pickle=False) as new:
                exact={k:bool(np.array_equal(old[k],new[k])) for k in new.files}
                patch_diff=float(np.abs(old['x'].astype(float)-new['x'].astype(float)).max())
        else:
            exact={};patch_diff=None
        old_frame=pd.read_csv(root/'data/processed/v5/hust_neural_patch_lineage.csv')
        checks={'patch_arrays':{'pass':all(exact.values()) and digest(out/'hust_neural_patches.npz')==expected_patch_sha,'exact_by_key':exact,'max_absolute_difference':patch_diff,'optional_reference_array_comparison_performed':args.reference_patches is not None,
                'byte_identical':digest(out/'hust_neural_patches.npz')==expected_patch_sha,
                'new_sha256':digest(out/'hust_neural_patches.npz'),'reference_sha256':expected_patch_sha},
            'patch_lineage':{'pass':frame.equals(old_frame),'byte_identical':digest(out/'hust_neural_patch_lineage.csv')==digest(root/'data/processed/v5/hust_neural_patch_lineage.csv')},
            'native_features':compare_csv(out/'hust_native_features.csv',root/'data/processed/v5/hust_native_features.csv'),
            'shape_features':compare_csv(out/'hust_native_shape_features.csv',root/'data/processed/v5/hust_native_shape_features.csv')}
        unchanged=before=={str(p):digest(p) for p in tracked}
        report.update(status='PASS' if all(v['pass'] for v in checks.values()) and unchanged else 'FAIL',
            finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.time()-started,
            source_files_verified=len(report['sources']),source_bytes_verified=sum(r['bytes'] for r in report['sources']),
            checks=checks,canonical_inputs_unchanged=unchanged,
            outputs={p.name:{'bytes':p.stat().st_size,'sha256':digest(p)} for p in out.iterdir() if p.suffix in ['.npz','.csv']},
            limitations=['Same 21 acquisitions; no added independent specimens.','No neural or conventional retraining in this wrapper.','Archived filters/features/lineage are reused; agreement is a reproducibility check, not independent method validation.'])
        save(out/'raw_regeneration_result.json',report)
        event({'type':'completed','status':report['status'],'source_files':21,'elapsed_seconds':report['elapsed_seconds']})
        if report['status']!='PASS':raise RuntimeError('Regeneration comparison failed; see result JSON')
    except Exception as e:
        report.update(status='FAIL',error=repr(e),finished_utc=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.time()-started)
        save(out/'raw_regeneration_result.json',report);event({'type':'run_failed','error':repr(e)})
        raise

if __name__=='__main__':main()
