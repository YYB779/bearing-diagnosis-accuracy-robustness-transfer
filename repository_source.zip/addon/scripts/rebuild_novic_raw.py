from pathlib import Path
import hashlib, importlib.util, json, os, shutil, subprocess, sys, time, io, contextlib
from datetime import datetime, timezone
import requests, certifi, numpy as np, pandas as pd

import argparse

def describe_raw_storage(cached_raw):
    """Describe the verified source I/O route; no effect on signal processing."""
    if cached_raw is None:
        return ('Complete official bytes consumed in RAM; full byte count, MD5 and SHA256 '
                'checked before loading. The I/O adapter supplies the real ndarray and '
                'measured digest to the unchanged v3 extractor. No full tensor is saved '
                'to disk by this run.')
    return ('An independently obtained complete source NPY remains on disk unchanged. '
            'Its full byte count, MD5 and SHA256 are verified before read-only memory '
            'mapping. The I/O adapter supplies that source array and measured digest '
            'to the unchanged v3 extractor. No duplicate full tensor is saved by this run.')

ap=argparse.ArgumentParser(description='Complete checksum-verified NOVIC source stream -> physical/native features; no fitting.')
ap.add_argument('--project',type=Path,required=True)
ap.add_argument('--output-dir',type=Path,required=True)
ap.add_argument('--cached-raw',type=Path)
ap.add_argument('--reference-views',type=Path)
ap.add_argument('--preflight',action='store_true')
args=ap.parse_args()
A=args.output_dir.resolve();R=args.project.resolve()
assert not A.is_relative_to(R), 'Use a new output directory outside the base extraction'
A.mkdir(parents=True,exist_ok=True)
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
    return h.hexdigest()
def save(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
plan=A/'PLAN.json'
if not plan.exists():
    save(plan,{'created_utc':datetime.now(timezone.utc).isoformat(),
        'question':'Does fresh reconstruction from the complete checksum-verified upstream 101-segment tensor reproduce the frozen 404 physical-interval feature tables?',
        'analysis_type':'Post-result computational reproducibility audit; not new independent data or prospective validation.',
        'inputs':'Official full test subsetE tensor and frozen source schema/segment membership. No tuning, refitting or relabelling.',
        'checks':['full source byte count, upstream MD5 and archived SHA256','physical feature table and lineage 404 rows','native25 on newly reconstructed physical endpoints','sample IDs and numeric differences vs frozen files'],
        'acceptance':'Report exact byte/array equality where achieved, otherwise all differences with tolerance 1e-10 relative and 1e-12 absolute, without modifying the extractor.'})
meta=json.loads((R/'data/raw/novic_variable_speed/test_data_4s_clf_subsetE.npy.metadata.json').read_text(encoding='utf-8'))
raw=A/'raw_temporary/test_data_4s_clf_subsetE.npy'
raw.parent.mkdir(exist_ok=True)
url='https://zenodo.org/records/15743425/files/test_data_4s_clf_subsetE.npy?download=1'
start=time.time()
required=['scripts/v3/prepare_novic_physical_features.py','scripts/v4/prepare_native_features.py','data/raw/novic_variable_speed/official_schema_and_pairing.json','data/raw/novic_variable_speed/subsetE_segment_manifest.csv','data/processed/v3/novic_subsetE_same_interval_v1_lineage.csv','data/processed/v3/novic_physical_features.csv','data/processed/v3/novic_physical_lineage.csv','data/processed/v4/native_fullband_features.csv']
assert all((R/q).is_file() for q in required), 'Missing base dependency'
if args.preflight:
    print(json.dumps({'status':'PREFLIGHT_PASS','source_bytes':meta['bytes'],'source_sha256':meta['sha256'],'dependencies':len(required),'optional_views':args.reference_views is not None}));sys.exit(0)
if args.cached_raw is None:
    # Low-disk I/O adapter: consume and checksum the complete official byte stream
    # in RAM, then pass its real NumPy array into the unchanged extractor.
    h=hashlib.sha256(); md5=hashlib.md5(); total=0
    payload=io.BytesIO()
    with requests.get(url,stream=True,verify=certifi.where(),timeout=(25,90)) as response:
        response.raise_for_status()
        for chunk in response.iter_content(4*1024*1024):
            payload.write(chunk);h.update(chunk);md5.update(chunk);total+=len(chunk)
            assert total<=meta['bytes'],'Unexpected response size'
            if total//(80*1024*1024)!=(total-len(chunk))//(80*1024*1024):
                print(f'NOVIC source downloaded {total}/{meta["bytes"]} bytes',flush=True)
    record={'retrieved_utc':datetime.now(timezone.utc).isoformat(),'source_url':url,'bytes':total,'sha256':h.hexdigest(),'md5':md5.hexdigest(),'elapsed_s':time.time()-start}
    save(A/'raw_download.json',record)
    assert total==meta['bytes'] and h.hexdigest()==meta['sha256']
    assert md5.hexdigest()==meta['expected_checksum'].split(':')[1]
    payload.seek(0)
    raw_array=np.load(payload,allow_pickle=False)
    payload.close()
else:
    cached=args.cached_raw.resolve()
    h=hashlib.sha256();md5=hashlib.md5();total=0
    with cached.open('rb') as stream:
        for chunk in iter(lambda:stream.read(4*1024*1024),b''):
            h.update(chunk);md5.update(chunk);total+=len(chunk)
    assert total==meta['bytes'] and h.hexdigest()==meta['sha256'] and md5.hexdigest()==meta['expected_checksum'].split(':')[1]
    record={'retrieved_utc':datetime.now(timezone.utc).isoformat(),'source_url':url,'cached_raw':str(cached),'bytes':total,'sha256':h.hexdigest(),'md5':md5.hexdigest(),'elapsed_s':time.time()-start}
    save(A/'raw_download.json',record)
    raw_array=np.load(cached,mmap_mode='r',allow_pickle=False)
raw_array.setflags(write=False)
assert meta['bytes']==record['bytes']
assert meta['sha256']==record['sha256']
assert record['md5']==meta['expected_checksum'].split(':')[1]
save(raw.with_suffix('.npy.metadata.json'),{**meta,'path':str(raw),'source_url':url,'checksum_verified':True})

vendor=A/'vendor'
for rel in ['scripts/v3/prepare_novic_physical_features.py','scripts/v4/prepare_native_features.py']:
    dst=vendor/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/rel,dst)
inputs=A/'inputs';inputs.mkdir(exist_ok=True)
schema=json.loads((R/'data/raw/novic_variable_speed/official_schema_and_pairing.json').read_text(encoding='utf-8'))
schema['data_path']=str(raw)
save(inputs/'schema.json',schema)
shutil.copy2(R/'data/raw/novic_variable_speed/subsetE_segment_manifest.csv',inputs/'subsetE_segment_manifest.csv')
frozen=R/'data/processed/v3/novic_subsetE_same_interval_v1_lineage.csv'
assert frozen.exists()
shutil.copy2(frozen,inputs/frozen.name)
save(inputs/'v2_pointer.json',{'data_path':str(inputs/'novic_subsetE_same_interval_v1.npz')})
out=A/'physical';out.mkdir(exist_ok=True)
cmd=[sys.executable,str(vendor/'scripts/v3/prepare_novic_physical_features.py'),'--schema',str(inputs/'schema.json'),'--manifest',str(inputs/'subsetE_segment_manifest.csv'),'--v2-pointer',str(inputs/'v2_pointer.json'),'--output-dir',str(out)]
spec3=importlib.util.spec_from_file_location('novic_physical_raw_rebuild',vendor/'scripts/v3/prepare_novic_physical_features.py')
mod3=importlib.util.module_from_spec(spec3);spec3.loader.exec_module(mod3)
original_load=np.load; original_digest=mod3.digest; original_argv=sys.argv
def verified_memory_load(path,*args,**kwargs):
    return raw_array if isinstance(path,(str,Path)) and Path(path)==raw else original_load(path,*args,**kwargs)
def verified_memory_digest(path):
    return record['sha256'] if Path(path)==raw else original_digest(path)
try:
    np.load=verified_memory_load
    mod3.digest=verified_memory_digest
    sys.argv=cmd[1:]
    with (A/'physical_stdout.txt').open('w',encoding='utf-8') as log,contextlib.redirect_stdout(log):
        mod3.main()
finally:
    np.load=original_load;mod3.digest=original_digest;sys.argv=original_argv
print('NOVIC raw physical reconstruction completed',flush=True)

def table_compare(new,old,key='sample_id'):
    n=pd.read_csv(new); o=pd.read_csv(old)
    assert n.columns.tolist()==o.columns.tolist(),(new,'column mismatch')
    assert n.shape==o.shape,(new,'shape mismatch')
    assert n[key].tolist()==o[key].tolist(),(new,'identity/order mismatch')
    nums=n.select_dtypes(include=[np.number]).columns
    cats=[c for c in n.columns if c not in nums]
    assert all(n[c].fillna('<NA>').equals(o[c].fillna('<NA>')) for c in cats)
    nv=n[nums].to_numpy(dtype=float);ov=o[nums].to_numpy(dtype=float)
    delta=np.abs(nv-ov)
    return {'new':str(new),'frozen':str(old),'rows':len(n),'columns':len(n.columns),'sha256':sha(new),'frozen_sha256':sha(old),'byte_equal':sha(new)==sha(old),'numeric_array_equal':np.array_equal(nv,ov,equal_nan=True),'max_abs_difference':float(np.nanmax(delta)),'within_declared_tolerance':bool(np.allclose(nv,ov,rtol=1e-10,atol=1e-12,equal_nan=True)),'categorical_and_ids_equal':True}
checks=[]
checks.append(table_compare(out/'novic_physical_features.csv',R/'data/processed/v3/novic_physical_features.csv'))
checks.append(table_compare(out/'novic_physical_lineage.csv',R/'data/processed/v3/novic_physical_lineage.csv'))
spec=importlib.util.spec_from_file_location('novic_native_rebuild',vendor/'scripts/v4/prepare_native_features.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
array=raw_array
assert array.shape==(101,102400,9)
features,definitions,crops=mod.build_feature_table(array,pd.read_csv(out/'novic_physical_lineage.csv'))
native=A/'native';native.mkdir(exist_ok=True)
features.to_csv(native/'native_fullband_features.csv',index=False)
crops.to_csv(native/'native_crops.csv',index=False)
save(native/'native_definitions.json',definitions)
checks.append(table_compare(native/'native_fullband_features.csv',R/'data/processed/v4/native_fullband_features.csv'))
views=[]
oldviews=args.reference_views
if oldviews is not None:
    assert oldviews.is_file(), 'Explicit reference view cache is missing'
    with np.load(out/'novic_physical_views.npz',allow_pickle=False) as n,np.load(oldviews,allow_pickle=False) as o:
        assert set(n.files)==set(o.files)
        for k in n.files:
            views.append({'key':k,'shape':list(n[k].shape),'array_equal':bool(np.array_equal(n[k],o[k]))})
assert all(c['within_declared_tolerance'] for c in checks)
assert all(c['array_equal'] for c in views)
report={'status':'PASS','completed_utc':datetime.now(timezone.utc).isoformat(),'input':record,'shape':list(array.shape),'physical_intervals':404,'inferred_recording_proxies':79,'tables':checks,'views':views,'optional_reference_view_check_performed':oldviews is not None,'vendor_sources':[{ 'file':rel,'sha256':sha(vendor/rel),'matches_archived_module':sha(vendor/rel)==sha(R/rel)} for rel in ['scripts/v3/prepare_novic_physical_features.py','scripts/v4/prepare_native_features.py']],'elapsed_s':time.time()-start,'scope':'Complete official tensor -> physical intervals, physical features and native25 features; no model fitting in this audit. Frozen groups retained; no new specimens.','raw_storage':describe_raw_storage(args.cached_raw)}
save(A/'NOVIC_RAW_REBUILD_CHECK.json',report)
print(json.dumps({'status':report['status'],'input_sha256':record['sha256'],'tables':[{k:c[k] for k in ['rows','columns','byte_equal','max_abs_difference']} for c in checks],'elapsed_s':report['elapsed_s']},indent=2),flush=True)
del array
