"""Verify the unchanged base inputs required by this revision add-on."""
import argparse,hashlib,json
from pathlib import Path

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--project',type=Path,required=True)
    p.add_argument('--archive',type=Path)
    a=p.parse_args();base=a.project.resolve()
    m=json.loads((Path(__file__).resolve().parents[1]/'BASE_INPUTS.json').read_text(encoding='utf-8'))
    errors=[]
    for rel,expected in m['required_extraction_files'].items():
        path=base/rel
        if not path.is_file() or sha(path)!=expected:errors.append(rel)
    if a.archive is not None and sha(a.archive)!=m['archive_sha256']:errors.append('base ZIP digest')
    if errors:raise ValueError('Base input integrity failure: '+', '.join(errors))
    print(json.dumps({'status':'PASS','checked_extracted_files':len(m['required_extraction_files']),'base_zip_checked':a.archive is not None}))

if __name__=='__main__':main()
