"""Post-hoc same-checkpoint healthy-recognition audit; Python standard library only.

Usage: python pair_frozen_health.py --archive bearing_diagnosis_software_v1.0.2.zip --output output
No fitting, threshold selection, neural inference, downloads or writes to the archive.
"""
import argparse
import csv
import hashlib
import io
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from statistics import fmean
from zipfile import ZipFile

HASHES = {
    'results/v6/analysis/record_predictions.csv': 'ad2eb0075c62c049c2809f98224d4129d391831754210db06a94b3e3309ae659',
    'results/v7/analysis/record_predictions.csv': '84bbe58b5e81834f6c8f7c959fce091fa5dfb8d43aecaf473bd6727c5a88dec5',
    'results/v7/zero_shot/v6/fold_record_predictions.csv': '417ea3884c213528cee55b2a8b6340e194d3a3fe90fc6d44d10c8e7873f35aaa',
    'results/v7/zero_shot/v7/fold_record_predictions.csv': 'c912f71fb37410c420ae98a948547118dacb146b76532814e27f1c2c617b86fb',
    'results/v7/zero_shot/v6/design.json': 'b9572bc47144732248754552a8829e1f0df873a63077594eb89460a100e2f26c',
    'results/v7/zero_shot/v7/design.json': '9c476d99bc4b471da77703fce6fd26f2a88dfd0fda303bcc9894278d1bb1f0a6',
}
PCOLS = ('p_H', 'p_I', 'p_O')
TIMINGS = ('nominal', 'timestamp_sensitive')
KEYS = ('cohort', 'excluded', 'arm', 'seed', 'fold')

def require(ok, message):
    if not ok:
        raise ValueError(message)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def probs(row):
    p = tuple(float(row[k]) for k in PCOLS)
    require(all(math.isfinite(v) and 0 <= v <= 1 for v in p), 'Invalid probability')
    require(abs(sum(p)-1) < 1e-6, 'Probability sum differs from one')
    return p

def mean(vectors):
    return tuple(fmean(x) for x in zip(*vectors))

def prediction(p):
    return max(range(3), key=p.__getitem__)

def key(row, cohort):
    return (cohort, row.get('excluded', 'none'), row['arm'], int(row['seed']), int(row['fold']))

def save_csv(path, rows):
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def run(archive, output):
    output.mkdir(parents=True, exist_ok=True)
    paired, bearings, weights, inputs = [], [], [], []
    healthy_names = set()
    with ZipFile(archive) as z:
        def read(path):
            raw = z.read(path)
            if path in HASHES:
                require(digest(raw) == HASHES[path], 'Frozen input hash mismatch: ' + path)
                inputs.append({'member': path, 'bytes': len(raw), 'sha256': digest(raw)})
            return raw

        for cohort, expected_models in [('v6', 60), ('v7', 120)]:
            design = json.loads(read(f'results/v7/zero_shot/{cohort}/design.json'))
            design_weights = {p.replace('\\', '/'): sha for p, sha in design['sha256'].items() if p.endswith('.pt')}
            require(len(design_weights) == expected_models, 'Frozen design model count')
            source_rows = list(csv.DictReader(io.StringIO(read(f'results/{cohort}/analysis/record_predictions.csv').decode('utf-8-sig'))))
            target_rows = list(csv.DictReader(io.StringIO(read(f'results/v7/zero_shot/{cohort}/fold_record_predictions.csv').decode('utf-8-sig'))))
            healthy, source_keys = {}, set()
            for row in source_rows:
                if row['panel'] != 'clean':
                    continue
                require(row.get('role', 'test') == 'test', 'Source row is not held out')
                k = key(row, cohort)
                source_keys.add(k)
                if int(row['label']) == 0:
                    require(k not in healthy, 'Multiple source healthy records for one network')
                    healthy[k] = (row['source_record'], probs(row))
                    healthy_names.add(row['source_record'])
            require(len(healthy) == expected_models and set(healthy) == source_keys, 'Source healthy coverage')
            for k in sorted(source_keys):
                _, excluded, arm, seed, fold = k
                stem = f'fold{fold}_{arm}_s{seed}'
                weight = f'results/v6/robustness/{stem}.pt' if cohort == 'v6' else f'results/v7/lofo/{excluded}_{stem}.pt'
                require(weight in design_weights, 'Source-fold weight missing from target design')
                actual_sha = digest(z.read(weight))
                require(actual_sha == design_weights[weight], 'Frozen weight hash mismatch')
                weights.append(dict(zip(KEYS, k)) | {'weight_member': weight, 'sha256': actual_sha})
            # Labels are validation/scoring metadata, never aggregation keys.
            labels, conditions, file_seen = {}, defaultdict(list), set()
            for row in target_rows:
                k = key(row, cohort)
                require(k in healthy, 'Target model is absent from source table')
                require(row['timing'] in TIMINGS, 'Unexpected timing')
                bid, cond, file_id = row['bearing_id'], row['condition'], row['file_id']
                label = int(row['label'])
                require(bid not in labels or labels[bid] == label, 'Inconsistent bearing labels')
                labels[bid] = label
                ck = k + (row['timing'], bid, cond)
                fk = ck + (file_id,)
                require(fk not in file_seen, 'Duplicate target measurement')
                file_seen.add(fk)
                conditions[ck].append(probs(row))
            require(Counter(labels.values()) == {0: 3, 1: 3, 2: 3}, 'Expected three bearings per class')
            grouped = defaultdict(list)
            for ck, pp in conditions.items():
                require(len(pp) in (3, 4), 'Unexpected selected measurements in condition')
                grouped[ck[:-1]].append(mean(pp))
            target_healthy = defaultdict(list)
            all_target = defaultdict(list)
            for bk, pp in sorted(grouped.items()):
                require(len(pp) == 4, 'Missing operating condition')
                k, timing, bid = bk[:-2], bk[-2], bk[-1]
                p = mean(pp)
                norm = sum(p)
                p = tuple(v / norm for v in p)
                lab = labels[bid]
                row = dict(zip(KEYS, k)) | {'timing': timing, 'bearing_id': bid, 'label': lab, **dict(zip(PCOLS, p)), 'predicted_label': prediction(p)}
                bearings.append(row)
                all_target[k+(timing,)].append(row)
                if lab == 0:
                    target_healthy[k+(timing,)].append(row)
            require(len(target_healthy) == expected_models*2, 'Incomplete model/timing target coverage')
            weightmap = {tuple(r[k] for k in KEYS): r for r in weights}
            for k in sorted(healthy):
                name, sp = healthy[k]
                for timing in TIMINGS:
                    ht = target_healthy[k+(timing,)]
                    require(len(ht) == 3 and len(all_target[k+(timing,)]) == 9, 'Wrong target denominator')
                    paired.append(dict(zip(KEYS, k)) | {'timing': timing, 'source_record': name, 'source_healthy_correct': int(prediction(sp)==0), 'source_healthy_total': 1, 'source_p_H': sp[0], 'source_p_I': sp[1], 'source_p_O': sp[2], 'target_healthy_correct': sum(r['predicted_label']==0 for r in ht), 'target_healthy_total': 3, 'weight_member': weightmap[k]['weight_member'], 'weight_sha256': weightmap[k]['sha256']})
    require(len(paired)==360 and len(bearings)==3240 and len(weights)==180, 'Unexpected output coverage')
    by_policy = defaultdict(list)
    for row in paired:
        by_policy[tuple(row[k] for k in KEYS[:3])].append(row)
    policy_rows = []
    for k, rows in sorted(by_policy.items()):
        nominal = [r for r in rows if r['timing']=='nominal']
        require(len(nominal)==15, 'Policy network count')
        pr = dict(zip(KEYS[:3], k)) | {'source_healthy_correct_network_evaluations':sum(r['source_healthy_correct'] for r in nominal),'source_network_evaluations':15}
        for seed in (11,22,33):
            subset=[r for r in nominal if r['seed']==seed]
            require(len(subset)==5, 'Policy seed fold count')
            pr[f'source_seed{seed}_correct_of5']=sum(r['source_healthy_correct'] for r in subset)
        for timing in TIMINGS:
            subset=[r for r in rows if r['timing']==timing]
            pr[f'{timing}_networks_with_zero_of3']=sum(r['target_healthy_correct']==0 for r in subset)
            pr[f'{timing}_min_correct_of3']=min(r['target_healthy_correct'] for r in subset)
            pr[f'{timing}_max_correct_of3']=max(r['target_healthy_correct'] for r in subset)
        policy_rows.append(pr)
    save_csv(output/'paired_checkpoint_health.csv', paired)
    save_csv(output/'single_checkpoint_target_bearings.csv', bearings)
    save_csv(output/'policy_summary.csv', policy_rows)
    save_csv(output/'checkpoint_manifest.csv', weights)
    report = {
        'status':'PASS', 'scope':'Post hoc saved-prediction pairing; no new inference or retraining',
        'archive':str(archive.resolve()),'archive_sha256':file_sha(archive),'input_files':inputs,
        'source_healthy_records':sorted(healthy_names),'selected_weight_hashes_checked':len(weights),
        'policy_count':len(policy_rows),'checkpoint_count':180,'timing_count':2,
        'source_correct_network_evaluations':sum(r['source_healthy_correct'] for r in paired if r['timing']=='nominal'),
        'target_correct_repeated_network_bearing_decisions':sum(r['target_healthy_correct'] for r in paired),
        'target_repeated_network_bearing_decisions':1080,
        'target_independent_healthy_bearings':3,
        'all_individual_networks_miss_all_target_healthy':all(r['target_healthy_correct']==0 for r in paired),
        'no_ensemble_averaging':True,'labels_excluded_from_target_aggregation_keys':True,
        'limitations':['Source healthy acquisitions reuse a bearing; source condition holdout is not specimen holdout.','180 networks and 1080 target decisions are repeated evaluations, not independent physical samples.','Manufacturer, specimen, acquisition, operation, duration and aggregation differences remain.','This does not identify a causal transfer effect or test the predictive relationship for unseen-specimen generalization.','Outcomes and the preliminary diagnostic were already known; no confirmatory or inferential claim.'],
        'outputs':{p.name:{'sha256':file_sha(p),'bytes':p.stat().st_size} for p in sorted(output.glob('*.csv'))},
    }
    (output/'report.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['status','checkpoint_count','source_correct_network_evaluations','target_correct_repeated_network_bearing_decisions','all_individual_networks_miss_all_target_healthy']},indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    run(args.archive,args.output)
