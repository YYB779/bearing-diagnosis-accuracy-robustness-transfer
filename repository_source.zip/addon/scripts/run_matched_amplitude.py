"""Post hoc matched WDCNN normalization experiment; immutable plan before fitting."""
from pathlib import Path
import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:
    os.environ.setdefault(k,'2')
import argparse, copy, hashlib, io, json, sys, time, zipfile
from datetime import datetime, timezone
import numpy as np
import pandas as pd
import torch
from torch.nn import functional as TF

CLI=argparse.ArgumentParser(description=__doc__)
CLI.add_argument('--project',type=Path,required=True)
CLI.add_argument('--patches',type=Path,required=True)
CLI.add_argument('--archive',type=Path,required=True)
CLI.add_argument('--output-dir',type=Path,required=True)
CLI.add_argument('--first-only',action='store_true')
ARGS=CLI.parse_args()
REPO=ARGS.project.resolve();PATCHES=ARGS.patches.resolve();ARCHIVE=ARGS.archive.resolve();OUT=ARGS.output_dir.resolve()
assert not OUT.is_relative_to(REPO), 'Use a new output directory outside the base extraction'
OUT.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(REPO))
from scripts.v5.classbd_models import ClassBDWDCNN
from scripts.v5.run_classbd_extension import balanced_batch_indices
from scripts.v5.prepare_neural_patches import zscore_patch
from scripts.v6.consistency import three_view_jsd, add_noise
from scripts.v4_external_common import aggregate, metrics
COND=['20Hz','30Hz','40Hz','60Hz','VS_0_40_0Hz']
SEEDS=[11,22,33]
ARMS=['patch_rms','training_rms']
STEPS=480
CHECKS=[120,240,360,480]

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ash(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
def statehash(s):
    h=hashlib.sha256()
    for k,v in sorted(s.items()):h.update(k.encode());h.update(v.cpu().numpy().tobytes())
    return h.hexdigest()
def normalize(x,arm,scale):
    x=np.asarray(x,np.float32)
    if arm=='patch_rms':return zscore_patch(x)
    return (x-x.mean(-1,keepdims=True))/np.float32(scale)

def evaluate(model,signals,frame,indices,arm,scale):
    model.eval();parts=[]
    with torch.no_grad():
        for i in range(0,len(indices),48):
            batch=torch.from_numpy(normalize(signals[indices[i:i+48]],arm,scale)[:,None,:])
            parts.append(torch.softmax(model(batch)['logits'],1).numpy().astype(np.float64))
    p=np.concatenate(parts);sf=frame.iloc[indices]
    names,y,pr=aggregate(p,sf.class_id.to_numpy(int),sf.source_record.to_numpy())
    pr/=pr.sum(1,keepdims=True)
    return metrics(y,pr),names,y,pr

def main(first_only):
    torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    xp=PATCHES
    lp=REPO/'data/processed/v5/hust_neural_patch_lineage.csv'
    xa=np.load(xp,allow_pickle=False);x=xa['x'];frame=pd.read_csv(lp)
    assert x.shape==(672,2048) and x.dtype==np.float32 and np.isfinite(x).all()
    assert np.array_equal(xa['patch_id'],frame.patch_id.to_numpy(str))
    assert sha(xp)=='d56ba26bde4c48d4ec9a45c3447cf332a96772474a882ce9a18235b009cfa737'
    raw_report=xp.parent/'raw_regeneration_result.json'
    bridge={'patches':str(xp),'patch_sha256':sha(xp),'matches_frozen_patch_digest':True,
            'scope':'Exact input-byte equivalence; original-source regeneration is established only by its separately recorded report.'}
    if raw_report.is_file():
        rr=json.loads(raw_report.read_text(encoding='utf-8'))
        assert rr['status']=='PASS' and rr['source_files_verified']==21
        assert rr['outputs']['hust_neural_patches.npz']['sha256']==sha(xp)
        bridge.update(raw_report=str(raw_report),raw_report_sha256=sha(raw_report),source_regeneration_verified=True)
    else:
        bridge['source_regeneration_verified']=False
    save(OUT/'RAW_INPUT_EQUIVALENCE.json',bridge)
    frame['domain_id']=frame.condition.map(dict(zip(COND,range(5))))
    paths=[xp,lp,Path(__file__)]+[REPO/q for q in ['scripts/v5/classbd_models.py','scripts/v5/run_classbd_extension.py','scripts/v5/prepare_neural_patches.py','scripts/v6/consistency.py','scripts/v4_external_common.py']]
    plan={'created_utc':datetime.now(timezone.utc).isoformat(),'status':'retrospective exploratory design; old test results and normalization concerns known; training_rms arm unrun before this plan',
          'question':'Within the same WDCNN, does retaining centered patch amplitude change condition-held-out clean discrimination under matched training and clean-only model selection?',
          'arms':{'patch_rms':'subtract each patch float32 mean; divide its population RMS (floor1e-8), exactly historical zscore_patch',
                  'training_rms':'subtract the same each-patch float32 mean; divide a single scalar sqrt(mean(centered_training_patches.astype(float64)**2)), cast scalar float32; validation and test reuse train scalar'},
          'normalizer_fit':'only fitting patch indices; all fitting patches equally weighted; never validation/test values; both arms remove patch DC',
          'input':{'shape':[672,2048],'dtype':'float32','source_records':21,'patches_per_record':32,'fs_hz':25600,'crop_seconds':.08},
          'split':'test condition i; validation i+1 modulo5; other three conditions fit; reuse existing lineage',
          'seeds':SEEDS,'folds':list(range(5)),'arms_order':ARMS,'model':'archived adapted ClassBDWDCNN baseline, 66083parameters; architecture unchanged',
          'optimizer':{'name':'AdamW','lr':.001,'weight_decay':.0001,'cosine_T_max':480,'gradient_clip':10},
          'updates':STEPS,'checkpoints':CHECKS,'batch':{'source_patches':18,'views':3,'forward_presentations':25920,'sampling':'same balanced_batch_indices; numpy seed+1000*fold; same exact indices across arms'},
          'loss':'historical CE+0*three_view_jsd; three identical clean normalized views, independent dropout per presentation',
          'initialization':'torch.manual_seed(seed) separately reset before each arm; equal initial state and dropout random stream',
          'formal_selection':'clean validation file macroF1, lower clean file NLL, earlier update; no train+validation refit',
          'historical_shadow':'baseline also evaluates fixed +6dB seed6606 validation at all4 checkpoints only to audit old clean+AWGN selection; not used in new clean-only selection; all4 checkpoints archived',
          'primary_endpoints':['OOF21-file macroF1','healthy recall','NLL'],'secondary':['class recalls','multiclass Brier','each-fold results','seed-paired training_rms minus patch_rms'],
          'inference':'float64 mean of 32 softmax patch predictions per file, roundoff renormalization, no calibration',
          'statistics':'all3 seeds reported; no p-values or confidence intervals; seeds and patches are not physical specimen replicates',
          'planned_fits':30,'planned_checkpoints':120,'stop_rules':'nonfinite values, source/lineage mismatch or unreconciled baseline training mismatch; no test-driven hyperparameter changes',
          'limitations':['same21 previously observed acquisitions with same-state bearing reuse','no new specimens/noise','post hoc, not confirmatory','normalization intervention within one architecture does not establish pure architecture superiority','BatchNorm and optimizer may mediate effects; no universal normalization ranking'],
          'inputs_and_code_sha256':{str(p):sha(p) for p in paths},
          'software':{'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'torch':torch.__version__,'cpu_threads':2,'interop_threads':1,'deterministic_algorithms':True}}
    planfile=OUT/'analysis_plan.json'
    if planfile.exists():
        existing=json.loads(planfile.read_text(encoding='utf-8'));plan['created_utc']=existing['created_utc'];assert existing==plan,'Frozen analysis plan mismatch'
    else:
        save(planfile,plan)
        (OUT/'analysis_plan.md').write_text('# Matched amplitude-retention experiment\n\nPlan frozen before new fitting. Retrospective, exploratory; old results known.\n\nTwo arms share 480 updates, architecture, seeds, folds, initialization, source batches, optimizer, clean-only selection and DC removal. Only denominator differs: per-patch RMS versus one fitting-only RMS. All 30 fits and 120 checkpoints are retained, with no outcome-based tuning. The old robust-validation selection is a separate baseline audit, not the new experiment.\n\nPrimary endpoint: paired OOF file macro-F1, healthy recall and NLL across all three seeds. No population inferential test. No claim of additional independent specimens. Exact parameters and SHA-256 records are in analysis_plan.json.\n',encoding='utf-8')
    oldnoise=add_noise(x,np.random.default_rng(6606).normal(size=x.shape),6).astype(np.float32)
    for fold in range(5):
        ti=np.flatnonzero(frame.domain_id.ne(fold)&frame.domain_id.ne((fold+1)%5));vi=np.flatnonzero(frame.domain_id.eq((fold+1)%5));ei=np.flatnonzero(frame.domain_id.eq(fold))
        for aa,bb in [(ti,vi),(ti,ei),(vi,ei)]:assert not set(frame.iloc[aa].source_record)&set(frame.iloc[bb].source_record)
        centered=x[ti]-x[ti].mean(-1,keepdims=True)
        scale=float(np.sqrt(np.mean(centered.astype(np.float64)**2)));assert scale>1e-8
        domains=sorted(frame.iloc[ti].domain_id.unique().tolist())
        for seed in SEEDS:
            if first_only and (fold,seed)!=(0,11):continue
            rng=np.random.default_rng(seed+1000*fold)
            batches=[balanced_batch_indices(frame,ti,domains,rng) for _ in range(STEPS)]
            split={'fold':fold,'seed':seed,'training_records':sorted(frame.iloc[ti].source_record.unique()),'validation_records':sorted(frame.iloc[vi].source_record.unique()),'test_records':sorted(frame.iloc[ei].source_record.unique()),'training_indices':ti.tolist(),'validation_indices':vi.tolist(),'test_indices':ei.tolist(),'training_rms':scale,'training_rms_float32':float(np.float32(scale)),'batch_sha256':ash(np.stack(batches)),'batches':np.stack(batches).tolist()}
            sp=OUT/f'fold{fold}_seed{seed}_split.json'
            if sp.exists():assert json.loads(sp.read_text())==split
            else:save(sp,split)
            for arm in (['patch_rms'] if first_only else ARMS):
                run=OUT/f'fold{fold}_seed{seed}_{arm}';run.mkdir(exist_ok=True)
                if (run/'result.json').exists():continue
                started=time.perf_counter();torch.manual_seed(seed);model=ClassBDWDCNN(variant='baseline')
                initial=statehash(model.state_dict());opt=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001);sched=torch.optim.lr_scheduler.CosineAnnealingLR(opt,T_max=STEPS)
                history=[];states={};best=(-1.,-np.inf);chosen=None
                old=json.loads((REPO/f'results/v6/robustness/fold{fold}_clean_ce_s{seed}.json').read_text()) if arm=='patch_rms' else None
                for step,idx in enumerate(batches,1):
                    model.train();opt.zero_grad(set_to_none=True)
                    normalized=normalize(x[idx],arm,scale);views=np.stack([normalized,normalized,normalized])
                    batch=torch.from_numpy(views.reshape(-1,2048)[:,None,:]);target=torch.from_numpy(frame.iloc[idx].class_id.to_numpy(np.int64))
                    logits=model(batch)['logits'].reshape(3,len(idx),3)
                    ce=TF.cross_entropy(logits.reshape(-1,3),target.repeat(3));jsd=three_view_jsd(logits);loss=ce+0.*jsd
                    assert torch.isfinite(loss)
                    loss.backward();gn=torch.nn.utils.clip_grad_norm_(model.parameters(),10.);assert torch.isfinite(gn)
                    opt.step();sched.step()
                    if step in CHECKS:
                        vm,_,_,_=evaluate(model,x,frame,vi,arm,scale)
                        row={'update':step,'train_loss':float(loss.detach()),'train_ce':float(ce.detach()),'train_jsd':float(jsd.detach()),'gradient_norm_before_clip':float(gn),'clean_validation':vm}
                        if arm=='patch_rms':
                            nm,_,_,_=evaluate(model,oldnoise,frame,vi,arm,scale);row['old_awgn6_validation']=nm
                        history.append(row);states[step]=copy.deepcopy(model.state_dict())
                        torch.save({'model_state':states[step],'fold':fold,'seed':seed,'arm':arm,'update':step,'normalization_rms':scale,'analysis_plan_sha256':sha(planfile)},run/f'checkpoint_{step}.pt')
                        key=(vm['macro_f1'],-vm['nll'])
                        if key>best:best=key;chosen=step
                audit=None
                if arm=='patch_rms':
                    diffs=[]
                    for nr,orr in zip(history,old['history']):
                        assert nr['update']==orr['update']
                        for key in ['train_loss','train_ce','train_jsd','gradient_norm_before_clip']:diffs.append(abs(nr[key]-orr[key]))
                        for key in ['macro_f1','nll','recall_H','recall_I','recall_O','multiclass_brier']:
                            diffs += [abs(nr['clean_validation'][key]-orr['validation']['clean'][key]),abs(nr['old_awgn6_validation'][key]-orr['validation']['AWGN6dB'][key])]
                    shadow=min(history,key=lambda h:(-np.mean([h['clean_validation']['macro_f1'],h['old_awgn6_validation']['macro_f1']]),np.mean([h['clean_validation']['nll'],h['old_awgn6_validation']['nll']]),h['update']))['update']
                    with zipfile.ZipFile(ARCHIVE) as z:oldstate=torch.load(io.BytesIO(z.read(f'results/v6/robustness/fold{fold}_clean_ce_s{seed}.pt')),map_location='cpu',weights_only=False)['model_state']
                    equal=all(torch.equal(states[shadow][k],oldstate[k]) for k in oldstate)
                    audit={'max_history_absolute_difference':max(diffs),'historical_selected_update':old['selected_update'],'shadow_selected_update':shadow,'historical_state_exact_equal':equal,'historical_state_sha256':statehash(oldstate),'new_shadow_state_sha256':statehash(states[shadow])}
                    save(run/'historical_training_audit.json',audit)
                    if max(diffs)>1e-10 or shadow!=old['selected_update'] or not equal:raise RuntimeError('Historical baseline mismatch; preserve run and diagnose before continuation: '+str(audit))
                model.load_state_dict(states[chosen]);tm,names,y,pr=evaluate(model,x,frame,ei,arm,scale)
                rows=[{'fold':fold,'seed':seed,'arm':arm,'selected_update':chosen,'source_record':n,'class_id':int(t),'p_H':float(p[0]),'p_I':float(p[1]),'p_O':float(p[2])} for n,t,p in zip(names,y,pr)]
                pd.DataFrame(rows).to_csv(run/'test_predictions.csv',index=False)
                # Arithmetic check independent of sklearn macro-F1 implementation.
                cm=np.zeros((3,3),int)
                for yy,pp in zip(y,pr.argmax(1)):cm[yy,pp]+=1
                manual=np.mean([2*cm[k,k]/(cm[k].sum()+cm[:,k].sum()) if cm[k].sum()+cm[:,k].sum() else 0 for k in range(3)])
                assert abs(manual-tm['macro_f1'])<1e-12
                result={'fold':fold,'seed':seed,'arm':arm,'selected_update':chosen,'selection_rule':'clean-only file macroF1/lowerNLL/earlierupdate','training_rms':scale,'initial_state_sha256':initial,'batch_sha256':split['batch_sha256'],'history':history,'test':tm,'seconds':time.perf_counter()-started,'parameter_count':sum(p.numel() for p in model.parameters()),'plan_sha256':sha(planfile),'historical_training_audit':audit}
                save(run/'result.json',result)
                print(json.dumps({'fold':fold,'seed':seed,'arm':arm,'seconds':result['seconds'],'selected_update':chosen,'test_macro_f1':tm['macro_f1'],'historical_equal':audit['historical_state_exact_equal'] if audit else None}),flush=True)
    if first_only:return
    allpred=pd.concat([pd.read_csv(OUT/f'fold{f}_seed{s}_{a}/test_predictions.csv') for f in range(5) for s in SEEDS for a in ARMS],ignore_index=True)
    allpred.to_csv(OUT/'record_predictions.csv',index=False)
    summary=[]
    for (seed,arm),q in allpred.groupby(['seed','arm']):
        assert len(q)==21 and q.source_record.nunique()==21
        summary.append({'seed':int(seed),'arm':arm,**metrics(q.class_id.to_numpy(),q[['p_H','p_I','p_O']].to_numpy())})
    save(OUT/'pooled_summary.json',summary)
    simple=pd.DataFrame([{k:v for k,v in r.items() if k!='confusion_matrix'} for r in summary]);simple.to_csv(OUT/'pooled_summary.csv',index=False)
    contrasts=[]
    for seed in SEEDS:
        left=next(r for r in summary if r['seed']==seed and r['arm']=='patch_rms');right=next(r for r in summary if r['seed']==seed and r['arm']=='training_rms')
        contrasts.append({'seed':seed,**{k:right[k]-left[k] for k in ['macro_f1','nll','recall_H','recall_I','recall_O','multiclass_brier']}})
    pd.DataFrame(contrasts).to_csv(OUT/'paired_seed_contrasts.csv',index=False)
    save(OUT/'completion.json',{'status':'completed','fits':30,'checkpoints':120,'record_predictions':len(allpred),'pairing':'same fold, seed, training indices, architecture and initialization','old_baseline_matches':15,'plan_sha256':sha(planfile),'paired_seed_contrasts':contrasts,'limits':plan['limitations']})
    print('COMPLETED 30 fits and 120 checkpoints',flush=True)

if __name__=='__main__':
    main(ARGS.first_only)
