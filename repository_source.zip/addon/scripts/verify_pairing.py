"""Independent weighted-sum check of newly paired saved-prediction outputs.

Requires pandas and numpy. It never invokes the primary pairing implementation.
"""
import argparse
import io
import json
from pathlib import Path
from zipfile import ZipFile
import numpy as np
import pandas as pd

def run(archive, output):
    pc=['p_H','p_I','p_O']
    keys=['cohort','excluded','arm','seed','fold','timing','bearing_id']
    actual=pd.read_csv(output/'single_checkpoint_target_bearings.csv')
    pairs=pd.read_csv(output/'paired_checkpoint_health.csv')
    maximum=0.0
    ensemble_maximum=0.0
    checked=0
    source_correct=0
    with ZipFile(archive) as z:
        for cohort in ['v6','v7']:
            r=pd.read_csv(io.BytesIO(z.read(f'results/v7/zero_shot/{cohort}/fold_record_predictions.csv')))
            # Independent route: each input measurement receives a weight
            # 1/(four conditions * measurements in that particular condition).
            r['weight']=1/(4*r.groupby(keys+['condition'])['file_id'].transform('size'))
            r[pc]=r[pc].mul(r.weight,axis=0)
            expected=r.groupby(keys)[pc].sum()
            expected=expected.div(expected.sum(axis=1),axis=0).sort_index()
            got=actual[actual.cohort.eq(cohort)].set_index(keys)[pc].sort_index()
            assert expected.index.equals(got.index)
            diff=float(np.abs(expected.to_numpy()-got.to_numpy()).max())
            maximum=max(maximum,diff)
            assert diff<1e-12
            checked+=len(got)
            # Recombining the newly derived single-network probabilities must
            # recover the old five-network ensemble, within float rounding.
            ek=[k for k in keys if k!='fold']
            ens=got.reset_index().groupby(ek)[pc].mean()
            old=pd.read_csv(io.BytesIO(z.read(f'results/v7/zero_shot/{cohort}/bearing_predictions.csv'))).set_index(ek)[pc]
            ens=ens.loc[old.index]
            diff2=float(np.abs(ens.to_numpy()-old.to_numpy()).max())
            ensemble_maximum=max(ensemble_maximum,diff2)
            assert diff2<1e-12
            s=pd.read_csv(io.BytesIO(z.read(f'results/{cohort}/analysis/record_predictions.csv')))
            s=s[s.panel.eq('clean')&s.label.eq(0)].copy()
            s['predicted']=s[pc].to_numpy().argmax(1)
            source_correct+=int(s.predicted.eq(0).sum())
            sk=['excluded','arm','seed','fold']
            if 'excluded' not in s:s['excluded']='none'
            original=s.set_index(sk).sort_index()
            for timing in ['nominal','timestamp_sensitive']:
                gotp=pairs[pairs.cohort.eq(cohort)&pairs.timing.eq(timing)].set_index(sk).sort_index()
                assert original.index.equals(gotp.index)
                assert original.source_record.equals(gotp.source_record)
                assert np.array_equal(original.predicted.eq(0).astype(int),gotp.source_healthy_correct)
    result={'status':'PASS','independent_probability_vectors':checked,'maximum_absolute_difference_direct_weighted_sum':maximum,'maximum_absolute_difference_recombined_archived_ensemble':ensemble_maximum,'source_correct_network_evaluations':source_correct,'scope':'Independent weighted-sum aggregation and source-row pairing checks; no training or inference.'}
    (output/'independent_check.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--archive',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    run(a.archive,a.output)
