"""Metadata regression only: no download, array extraction or training."""
from pathlib import Path
from types import SimpleNamespace
import ast,json,hashlib
root=Path(__file__).resolve().parents[1]
script=root/'scripts/rebuild_novic_raw.py'
tree=ast.parse(script.read_text(encoding='utf-8'))
function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='describe_raw_storage')
namespace={}
exec(compile(ast.Module(body=[function],type_ignores=[]),'<actual-storage-helper>','exec'),namespace)
expression=next(v for n in ast.walk(tree) if isinstance(n,ast.Dict) for k,v in zip(n.keys,n.values) if isinstance(k,ast.Constant) and k.value=='raw_storage')
checks=[]
for cache in [None,Path('synthetic-existing-source.npy')]:
    namespace['args']=SimpleNamespace(cached_raw=cache)
    value=eval(compile(ast.Expression(body=expression),'<actual-report-field>','eval'),namespace)
    assert 'MD5' in value and 'SHA256' in value and 'unchanged v3 extractor' in value
    if cache is None:
        assert 'consumed in RAM' in value and 'No full tensor is saved to disk by this run.' in value
    else:
        assert 'remains on disk unchanged' in value and 'read-only memory mapping' in value
        assert 'No duplicate full tensor' in value and 'consumed in RAM' not in value
    checks.append({'branch':'ram_download' if cache is None else 'cached_readonly_mmap','raw_storage':value,'pass':True})
print(json.dumps({'status':'PASS','script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'checks':checks,'scope':'Actual helper and report expression evaluated with synthetic branch selectors only; zero downloads, signal calculations and training.'},ensure_ascii=False))
